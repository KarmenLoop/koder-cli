// Application-only runtime under the original KARMEN LOOP process supervisor.
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {appScope,scopeIdentity} from '../fusion/app-profile.mjs';
import {createStorageClient} from './storage-client.mjs';
import {createAppConnections} from './app-connections.mjs';
import {createMcpAuthStore} from '../fusion/mcp-auth-store.mjs';
import {createMcpOAuth} from '../fusion/mcp-oauth.mjs';
import {createMcpRoutes} from '../fusion/mcp-routes.mjs';
import {appDigest} from '../fusion/app-binding.mjs';
import {effectFinish} from '../agent/kernel/ledger.mjs';
import {createAppConnect,createGammaProvider} from '../fusion/app-connect.mjs';
import {createProtectedContext,parkToolOutput,readContext} from './context-keep.mjs';
import {createConnectionMigrationStore} from '../fusion/app-migration.mjs';

async function readBody(req) {
  const chunks=[];let size=0;
  const limit=req.url==='/internal/shared-apps/artifacts'?12*1024*1024:1_000_000;
  for await(const chunk of req){size+=chunk.length;if(size>limit)throw Object.assign(new Error('请求过大'),{status:413});chunks.push(chunk);}
  return size?JSON.parse(Buffer.concat(chunks).toString('utf8')):{};
}
export async function startConnectionRuntime({dataDir,services,scope,ownerGeneration=null,initialClient=null,initialClients=null,onClientsChange=async()=>{},onEvent=()=>{},onIdle=()=>{},workbenchToken=process.env.KODER_WORKBENCH_TOKEN,oauthFactory=createMcpOAuth,gammaFactory=createAppConnect}) {
  const storage=createStorageClient({worker:services.worker('storage'),dir:dataDir});
  const migration=createConnectionMigrationStore({dir:dataDir,storage});await migration.recover();
  let gamma=gammaFactory({dir:dataDir,storage,scope});
  const makeApps=()=>createAppConnections({storage,worker:services.worker('mcp'),file:path.join(dataDir,'loop/mcp.json'),currentScope:()=>scope,applications:[createGammaProvider(gamma)],onChange:event=>onEvent(`data: ${JSON.stringify({type:'apps',...event})}\n\n`)});
  let apps=await makeApps(),used=false,migrating=false;
  let boot;
  const connectSaved=()=>boot||=(async()=>{for(const entry of apps.state.servers)if(entry.enabled)await apps.connect(entry);})();
  const oauth=await oauthFactory({dir:dataDir,scope,authStore:createMcpAuthStore({dir:dataDir,storage})});
  // Management uses the same service directly, not an HTTP call back into its
  // own pending discovery. This avoids a bootstrap authorization deadlock.
  const localKernel={async call(method,url,body){
    try {
      if(method==='GET'&&url==='/api/mcp')return {status:200,json:{servers:apps.list()}};
      if(method==='POST'&&url==='/api/mcp')return {status:200,json:{server:await apps.add(body)}};
      const id=/^\/api\/mcp\/([a-f0-9-]{36})$/.exec(url)?.[1];
      if(id&&method==='PATCH')return {status:200,json:{server:await apps.update(id,body)}};
      throw Object.assign(new Error('无效 MCP 管理操作'),{status:404});
    }catch(error){return {status:error.status||500,json:{code:error.code,error:error.message}};}
  }};
  const mcpRoutes=await createMcpRoutes({dir:dataDir,kernel:localKernel,workbenchToken,oauth});
  const effectLanes=new Map();
  const contexts=new Map();
  const effectFile=id=>{if(!/^[a-f0-9-]{36}$/.test(id))throw Object.assign(new Error('任务身份无效'),{status:400,code:'APP_TASK_INVALID'});return path.join(dataDir,'app-effects',id+'.json');};
  const readEffects=id=>storage.readJson(effectFile(id),{version:1,revision:0,rows:{}});
  const changeEffects=(id,change)=>{
    const job=(effectLanes.get(id)||Promise.resolve()).then(async()=>{const record=await readEffects(id);const value=await change(record);record.revision++;await storage.writeJson(effectFile(id),record);return value??record;});
    effectLanes.set(id,job.catch(()=>{}));return job;
  };
  let closed=false,idle=false,idleTimer,erasing=false,activeRequests=0;
  const clients=new Map();
  const publishClients=()=>onClientsChange([...clients.values()]);
  async function acquire(client,{publish=true}={}) {
    if(idle||closed||erasing)throw Object.assign(new Error('应用宿主正在关闭，请稍后重连'),{status:409,code:'APP_STOPPING'});
    const bound=appScope(client.scope);
    if(scopeIdentity(bound)!==scopeIdentity(scope)||client.host!==os.hostname()||!Number.isSafeInteger(client.pid)||client.pid<=0||typeof client.id!=='string'||!/^[a-f0-9-]{36}$/.test(client.id))throw Object.assign(new Error('应用客户端归属不匹配'),{status:409,code:'APP_CONNECTION_CHANGED'});
    process.kill(client.pid,0);
    const existing=clients.get(client.id);
    if(existing&&JSON.stringify(existing)!==JSON.stringify({...client,scope:bound}))throw Object.assign(new Error('应用客户端已变化'),{status:409,code:'APP_CONNECTION_CHANGED'});
    if(!existing&&clients.size>=1024)throw Object.assign(new Error('应用客户端数量已达上限'),{status:409,code:'APP_CLIENT_LIMIT'});
    clients.set(client.id,{...client,scope:bound});if(publish)await publishClients();return {clients:clients.size,generation:ownerGeneration};
  }
  function stopIfIdle() {if(!clients.size&&!idle){idle=true;idleTimer=setTimeout(onIdle,30);}}
  for(const client of initialClients??(initialClient?[initialClient]:[])){
    try{await acquire(client,{publish:false});}catch(error){if(error.code!=='ESRCH')throw error;}
  }
  if(ownerGeneration)await publishClients();
  const reaper=ownerGeneration?setInterval(()=>{
    let changed=false;
    for(const [id,client]of clients)try{process.kill(client.pid,0);}catch(error){if(error.code==='ESRCH'){clients.delete(id);changed=true;}}
    if(changed)void publishClients().then(stopIfIdle).catch(()=>{});else stopIfIdle();
  },1000):null;
  reaper?.unref();
  async function route(method,url,body,headers,signal) {
    const requestUrl=new URL(url,'http://localhost');url=requestUrl.pathname;
    if(closed)throw Object.assign(new Error('应用连接正在关闭'),{status:503,code:'APP_STOPPING'});
    if(url==='/internal/apps-host/identity'&&method==='GET')return {generation:ownerGeneration,scope};
    if(url==='/internal/apps-host/acquire'&&method==='POST')return acquire(body);
    // Only the original worker's private bridge can obtain authorization
    // headers; browser/CLI management clients never receive this token data.
    if(url==='/api/internal/mcp-headers')return (await mcpRoutes.dispatch(method,requestUrl,body,{signal,internalToken:headers['x-koder-workbench']})).json;
    if(ownerGeneration&&!clients.has(headers['x-koder-app-client']))throw Object.assign(new Error('应用连接已释放或会话已变化'),{status:409,code:'APP_CONNECTION_CHANGED'});
    if(url==='/internal/apps-host/release'&&method==='POST'){
      if(body.id!==headers['x-koder-app-client'])throw Object.assign(new Error('应用客户端归属不匹配'),{status:403,code:'APP_CONNECTION_CHANGED'});
      clients.delete(body.id);await publishClients();stopIfIdle();return {clients:clients.size};
    }
    if(url==='/internal/apps-host/prepare-erase'&&method==='POST'){
      if(clients.size!==1||activeRequests!==1)throw Object.assign(new Error('请关闭其他 CLI／桌面应用连接并等待操作结束，再抹掉数据'),{status:409,code:'APP_ERASE_BUSY'});
      erasing=true;return {prepared:true};
    }
    if(erasing)throw Object.assign(new Error('应用资料正在擦除'),{status:409,code:'APP_STOPPING'});
    if(url==='/internal/shared-apps/migration'&&method==='POST'){
      if(!workbenchToken||body.bridgeToken!==workbenchToken)throw Object.assign(new Error('应用桥凭证无效'),{status:403,code:'APP_BRIDGE_DENIED'});
      if(used||migrating||clients.size>1)throw Object.assign(new Error('迁移需要尚未使用的独占连接宿主，请关闭其他应用连接后重开'),{status:409,code:'APP_MIGRATION_BUSY'});
      migrating=true;
      try{const result=await migration.request(body.action,body);if(result.state==='committed'){await apps.close();await gamma.close();gamma=gammaFactory({dir:dataDir,storage,scope});apps=await makeApps();}return result;}
      finally{migrating=false;}
    }
    if(migrating)throw Object.assign(new Error('应用连接正在迁移，请稍后重试'),{status:409,code:'APP_MIGRATION_BUSY'});
    used=true;
    const managed=await mcpRoutes.dispatch(method,requestUrl,body,{signal});
    if(managed)return managed.json;
    if(url==='/api/apps/connect'&&method==='POST')return mcpRoutes.connectApps.connect(body.app,{signal});
    if(url==='/api/apps/connect'&&method==='DELETE')return mcpRoutes.connectApps.disconnect(body.app);
    if(url==='/api/apps/key'&&method==='POST')return gamma.saveKey({...body,signal});
    if(url==='/api/apps/login'&&method==='POST')return gamma.login({...body,signal});
    if(url==='/api/apps'&&method==='DELETE')return gamma.disconnect(body.app);
    if(url==='/api/apps'&&method==='GET') {
      await connectSaved();
      const servers=apps.list();
      const gammaStatus=await gamma.status(),connected=await mcpRoutes.connectApps.list();
      return {scope:'local-profile',servers,note:gammaStatus.note,apps:[...gammaStatus.apps,...connected.connects]};
    }
    if(url==='/api/mcp'&&method==='GET'){await connectSaved();return {servers:apps.list()};}
    if(url==='/api/mcp'&&method==='POST')return {server:await apps.add(body)};
    const match=/^\/api\/mcp\/([a-f0-9-]{36})$/.exec(url);
    if(match&&method==='PATCH')return {server:await apps.update(match[1],body)};
    if(match&&method==='DELETE')return apps.remove(match[1]);
    const shared=/^\/internal\/shared-apps\/(tools|prepare|validate|call|effects|request|artifacts)$/.exec(url);
    if(shared&&method==='POST'){
      if(!workbenchToken||body.bridgeToken!==workbenchToken)throw Object.assign(new Error('应用桥凭证无效'),{status:403,code:'APP_BRIDGE_DENIED'});
      const current=clients.get(headers['x-koder-app-client'])?.scope||scope;
      const options={scope:current,signal},op=shared[1];
      if(op==='artifacts'){
        effectFile(body.threadId);
        const id=body.action==='put'?'c'+crypto.randomBytes(12).toString('hex'):body.id;
        if(!/^c[a-z0-9]{8,24}$/.test(id||'')||!['put','read'].includes(body.action))throw Object.assign(new Error('应用产物引用无效'),{status:400,code:'APP_ARTIFACT_INVALID'});
        const key=body.threadId+'/'+id;
        if(!contexts.has(key))contexts.set(key,createProtectedContext({storage,dir:path.join(dataDir,'app-results',body.threadId),file:id+'.sqlite'}));
        return contexts.get(key)(db=>{
          if(body.action==='put'){
            if(typeof body.text!=='string'||typeof body.callId!=='string'||body.callId.length>160)throw Object.assign(new Error('应用结果无效'),{status:400});
            parkToolOutput(db,{id,threadId:body.threadId,name:body.callId,text:body.text,parkAt:0,complete:true});return {id};
          }
          return readContext(db,body.threadId,id,body.offset,body.chars);
        });
      }
      if(op==='effects'){
        if(body.action==='load')return readEffects(body.threadId);
        if(body.action!=='save'||!body.rows||Object.keys(body.rows).length>128)throw Object.assign(new Error('应用回执无效'),{status:400,code:'APP_EFFECT_INVALID'});
        return changeEffects(body.threadId,record=>{
          if(record.revision!==body.expectedRevision)throw Object.assign(new Error('应用回执已变化'),{status:409,code:'APP_EFFECT_CONFLICT'});
          for(const [key,row]of Object.entries(body.rows))if(!row?.bound||row.bound.task?.threadId!==body.threadId||key!==row.bound.task.callId||row.effect?.phase!=='started')throw Object.assign(new Error('应用回执无效'),{status:400,code:'APP_EFFECT_INVALID'});
          // Finished/unknown receipts are immutable through the client port.
          for(const [key,row]of Object.entries(record.rows))if(body.rows[key]&&appDigest(row)!==appDigest(body.rows[key]))throw Object.assign(new Error('旧应用回执不可覆盖'),{status:409,code:'APP_EFFECT_CONFLICT'});
          record.rows={...record.rows,...structuredClone(body.rows)};
        });
      }
      await connectSaved();
      if(op==='request')return apps.protocol(body,{signal});
      if(op==='tools')return {scope:current,tools:await apps.refresh({signal})};
      if(op==='prepare')return apps.prepare(body,options);
      if(op==='validate'){await apps.validate(body,options);return {ok:true};}
      await apps.validate(body,options);
      const id=body.task.threadId,key=body.task.callId;
      await changeEffects(id,record=>{
        const row=record.rows[key];
        if(!row||appDigest(row.bound)!==appDigest(Object.fromEntries(Object.entries(body).filter(([k])=>k!=='bridgeToken')))||row.effect?.phase!=='started'||row.dispatched)throw Object.assign(new Error('应用调用已提交或缺少持久回执'),{status:409,code:'APP_EFFECT_UNCONFIRMED'});
        row.dispatched=true;
      });
      let result;
      try{result=await apps.call(body,options);}
      catch(error){const unknown=error.effectsMayHaveCompleted||error.cleanupComplete===false;result={ok:false,state:unknown?'unknown':'failed',notStarted:!unknown,content:[],cleanupComplete:error.cleanupComplete!==false,errorCode:error.code||'APP_CALL_FAILED'};}
      await changeEffects(id,record=>{const row=record.rows[key];const projection={effect:row.effect,seq:row.effect.seq};effectFinish(projection,result.state==='succeeded'?{ok:true}:result.notStarted?{ok:false,notStarted:true}:{ok:false});row.effect=projection.effect;row.result=result;});
      return result;
    }
    throw Object.assign(new Error('没有这个应用操作'),{status:404,code:'APP_ROUTE_NOT_FOUND'});
  }
  return {
    async handle(req) {
      let status=200,body;
      activeRequests++;
      try {body=await route(req.method,req.url,await readBody(req),req.headers||{},req.signal);}
      catch(error){status=error.status||500;body={code:error.code||'APP_FAILED',error:error.message||'应用操作没有完成'};}
      finally{activeRequests--;}
      return {status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'},body:JSON.stringify(body)};
    },
    async close(){closed=true;clearInterval(reaper);clearTimeout(idleTimer);await Promise.all([...contexts.values()].map(value=>value.drain()));const results=await Promise.allSettled([mcpRoutes.close(),apps.close(),gamma.close()]);const cleanupComplete=results.every(r=>r.status==='fulfilled'&&r.value?.cleanupComplete===true);return {ok:cleanupComplete,cleanupComplete};},
  };
}
