// KARMEN LOOP microkernel: admission scheduling, process memory limits and IPC.
// Product rules, model prompts, tasks and persistence live in the runtime process.
import crypto from 'node:crypto';
import http from 'node:http';
import { fork } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createServices, createScheduler, WORKER_NAMES } from './core-services.mjs';
import { sendIpc, wireError, fromError, MAX_FRAME_BYTES } from './core-ipc.mjs';
import { readProcessRss } from './supervisor.mjs';
import {BROWSER_HOST_PATH,browserHostFromEnv,browserHostStatus,validateBrowserHost,browserHostError} from '../fusion/browser-host.mjs';

const MAX_BODY=1_000_000;
function send(res,status,payload){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(payload));}
export async function startLoop({root,dataDir,workspace,port=0,gate='',runtimeRestartLimit=3,runtimeRestartDelayMs=200,runtimeRssLimit=768*1024*1024,serviceModules={},runtimeKind="product",scope=null,ownerGeneration=null,initialClient=null,signal,onClosed=async()=>{}}) {
  if(!['product','connections'].includes(runtimeKind))throw new Error('未知运行配置');
  const serviceEnv={...process.env,KODER_ROOT:root,KODER_DATA:dataDir,KODER_WORKSPACE:workspace,KODER_RUNTIME_KIND:runtimeKind};
  const services=createServices({env:serviceEnv,modules:serviceModules,runtimeKind}),scheduler=createScheduler(2),clients=new Set(),requests=new Map(),calls=new Map();
  let child=null,epoch='',sequence=0,state='starting',closing=false,closingPromise,restartTimer,restarts=0,lastError=null,lastReceipt=null,rssBytes=null,rssTimer,initial=true,launched=false;
  let browserHost=browserHostFromEnv(process.env),browserRevision=0,browserTail=Promise.resolve();
  // The Core outlives its runtime child. Retain acknowledged client leases,
  // including releases; the original launch client is not a restart snapshot.
  let connectionClients=initialClient?[structuredClone(initialClient)]:[];
  let readyResolve,readyReject;
  const ready=new Promise((resolve,reject)=>{readyResolve=resolve;readyReject=reject;});
  const runtimeFile=fileURLToPath(new URL(runtimeKind==='connections'?'./connection-entry.mjs':'./runtime-entry.mjs',import.meta.url));
  const post=message=>sendIpc(child,{...message,epoch});
  const infos=()=>[...services.values()].map(worker=>worker.info());
  const health=()=>({ok:state==='ready',engine:'karmen-loop',core:['schedule','memory','ipc'],corePid:process.pid,runtime:{pid:child?.pid??null,state,restarts,rssBytes,error:lastError},scheduler:scheduler.info(),workers:infos(),services:[...services.values()].map(s=>s.info()),port:server.address()?.port});
  function failRequests(error){for(const [id,item]of requests){clearTimeout(item.timer);item.reject(error);requests.delete(id);}}
  async function stopServices(){for(const item of calls.values())item.controller.abort();const results=await Promise.allSettled([...services.values()].map(service=>service.stop()));scheduler.clear();return results.map((result,index)=>({name:[...services.keys()][index],...(result.status==='fulfilled'?result.value:{ok:false,cleanupComplete:false,error:result.reason?.message})}));}
  function output(frame){for(const client of clients){if(client.destroyed){clients.delete(client);continue;}if(client.writableLength>MAX_FRAME_BYTES){client.destroy();clients.delete(client);}else client.write(frame);}}
  async function service(message,proc,generation){
    if(!Number.isSafeInteger(message.id)||message.id<=0||calls.has(`${generation}:${message.id}`))return;
    const key=`${generation}:${message.id}`,controller=new AbortController();calls.set(key,{controller,proc});
    const reply=body=>sendIpc(proc,{type:'service-result',epoch:generation,id:message.id,...body});
    try{
      let result,info;
      if(message.service==='$schedule'){
        const token=String(message.payload?.token||'');if(!token||token.length>128)throw new Error('无效调度标识');
        if(message.action==='acquire')result=await scheduler.acquire(`${generation}:${token}`);
        else if(message.action==='release'){scheduler.release(`${generation}:${token}`);result=true;}
        else throw new Error('未知调度操作');
      }else{
        const worker=services.get(message.service);if(!worker)throw Object.assign(new Error('未注册服务'),{code:'UNKNOWN_SERVICE'});
        if(message.action==='stop')result=await worker.stop();
        else if(message.action==='call'){
          if(!message.payload||typeof message.payload!=='object'||typeof message.payload.op!=='string')throw new Error('无效服务消息');
          const timeout=Math.max(1,Math.min(600000,Number(message.timeoutMs)||60000));
          result=await worker.call(message.payload,timeout,{signal:controller.signal,onDelta:delta=>{void reply({delta}).catch(()=>controller.abort());}});
        }else throw new Error('未知服务操作');
        info=worker.info();
      }
      await reply({result,info});
    }catch(error){await reply({error:wireError(error)}).catch(()=>{});}
    finally{calls.delete(key);}
  }
  async function monitor(proc,generation){
    if(closing||proc!==child||generation!==epoch)return;
    try{rssBytes=await readProcessRss(proc.pid);if(rssBytes>runtimeRssLimit){lastError='Runtime 超过内存限制';proc.kill('SIGTERM');setTimeout(()=>{if(proc.exitCode===null&&proc.signalCode===null)proc.kill('SIGKILL');},2000).unref();}}
    catch(error){if(proc===child)lastError=`Runtime 内存检查失败：${error.message}`;}
    if(!closing&&proc===child){rssTimer=setTimeout(()=>{void monitor(proc,generation);},1000);rssTimer.unref();}
  }
  function launch(){
    if(closing)return;
    state='starting';lastReceipt=null;epoch=crypto.randomUUID();const generation=epoch;
    // argv and module path are owned by core, not supplied over the runtime wire.
    const proc=fork(runtimeFile,[],{stdio:['ignore','ignore','pipe','ipc'],serialization:'json',windowsHide:true,env:serviceEnv});child=proc;launched=true;
    let bootTimer=setTimeout(()=>{lastError='Runtime 启动超时';proc.kill('SIGTERM');setTimeout(()=>{if(proc.exitCode===null&&proc.signalCode===null)proc.kill('SIGKILL');},2000).unref();},30000);
    proc.stderr.on('data',chunk=>{lastError=String(chunk).slice(-2048);});
    proc.on('message',message=>{
      if(message?.epoch!==generation||generation!==epoch)return;
      if(Buffer.byteLength(JSON.stringify(message))>MAX_FRAME_BYTES){lastError='Runtime IPC 超过容量';proc.kill('SIGTERM');return;}
      if(message.type==='service'){void service(message,proc,generation);return;}
      if(message.type==='service-cancel'){calls.get(`${generation}:${message.id}`)?.controller.abort();return;}
      if(message.type==='ready'){
        if(closing)return;
        void (async()=>{
          // A detach received while the child was booting must win over its
          // earlier init snapshot before the runtime becomes publicly ready.
          let revision;
          do {revision=browserRevision;if(browserHost)await browserRequest(browserHost);} while(revision!==browserRevision);
          if(closing||proc!==child)return;
          clearTimeout(bootTimer);state='ready';lastError=null;if(initial){initial=false;readyResolve();}
          void monitor(proc,generation);output(`data: ${JSON.stringify({type:'kernel',state:'ready'})}\n\n`);
        })().catch(error=>{lastError=error.message;proc.kill('SIGTERM');});return;
      }
      if(message.type==='startup-error'){lastError=message.error?.message;state='failed';if(initial)readyReject(fromError(message.error));return;}
      if(message.type==='connections-clients'&&runtimeKind==='connections'){
        if(!Array.isArray(message.clients)||message.clients.length>1024){lastError='连接客户端快照无效';proc.kill('SIGTERM');return;}
        connectionClients=structuredClone(message.clients);return;
      }
      if(message.type==='connections-idle'&&runtimeKind==='connections'){void close().then(receipt=>{process.exitCode=receipt.ok?0:1;}).catch(()=>{process.exitCode=1;});return;}
      if(message.type==='event'&&typeof message.frame==='string'){output(message.frame);return;}
      if(message.type==='closed'){lastReceipt=message.receipt;return;}
      if(message.type==='http-result'){
        const item=requests.get(message.id);if(!item||item.epoch!==generation)return;requests.delete(message.id);clearTimeout(item.timer);
        if(message.error)item.reject(fromError(message.error));else item.resolve(message.result);
      }
    });
    proc.on('error',error=>{lastError=error.message;if(initial)readyReject(error);});
    proc.once('close',()=>{
      clearTimeout(bootTimer);clearTimeout(rssTimer);
      if(proc!==child)return;
      child=null;
      const failed=state==='failed';state=closing?'stopped':'recovering';
      failRequests(Object.assign(new Error('Runtime 已停止；未重放未确认的请求'),{code:'RUNTIME_UNAVAILABLE'}));
      if(initial&&!failed)readyReject(new Error(lastError||'Runtime 在就绪前退出'));
      if(closing)return;
      void stopServices().then(receipts=>{
        if(closing)return;
        if(failed||receipts.some(item=>!item.cleanupComplete)||restarts>=runtimeRestartLimit){state='failed';lastError ||= 'Runtime 自动恢复已停止';return;}
        restarts++;restartTimer=setTimeout(launch,Math.min(5000,runtimeRestartDelayMs*2**(restarts-1)));
      }).catch(error=>{state='failed';lastError=error.message;});
    });
    void sendIpc(proc,{type:'init',epoch:generation,options:{root,dataDir,workspace,browserHost,scope,ownerGeneration,initialClient,...(runtimeKind==='connections'?{initialClients:connectionClients}:{})}}).catch(error=>{lastError=error.message;proc.kill('SIGTERM');});
  }
  function browserRequest(binding){
    if(!child||closing)return Promise.reject(browserHostError('RUNTIME_UNAVAILABLE','内核正在恢复，请稍后再试',503));
    const id=++sequence,generation=epoch;
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{requests.delete(id);reject(browserHostError('BROWSER_HOST_TIMEOUT','浏览器接线确认超时',503));},5000);
      requests.set(id,{resolve,reject,timer,epoch:generation});
      void post({type:'browser-host',id,binding}).catch(error=>{const item=requests.get(id);if(item){requests.delete(id);clearTimeout(timer);item.reject(error);}});
    });
  }
  async function configureBrowser(input){
    const next=validateBrowserHost(input);
    if(next.detach){
      if(browserHost&&browserHost.generation!==next.generation)throw browserHostError('BROWSER_HOST_STALE','浏览器宿主已更换');
      browserHost=next;browserRevision++;
      if(state==='ready')await browserRequest(next);
      return browserHostStatus(next);
    }
    if(state!=='ready')throw browserHostError('RUNTIME_UNAVAILABLE','内核正在恢复，请稍后再试',503);
    const previous=browserHost,revision=++browserRevision;browserHost=next;
    try{return await browserRequest(next);}
    catch(error){
      // A known busy refusal made no change. A lost acknowledgement may have
      // applied the binding: retain its generation so disconnect can revoke it.
      if(error.code==='BROWSER_HOST_BUSY'&&browserRevision===revision)browserHost=previous;
      throw error;
    }
  }
  function request(req,body,signal){
    if(state!=='ready'||!child)return Promise.reject(Object.assign(new Error('Runtime 正在恢复，请稍后重试'),{code:'RUNTIME_UNAVAILABLE'}));
    if(requests.size>=128)return Promise.reject(Object.assign(new Error('IPC 请求队列已满'),{code:'IPC_BUSY'}));
    const id=++sequence,generation=epoch;
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{const item=requests.get(id);if(!item)return;requests.delete(id);abort();item.reject(Object.assign(new Error('Runtime 请求超时，结果未确认'),{code:'RUNTIME_TIMEOUT'}));},120000);
      const abort=()=>{void post({type:"http-cancel",id}).catch(()=>{});};
      signal?.addEventListener("abort",abort,{once:true});
      const clean=()=>signal?.removeEventListener("abort",abort);
      requests.set(id,{resolve:value=>{clean();resolve(value);},reject:error=>{clean();reject(error);},timer,epoch:generation});
      void post({type:'http',id,method:req.method,url:req.url,headers:req.headers,body:body.toString('base64')}).then(()=>{if(signal?.aborted)abort();}).catch(error=>{const item=requests.get(id);if(item){requests.delete(id);clearTimeout(timer);item.reject(error);}});
    });
  }
  const server=http.createServer(async(req,res)=>{
    if(closing){send(res,503,{code:'STOPPING',error:'内核正在停止'});return;}
    if(gate){const expected=Buffer.from(gate),given=Buffer.from(String(req.headers['x-koder-gate']||''));if(given.length!==expected.length||!crypto.timingSafeEqual(given,expected)){send(res,403,{code:'FORBIDDEN_GATE',error:'只接受 Koder 外壳的请求'});return;}}
    const {pathname}=new URL(req.url,'http://koder.local');
    if(req.headers.origin){try{const origin=new URL(req.headers.origin);if(!['127.0.0.1','localhost','[::1]'].includes(origin.hostname)){send(res,403,{code:'FORBIDDEN_ORIGIN',error:'拒绝外部来源'});return;}}catch{send(res,403,{code:'FORBIDDEN_ORIGIN',error:'拒绝外部来源'});return;}}
    if(pathname===BROWSER_HOST_PATH){
      if(!gate){send(res,403,{code:'FORBIDDEN_GATE',error:'浏览器接线需要外壳授权'});return;}
      if(req.method==='GET'){send(res,200,browserHostStatus(browserHost));return;}
      if(req.method!=='PUT'){send(res,405,{code:'METHOD_NOT_ALLOWED',error:'无效操作'});return;}
      try{
        if(!String(req.headers['content-type']||'').startsWith('application/json'))throw browserHostError('CONTENT_TYPE','需要 JSON 请求',415);
        const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>4096)throw browserHostError('BODY_TOO_LARGE','请求过大',413);chunks.push(chunk);}
        const input=JSON.parse(Buffer.concat(chunks).toString('utf8'));
        const job=browserTail.then(()=>configureBrowser(input));browserTail=job.catch(()=>{});
        send(res,200,await job);
      }catch(error){send(res,error.status||(error.code==='BROWSER_HOST_BUSY'?409:400),{code:error.code||'BAD_BROWSER_HOST',error:'浏览器宿主接线未完成'});}
      return;
    }
    if(req.method==='GET'&&pathname==='/koder/health'){send(res,state==='ready'?200:503,health());return;}
    if(req.method==='GET'&&pathname==='/api/events'){
      res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-store',connection:'keep-alive'});res.write(': connected\n\n');clients.add(res);
      const heartbeat=setInterval(()=>res.write(': ping\n\n'),25000);req.on('close',()=>{clearInterval(heartbeat);clients.delete(res);});return;
    }
    try{
      if(!['GET','HEAD','DELETE'].includes(req.method)&&!String(req.headers['content-type']||'').startsWith('application/json')){send(res,415,{code:'CONTENT_TYPE',error:'需要 JSON 请求'});return;}
      const bodyLimit=pathname==='/internal/shared-apps/artifacts'?12*1024*1024:/^\/api\/karmen\/voice\/sessions\/[a-f0-9-]{36}\/turn$/.test(pathname)?2_000_000:MAX_BODY;
      const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>bodyLimit){send(res,413,{code:'BODY_TOO_LARGE',error:'请求过大'});return;}chunks.push(chunk);}
      const controller=new AbortController();res.once("close",()=>{if(!res.writableEnded)controller.abort();});
      const result=await request(req,Buffer.concat(chunks),controller.signal);if(res.destroyed)return;
      if(result.status===200 && ((req.method==='GET'&&pathname==='/api/memory') || (req.method==='POST'&&pathname==='/api/memory/release'))){
        const observed=JSON.parse(result.body),usage=process.memoryUsage();
        const runtime={pid:observed.pid,rss:observed.rss,heapUsed:observed.heapUsed},core={pid:process.pid,rss:usage.rss,heapUsed:usage.heapUsed};
        delete observed.pid;
        // Only these two processes are sampled here; independent workers and
        // the Electron host are not silently counted as zero or included.
        result.body=JSON.stringify({...observed,rss:core.rss+runtime.rss,heapUsed:core.heapUsed+runtime.heapUsed,rssScope:'core+runtime',core,runtime});
        delete result.headers['content-length'];
      }
      res.writeHead(result.status,result.headers);res.end(result.body);
    }catch(error){if(!res.destroyed)send(res,error.code?.startsWith('RUNTIME')?503:500,{code:error.code||'INTERNAL',error:error.message||'内部错误'});}
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',()=>{server.off('error',reject);resolve();});});
  if(runtimeKind==='connections'){serviceEnv.KODER_WORKBENCH_URL=`http://127.0.0.1:${server.address().port}`;serviceEnv.KODER_WORKBENCH_TOKEN=gate;}
  async function close(){
    if(closingPromise)return closingPromise;closing=true;state='stopping';clearTimeout(restartTimer);clearTimeout(rssTimer);
    for(const client of clients)client.end();clients.clear();const serverClosed=new Promise(resolve=>server.close(resolve));
    closingPromise=(async()=>{
      let forced=false;const proc=child;
      if(proc){
        await new Promise(resolve=>{let done=false;const finish=()=>{if(done)return;done=true;clearTimeout(kill);clearTimeout(final);resolve();};proc.once('close',finish);
          const kill=setTimeout(()=>{forced=true;proc.kill('SIGKILL');},35000);const final=setTimeout(finish,37000);
          void sendIpc(proc,{type:'close',epoch}).catch(()=>proc.kill('SIGTERM'));
        });
      }
      failRequests(Object.assign(new Error('内核已停止'),{code:'STOPPING'}));
      const workers=await stopServices();server.closeAllConnections();await serverClosed;state='stopped';
      const receipt={ok:!forced&&(!launched||lastReceipt?.ok===true)&&workers.every(item=>item.cleanupComplete),runtime:lastReceipt,workers,forced,saveErrors:lastReceipt?.saveErrors||[]};
      await onClosed(receipt);return receipt;
    })();return closingPromise;
  }
  const abortStartup=()=>{
    readyReject(Object.assign(new Error('内核启动已取消'),{name:'AbortError',code:'ABORT_ERR'}));
    void close().catch(()=>{});
  };
  signal?.addEventListener('abort',abortStartup,{once:true});
  if(signal?.aborted)abortStartup();else launch();
  try{await ready;}catch(error){const receipt=await close();error.cleanupComplete=receipt.ok;error.receipt=receipt;throw error;}
  finally{signal?.removeEventListener('abort',abortStartup);}
  return {port:server.address().port,close,info:health};
}
