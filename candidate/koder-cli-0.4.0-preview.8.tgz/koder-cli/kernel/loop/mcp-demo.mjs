// Official MCP SDK server; stdout is newline-delimited JSON-RPC only.
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { ListToolsRequestSchema, CallToolRequestSchema } from '@modelcontextprotocol/sdk/types.js';
const server = new Server({ name: 'koder-demo', version: '1.0.0' }, { capabilities: { tools: {} } });
server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools: [{
  name: 'add', description: '把两个有限数相加。不读文件，不上网，不操作电脑。',
  inputSchema: { type: 'object', properties: { a: { type: 'number' }, b: { type: 'number' } }, required: ['a', 'b'] },
  annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
}] }));
server.setRequestHandler(CallToolRequestSchema, async ({ params }) => {
  if (params.name !== 'add') throw new Error('没有这个工具');
  const { a, b } = params.arguments || {}, sum = a + b;
  if (![a, b, sum].every(Number.isFinite)) return { isError: true, content: [{ type: 'text', text: '结果溢出或参数不是有限数' }] };
  return { content: [{ type: 'text', text: String(sum) }], structuredContent: { sum } };
});
await server.connect(new StdioServerTransport());
process.stdin.once('end', () => { void server.close(); });
