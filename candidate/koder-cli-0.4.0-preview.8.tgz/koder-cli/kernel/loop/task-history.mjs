import crypto from 'node:crypto';

// Restoring conversation state never rewinds the external world or authorizes a
// tool call. Keep newer uncertainty and call identities even when looking back.
export function restoredTask(selected,current,{revision,hash,currentRevision,currentHash,now=Date.now()}={}) {
 const next=structuredClone(selected),at=now;
 const answered=new Set((next.messages||[]).filter(item=>item.role==='tool').map(item=>item.toolCallId));
 next.messages=(next.messages||[]).flatMap(message=>{
  const missing=(message.toolCalls||[]).filter(call=>!answered.has(call.id));
  for(const call of missing)answered.add(call.id);
  return [message,...missing.map(call=>({id:crypto.randomUUID(),role:'tool',toolCallId:call.id,name:call.name,at,content:'已恢复任务历史。这个版本没有该调用的已确认结果；本次恢复没有执行此调用。先读取外部状态核实，不能自动重复写入或提交。'}))];
 });
 next.restoration={fromRevision:revision,fromHash:hash,previousRevision:currentRevision,previousHash:currentHash,at,fileRestore:false,
  savedInputs:(selected.pendingTurns||[]).filter(item=>typeof item.text==='string').map(({token,text})=>({token,text})),savedDraft:String(selected.draft||''),
  message:'已恢复对话历史；目标已暂停，历史排队输入未执行。工作区文件不会随对话历史回退。'};
 Object.assign(next,{running:false,resumable:false,resumeActive:false,interruptedAt:null,pendingTurns:[],approvals:[],choices:[],changes:[],draft:'',error:null,verification:null,workbench:null,stream:[],streamSig:null,updatedAt:at});
 if(next.goal)next.goal={...next.goal,status:'paused',note:'历史恢复后暂停；继续执行需明确发起。'};
 if(next.task)next.task={...next.task,stage:'understand'};
 // Branches and workspaces represent current files, not a historical document.
 // Token totals account for calls already made; restoring text cannot refund them.
 next.usage=structuredClone(current.usage||null);
 next.cwd=current.cwd;next.branch=current.branch?{...current.branch,offer:false}:null;
 next.role=current.role||null;next.parentId=current.parentId||null;
 for(const key of ["projectRoot","projectId","leadCreationKey","leadProjectId","automationId"])next[key]=current[key]??null;
 next.projectSyncRevision=(current.projectSyncRevision||0)+1;
 next.seenCallIds=[...new Set([...(current.seenCallIds||[]),...(selected.seenCallIds||[]),...(current.messages||[]).flatMap(item=>(item.toolCalls||[]).map(call=>call.id)),...next.messages.flatMap(item=>(item.toolCalls||[]).map(call=>call.id))])].slice(-400);
 for(const key of ['effect','computerUncertain','mcpUncertain','workbenchUncertain'])next[key]=structuredClone(current[key]||selected[key]||null);
 if(next.effect?.phase==='started')next.effect.phase='uncertain';
 next.cancellationUnconfirmed=current.cancellationUnconfirmed===true||selected.cancellationUnconfirmed===true;
 delete next.selection;delete next.review;delete next.claims;
 next.seq=Math.max(Number(current.seq)||0,Number(selected.seq)||0)+1;
 next.events=[...(next.events||[]),{sequence:next.seq,at,type:'history.restored',data:{revision,hash,fileRestore:false}}].slice(-80);
 return next;
}
