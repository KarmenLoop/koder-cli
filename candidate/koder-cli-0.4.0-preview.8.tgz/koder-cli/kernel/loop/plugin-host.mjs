// Plugin process beside the kernel. It is not the DeepSeek Harness desktop app.
import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const childPath = fileURLToPath(new URL("./plugin-host-child.mjs", import.meta.url));

export function startPluginHost({ node = process.execPath, timeoutMs = 10_000 } = {}) {
  let child = null;
  let buffer = "";
  let nextId = 0;
  let failure = null;
  let exitReceipt = null;
  const pending = new Map();
  function failAll(error) {
    for (const item of pending.values()) {
      clearTimeout(item.timer);
      item.signal?.removeEventListener("abort", item.onAbort);
      item.reject(error);
    }
    pending.clear();
  }
  function noteFailure(error) {
    if (!failure) failure = error;
    failAll(Object.assign(new Error(failure?.message || "插件进程故障"), { code: "PLUGIN", cleanupComplete: false }));
  }
  function watch(stream) {
    stream?.on("error", (error) => noteFailure(error));
  }
  function launch() {
    buffer = "";
    failure = null;
    exitReceipt = null;
    let spawned;
    try { spawned = spawn(node, [childPath], { stdio: ["pipe", "pipe", "pipe"] }); }
    catch (error) {
      noteFailure(error);
      return;
    }
    child = spawned;
    watch(child);
    watch(child.stdin);
    watch(child.stdout);
    watch(child.stderr);
    child.stdout.on("data", (chunk) => {
      buffer += chunk.toString("utf8");
      let end = buffer.indexOf("\n");
      while (end >= 0) {
        const line = buffer.slice(0, end);
        buffer = buffer.slice(end + 1);
        end = buffer.indexOf("\n");
        let message;
        try { message = JSON.parse(line); } catch { continue; }
        const item = pending.get(message.id);
        if (!item) continue;
        if (message.started === true && !message.proposal && message.cancelled !== true) {
          item.started = true;
          continue;
        }
        clearTimeout(item.timer);
        item.signal?.removeEventListener("abort", item.onAbort);
        pending.delete(message.id);
        if (message.cancelled === true) item.reject(Object.assign(new Error("插件调用已取消"), { code: "CANCELLED", cleanupComplete: true }));
        else item.resolve(message);
      }
    });
    child.on("exit", (code, exitSignal) => {
      exitReceipt = { code, exitSignal };
      child = null;
      failAll(Object.assign(new Error("插件进程已退出"), { code: "PLUGIN_EXIT", cleanupComplete: true, exitCode: code, signal: exitSignal }));
    });
  }
  launch();
  return {
    provider: "koder-plugin-host",
    alive() { return Boolean(child && child.exitCode === null); },
    pending() { return pending.size; },
    call(message, signal) {
      if (!child || child.exitCode !== null) return Promise.reject(Object.assign(new Error("插件没有在运行"), { code: "PLUGIN" }));
      if (signal?.aborted) return Promise.reject(Object.assign(new Error("插件调用已取消"), { code: "CANCELLED" }));
      const id = ++nextId;
      return new Promise((resolve, reject) => {
        let timer;
        const finish = (error) => {
          const current = pending.get(id);
          if (!current) return;
          clearTimeout(current.timer);
          signal?.removeEventListener("abort", onAbort);
          pending.delete(id);
          reject(error);
        };
        const onAbort = () => {
          const current = pending.get(id);
          if (!current || current.cancelling) return;
          current.cancelling = true;
          clearTimeout(current.timer);
          try { child?.stdin.write(`${JSON.stringify({ op: "cancel", target: id })}\n`); } catch {}
          current.timer = setTimeout(() => finish(Object.assign(new Error("插件调用已取消，但子进程没有确认终态"), { code: "CANCELLED", cleanupComplete: false })), 2_000);
        };
        timer = setTimeout(() => finish(Object.assign(new Error("插件调用超时"), { code: "TIMEOUT" })), timeoutMs);
        pending.set(id, { resolve, reject, timer, signal, onAbort });
        signal?.addEventListener("abort", onAbort, { once: true });
        if (signal?.aborted || !pending.has(id)) {
          onAbort();
          return;
        }
        child.stdin.write(`${JSON.stringify({ ...message, id })}\n`, (error) => {
          if (error) finish(error);
        });
      });
    },
    crash() { if (child) child.stdin.write(`${JSON.stringify({ op: "crash", id: 0 })}\n`); },
    async stop() {
      if (!child) {
        failAll(Object.assign(new Error(failure?.message || "插件进程已退出"), { code: failure ? "PLUGIN" : "PLUGIN_EXIT", cleanupComplete: false }));
        return { stopped: true, cleanupComplete: Boolean(exitReceipt) || !failure, exitCode: exitReceipt?.code ?? null, signal: exitReceipt?.exitSignal ?? null, pending: 0 };
      }
      const exited = new Promise((resolve) => {
        const timer = setTimeout(() => resolve(null), 2_000);
        child.once("exit", (code, exitSignal) => { clearTimeout(timer); resolve({ code, exitSignal }); });
      });
      try { child.kill("SIGTERM"); } catch (error) { noteFailure(error); }
      const result = await exited;
      return { stopped: true, cleanupComplete: result !== null, exitCode: result?.code ?? null, signal: result?.exitSignal ?? null, pending: pending.size };
    },
    restart() { if (this.alive()) throw Object.assign(new Error("插件还在运行"), { code: "PLUGIN" }); launch(); },
  };
}

export function pluginNotePath(root, name) {
  return path.join(root, `${String(name || "note").replace(/[^a-z0-9.-]/gi, "")}.txt`);
}
