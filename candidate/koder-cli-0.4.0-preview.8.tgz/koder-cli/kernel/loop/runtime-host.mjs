// One product runtime per epoch. This process never owns worker executables.
import { Readable } from 'node:stream';
import { createRuntimeClient } from './runtime-client.mjs';
import { sendIpc, wireError } from './core-ipc.mjs';
export function runRuntimeHost(startRuntime) {
let runtime,client,epoch,closing,booting;
const httpRequests=new Map();
const post=message=>sendIpc(process,{...message,epoch});
process.on('message',message=>{
  if(message?.type==='init'&&!epoch){
    epoch=message.epoch;client=createRuntimeClient({epoch});
    booting=startRuntime({...message.options,services:client,onEvent:frame=>{void post({type:'event',frame}).catch(()=>{});},onClientsChange:clients=>post({type:'connections-clients',clients}),onIdle:()=>{void post({type:'connections-idle'}).catch(()=>{});}});
    void booting.then(value=>{runtime=value;if(!closing)return post({type:'ready'});}).catch(error=>{if(!closing)void post({type:'startup-error',error:wireError(error)}).catch(()=>{}).finally(()=>process.exit(1));});
    return;
  }
  if(message?.epoch!==epoch)return;
  if(message.type==='browser-host'&&runtime&&!closing){
    try{void post({type:'http-result',id:message.id,result:runtime.configureBrowser(message.binding)}).catch(()=>{});}
    catch(error){void post({type:'http-result',id:message.id,error:wireError(error)}).catch(()=>{});}
    return;
  }
  if(message.type==='http'&&runtime&&!closing){
    const controller=new AbortController();httpRequests.set(message.id,controller);
    const req=Readable.from(message.body ? [Buffer.from(message.body,'base64')] : []);req.method=message.method;req.url=message.url;req.headers=message.headers;req.signal=controller.signal;
    void runtime.handle(req).then(result=>post({type:'http-result',id:message.id,result}),error=>post({type:'http-result',id:message.id,error:wireError(error)})).catch(()=>{}).finally(()=>httpRequests.delete(message.id));
  }
  if(message.type==='http-cancel')httpRequests.get(message.id)?.abort();
  if(message.type==='close')void close();
});
function close(){
  return closing ||= (async()=>{
    let receipt;for(const controller of httpRequests.values())controller.abort();
    // Boot may already own storage/system workers. Wait for their runtime owner
    // before releasing the IPC client, so its close receipt is real and complete.
    try{runtime ||= await booting;receipt=runtime?await runtime.close():{ok:true,startupCancelled:true};}
    catch(error){receipt={ok:false,error:error.message};}
    await post({type:'closed',receipt}).catch(()=>{});client?.close();if(process.connected)process.disconnect();
  })();
}
process.on('disconnect',()=>{if(!closing)process.exit(1);});
process.on('SIGTERM',()=>{void close();});

}
