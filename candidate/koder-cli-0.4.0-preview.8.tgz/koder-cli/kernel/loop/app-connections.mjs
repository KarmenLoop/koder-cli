// Single owner of application configuration and live MCP generations.
// Uses the existing storage and MCP worker ports; it does not implement MCP.
import crypto from 'node:crypto';
import path from 'node:path';
import {AjvJsonSchemaValidator} from '@modelcontextprotocol/sdk/validation/ajv';
import {appDigest,appTask} from '../fusion/app-binding.mjs';
import {redactAppValue} from '../fusion/app-results.mjs';

export class AppConnectionError extends Error {
  constructor(status, code, message) {super(message);this.status=status;this.code=code;}
}
export async function createAppConnections({storage, worker, file, currentScope=()=>null, onChange=()=>{},applications=[],initialState=null}) {
  const mcpWorker=worker, mcpUp=new Set(), mcpConnections=new Map();
  const mcp=await storage.readJson(file,initialState||{servers:[]});
  mcp.servers=(Array.isArray(mcp.servers)?mcp.servers:[]).flatMap(entry=>{
    if(entry?.protocol!=='native')return [{...entry,tools:[],verifiedAt:null}];
    if(entry.pluginId!=='note')return [];
    return [{...entry,protocol:'native',pluginId:'note',bundleVersion:'1',transport:'native',command:'',args:[],url:'',cwd:'',allowAll:false,tools:[]}];
  });
  for(const entry of mcp.servers)mcpConnections.set(entry.id,crypto.randomUUID());
  let closing=false, tail=Promise.resolve();
  const enqueue=work=>{const run=tail.then(work);tail=run.catch(()=>{});return run;};
  const save=()=>storage.writeJson(file,mcp);
  function publicValue(value) {
    const secrets=[];
    for(const entry of mcp.servers){
      for(const [key,value] of Object.entries(entry.env||{}))if(/token|key|pass|secret|auth|credential/i.test(key)&&typeof value==='string')secrets.push(value);
      secrets.push(...Object.values(entry.headers||{}).filter(value=>typeof value==='string'));
      try{const u=new URL(entry.url);secrets.push(decodeURIComponent(u.username),decodeURIComponent(u.password));for(const [key,value] of u.searchParams)if(/token|key|pass|secret|auth|credential/i.test(key))secrets.push(value);}catch{}
      const args=entry.args||[];for(let i=0;i<args.length;i++)if(/^--?(?:.*[-_])?(?:token|key|password|secret|authorization|credential)(?:=|$)/i.test(args[i])){const equal=args[i].indexOf('=');secrets.push(equal<0?args[++i]:args[i].slice(equal+1));}
    }
    return redactAppValue(value,secrets.filter(value=>typeof value==='string'&&value));
  }
  const changed=entry=>{mcpConnections.set(entry.id,crypto.randomUUID());onChange({id:entry.id,generation:mcpConnections.get(entry.id)});};
  const find=id=>{const entry=mcp.servers.find(x=>x.id===id);if(!entry)throw new AppConnectionError(404,'NO_MCP','没有这个外部工具');return entry;};
  async function disconnect(entry) {
    changed(entry);mcpUp.delete(entry.id);entry.tools=[];entry.verifiedAt=null;
    if(entry.protocol==='native')entry.generation=(entry.generation||0)+1;
    const receipt=await worker.call({op:'close',serverId:entry.id},30000).catch(()=>({cleanupComplete:false}));
    entry.cleanupComplete=receipt.cleanupComplete!==false;
    entry.error=entry.cleanupComplete?null:'连接进程没有确认退出';
    entry.errorCode=entry.cleanupComplete?null:'APP_CLEANUP_PENDING';
    return {ok:entry.cleanupComplete,cleanupComplete:entry.cleanupComplete};
  }
  async function connectNative(entry) {
    mcpUp.delete(entry.id);
    entry.tools = [];
    const generation = (entry.generation || 0) + 1;
    entry.generation = generation;
    const closed = await mcpWorker.call({ op: "close", serverId: entry.id }, 30_000).catch((error) => ({ cleanupComplete: false, error: error.message }));
    entry.cleanupComplete = closed.cleanupComplete !== false;
    if (!entry.enabled) {
      entry.statusError = entry.cleanupComplete ? null : "插件进程没有确认退出";
      entry.error = entry.statusError;
      return;
    }
    if (entry.pluginId !== "note") {
      entry.error = "没有这个随包插件";
      return;
    }
    try {
      const result = await mcpWorker.call({ op: "connect", serverId: entry.id, server: { protocol: "native", pluginId: "note", bundleVersion: "1" } }, 30_000);
      if (!entry.enabled || entry.generation !== generation) {
        const dropped = await mcpWorker.call({ op: "close", serverId: entry.id }, 30_000).catch(() => ({ cleanupComplete: false }));
        entry.cleanupComplete = dropped.cleanupComplete !== false;
        entry.tools = [];
        return;
      }
      entry.tools = result.tools || [];
      entry.generation = result.generation;
      entry.error = null;
      entry.cleanupComplete = true;
      mcpUp.add(entry.id);
    } catch (error) {
      entry.tools = [];
      entry.cleanupComplete = error.cleanupComplete !== false;
      entry.error = error.cleanupComplete === false ? "插件进程没有确认退出" : (error.message || "没有连上");
    }
  }

  async function connectMcp(entry) {
    if(closing)throw new AppConnectionError(503,'APP_STOPPING','应用连接正在关闭');
    if(entry.enabled && mcpUp.has(entry.id))return;
    if(!entry.enabled){await disconnect(entry);return;}
    changed(entry);
    if(entry.protocol==='native'){await connectNative(entry);return;}
    mcpUp.delete(entry.id);entry.tools=[];
    const generation=mcpConnections.get(entry.id);
    const http=['http','streamable-http'].includes(entry.transport);
    try {
      const result=await worker.call({op:'connect',server:{id:entry.id,serverName:entry.serverName,transport:http?'http':'stdio',command:entry.command,args:entry.args,env:entry.env,cwd:entry.cwd,url:entry.url,headers:entry.headers||{},oauth:entry.oauth===true,auth:entry.auth}},30000);
      if(closing || !entry.enabled || mcpConnections.get(entry.id)!==generation){await disconnect(entry);return;}
      entry.tools=result.tools||[];entry.capabilities=result.capabilities||{};entry.catalogVersion=result.catalogVersion;entry.error=null;entry.errorCode=null;entry.cleanupComplete=true;entry.verifiedAt=new Date().toISOString();mcpUp.add(entry.id);
    } catch(error) {
      entry.tools=[];entry.error=error.message||'没有连上';entry.errorCode=error.code||'MCP_CONNECT_FAILED';entry.cleanupComplete=error.cleanupComplete!==false;
    }
  }
  function mcpView(entry) {
    return publicValue({
      id: entry.id,
      generation: mcpConnections.get(entry.id),
      authState: entry.auth?.type === "oauth" ? (mcpUp.has(entry.id) ? "authorized" : "required") : "none",
      connectionState: entry.cleanupComplete === false ? "cleanup-pending" : !entry.enabled ? "disabled" : mcpUp.has(entry.id) ? "connected" : entry.error ? "disconnected" : "connecting",
      workspaceLabel: null,
      verifiedAt: entry.verifiedAt || null,
      capabilities: entry.capabilities || {},
      errorCode: entry.errorCode || null,
      name: entry.name,
      serverName: entry.serverName,
      protocol: entry.protocol || "mcp",
      pluginId: entry.pluginId || null,
      bundleVersion: entry.bundleVersion || null,
      cleanupComplete: entry.cleanupComplete !== false,
      transport: entry.transport,
      command: entry.command,
      args: entry.args,
      url: entry.url || "",
      env: Object.fromEntries(Object.keys(entry.env || {}).map((key) => [key, "••••"])),
      headers: {},
      auth: entry.auth?.type === "oauth" ? {type:"oauth"} : null,
      registry: entry.registry || null,
      enabled: entry.enabled,
      allowed: entry.allowed || [],
      allowAll: Boolean(entry.allowAll),
      guidance: entry.guidance || "",
      addedAt: entry.addedAt,
      status: !entry.enabled ? "off" : entry.error ? "error" : mcpUp.has(entry.id) ? "connected" : "connecting",
      error: entry.error || null,
      tools: entry.tools || [],
    });
  }

  function config(body) {
    const http=['http','streamable-http'].includes(body.transport);
    if(body.transport!=='stdio'&&!http)throw new AppConnectionError(400,'BAD_MCP','类型只能是本地程序或 HTTPS 网址');
    if(!http&&!body.command)throw new AppConnectionError(400,'BAD_MCP','要填写启动这个服务的命令');
    if(http&&!body.url)throw new AppConnectionError(400,'BAD_MCP','要填写 MCP 网址');
    const program=Array.isArray(body.args)?body.args.find(arg=>typeof arg==='string'&&/\.(?:m?js|cjs|py)$/.test(arg)):null;
    const inferred=http?'remote':path.basename(program||String(body.command),path.extname(program||String(body.command)));
    const baseName=String(body.serverName||inferred).replace(/[^A-Za-z0-9_-]/g,'').slice(0,28)||'mcp';
    let serverName=baseName;for(let n=2;mcp.servers.some(x=>x.serverName===serverName);n++)serverName=`${baseName}-${n}`;
    const entry={id:crypto.randomUUID(),name:String(body.name||'外部工具').slice(0,60),serverName,transport:http?'streamable-http':'stdio',command:http?'':String(body.command),args:Array.isArray(body.args)?body.args.map(String):[],cwd:String(body.cwd||''),env:!http&&body.env&&typeof body.env==='object'?body.env:{},url:http?String(body.url):'',headers:http&&body.headers&&typeof body.headers==='object'?body.headers:{},enabled:body.enabled!==false,allowed:[],guidance:'',tools:[],addedAt:Date.now(),registry:body.registry&&typeof body.registry==='object'?Object.fromEntries(['name','package','version','integrity','executableSHA256'].filter(k=>typeof body.registry[k]==='string').map(k=>[k,body.registry[k].slice(0,1000)])):null};
    if(http&&body.auth?.type==='oauth')entry.auth={type:'oauth',id:entry.id};
    return entry;
  }
  async function add(body) {return enqueue(async()=>{
    const entry=config(body);mcp.servers.push(entry);changed(entry);
    await save();await connectMcp(entry);await save();return mcpView(entry);
  });}
  async function update(id,body) {
    // Revoke admission synchronously, even while an earlier connect is pending.
    const entry=find(id);
    const reconnect=(typeof body.enabled==='boolean'&&body.enabled!==entry.enabled)||Object.hasOwn(body,'auth');
    if(body.enabled===false){entry.enabled=false;mcpUp.delete(id);changed(entry);}
    return enqueue(async()=>{
      const permissions=appDigest({allowed:entry.allowed||[],allowAll:entry.allowAll||false,guidance:entry.guidance||''});
      if(Object.hasOwn(body,'auth')&&body.auth!==null&&!(body.auth?.type==='oauth'&&['http','streamable-http'].includes(entry.transport)))throw new AppConnectionError(400,'BAD_AUTH','OAuth 仅适用于 HTTP 服务');
      if(typeof body.guidance==='string')entry.guidance=body.guidance.slice(0,2000);
      if(typeof body.enabled==='boolean')entry.enabled=body.enabled;
      if(Array.isArray(body.allow))entry.allowed=[...new Set([...(entry.allowed||[]),...body.allow.map(String)])];
      if(typeof body.allowAll==='boolean')entry.allowAll=body.allowAll;
      if(Object.hasOwn(body,'auth'))entry.auth=body.auth===null?null:{type:'oauth',id:entry.id};
      if(permissions!==appDigest({allowed:entry.allowed||[],allowAll:entry.allowAll||false,guidance:entry.guidance||''}))changed(entry);
      await save();
      if(reconnect || body.enabled===false || (body.enabled===true&&!mcpUp.has(id))) {
        if(mcpUp.has(id))await disconnect(entry);
        await connectMcp(entry);await save();
      }
      return mcpView(entry);
    });
  }
  function remove(id) {
    const entry=find(id);entry.enabled=false;mcpUp.delete(id);changed(entry);
    return enqueue(async()=>{
      const receipt=await disconnect(entry);
      if(!receipt.cleanupComplete){await save();return {...receipt,server:mcpView(entry)};}
      mcp.servers=mcp.servers.filter(x=>x!==entry);await save();return receipt;
    });
  }
  function discover() {
    return publicValue(mcp.servers.filter(x=>x.enabled&&mcpUp.has(x.id)&&x.protocol!=='native').flatMap(entry=>(entry.tools||[]).map(tool=>({name:tool.name,description:`${entry.name}：${tool.description||tool.tool}`,parameters:tool.inputSchema||{type:'object',additionalProperties:true},...(tool.outputSchema?{outputSchema:tool.outputSchema}:{}),...(tool.annotations?{annotations:tool.annotations}:{}),schemaDigest:appDigest({input:tool.inputSchema||{},output:tool.outputSchema||null,annotations:tool.annotations||{}}),connection:{id:entry.id,generation:mcpConnections.get(entry.id)},catalogVersion:entry.catalogVersion}))));
  }
  async function refresh({signal}={}) {
    for(const entry of mcp.servers.filter(x=>x.enabled&&mcpUp.has(x.id)&&x.protocol!=='native'&&x.catalogVersion)) {
      const generation=mcpConnections.get(entry.id);
      const result=await worker.call({op:'catalog',serverId:entry.id},30000,{signal});
      if(!entry.enabled||mcpConnections.get(entry.id)!==generation)continue;
      if(result.catalogVersion!==entry.catalogVersion){entry.tools=result.tools;entry.capabilities=result.capabilities;entry.catalogVersion=result.catalogVersion;changed(entry);}
    }
    return [...discover(),...(await Promise.all(applications.map(app=>app.discover()))).flat()];
  }
  async function prepare(input,{scope=currentScope(),signal}={}) {
    const selected=(await refresh({signal})).find(t=>t.name===input.name);
    if(!selected)throw new AppConnectionError(409,'APP_CONNECTION_CHANGED','应用连接或权限已变化');
    if(!input.arguments||typeof input.arguments!=='object'||Array.isArray(input.arguments)||Buffer.byteLength(JSON.stringify(input.arguments))>32000)throw new AppConnectionError(400,'APP_ARGUMENTS','应用工具参数必须是有限对象');
    // A validator belongs to this exact schema, never a remote $id cache.
    if(!new AjvJsonSchemaValidator().getValidator(selected.parameters)(input.arguments).valid)throw new AppConnectionError(400,'APP_ARGUMENTS','应用参数不符合当前工具定义');
    return {name:selected.name,arguments:structuredClone(input.arguments),argumentsDigest:appDigest(input.arguments),connection:selected.connection,catalogVersion:selected.catalogVersion,schemaDigest:selected.schemaDigest,task:appTask(input.task),scope:structuredClone(scope)};
  }
  async function validate(bound,options={}) {
    const current=await prepare(bound,options);
    if(['connection','catalogVersion','schemaDigest','argumentsDigest','task','scope'].some(key=>appDigest(current[key]??null)!==appDigest(bound[key]??null)))throw new AppConnectionError(409,'APP_CONNECTION_CHANGED','应用连接、任务或参数已变化，请重新确认');
    return current;
  }
  async function call(bound,options={}) {
    await validate(bound,options);
    await options.assertCurrent?.();
    options.signal?.throwIfAborted();
    const app=applications.find(item=>item.id===bound.connection.id);
    if(app)return app.call(bound,options);
    const entry=find(bound.connection.id),tool=entry.tools.find(t=>t.name===bound.name);
    options.signal?.throwIfAborted();
    try {
      const result=await worker.call({op:'call',serverId:entry.id,tool:tool.tool,arguments:bound.arguments,catalogVersion:bound.catalogVersion},30000,{signal:options.signal});
      return publicValue({...result,ok:result.ok!==false&&result.isError!==true,state:result.ok===false||result.isError===true?'failed':'succeeded',cleanupComplete:result.cleanupComplete!==false,content:result.content||[],errorCode:result.isError?'MCP_TOOL_ERROR':null});
    }catch(error){
      const unknown=error.effectsMayHaveCompleted===true||error.cleanupComplete===false;
      return {ok:false,state:unknown?'unknown':'failed',notStarted:!unknown,content:[],cleanupComplete:!unknown,errorCode:typeof error.code==='string'?error.code:'MCP_CALL_FAILED'};
    }
  }
  async function protocol(input,{signal}={}){
    const entry=find(input.serverId);
    if(!entry.enabled||!mcpUp.has(entry.id)||entry.protocol==='native')throw new AppConnectionError(409,'APP_CONNECTION_CHANGED','MCP 连接不可用');
    if(!['resources/list','resources/templates/list','resources/read','prompts/list','prompts/get'].includes(input.method))throw new AppConnectionError(400,'MCP_CAPABILITY_UNAVAILABLE','没有此 MCP 读取能力');
    if(input.params&&(!input.params||typeof input.params!=='object'||Array.isArray(input.params)||Buffer.byteLength(JSON.stringify(input.params))>32000))throw new AppConnectionError(400,'APP_ARGUMENTS','参数必须是有限对象');
    signal?.throwIfAborted();return publicValue(await worker.call({op:'request',serverId:entry.id,method:input.method,params:input.params||{}},30000,{signal}));
  }
  return {
    // These internal references keep the original task/native-plugin routes on
    // this same owner during extraction. They never cross the public bridge.
    state:mcp, up:mcpUp, generations:mcpConnections, view:mcpView, connect:connectMcp, save,
    list:()=>mcp.servers.map(mcpView), add, update, remove, discover,refresh,prepare,validate,call,protocol,
    enable:id=>update(id,{enabled:true}),disable:id=>update(id,{enabled:false}),
    async close(){closing=true;for(const entry of mcp.servers){mcpUp.delete(entry.id);changed(entry);}await tail;const receipts=await Promise.all(mcp.servers.map(disconnect));return {cleanupComplete:receipts.every(x=>x.cleanupComplete)};},
  };
}
