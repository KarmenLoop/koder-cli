// KARMEN LOOP keeps oversized tool output out of the model window.
// The full text stays in this session's local index. The model gets a short
// preview and can search or read a slice later. This is our own store.
import { DatabaseSync } from "node:sqlite";
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export function createProtectedContext({storage,dir,file='context-keep.sqlite'}){
 let tail=Promise.resolve();
 const withContext=fn=>{
  const job=tail.then(async()=>{
   await fs.mkdir(dir,{recursive:true,mode:0o700});const stored=path.join(dir,file),tmp=path.join(dir,`.context-${crypto.randomUUID()}.sqlite`);let db;
   try{
    const previous=await storage.readBytes(stored,null),handle=await fs.open(tmp,'wx',0o600);
    try{if(previous?.length)await handle.writeFile(previous);}finally{await handle.close();}
    db=openContextStore(tmp);const result=await fn(db);db.close();db=null;
    await storage.writeBytes(stored,await fs.readFile(tmp));return result;
   }finally{db?.close();await fs.rm(tmp,{force:true});await fs.rm(tmp+'-journal',{force:true});}
  });tail=job.catch(()=>{});return job;
 };withContext.drain=()=>tail;return withContext;
}

const PARK_AT = 2400;
const PREVIEW = 480;
const STORE_MAX = 400000;
const READ_MAX = 8000;

function tokens(text) {
  return [...String(text || "")].filter((ch) => !/\s/.test(ch)).join(" ").slice(0, 120000);
}

export function openContextStore(file) {
  const db = new DatabaseSync(file);
  db.exec("PRAGMA journal_mode=DELETE");
  db.exec(`CREATE TABLE IF NOT EXISTS kept (
    id TEXT PRIMARY KEY,
    thread TEXT NOT NULL,
    name TEXT NOT NULL,
    body TEXT NOT NULL,
    bytes INTEGER NOT NULL,
    at INTEGER NOT NULL
  )`);
  db.exec("CREATE VIRTUAL TABLE IF NOT EXISTS kept_fts USING fts5(id UNINDEXED, body)");
  return db;
}

export function parkToolOutput(db, { id, threadId, name, text, at = Date.now(), parkAt = PARK_AT, preview = PREVIEW,complete=false }) {
  const raw = String(text || "");
  if (raw.length < parkAt) return { parked: false, text: raw, bytes: raw.length };
  if(complete&&Buffer.byteLength(raw)>8*1024*1024)throw Object.assign(new Error('应用结果超过完整存储上限'),{code:'APP_RESULT_TOO_LARGE'});
  const body = complete?raw:raw.slice(0, STORE_MAX);
  const key = String(id || "");
  if (!/^c[a-z0-9]{8,24}$/.test(key)) throw Object.assign(new Error("上下文编号不合法"), { code: "BAD_CONTEXT" });
  db.prepare("INSERT INTO kept (id, thread, name, body, bytes, at) VALUES (?, ?, ?, ?, ?, ?)").run(key, String(threadId), String(name || "tool").slice(0, 80), body, raw.length, at);
  db.prepare("INSERT INTO kept_fts (id, body) VALUES (?, ?)").run(key, tokens(body));
  const omitted = raw.length > body.length ? `原文 ${raw.length} 字，只保存了前 ${body.length} 字，不是全文。` : `原文 ${raw.length} 字，已保存在这台电脑。`;
  const lead = preview >= 1024
    ? `上下文已收起。本机编号 ${key}（${name}）。${omitted}这里只留前 ${preview} 字。用 context_read 按页取后面的原文，不要把没看到的部分说成已经看过。`
    : `上下文已收起 ${key}（${name}）。${omitted}预览：`;
  return {
    parked: true,
    id: key,
    bytes: raw.length,
    original: raw.length,
    saved: body.length,
    truncated: raw.length > body.length,
    text: `${lead}\n${body.slice(0, preview)}\n需要细节时用 context_search 或 context_read，不要把整段原文抄进回复。`,
  };
}

export function readParked(db, id) {
  const row = db.prepare("SELECT thread, name, body, bytes FROM kept WHERE id = ?").get(String(id || ""));
  if (!row) return { ok: false, unavailable: true, text: "上下文库里没有这段原文。" };
  return { ok: true, unavailable: false, threadId: row.thread, name: row.name, body: row.body, saved: row.body.length, original: row.bytes, truncated: row.bytes > row.body.length };
}

export function searchContext(db, threadId, query, limit = 5) {
  const needle = tokens(query);
  if (!needle) return [];
  const cap = Math.max(1, Math.min(8, Number(limit) || 5));
  return db.prepare(`SELECT kept.id, kept.name, substr(kept.body, 1, 180) AS preview
    FROM kept_fts JOIN kept ON kept.id = kept_fts.id
    WHERE kept.thread = ? AND kept_fts MATCH ?
    LIMIT ?`).all(String(threadId), needle, cap);
}

export function readContext(db, threadId, id, offset = 0, chars = 1600) {
  const row = db.prepare("SELECT body, bytes, name FROM kept WHERE id = ? AND thread = ?").get(String(id || ""), String(threadId));
  if (!row) return { ok: false, text: "没有这段上下文，或它属于另一条任务。" };
  const start = Math.max(0, Math.min(row.body.length, Number(offset) || 0));
  const size = Math.max(1, Math.min(READ_MAX, Number(chars) || 1600));
  return { ok: true, name: row.name, bytes: row.bytes, offset: start, text: row.body.slice(start, start + size) };
}

export function contextStats(db, threadId) {
  const row = db.prepare("SELECT COUNT(*) AS count, COALESCE(SUM(bytes), 0) AS bytes FROM kept WHERE thread = ?").get(String(threadId));
  return { count: row.count, bytes: row.bytes };
}
