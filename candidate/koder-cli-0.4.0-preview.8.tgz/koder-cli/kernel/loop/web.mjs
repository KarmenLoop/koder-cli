// Web search and page reading for the KARMEN LOOP kernel. No DeepSeek Harness client.
const LIMIT = 12_000;

export function pageText(html) {
  return String(html ?? "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#39;|&quot;/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, LIMIT);
}

export function parseDuckResults(html) {
  const hits = [];
  const pattern = /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  for (const match of String(html ?? "").matchAll(pattern)) {
    const title = pageText(match[2]).slice(0, 180);
    let url = match[1];
    const wrapped = /uddg=([^&"]+)/.exec(url);
    if (wrapped) {
      try {
        url = decodeURIComponent(wrapped[1]);
      } catch {
        url = wrapped[1];
      }
    }
    if (!title || !/^https?:\/\//.test(url)) continue;
    hits.push({ title, url });
    if (hits.length >= 8) break;
  }
  return hits;
}

function publicUrl(value) {
  let url;
  try {
    url = new URL(String(value ?? ""));
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  const host = url.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host === "0.0.0.0" || host === "::1") return null;
  if (/^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[0-1])\.)/.test(host)) return null;
  return url;
}

export async function searchWeb(query, fetchImpl = fetch) {
  const q = String(query ?? "").trim().slice(0, 300);
  if (!q) return "搜索需要一个关键词。";
  const headers = { "user-agent": "Koder/0.4", accept: "application/json,text/html" };
  const instant = await fetchImpl(`https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_html=1&skip_disambig=1`, {
    headers,
    signal: AbortSignal.timeout(12_000),
  }).then((response) => (response.ok ? response.json() : null), () => null);
  const lines = [];
  if (instant?.AbstractText) lines.push(instant.AbstractText);
  if (instant?.AbstractURL) lines.push(instant.AbstractURL);
  for (const topic of (instant?.RelatedTopics ?? []).slice(0, 8)) {
    if (topic?.Text) lines.push(`- ${topic.Text}${topic.FirstURL ? ` ${topic.FirstURL}` : ""}`);
  }
  if (lines.length) return lines.join("\n").slice(0, LIMIT);
  const html = await fetchImpl(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`, {
    headers: { ...headers, accept: "text/html" },
    signal: AbortSignal.timeout(12_000),
  }).then((response) => (response.ok ? response.text() : ""), () => "");
  const hits = parseDuckResults(html);
  if (!hits.length) return "没有搜到可用的结果。";
  return hits.map((hit) => `- ${hit.title}\n  ${hit.url}`).join("\n");
}

export async function fetchPage(address, fetchImpl = fetch) {
  const url = publicUrl(address);
  if (!url) return "只读取 http 或 https 的公开网页，不读取本机地址。";
  const response = await fetchImpl(url, {
    headers: { "user-agent": "Koder/0.4", accept: "text/html,text/plain" },
    redirect: "follow",
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) return `网页没有打开：${response.status}`;
  const type = response.headers.get("content-type") || "";
  const raw = await response.text();
  const text = /html|xml/.test(type) || raw.trimStart().startsWith("<") ? pageText(raw) : raw.replace(/\s+/g, " ").trim().slice(0, LIMIT);
  return `${url}\n\n${text || "（页面没有可读的文字）"}`;
}
