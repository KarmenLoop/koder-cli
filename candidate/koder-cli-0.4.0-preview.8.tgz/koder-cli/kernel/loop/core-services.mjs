// Trusted service registrations. Runtime messages select a name, never a path.
import fs from 'node:fs';
import path from 'node:path';
import {SERVICE_ABI,REPLACEABLE_SERVICES,serviceError} from './service-contracts.mjs';
import { fileURLToPath } from 'node:url';
import { createSupervisor } from './supervisor.mjs';
export const WORKER_NAMES = Object.freeze(['tools','model','gpu','web','measure','desktop','mcp','studio']);
export function createServices({env=process.env,modules={},runtimeKind='product'}={}) {
  if(!['product','connections'].includes(runtimeKind))throw serviceError('未知运行配置');
  if(runtimeKind==='connections') {
    for(const name of Object.keys(modules))if(name!=='storage')throw serviceError('连接宿主只允许替换受信任的存储端口');
    const replacement=modules.storage;
    if(replacement&&(replacement.apiVersion!==SERVICE_ABI||typeof replacement.file!=='string'||!path.isAbsolute(replacement.file)))throw serviceError('存储模块声明无效');
    const storageFile=replacement?.file||fileURLToPath(new URL('./workers/storage.mjs',import.meta.url));
    const stat=fs.lstatSync(storageFile);if(!stat.isFile()||stat.isSymbolicLink())throw serviceError('存储模块必须是常规文件');
    return new Map([
      ['storage',createSupervisor({name:'storage',env,file:storageFile,maxFrameBytes:40*1024*1024})],
      ['mcp',createSupervisor({name:'mcp',env,file:fileURLToPath(new URL('./workers/mcp.mjs',import.meta.url))})],
    ]);
  }
  const services = new Map(WORKER_NAMES.map(name => [name,createSupervisor({name,env,file:fileURLToPath(new URL(`./workers/${name}.mjs`,import.meta.url))})]));
  services.set('computer',createSupervisor({name:'computer',env,file:fileURLToPath(new URL('./workers/computer.mjs',import.meta.url)),cancellationGraceMs:15000,stopGraceMs:25000,killGraceMs:2000,maxFrameBytes:40*1024*1024}));
  services.set('system',createSupervisor({name:'system',env,file:fileURLToPath(new URL('./runtime-system-worker.mjs',import.meta.url))}));
  services.set('storage',createSupervisor({name:'storage',env,file:fileURLToPath(new URL('./workers/storage.mjs',import.meta.url)),maxFrameBytes:40*1024*1024}));
  for(const name of Object.keys(modules))if(!REPLACEABLE_SERVICES.includes(name))throw serviceError('不可替换的服务名称');
  for(const name of REPLACEABLE_SERVICES){
    const replacement=modules[name];
    if(replacement && (replacement.apiVersion!==SERVICE_ABI || typeof replacement.file!=='string' || !path.isAbsolute(replacement.file)))throw serviceError(`${name} 模块声明无效`);
    const file=replacement?.file || fileURLToPath(new URL(`./workers/${name}.mjs`,import.meta.url));
    const stat=fs.lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink())throw serviceError(`${name} 模块必须是常规文件`);
    services.set(name,createSupervisor({name,env,file}));
  }
  return services;
}

// Generic admission slots live in core; domain queues and prompts live in runtime.
export function createScheduler(limit=2) {
  const active=new Set(),waiting=[];
  const drain=()=>{while(active.size<limit&&waiting.length){const item=waiting.shift();active.add(item.id);item.resolve(item.id);}};
  return {
    acquire(id){if(active.has(id)||waiting.some(item=>item.id===id))return Promise.reject(Object.assign(new Error('重复调度请求'),{code:'DUPLICATE'}));return new Promise(resolve=>{waiting.push({id,resolve});drain();});},
    release(id){active.delete(id);drain();},
    clear(){active.clear();for(const item of waiting.splice(0))item.resolve(null);},
    info(){return {limit,active:active.size,queued:waiting.length};}
  };
}
