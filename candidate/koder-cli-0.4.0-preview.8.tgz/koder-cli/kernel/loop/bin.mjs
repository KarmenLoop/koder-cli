#!/usr/bin/env node
// KARMEN LOOP core entry. Product runtime and service processes are children.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {writeFileJson} from './json-store.mjs';
import { fileURLToPath } from 'node:url';
export async function runCore({serviceModules={}}={}) {
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dataDir=process.env.KODER_DATA?path.resolve(process.env.KODER_DATA):path.join(root,'data');
const workspace=process.env.KODER_WORKSPACE?path.resolve(process.env.KODER_WORKSPACE):path.join(root,'workspace');
const requested=Number(process.env.KODER_PORT||0);
const gate=process.env.KODER_GATE_FILE?fs.readFileSync(process.env.KODER_GATE_FILE,'utf8').trim():'';
const runtimeKind=process.env.KODER_RUNTIME_KIND||'product';
const scope=runtimeKind==='connections'?JSON.parse(process.env.KODER_APP_SCOPE||'null'):null;
const ownerGeneration=process.env.KODER_APP_GENERATION||null;
const initialClient=runtimeKind==='connections'?JSON.parse(process.env.KODER_APP_INITIAL_CLIENT||'null'):null;
const startup=new AbortController();
let kernel,stopping;
const stop=()=>{
  startup.abort();
  if(kernel)stopping ||= kernel.close().then(receipt=>{process.exitCode=receipt.ok?0:1;}).catch(error=>{process.stderr.write(`${error.message}\n`);process.exitCode=1;});
  return stopping;
};
process.on('SIGINT',stop);process.on('SIGTERM',stop);
process.stdout.write('Koder core starting\n');
try{
  const {startLoop}=await import('./kernel.mjs');
  kernel=await startLoop({root,dataDir,workspace,port:Number.isInteger(requested)?requested:0,gate,serviceModules,runtimeKind,scope,ownerGeneration,initialClient,signal:startup.signal,onClosed:async receipt=>{
    if(runtimeKind==='connections')await writeFileJson(path.join(dataDir,'app-host-closed.json'),{version:1,host:os.hostname(),pid:process.pid,generation:ownerGeneration,receipt});
  }});
  if(startup.signal.aborted)await stop();
  else {
    if(runtimeKind==='connections')await writeFileJson(path.join(dataDir,'app-host.json'),{version:1,host:os.hostname(),pid:process.pid,generation:ownerGeneration,scope,gate,port:kernel.port});
    process.stdout.write(`Koder http://127.0.0.1:${kernel.port}\n`);
  }
}catch(error){
  if(error.name==='AbortError'&&error.cleanupComplete===true)process.exitCode=0;
  else{process.stderr.write(`${error.stack||error.message}\n`);process.exitCode=1;}
}

}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))await runCore();
