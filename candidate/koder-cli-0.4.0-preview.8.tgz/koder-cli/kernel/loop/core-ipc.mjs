// Small shared wire format. No product code or private data is imported here.
export const MAX_FRAME_BYTES = 40 * 1024 * 1024;
export function wireError(error) {
  const result={message:String(error?.message||'请求失败')};
  for(const key of ['name','code','cleanupComplete','exitConfirmed','effectsMayHaveCompleted','forced'])if(error?.[key]!==undefined)result[key]=error[key];
  return result;
}
export function fromError(error){return Object.assign(new Error(error?.message||'请求失败'),error);}
export function sendIpc(peer,message){
  return new Promise((resolve,reject)=>{
    if(!peer.connected)return reject(Object.assign(new Error('IPC 已断开'),{code:'IPC_CLOSED'}));
    let size;try{size=Buffer.byteLength(JSON.stringify(message));}catch(error){return reject(error);}
    if(size>MAX_FRAME_BYTES)return reject(Object.assign(new Error('IPC 消息过大'),{code:'IPC_SIZE'}));
    try{peer.send(message,error=>error?reject(error):resolve());}catch(error){reject(error);}
  });
}
