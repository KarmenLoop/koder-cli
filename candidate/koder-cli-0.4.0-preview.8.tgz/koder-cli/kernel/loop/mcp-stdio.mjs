import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { ReadBuffer, serializeMessage } from '@modelcontextprotocol/sdk/shared/stdio.js';
import { fileURLToPath } from 'node:url';
import { sdkClient } from '../fusion/mcp-sdk.mjs';

export const frame = (message) => Buffer.from(serializeMessage(message));
export function createFramer(onMessage) {
  const buffer = new ReadBuffer({ maxBufferSize: 20 * 1024 * 1024 });
  return (chunk) => {
    buffer.append(chunk);
    let message;
    while ((message = buffer.readMessage()) !== null) onMessage(message);
  };
}
export function connectStdio({ command, args = [], env = {}, cwd = '', timeoutMs }) {
  let receipt = null, diagnostics = '';
  const transport = new StdioClientTransport({
    command: process.execPath, args: [fileURLToPath(new URL('./mcp-owned-stdio.mjs', import.meta.url)), JSON.stringify({ command, args, cwd })], cwd: cwd || undefined, stderr: 'pipe', maxBufferSize: 20 * 1024 * 1024,
    env: { ...(process.versions.electron ? { ELECTRON_RUN_AS_NODE: '1' } : {}), ...env },
  });
  transport.stderr?.on('data', (chunk) => {
    diagnostics = (diagnostics + chunk.toString('utf8')).slice(-4096);
    for (const line of diagnostics.split('\n')) if (line.startsWith('KODER_MCP_CLEANUP ')) { try { receipt = JSON.parse(line.slice(18)); } catch {} }
  });
  return sdkClient(transport, { timeoutMs, closeTransport: async () => {
    const pid = transport.pid;
    await transport.close();
    if (!pid) return { cleanupComplete: true };
    const until = Date.now() + 1000;
    while (Date.now() < until) {
      try { process.kill(pid, 0); } catch (error) { if (error.code === 'ESRCH') return { cleanupComplete: receipt?.cleanupComplete === true }; }
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    return { cleanupComplete: false };
  } });
}
