import {modelRecoveryHints} from '../harness/provider-errors.mjs';

// A cancelled request acknowledges only after its operation has settled and
// cleanup has finished. Other requests keep their own independent controllers.
export function createRequestHandler({ perform, post }) {
  const requests = new Map();
  let closed = false;
  let cleanupFailed = false;
  return {
    async handle(message) {
      if (!message || typeof message !== 'object') return;
      if (message.op === 'cancel') {
        requests.get(message.targetId)?.controller.abort();
        return;
      }
      if (!Number.isSafeInteger(message.id) || message.id <= 0) return;
      if (closed || requests.has(message.id)) {
        post({ id: message.id, ok: false, error: '请求已关闭或重复' });
        return;
      }
      const controller = new AbortController();
      let resolveDone;
      const done = new Promise((resolve) => { resolveDone = resolve; });
      const entry = { controller, done };
      requests.set(message.id, entry);
      const reply = (body) => {
        if (requests.get(message.id) === entry && !controller.signal.aborted) post({ id: message.id, ...body });
      };
      let result, failure;
      try {
        result = await perform(message, controller.signal, (delta) => reply({ delta: String(delta ?? '') }));
        reply({ ok: true, result });
      } catch (error) {
        failure = error;
        reply({ ok: false, error: error?.message || '请求没有完成', code: error?.code, ...modelRecoveryHints(error), ...(error?.cleanupComplete !== undefined ? {cleanupComplete:error.cleanupComplete} : {}), ...(error?.effectsMayHaveCompleted !== undefined ? {effectsMayHaveCompleted:error.effectsMayHaveCompleted} : {}) });
      } finally {
        const cleanupComplete = result?.cleanupComplete !== false && failure?.cleanupComplete !== false;
        cleanupFailed ||= !cleanupComplete;
        if (controller.signal.aborted) post({ id: message.id, cancelled: true, cleanupComplete, effectsMayHaveCompleted: message.op === 'apply' || result?.effectsMayHaveCompleted === true || result?.uncertain === true || failure?.effectsMayHaveCompleted === true });
        if (requests.get(message.id) === entry) requests.delete(message.id);
        resolveDone();
      }
    },
    async close() {
      closed = true;
      const active = [...requests.values()];
      for (const entry of active) entry.controller.abort();
      await Promise.all(active.map((entry) => entry.done));
      return { cleanupComplete: !cleanupFailed };
    },
    get size() { return requests.size; },
  };
}
