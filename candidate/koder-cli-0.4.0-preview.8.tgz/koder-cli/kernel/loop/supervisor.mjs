// Each request owns its timeout and cancellation. Settlement waits for a
// terminal acknowledgement; unresponsive workers are retired within bounds.
import { execFile, spawn } from 'node:child_process';

export function readProcessRss(pid, { platform = process.platform, execFileImpl = execFile } = {}) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return Promise.resolve(0);
  const windows = platform === 'win32';
  const file = windows ? 'tasklist.exe' : '/bin/ps';
  const args = windows ? ['/FI', `PID eq ${pid}`, '/FO', 'CSV', '/NH'] : ['-o', 'rss=', '-p', String(pid)];
  return new Promise((resolve, reject) => {
    execFileImpl(file, args, { timeout: 1000, maxBuffer: 16 * 1024, windowsHide: true }, (error, stdout) => {
      if (error) return reject(error);
      const value = String(stdout).trim();
      const field = windows ? value.match(/^"(?:[^"]|"")*","(\d+)","(?:[^"]|"")*","(?:[^"]|"")*","([^"\r\n]+)"$/m) : null;
      const kb = windows ? (field && Number(field[1]) === pid ? Number(field[2].replace(/[^\d]/g, '')) : NaN) : Number(value);
      if (!Number.isFinite(kb) || kb < 0 || !value) return reject(new Error('无法读取工作进程内存'));
      resolve(kb * 1024);
    });
  });
}

function abortError(signal) {
  return Object.assign(new Error(signal?.reason?.message || '请求已取消'), { name: 'AbortError', code: 'ABORT_ERR' });
}

export function createSupervisor({ file, name, node = process.execPath, env = process.env, spawnImpl = spawn, rss = readProcessRss, rssLimit = 768 * 1024 * 1024, rssIntervalMs = 1000, stopGraceMs = 2000, killGraceMs = 1000, cancellationGraceMs = 2000, maxFrameBytes = 8 * 1024 * 1024 }) {
  let child = null;
  let closed = false;
  let seq = 0;
  let restarts = 0;
  let state = 'down';
  let lastRss = null;
  let rssError = null;
  const pending = new Map();
  const retiring = new Set();
  const unconfirmed = new Set();

  function clearWaiter(waiter) {
    clearTimeout(waiter.timer);
    clearTimeout(waiter.cancelTimer);
    waiter.signal?.removeEventListener('abort', waiter.onAbort);
  }

  function settle(id, error, result) {
    const waiter = pending.get(id);
    if (!waiter) return;
    pending.delete(id);
    clearWaiter(waiter);
    if (error) waiter.reject(error); else waiter.resolve(result);
  }

  function retire(proc, error, { terminate = true } = {}) {
    if (proc.retiring) return proc.retiring;
    if (child === proc) {
      child = null;
      state = 'down';
      restarts += 1;
    }
    clearTimeout(proc.rssTimer);
    const active = [...pending.values()].filter((waiter) => waiter.proc === proc);
    for (const waiter of active) clearWaiter(waiter);
    let resolveRetirement;
    proc.retiring = new Promise((resolve) => { resolveRetirement = resolve; });
    retiring.add(proc);
    let finished = false;
    let forceTimer;
    let finalTimer;
    let forced = false;
    const finish = (exitConfirmed) => {
      if (finished) return;
      finished = true;
      clearTimeout(forceTimer);
      clearTimeout(finalTimer);
      const cleanupComplete = exitConfirmed && proc.exited && !forced && !proc.cleanupFailed && (!active.length || proc.shutdownReceipt?.cleanupComplete === true);
      const receipt = { ok: exitConfirmed && cleanupComplete, exitConfirmed, cleanupComplete, forced };
      for (const [id, waiter] of pending) {
        if (waiter.proc !== proc) continue;
        const cause = waiter.cancelError || error;
        settle(id, Object.assign(new Error(cause.message), { name: cause.name, code: cause.code, ...receipt }));
      }
      retiring.delete(proc);
      if (!exitConfirmed) unconfirmed.add(proc);
      resolveRetirement(receipt);
    };
    proc.once('workerExit', () => finish(true));
    if (proc.exited) { finish(true); return proc.retiring; }
    if (terminate) {
      // Queue cooperative shutdown even while the child is loading imports.
      // An immediate SIGTERM can arrive before its handlers exist and kill the
      // process before it reads this frame or acknowledges owned cleanup.
      try { proc.stdin.write(`${JSON.stringify({ op: 'shutdown' })}\n`, () => {}); } catch {}
      if (finished) return proc.retiring;
      forceTimer = setTimeout(() => {
        forced = true;
        try { proc.kill('SIGKILL'); } catch {}
      }, stopGraceMs);
    }
    finalTimer = setTimeout(() => finish(proc.exitObserved === true), stopGraceMs + killGraceMs);
    return proc.retiring;
  }

  async function checkMemory(proc) {
    if (child !== proc) return;
    if (proc.rssCheck) return proc.rssCheck;
    proc.rssCheck = (async () => {
      let used;
      try { used = await rss(proc.pid); }
      catch (error) {
        if (child === proc) rssError = error.message || '无法读取工作进程内存';
        return;
      }
      if (child !== proc) return;
      lastRss = used;
      rssError = null;
      if (used > rssLimit) {
        const error = new Error(`${name} 超过内存上限，已停下`);
        const receipt = await retire(proc, error);
        throw Object.assign(error, receipt);
      }
    })();
    try { await proc.rssCheck; } finally { proc.rssCheck = null; }
  }

  function monitor(proc) {
    if (proc.rssTimer || child !== proc || ![...pending.values()].some((waiter) => waiter.proc === proc)) return;
    proc.rssTimer = setTimeout(async () => {
      proc.rssTimer = null;
      try { await checkMemory(proc); } catch {}
      monitor(proc);
    }, Math.max(10, rssIntervalMs));
    proc.rssTimer.unref?.();
  }

  function send(proc, message) {
    try {
      proc.stdin.write(`${JSON.stringify(message)}\n`, (error) => {
        if (error) void retire(proc, new Error(`${name} 输入通道关闭：${error.message}`));
      });
    } catch (error) {
      void retire(proc, new Error(`${name} 输入通道关闭：${error.message}`));
    }
  }

  function launch() {
    const proc = spawnImpl(node, [file], { stdio: ['pipe', 'pipe', 'ignore'], windowsHide: true, env });
    child = proc;
    state = 'up';
    lastRss = null;
    rssError = null;
    let buffer = '';
    const exited = () => {
      if (proc.exited) return;
      proc.exited = true;
      unconfirmed.delete(proc);
      proc.exitObserved = true;
      proc.emit('workerExit');
      if (!proc.retiring) void retire(proc, new Error(`${name} 进程退出了`), { terminate: false });
    };
    const failed = (error) => {
      if (!proc.pid) proc.exited = true; // spawn failure has no operating-system process.
      void retire(proc, new Error(`${name} 进程或通道错误：${error.message}`));
    };
    proc.on('error', failed);
    proc.stdin.on('error', failed);
    proc.stdout.on('error', failed);
    proc.stdout.on('data', (chunk) => {
      buffer += chunk.toString('utf8');
      if (Buffer.byteLength(buffer) > maxFrameBytes) {
        void retire(proc, new Error(`${name} 响应超过大小上限`));
        return;
      }
      let cut;
      while ((cut = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, cut);
        buffer = buffer.slice(cut + 1);
        if (!line.trim()) continue;
        let message;
        try { message = JSON.parse(line); } catch { continue; }
        if (message.control === 'shutdown') {
          proc.shutdownReceipt = message;
          continue;
        }
        if (proc.retiring) continue;
        const waiter = pending.get(message.id);
        if (!waiter || waiter.proc !== proc) continue;
        if (typeof message.delta === 'string') {
          if (waiter.cancelError) continue;
          try { waiter.onDelta?.(message.delta); }
          catch (error) { waiter.cancel(error); }
          continue;
        }
        if (waiter.cancelError) {
          const cleanupComplete = message.cancelled ? message.cleanupComplete === true : message.result?.cleanupComplete !== false;
          if (!cleanupComplete) {
            proc.cleanupFailed = true;
            void retire(proc, waiter.cancelError);
          } else {
            settle(message.id, Object.assign(waiter.cancelError, { cleanupComplete: true, effectsMayHaveCompleted: message.effectsMayHaveCompleted === true }));
          }
        } else if (message.ok) settle(message.id, null, message.result);
        else settle(message.id, Object.assign(new Error(message.error || `${name} 没有完成`), { code: message.code, ...(message.cleanupComplete !== undefined ? {cleanupComplete:message.cleanupComplete} : {}), ...(message.effectsMayHaveCompleted !== undefined ? {effectsMayHaveCompleted:message.effectsMayHaveCompleted} : {}) }));
      }
    });
    proc.on('exit', () => {
      proc.exitObserved = true;
      if (!proc.retiring) void retire(proc, new Error(`${name} 进程退出了`), { terminate: false });
    });
    proc.on('close', exited);
    return proc;
  }

  async function stop() {
    const waits = new Set([...retiring].map((proc) => proc.retiring));
    if (child) waits.add(retire(child, new Error(`${name} 已停下`)));
    const receipts = await Promise.all(waits);
    for (const proc of unconfirmed) receipts.push({ ok: false, exitConfirmed: false, cleanupComplete: false, forced: true });
    return { ok: receipts.every((item) => item.ok), exitConfirmed: receipts.every((item) => item.exitConfirmed), cleanupComplete: receipts.every((item) => item.cleanupComplete), forced: receipts.some((item) => item.forced) };
  }

  function closedError() {
    return Object.assign(new Error(`${name} 已关闭`), { code: "WORKER_CLOSED", cleanupComplete: true });
  }

  // stop() retires one generation and the next call may start another.
  // close() is only the runtime shutdown latch: nothing may launch after it.
  async function close() {
    closed = true;
    return stop();
  }

  function waitForRetirement(signal) {
    return new Promise((resolve, reject) => {
      const finish = (error) => {
        signal?.removeEventListener('abort', onAbort);
        if (error) reject(error); else resolve();
      };
      // This request has not reached a worker, so cancelling the wait has no effects.
      const onAbort = () => finish(Object.assign(abortError(signal), { cleanupComplete: true }));
      signal?.addEventListener('abort', onAbort, { once: true });
      Promise.all([...retiring].map(proc => proc.retiring)).then(() => finish(), finish);
      if (signal?.aborted) onAbort();
    });
  }

  return {
    info() { return { name, pid:child?.pid || null, state, restarts, inflight: pending.size, retiring: retiring.size, unconfirmed: unconfirmed.size, rssBytes: lastRss, rssError }; },
    async call(message, timeoutMs = 60_000, { onDelta = null, signal } = {}) {
      let proc;
      for (;;) {
        if (closed) throw closedError();
        if (unconfirmed.size) throw Object.assign(new Error(`${name} 旧进程退出尚未确认`), { code: 'WORKER_EXIT_UNCONFIRMED', cleanupComplete: false, exitConfirmed: false });
        if (signal?.aborted) throw Object.assign(abortError(signal), { cleanupComplete: true });
        if (retiring.size) { await waitForRetirement(signal); continue; }
        const observed = child;
        if (observed) await checkMemory(observed);
        if (closed) throw closedError();
        if (signal?.aborted) throw Object.assign(abortError(signal), { cleanupComplete: true });
        // stop() may have retired this generation during the memory check.
        if (retiring.size || observed !== child) continue;
        proc = child && child.exitCode === null ? child : launch();
        if (closed) {
          void retire(proc, closedError());
          throw closedError();
        }
        break;
      }
      const id = ++seq;
      return new Promise((resolve, reject) => {
        const cancel = (error) => {
          const waiter = pending.get(id);
          if (!waiter || waiter.cancelError || proc.retiring) return;
          waiter.cancelError = error;
          clearTimeout(waiter.timer);
          waiter.cancelTimer = setTimeout(() => {
            // No terminal acknowledgement: unknown/legacy workers must not run forever.
            void retire(proc, new Error(`${name} 没有确认取消，已关闭工作进程`));
          }, cancellationGraceMs);
          if (child === proc) send(proc, { op: 'cancel', targetId: id });
        };
        const timer = setTimeout(() => cancel(Object.assign(new Error(`${name} 超时`), { code: 'ETIMEDOUT' })), timeoutMs);
        const onAbort = () => cancel(abortError(signal));
        pending.set(id, { proc, resolve, reject, timer, onDelta, signal, onAbort, cancel });
        signal?.addEventListener('abort', onAbort, { once: true });
        if (signal?.aborted) return settle(id, Object.assign(abortError(signal), { cleanupComplete: true }));
        send(proc, { ...message, id });
        monitor(proc);
      });
    },
    stop,
    close,
    interrupt: stop,
  };
}
