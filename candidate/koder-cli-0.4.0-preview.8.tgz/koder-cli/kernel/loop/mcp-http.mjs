import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { isLoopbackHost } from '../fusion/browser-page.mjs';
import { sdkClient } from '../fusion/mcp-sdk.mjs';

export function safeMcpUrl(input, { bearer = false } = {}) {
  const url = new URL(String(input || ''));
  if (url.username || url.password) throw new Error('MCP 地址里不能带账号密码');
  if (url.protocol === 'https:') return url;
  if (url.protocol === 'http:' && isLoopbackHost(url.hostname) && !bearer) return url;
  if (bearer) throw new Error('带令牌的远程 MCP 必须用 HTTPS');
  throw new Error('远程 MCP 用 HTTPS；本机预览可用 http://127.0.0.1');
}
export function connectHttp({ url, headers = {}, fetchImpl = fetch, authProvider, getHeaders, timeoutMs = 20_000 }) {
  const target = safeMcpUrl(url, { bearer: Boolean(headers.Authorization || headers.authorization || authProvider || getHeaders) });
  for (const value of Object.values(headers)) if (/[\r\n]/.test(String(value))) throw new Error('MCP 请求头不合法');
  const transport = new StreamableHTTPClientTransport(target, {
    requestInit: { headers, redirect: 'error' }, authProvider,
    reconnectionOptions: { maxRetries: 1, maxReconnectionDelay: 1000, initialReconnectionDelay: 500, reconnectionDelayGrowFactor: 1 },
    fetch: async (input, init = {}) => {
      if (new URL(typeof input === 'string' || input instanceof URL ? input : input.url).origin !== target.origin) throw new Error('MCP transport 跨源请求被拒绝');
      const dynamic = getHeaders ? await getHeaders({ signal: init.signal }) : {};
      let response = await fetchImpl(input, { ...init, headers: { ...Object.fromEntries(new Headers(init.headers)), ...dynamic }, redirect: 'error' });
      if (response.status === 401 && getHeaders) {
        await response.body?.cancel();
        const refreshed = await getHeaders({ forceRefresh: true, rejectedAuthorization: dynamic.Authorization, signal: init.signal });
        response = await fetchImpl(input, { ...init, headers: { ...Object.fromEntries(new Headers(init.headers)), ...refreshed }, redirect: 'error' });
      }
      if (response.redirected) throw new Error('MCP 连接拒绝重定向');
      return response;
    },
  });
  return sdkClient(transport, { timeoutMs, closeTransport: async () => {
    let cleanupComplete = true;
    try { if (transport.sessionId) await Promise.race([transport.terminateSession(), new Promise((_, reject) => setTimeout(() => reject(new Error('MCP session close timed out')), 2000).unref())]); }
    catch { cleanupComplete = false; }
    await transport.close();
    return { cleanupComplete };
  } });
}
