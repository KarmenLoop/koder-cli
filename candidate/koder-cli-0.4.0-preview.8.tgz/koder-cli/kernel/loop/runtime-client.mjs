// Runtime may request registered services, but cannot select executables or spawn workers.
import { fromError, sendIpc } from './core-ipc.mjs';
export function createRuntimeClient({peer=process,epoch}) {
  let sequence=0,closed=false;const pending=new Map(),info=new Map();
  const rejectAll=()=>{closed=true;for(const item of pending.values()){item.signal?.removeEventListener('abort',item.abort);item.reject(Object.assign(new Error('Core IPC 已断开'),{code:'IPC_CLOSED',cleanupComplete:false}));}pending.clear();};
  peer.on('disconnect',rejectAll);
  peer.on('message',message=>{
    if(message?.epoch!==epoch||message.type!=='service-result')return;
    const item=pending.get(message.id);if(!item)return;
    if(message.info)info.set(item.service,message.info);
    if(typeof message.delta==='string'){try{item.onDelta?.(message.delta);}catch{item.abort();}return;}
    pending.delete(message.id);item.signal?.removeEventListener('abort',item.abort);
    if(message.error)item.reject(fromError(message.error));else item.resolve(message.result);
  });
  function request(service,action,payload,timeoutMs,{signal,onDelta}={}) {
    if(closed||signal?.aborted)return Promise.reject(Object.assign(new Error('请求已取消或 IPC 已关闭'),{name:'AbortError',code:'ABORT_ERR',cleanupComplete:true}));
    const id=++sequence;
    return new Promise((resolve,reject)=>{
      const abort=()=>{void sendIpc(peer,{type:'service-cancel',epoch,id}).catch(rejectAll);};
      pending.set(id,{resolve,reject,signal,onDelta,abort,service});signal?.addEventListener('abort',abort,{once:true});
      void sendIpc(peer,{type:'service',epoch,id,service,action,payload,timeoutMs}).catch(error=>{const item=pending.get(id);if(!item)return;pending.delete(id);signal?.removeEventListener('abort',abort);reject(error);});
    });
  }
  return {
    worker(name){return {call:(message,timeout=60000,options)=>request(name,'call',message,timeout,options),stop:()=>request(name,'stop',null,10000),info:()=>info.get(name)||{name,state:'down',restarts:0,inflight:0}};},
    async acquire(token){const id=await request('$schedule','acquire',{token},60000);if(!id)throw new Error('调度已停止');return ()=>request('$schedule','release',{token},10000);},
    close:rejectAll,
  };
}
