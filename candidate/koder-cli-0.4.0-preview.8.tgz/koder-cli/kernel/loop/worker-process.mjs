// Execute an argv vector in an owned process group, retaining separate output
// streams for parsers and waiting for descendant cleanup before returning.
import { spawn } from 'node:child_process';
import { runOwnedCommand } from '../harness/process-control.mjs';
export async function runWorkerFile(file,args,{cwd,env=process.env,signal,timeout=20000,maxBuffer=16*1024*1024}={}) {
 let stdout='',stderr='',launched=false;
 const result=await runOwnedCommand({cwd,command:'',signal,env,timeoutMs:timeout,maxOutput:maxBuffer,spawnImpl:(_file,_args,options)=>{
  if(launched)return spawn(_file,_args,options);
  launched=true;
  const child=spawn(file,args,{...options,windowsVerbatimArguments:false});
  child.stdout?.on('data',chunk=>{stdout=(stdout+chunk).slice(-maxBuffer);});child.stderr?.on('data',chunk=>{stderr=(stderr+chunk).slice(-maxBuffer);});return child;
 }});
 if(!result.ok)throw Object.assign(new Error(result.content||'子进程失败'),{code:result.aborted?'ABORT_ERR':result.timedOut?'ETIMEDOUT':result.exitCode,name:result.aborted?'AbortError':'Error',stdout,stderr,...result});
 return {...result,stdout,stderr};
}
export function workerExec(signal){const exec=(file,args,options,callback)=>{void runWorkerFile(file,args,{...options,signal}).then(value=>callback(null,value.stdout,value.stderr),error=>{if(error.cleanupComplete===false)exec.cleanupComplete=false;callback(error,error.stdout||'',error.stderr||'');});};exec.cleanupComplete=true;return exec;}
