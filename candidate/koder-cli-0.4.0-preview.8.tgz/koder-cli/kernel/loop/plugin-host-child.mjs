import fs from "node:fs/promises";
import readline from "node:readline";

const lines = readline.createInterface({ input: process.stdin });
const held = new Map();
function send(message) {
  process.stdout.write(`${JSON.stringify(message)}\n`);
}
lines.on("line", (line) => {
  let message;
  try { message = JSON.parse(line); } catch { return; }
  if (message.op === "cancel") {
    const pending = held.get(message.target);
    if (!pending) return;
    held.delete(message.target);
    clearTimeout(pending.timer);
    send({ id: message.target, ok: false, cancelled: true });
    return;
  }
  if (message.op === "release") {
    const pending = held.get(message.target);
    if (!pending) return;
    held.delete(message.target);
    clearTimeout(pending.timer);
    pending.reply();
    return;
  }
  if (message.op === "propose-note") {
    const reply = () => send({
      id: message.id,
      ok: true,
      proposal: {
        name: String(message.name || "note").replace(/[^a-z0-9.-]/gi, "").slice(0, 40) || "note",
        text: String(message.text || "").slice(0, 4000),
      },
    });
    if (message.hold === true) {
      send({ id: message.id, started: true });
      const timer = setTimeout(() => {
        if (!held.has(message.id)) return;
        held.delete(message.id);
        send({ id: message.id, ok: false, cancelled: true, reason: "hold expired" });
      }, 30_000);
      held.set(message.id, { reply, timer });
      return;
    }
    reply();
    return;
  }
  if (message.op === "write-note") {
    fs.writeFile(message.path, String(message.text || ""), "utf8").then(() => {
      process.stdout.write(`${JSON.stringify({ id: message.id, ok: true, bytes: Buffer.byteLength(String(message.text || "")) })}\n`);
    }).catch((error) => {
      process.stdout.write(`${JSON.stringify({ id: message.id, ok: false, error: error.message })}\n`);
    });
    return;
  }
  if (message.op === "crash") process.exit(1);
  process.stdout.write(`${JSON.stringify({ id: message.id, ok: false, error: "没有这个插件操作" })}\n`);
});
