// The official SDK launches this owned supervisor. JSON-RPC bytes pass through
// untouched; only this process owns and terminates the server process group.
import spawn from 'cross-spawn';

let config;
try { config = JSON.parse(process.argv[2]); if (typeof config.command !== 'string' || !Array.isArray(config.args)) throw new Error(); }
catch { process.stderr.write('KODER_MCP_CLEANUP {"cleanupComplete":true,"spawnFailed":true}\n'); process.exit(1); }
const windows = process.platform === 'win32';
let child, closed = false, exitCode = null, stopping = false, finished = false, failed = false;
let grace, escalation, deadline, poll, killer, windowsTreeGone = false;
const alive = () => {
  if (!child?.pid) return false;
  if (windows) return !windowsTreeGone;
  try { process.kill(-child.pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; }
};
function finish(cleanupComplete) {
  if (finished) return; finished = true;
  for (const timer of [grace, escalation, deadline, poll]) clearTimeout(timer);
  process.stdin.unpipe(); process.stdin.pause(); child?.stdout?.unpipe();
  const receipt = { cleanupComplete, exitCode };
  process.stderr.write(`KODER_MCP_CLEANUP ${JSON.stringify(receipt)}\n`, () => process.exit(cleanupComplete ? (exitCode || 0) : 2));
}
function check() {
  if (finished) return;
  if (closed && !alive()) return finish(!failed);
  poll = setTimeout(check, 20);
}
function kill(force = false) {
  if (!child?.pid || finished) return;
  if (windows) {
    if (killer) return;
    killer = spawn(`${process.env.SystemRoot || 'C:\\Windows'}\\System32\\taskkill.exe`, ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
    const timeout = setTimeout(() => { failed = true; killer.kill(); }, 700);
    killer.once('error', () => { failed = true; clearTimeout(timeout); });
    killer.once('close', (code) => { clearTimeout(timeout); windowsTreeGone = code === 0; if (code !== 0) failed = true; });
    return;
  }
  try { process.kill(-child.pid, force ? 'SIGKILL' : 'SIGTERM'); } catch (error) { if (error.code !== 'ESRCH') failed = true; }
}
function stop() {
  if (stopping) return; stopping = true;
  process.stdin.unpipe(child?.stdin);
  if (windows) kill(true); // taskkill /T needs the owned root while it is alive.
  child?.stdin?.end();
  // Give normal protocol EOF a brief opportunity, then stop the owned tree.
  grace = setTimeout(() => { if (alive()) kill(); }, 300);
  escalation = setTimeout(() => { if (alive()) kill(true); }, 550);
  deadline = setTimeout(() => { if (alive()) kill(true); finish(closed && !alive() && !failed); }, 1500);
  check();
}
try {
  child = spawn(config.command, config.args, { cwd: config.cwd || undefined, env: process.env, detached: !windows, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  child.stderr.resume(); // never mix untrusted stderr with supervisor receipts
  child.stdout.pipe(process.stdout); process.stdin.pipe(child.stdin);
  child.stdin.on('error', () => stop()); child.stdout.on('error', () => { failed = true; stop(); });
  child.once('error', () => { failed = true; if (!child.pid) { closed = true; finish(true); } else stop(); });
  child.once('exit', (code) => { exitCode = code; stop(); });
  child.once('close', () => { closed = true; if (stopping) check(); else stop(); });
} catch { closed = true; finish(true); }
process.stdin.once('end', stop); process.stdin.once('error', stop);
process.stdout.once('error', stop);
process.once('SIGTERM', stop); process.once('SIGINT', stop);
