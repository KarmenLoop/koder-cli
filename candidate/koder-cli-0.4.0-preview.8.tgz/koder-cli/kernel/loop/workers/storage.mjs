import {createStorageService} from '../storage-service.mjs';
import {openMemoryCredentials} from '../../fusion/native-credentials.mjs';
import {createPersonalizationLock} from '../../fusion/protected-lock.mjs';
import {withPrivateLease} from '../../fusion/private-lease.mjs';
import {serveWorker} from '../worker-stdio.mjs';
let service;
serveWorker(async(message,signal)=>{
 service ||= (async()=>{
   const dir=process.env.KODER_DATA;
   let lock;
   if(process.env.KODER_RUNTIME_KIND==='connections')lock=await createPersonalizationLock({credentials:openMemoryCredentials({dir,namespace:'apps'}),scope:dir,withLease:work=>withPrivateLease(dir,'apps-protected-key',work)});
   return createStorageService({dir,lock});
 })().catch(error=>{service=null;throw error;});
 const ready=await service;
 return ready.perform(message,signal);
});
