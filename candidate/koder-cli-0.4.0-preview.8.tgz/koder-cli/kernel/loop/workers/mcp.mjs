import readline from 'node:readline';
import { pathToFileURL } from 'node:url';
import { connectHttp } from '../mcp-http.mjs';
import { connectStdio } from '../mcp-stdio.mjs';
import { startPluginHost } from '../plugin-host.mjs';
import { createRequestHandler } from '../worker-requests.mjs';
import {randomUUID} from 'node:crypto';

export async function oauthHeaders(id, { forceRefresh = false, rejectedAuthorization, signal } = {}, { url = process.env.KODER_WORKBENCH_URL, token = process.env.KODER_WORKBENCH_TOKEN, fetchImpl = fetch } = {}) {
  const target = new URL(url);
  if (target.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(target.hostname) || target.username || target.password || !token) throw new Error('MCP 授权桥不可用');
  target.pathname = '/api/internal/mcp-headers'; target.search = ''; target.hash = '';
  const response = await fetchImpl(target, { method: 'POST', redirect: 'error', headers: { 'content-type': 'application/json', 'x-koder-workbench': token, 'x-koder-gate': token }, body: JSON.stringify({ id, forceRefresh, rejectedAuthorization }), signal: AbortSignal.any([AbortSignal.timeout(30_000), ...(signal ? [signal] : [])]) });
  if (!response.ok || response.redirected) throw Object.assign(new Error('MCP 授权不可用，请重新授权'), { code: 'MCP_AUTH_REQUIRED' });
  const body = await response.json();
  const authorization = body?.headers?.Authorization;
  if (typeof authorization !== 'string' || !authorization.startsWith('Bearer ') || /[\r\n]/.test(authorization)) throw new Error('MCP 授权桥返回无效');
  return { Authorization: authorization };
}

export function createMcpHandler({ post, stdio = connectStdio, http = connectHttp, nativeHost = startPluginHost } = {}) {
  const live = new Map(), pending = new Set(), generations = new Map(), closingClients = new Map(), unsettled = new Map(), retiring = new Set(), lanes = new Map();
  let closing = false;
  async function catalog(client, signal) {
    // A notification invalidates immediately, including while a list is loading.
    const version = client.catalogVersion;
    if (client.catalog) return client.catalog;
    const tools = new Map(), cursors = new Set();
    let cursor;
    if (client.capabilities.tools) for (let page = 0; page < 50; page++) {
      const listed = await client.request('tools/list', cursor ? {cursor} : {}, {signal});
      for (const tool of listed.tools) {
        const old = tools.get(tool.name);
        if (old && JSON.stringify(old) !== JSON.stringify(tool)) throw Object.assign(new Error('MCP 工具名称重复且定义冲突'),{code:'MCP_TOOL_CONFLICT'});
        tools.set(tool.name,tool);
      }
      cursor = listed.nextCursor;
      if (!cursor) break;
      if (cursors.has(cursor)) throw Object.assign(new Error('MCP 分页游标重复'),{code:'MCP_CURSOR_LOOP'});
      cursors.add(cursor);
      if (page === 49) throw Object.assign(new Error('MCP 工具列表超过分页上限'),{code:'MCP_PAGE_LIMIT'});
    }
    if (client.catalogVersion !== version) throw Object.assign(new Error('MCP 工具列表正在更新，请重新发现'),{code:'APP_SCHEMA_CHANGED'});
    client.catalog = {catalogVersion:version,capabilities:client.capabilities,tools:[...tools.values()].map(tool=>({...tool,name:`mcp__${client.serverName}__${tool.name}`,tool:tool.name}))};
    return client.catalog;
  }
  function enqueue(id, work) {
    const previous = lanes.get(id) || Promise.resolve();
    const run = previous.then(work, work);
    lanes.set(id, run.then(() => {}, () => {}));
    return run;
  }
  function beginClose(id, client) {
    const existing = closingClients.get(id);
    if (existing) return existing;
    const held = unsettled.get(id)?.clients || [];
    const targets = [...new Set([client, ...held].filter(Boolean))];
    live.delete(id);
    if (!targets.length) return Promise.resolve({ cleanupComplete: true });
    for (const target of targets) retiring.add(target);
    const job = (async () => {
      const receipts = [];
      for (const target of targets) {
        try {
          const receipt = await target.close();
          receipts.push({ target, receipt: { ...receipt, cleanupComplete: receipt?.cleanupComplete === true } });
        } catch (error) {
          receipts.push({ target, receipt: { cleanupComplete: false, error: error?.message || "关闭没有完成" } });
        }
      }
      const failed = receipts.filter((item) => item.receipt.cleanupComplete !== true);
      if (failed.length) unsettled.set(id, { clients: failed.map((item) => item.target), receipt: failed.at(-1).receipt });
      else unsettled.delete(id);
      return (failed.at(-1) || receipts.at(-1)).receipt;
    })();
    closingClients.set(id, job);
    job.finally(() => { if (closingClients.get(id) === job) closingClients.delete(id); });
    return job;
  }
  const requests = createRequestHandler({ post, perform: async (message, signal) => {
    const id = String(message.serverId || message.server?.id || '');
    if (!id) throw new Error('MCP 服务缺少 ID');
    if (message.op === 'close') {
      if (!closingClients.has(id)) generations.set(id, (generations.get(id) || 0) + 1);
      const receiptPromise = beginClose(id, live.get(id));
      const previous = lanes.get(id) || Promise.resolve();
      lanes.set(id, previous.then(() => receiptPromise, () => receiptPromise).then(() => {}, () => {}));
      const receipt = await receiptPromise;
      return { ok: receipt.cleanupComplete === true, ...receipt };
    }
    if (message.op === 'connect' && message.server?.protocol === 'native') {
      return enqueue(id, async () => {
        const mine = (generations.get(id) || 0) + 1;
        generations.set(id, mine);
        if (message.server.pluginId !== 'note') throw new Error('没有这个随包插件');
        const retired = await beginClose(id, live.get(id));
        if (retired.cleanupComplete !== true) throw Object.assign(new Error('上一份插件进程还没有退出'), { cleanupComplete: false });
        if (closing || generations.get(id) !== mine) throw Object.assign(new Error('插件连接已被更新'), { cleanupComplete: true });
        const host = nativeHost();
        const client = {
          protocol: 'native',
          generation: mine,
          async close() {
            const receipt = await host.stop();
            return { cleanupComplete: receipt.cleanupComplete === true, exitCode: receipt.exitCode ?? null, signal: receipt.signal ?? null };
          },
          async propose(body, callSignal) {
            if (generations.get(id) !== mine) throw Object.assign(new Error('插件世代已失效'), { cleanupComplete: true });
            return host.call({ op: 'propose-note', name: body.name, text: body.text }, callSignal);
          },
        };
        try {
          signal.throwIfAborted();
          if (closing || generations.get(id) !== mine) throw Object.assign(new Error('插件连接已被更新'), { cleanupComplete: true });
          live.set(id, client);
          return { generation: mine, tools: [{ name: 'plugin__note__write', tool: 'write', description: '提出一条便笺，由 Koder 审批后写入当前任务。这不是 MCP。', inputSchema: { type: 'object', properties: { name: { type: 'string' }, text: { type: 'string' } }, required: ['text'] } }] };
        } catch (error) {
          const receipt = await client.close();
          if (receipt.cleanupComplete !== true) unsettled.set(id, { clients: [client], receipt: { ...receipt, cleanupComplete: false } });
          if (receipt.cleanupComplete === false) error.cleanupComplete = false;
          throw error;
        }
      });
    }
    if (message.op === 'call' && live.get(id)?.protocol === 'native') {
      const client = live.get(id);
      if (message.generation !== client.generation) throw Object.assign(new Error('插件世代已失效'), { cleanupComplete: true });
      const trusted = message.trusted || {};
      if (typeof trusted.cwd !== 'string' || !trusted.cwd || typeof trusted.threadId !== 'string' || !trusted.threadId || typeof trusted.toolCallId !== 'string' || !trusted.toolCallId || trusted.generation !== client.generation) throw new Error('缺少宿主填写的调用身份');
      const args = message.arguments || {};
      const result = await client.propose({ name: typeof args.name === 'string' ? args.name : 'note', text: typeof args.text === 'string' ? args.text : '' }, signal);
      if (result?.cancelled === true || result?.ok === false) throw Object.assign(new Error(result?.error || '插件调用已取消'), { code: 'CANCELLED', cleanupComplete: true });
      if (result?.ok !== true || typeof result.proposal?.text !== 'string') throw new Error('便笺插件没有返回提案');
      return { ok: true, proposal: { name: result.proposal.name || 'note', text: result.proposal.text.slice(0, 4000) }, trusted: { cwd: trusted.cwd, threadId: trusted.threadId, toolCallId: trusted.toolCallId, generation: client.generation }, cleanupComplete: true };
    }
    if (message.op === 'connect') {
      const retired = await beginClose(id, live.get(id));
      if (retired.cleanupComplete !== true) throw Object.assign(new Error('上一个连接还没有退出'), { cleanupComplete: false });
      const generation = (generations.get(id) || 0) + 1;
      generations.set(id, generation);
      signal.throwIfAborted();
      const server = message.server;
      const remote = server.transport === 'http' || server.transport === 'streamable-http' || Boolean(server.url && !server.command);
      const client = remote ? http({ url: server.url, headers: server.headers || {}, ...((server.auth?.type === 'oauth' || server.oauth) ? { getHeaders: (options) => oauthHeaders(server.auth?.id || id, options) } : {}) }) : stdio(server);
      pending.add(client);
      try {
        const initialized = await client.request('initialize', {}, { signal });
        client.capabilities = initialized.capabilities || {};
        client.serverName = server.serverName;
        client.catalogVersion = randomUUID();
        client.onListChanged?.(() => { client.catalogVersion = randomUUID(); client.catalog = null; });
        const found = await catalog(client,signal);
        signal.throwIfAborted();
        if (closing || generations.get(id) !== generation) throw new Error('MCP 连接已被更新');
        live.set(id, client);
        return found;
      } catch (error) {
        const receipt = await client.close();
        if (receipt?.cleanupComplete === false) {
          error.cleanupComplete = false;
          unsettled.set(id,{clients:[client],receipt});
        }
        throw error;
      } finally { pending.delete(client); }
    }
    if (message.op === 'call') {
      const client = live.get(id);
      if (!client) throw new Error('这个外部工具没有连上');
      if (message.catalogVersion !== undefined && message.catalogVersion !== client.catalogVersion) throw Object.assign(new Error('应用工具定义已变化，请重新确认'),{code:'APP_SCHEMA_CHANGED',cleanupComplete:true});
      const result = await client.request('tools/call', { name: message.tool, arguments: message.arguments || {} }, { signal });
      return { ...result, ok: result.isError !== true, text: (result.content || []).filter((block) => block.type === 'text').map((block) => block.text).join('\n') };
    }
    if (message.op === 'catalog' || message.op === 'request') {
      const client = live.get(id);
      if (!client || client.protocol === 'native') throw Object.assign(new Error('MCP 服务没有连接'),{code:'APP_CONNECTION_CHANGED'});
      if (message.op === 'catalog') return catalog(client,signal);
      if (!['resources/list','resources/templates/list','resources/read','prompts/list','prompts/get'].includes(message.method)) throw Object.assign(new Error('没有此 MCP 读取能力'),{code:'MCP_CAPABILITY_UNAVAILABLE'});
      return client.request(message.method,message.params||{},{signal});
    }
    throw new Error('没有这个操作');
  } });
  let done;
  return {
    handle: (message) => requests.handle(message),
    close: () => done ||= (async () => {
      closing = true;
      await requests.close();
      const ids = [...new Set([...live.keys(), ...closingClients.keys(), ...unsettled.keys()])];
      const receipts = await Promise.allSettled([
        ...ids.map((serverId) => beginClose(serverId, live.get(serverId))),
        ...[...pending].filter((client) => !retiring.has(client)).map((client) => client.close()),
      ]);
      // A cancelled remote write stays uncertain in its request/effect receipt.
      // Worker shutdown separately requires every owned transport to confirm
      // closure, including a connection whose earlier cleanup was incomplete.
      return { cleanupComplete: receipts.every((r) => r.status === 'fulfilled' && r.value?.cleanupComplete === true) };
    })(),
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const lines = readline.createInterface({ input: process.stdin });
  const post = (body) => { if (!process.stdout.destroyed) process.stdout.write(`${JSON.stringify(body)}\n`); };
  const handler = createMcpHandler({ post });
  let closing;
  const close = () => closing ||= (async () => {
    const receipt = await handler.close();
    post({ control: 'shutdown', ...receipt });
    lines.close(); process.stdin.destroy();
  })();
  lines.on('line', (line) => {
    let message; try { message = JSON.parse(line); } catch { return; }
    if (message.op === 'die') process.exit(1);
    if (message.op === 'shutdown') { void close(); return; }
    void handler.handle(message);
  });
  lines.on('close', () => { void close(); });
  process.once('SIGTERM', () => { void close(); });
  process.stdout.on('error', () => { void close(); });
}
