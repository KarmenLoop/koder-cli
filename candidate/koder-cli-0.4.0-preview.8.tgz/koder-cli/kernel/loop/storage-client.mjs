import path from 'node:path';
export function createStorageClient({worker,dir}) {
 const relative=file=>{const name=path.relative(dir,file).split(path.sep).join('/');if(!name||name==='..'||name.startsWith('../')||path.isAbsolute(name))throw new Error('私有文件越过数据目录');return name;};
 return {
  boot:()=>worker.call({op:'boot'}),
  readJson:(file,fallback)=>worker.call({op:'read-json',path:relative(file),fallback}),
  writeJson:(file,value)=>worker.call({op:'write-json',path:relative(file),value:JSON.parse(JSON.stringify(value))}),
  trashTask:file=>worker.call({op:'task-trash',path:relative(file)}),
  trashList:()=>worker.call({op:'task-trash-list'}),
  trashSweep:()=>worker.call({op:'task-trash-sweep'}),
  restoreTrash:id=>worker.call({op:'task-trash-restore',recycleId:id}),
  purgeTrash:id=>worker.call({op:'task-trash-purge',recycleId:id}),
  taskHistory:file=>worker.call({op:'task-history',path:relative(file)}),
  restoreTask:(file,selection,{signal}={})=>worker.call({...selection,op:'task-restore',path:relative(file)},undefined,{signal}),
  async readBytes(file,fallback=null){const bytes=await worker.call({op:'read-bytes',path:relative(file)});return bytes===null?fallback:Buffer.from(bytes,'base64');},
  writeBytes:(file,bytes)=>worker.call({op:'write-bytes',path:relative(file),base64:Buffer.from(bytes).toString('base64')}),
  list:file=>worker.call({op:'list',path:relative(file)}),
  remove:file=>worker.call({op:'remove',path:relative(file)}),
  stat:file=>worker.call({op:'stat',path:relative(file)}),
 };
}
