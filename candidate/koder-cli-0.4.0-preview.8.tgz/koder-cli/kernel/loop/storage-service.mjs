// Domain storage is a service, not part of core. All task snapshots are sealed.
import crypto from 'node:crypto';
import path from 'node:path';
import { createDataLock, keychainPepper } from '../fusion/data-lock.mjs';
import { createPrivateStore } from '../fusion/private-store.mjs';
import { createDesk } from '../fusion/desk.mjs';
import { restoredTask } from './task-history.mjs';
import { createRecycleBin, recycleError, recycleSummary } from '../fusion/recycle-bin.mjs';
const digest=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const taskPath=/^loop\/threads\/([A-Za-z0-9-]{1,80})\.json$/;
const fail=(code,message)=>Object.assign(new Error(message),{code});
export function unpackTaskSnapshot(record,id) {
  if(record?.kind!=='task-snapshot')return record;
  if(record.schemaVersion!==1||record.taskId!==id||!Number.isSafeInteger(record.revision)||record.revision<1||record.hash!==digest(record.thread)||record.thread?.id!==id)throw Object.assign(new Error('任务镜像完整性验证失败'),{code:'TASK_SNAPSHOT_DAMAGED'});
  return record.thread;
}
export async function createStorageService({dir,lock,env=process.env,now=Date.now}={}) {
 lock ||= await createDataLock({dir,pepper:env.KODER_KEYCHAIN_HELPER&&env.KODER_KEYCHAIN_ACCOUNT?keychainPepper({helper:env.KODER_KEYCHAIN_HELPER,account:env.KODER_KEYCHAIN_ACCOUNT}):null});
 const store=createPrivateStore({dir,lock}),tails=new Map();
 const relative=file=>path.relative(dir,file).split(path.sep).join('/');
 const desk=createDesk({dir:path.join(dir,'desk'),storage:{readBytes:file=>store.readBytes(relative(file)),writeBytes:(file,bytes)=>store.writeBytes(relative(file),bytes),list:file=>store.list(relative(file)),remove:file=>store.remove(relative(file)),stat:file=>store.stat(relative(file))}});
 function serial(key,work){const value=(tails.get(key)||Promise.resolve()).then(work);const settled=value.then(()=>{},()=>{});tails.set(key,settled);void settled.then(()=>{if(tails.get(key)===settled)tails.delete(key);});return value;}
 const unpack=unpackTaskSnapshot;
 const recycle=createRecycleBin({dir,now,storage:{
  readJson:(file,fallback)=>store.readJson(relative(file),fallback),writeJson:(file,value)=>store.writeJson(relative(file),value),
  list:file=>store.list(relative(file)),remove:file=>store.remove(relative(file)),
 }});
 async function eraseTask(file) {
  await store.remove(file);
  const id=historyId(file);
  for(const folder of [`task-snapshots/${id}`,`checkpoints/${id}`])for(const name of await store.list(folder))await store.remove(`${folder}/${name}`);
 }
 async function finishTrash(item) {
  const file=`loop/threads/${item.payload.thread.id}.json`,record=await store.readJson(file,null);
  if(record) {
   const current=unpack(record,item.payload.thread.id);
   if(item.phase==='restoring'&&current.recycleRestoration?.id===item.id){await recycle.remove(item.id);return false;}
   if(digest(current)!==item.payload.hash)throw recycleError('RECYCLE_CONFLICT','原任务已改变，保留原件并停止回收');
   await store.remove(file);
  }
  return true;
 }
 async function purgeTrash(item) {if(await finishTrash(item)){await eraseTask(`loop/threads/${item.payload.thread.id}.json`);await recycle.remove(item.id);}}
 async function sweepTrash() {
  let removed=0;
  for(const item of await recycle.records())if(item.kind==='thread'&&now()>=item.expiresAt) {
   await serial(`loop/threads/${item.payload.thread.id}.json`,()=>purgeTrash(item));removed++;
  }
  return {removed};
 }
 async function trashTask(file) {
  const id=historyId(file),record=await store.readJson(file,null);
  if(!record)throw recycleError('RECYCLE_MISSING','没有这个任务',404);
  const thread=unpack(record,id);
  if(thread.running||thread.pendingTurns?.length)throw recycleError('TASK_BUSY','任务仍在执行或排队，请先取消后再删除');
  const item=await recycle.put({id:`thread-${id}`,kind:'thread',title:thread.title,payload:{thread,record,hash:digest(thread)}});
  await finishTrash(item);
  return {item:recycleSummary(item)};
 }
 async function restoreTrash(id) {
  const item=await recycle.get(id),thread=item.payload.thread;
  if(!(await finishTrash(item)))return {thread:unpack(await store.readJson(`loop/threads/${thread.id}.json`),thread.id),restored:true};
  const file=`loop/threads/${thread.id}.json`;
  const next=restoredTask(thread,thread,{now:now()});
  next.recycleRestoration={id:item.id,at:now()};
  next.automationId=null;next.resumeActive=false;next.resumable=false;
  item.phase='restoring';await recycle.replace(item);
  await store.writeJson(file,item.payload.record||thread);
  await saveTask(file,next);
  await recycle.remove(id);
  return {thread:next,restored:true};
 }

 async function saveTask(relative,thread,{protectRevision}={}) {
  const id=taskPath.exec(relative)?.[1];if(thread?.id!==id)throw new Error('任务镜像编号不匹配');
  const previous=await store.readJson(relative,null);if(previous)unpack(previous,id);
  const revision=previous?.kind==='task-snapshot'?previous.revision+1:1;
  const record={kind:'task-snapshot',schemaVersion:1,taskId:id,revision,parentHash:previous?digest(unpack(previous,id)):null,hash:digest(thread),committedAt:Date.now(),thread};
  const history=`task-snapshots/${id}`;
  const existing=(await store.list(history)).filter(name=>name.endsWith('.json')).sort();
  // Keep two earlier confirmed snapshots; failed cleanup prevents further growth.
  for(const name of existing.filter(name=>Number(name.slice(0,-5))!==protectRevision).slice(0,Math.max(0,existing.length-2)))await store.remove(`${history}/${name}`);
  // Only previously committed state is recoverable history. The new candidate
  // must not become a recovery source if its authoritative rename later fails.
  if(previous?.kind==='task-snapshot')await store.writeJson(`${history}/${String(previous.revision).padStart(12,'0')}.json`,previous);
  const retained=new Set((thread.checkpoints||[]).map(item=>item.blob));
  for(const name of await store.list(history)) {
   const old=await store.readJson(`${history}/${name}`,null);
   for(const item of old?.thread?.checkpoints||[])retained.add(item.blob);
  }
  for(const name of await store.list(`checkpoints/${id}`))if(!retained.has(`checkpoints/${id}/${name}`))await store.remove(`checkpoints/${id}/${name}`);
  await store.writeJson(relative,record);
  return {revision,hash:record.hash};
 }
 function historyId(relative) {
  const id=taskPath.exec(relative)?.[1];if(!id)throw fail('TASK_HISTORY_PATH','任务历史只能访问该任务自己的快照');return id;
 }
 function summary(record,id,current=false) {
  const thread=unpack(record,id);if(!thread||thread.id!==id)throw fail('TASK_SNAPSHOT_DAMAGED','任务镜像编号不匹配');
  return {revision:record.kind==='task-snapshot'?record.revision:0,hash:record.kind==='task-snapshot'?record.hash:digest(thread),parentHash:record.parentHash||null,
   committedAt:record.committedAt||thread.updatedAt||thread.createdAt||0,title:thread.title||'',messageCount:Array.isArray(thread.messages)?thread.messages.length:0,
   queuedInputCount:Array.isArray(thread.pendingTurns)?thread.pendingTurns.length:0,current,restoredFrom:thread.restoration?.fromRevision??null};
 }
 async function history(relative) {
  const id=historyId(relative),record=await store.readJson(relative,null);if(!record)throw fail('TASK_HISTORY_MISSING','没有这个任务的历史');
  const current=summary(record,id,true),versions=[current];
  for(const name of (await store.list(`task-snapshots/${id}`)).filter(name=>/^\d{12}\.json$/.test(name)).sort().reverse()) {
   const saved=await store.readJson(`task-snapshots/${id}/${name}`,null),item=summary(saved,id);
   if(item.revision!==Number(name.slice(0,-5))||item.revision>current.revision||(item.revision===current.revision&&item.hash!==current.hash))throw fail('TASK_SNAPSHOT_DAMAGED','任务历史版本顺序无效');
   // A failed authoritative rename can leave an exact copy of current in history.
   if(item.revision===current.revision)continue;
   versions.push(item);
  }
  return {taskId:id,current,versions,fileRestore:false};
 }
 async function restore(relative,message,signal) {
  const id=historyId(relative);
  if(!Number.isSafeInteger(message.revision)||message.revision<1||!Number.isSafeInteger(message.expectedRevision)||message.expectedRevision<0||!(/^[a-f0-9]{64}$/.test(message.hash||'')&&/^[a-f0-9]{64}$/.test(message.expectedHash||'')))throw fail('TASK_HISTORY_INPUT','请选择有效历史版本，并提供当前版本校验信息');
  const record=await store.readJson(relative,null);if(!record)throw fail('TASK_HISTORY_MISSING','任务已不存在');
  const current=summary(record,id,true);
  if(current.revision!==message.expectedRevision||current.hash!==message.expectedHash)throw fail('TASK_HISTORY_CONFLICT','任务已改变，请刷新历史后再恢复');
  if(message.revision>=current.revision)throw fail('TASK_HISTORY_CONFLICT','只能选择当前版本之前的已确认历史');
  const authority=unpack(record,id);
  if(authority.running||authority.pendingTurns?.length||[...(authority.approvals||[]),...(authority.choices||[]),...(authority.changes||[])].some(item=>item.status==='pending'))throw fail('TASK_HISTORY_BUSY','任务仍在执行、排队或等待确认，请先取消再恢复');
  const selected=await store.readJson(`task-snapshots/${id}/${String(message.revision).padStart(12,'0')}.json`,null);
  if(!selected)throw fail('TASK_HISTORY_MISSING','所选历史已不在保留范围，请刷新列表');
  const version=summary(selected,id);
  if(version.revision!==message.revision||version.hash!==message.hash)throw fail('TASK_HISTORY_CONFLICT','所选历史的校验信息不一致');
  const thread=restoredTask(unpack(selected,id),authority,{revision:version.revision,hash:version.hash,currentRevision:current.revision,currentHash:current.hash});
  signal?.throwIfAborted();
  const saved=await saveTask(relative,thread,{protectRevision:version.revision});
  return {thread,current:{...saved,committedAt:thread.updatedAt},restoredFrom:version,fileRestore:false};
 }
 return {store,lock,async perform(message,signal) {
  signal?.throwIfAborted();const relative=message.path;
  switch(message.op) {
   case 'boot':await desk.initialize();await sweepTrash();return {ok:true,kind:lock.kind,version:1};
   case 'desk': {if(!['search','write','brief'].includes(message.method))throw new Error('未知笔记操作');return desk[message.method](...(message.args||[]));}
   case 'read-json': {if(taskPath.test(relative)&&await recycle.has(`thread-${taskPath.exec(relative)[1]}`)) {const item=await recycle.get(`thread-${taskPath.exec(relative)[1]}`,{allowExpired:true});const record=await store.readJson(relative,null);if(item.phase!=='restoring'||unpack(record,taskPath.exec(relative)[1])?.recycleRestoration?.id!==item.id)return message.fallback??null;}const value=await store.readJson(relative,message.fallback);return taskPath.test(relative)?unpack(value,taskPath.exec(relative)[1]):value;}
   case 'write-json': {const value=structuredClone(message.value);return serial(relative,async()=>{if(taskPath.test(relative)){if(await recycle.has(`thread-${taskPath.exec(relative)[1]}`))throw recycleError('TASK_DELETED','任务已移到回收站');return saveTask(relative,value);}return store.writeJson(relative,value).then(()=>({ok:true}));});}
   case 'task-trash':return serial(relative,()=>trashTask(relative));
   case 'task-trash-list':await sweepTrash();return {items:(await recycle.records()).filter(item=>item.kind==='thread').map(recycleSummary)};
   case 'task-trash-sweep':return sweepTrash();
   case 'task-trash-restore': {const id=String(message.recycleId||'');if(!/^thread-[A-Za-z0-9-]{1,80}$/.test(id))throw recycleError('RECYCLE_ID','任务回收项目无效',400);return serial(`loop/threads/${id.slice(7)}.json`,()=>restoreTrash(id));}
   case 'task-trash-purge': {const id=String(message.recycleId||'');if(!/^thread-[A-Za-z0-9-]{1,80}$/.test(id))throw recycleError('RECYCLE_ID','任务回收项目无效',400);return serial(`loop/threads/${id.slice(7)}.json`,async()=>{await purgeTrash(await recycle.get(id,{allowExpired:true}));return {ok:true};});}
   case 'task-history':return serial(relative,()=>history(relative));
   case 'task-restore':return serial(relative,()=>restore(relative,message,signal));
   case 'read-bytes': {const bytes=await store.readBytes(relative,{fallback:null});return bytes===null?null:bytes.toString('base64');}
   case 'write-bytes': {if(typeof message.base64!=='string'||message.base64.length>16*1024*1024)throw new Error('存储字节超过容量');await store.writeBytes(relative,Buffer.from(message.base64,'base64'));return {ok:true};}
   case 'list':return store.list(relative);
   case 'remove':return serial(relative,async()=>{
    // An explicit task deletion includes its private recoverable versions.
    // Remove authority first; interruption cannot make old history live again.
    await store.remove(relative);
    const id=taskPath.exec(relative)?.[1];
    if(id)for(const folder of [`task-snapshots/${id}`,`checkpoints/${id}`])for(const name of await store.list(folder))await store.remove(`${folder}/${name}`);
    return {ok:true};
   });
   case 'stat': {const value=await store.stat(relative);return {size:value.size,mtimeMs:value.mtimeMs};}
   default:throw new Error('未知私有存储操作');
  }
 }};
}
