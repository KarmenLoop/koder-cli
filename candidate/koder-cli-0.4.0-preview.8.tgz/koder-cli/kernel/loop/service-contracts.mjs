// Only the trusted host may replace implementations. This is an IPC contract,
// not a permission grant: runtime still owns user approvals and request leases.
export const SERVICE_ABI = 1;
export const REPLACEABLE_SERVICES = Object.freeze(['permission', 'verification']);
export function serviceError(message, code = 'SERVICE_CONTRACT') { return Object.assign(new Error(message), {code}); }
export function requireServiceRequest(message, module) {
  if(message?.apiVersion !== SERVICE_ABI || message?.module !== module || typeof message.op !== 'string') throw serviceError(`${module} 接口版本或请求无效`);
}
export function serviceReply(module, result) { return {apiVersion:SERVICE_ABI, module, result}; }
export async function callModule(worker, module, op, payload = {}, {signal, timeoutMs = 30000} = {}) {
  signal?.throwIfAborted();
  const reply = await worker.call({...payload, op, module, apiVersion:SERVICE_ABI}, timeoutMs, {signal});
  signal?.throwIfAborted();
  if(reply?.apiVersion !== SERVICE_ABI || reply.module !== module || !reply.result || typeof reply.result !== 'object') throw serviceError(`${module} 服务响应不兼容`);
  const result = reply.result;
  if(module === 'permission') {
    if(op === 'admit' && (typeof result.ok !== 'boolean' || !result.ok && typeof result.reason !== 'string')) throw serviceError('权限判定响应无效');
    if(op === 'edit' && !['ask','apply'].includes(result.decision)) throw serviceError('文件权限响应无效');
    if(['command','benchmark','desktop'].includes(op) && (typeof result.allowed !== 'boolean' || typeof result.ask !== 'boolean')) throw serviceError('操作权限响应无效');
  } else if(module === 'verification' && op === 'verify') {
    if(typeof result.passed !== 'boolean' || typeof result.checked !== 'boolean' || !Array.isArray(result.files) || result.roundId !== payload.roundId || typeof result.reason !== 'string') throw serviceError('验收响应无效');
    if(result.files.some(file=>typeof file?.path!=='string'||typeof file.cwd!=='string'||typeof file.matched!=='boolean') || result.passed && (!result.checked || payload.uncertain === true || result.files.some(file=>!file.matched))) throw serviceError('验收响应互相矛盾');
  }
  return result;
}
