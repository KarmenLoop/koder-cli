// Shared lifecycle adapter: EOF, shutdown and signals settle owned requests first.
import readline from 'node:readline';
import { createRequestHandler } from './worker-requests.mjs';
export function serveWorker(perform,{cleanup=async()=>({cleanupComplete:true})}={}) {
 const post=body=>{if(!process.stdout.destroyed)process.stdout.write(`${JSON.stringify(body)}\n`);};
 const handler=createRequestHandler({perform,post});
 const lines=readline.createInterface({input:process.stdin});let closing;
 const close=()=>closing ||= (async()=>{
  let receipt;try{const a=await handler.close(),b=await cleanup();receipt={cleanupComplete:a.cleanupComplete&&b?.cleanupComplete!==false};}catch(error){receipt={cleanupComplete:false,error:error.message};}
  post({control:'shutdown',...receipt});lines.close();process.stdin.destroy();
 })();
 lines.on('line',line=>{let message;try{message=JSON.parse(line);}catch{return;}if(message.op==='die')process.exit(1);if(message.op==='shutdown'){void close();return;}void handler.handle(message).catch(()=>{void close();});});
 lines.on('close',()=>{void close();});process.on('SIGTERM',()=>{void close();});process.on('SIGINT',()=>{void close();});process.stdout.on('error',()=>{void close();});
 return {handler,close};
}
