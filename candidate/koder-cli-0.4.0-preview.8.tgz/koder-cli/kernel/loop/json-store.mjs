import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

const pendingWrites = new Map();

async function replaceFile(file, content) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temp = `${file}.${process.pid}.${randomUUID()}.tmp`;
  let created = false, renamed = false;
  try {
    const handle = await fs.open(temp, "wx", 0o600);
    created = true;
    const failures = [];
    try {
      await handle.writeFile(content);
      await handle.sync();
    } catch (error) {
      failures.push(error);
    }
    try {
      await handle.close();
    } catch (error) {
      failures.push(error);
    }
    if (failures.length === 1) throw failures[0];
    if (failures.length > 1) throw new AggregateError(failures, "JSON write and close failed", { cause: failures[0] });
    await fs.rename(temp, file);
    renamed = true;
    // The rename itself must also be durable on filesystems that support
    // directory fsync. Windows does not expose directory handles this way.
    if (process.platform !== "win32") {
      const directory = await fs.open(path.dirname(file), "r");
      try { await directory.sync(); } finally { await directory.close(); }
    }
  } catch (error) {
    let failure = error;
    // Only a successfully opened exclusive temp belongs to this call.
    if (created) {
      try {
        await fs.unlink(temp);
      } catch (cleanupError) {
        if (cleanupError.code !== "ENOENT") {
          failure = new AggregateError([error, cleanupError], "JSON write and cleanup failed", { cause: error });
        }
      }
    }
    // Callers that own a recovery record must distinguish rejection before
    // replacement from a visible replacement whose durability is unconfirmed.
    if (renamed) Object.assign(failure, { committed: true, committedPath: file });
    throw failure;
  }
}

export function writeFileJson(file, value) {
  let target;
  let content;
  try {
    target = path.resolve(file);
    // Snapshot before any await: callers may keep mutating their in-memory state.
    const json = JSON.stringify(value, null, 2);
    if (json === undefined) throw new TypeError("Value cannot be serialized as JSON");
    content = `${json}\n`;
  } catch (error) {
    return Promise.reject(error);
  }

  return writeFileBytes(target, content);
}

export function writeFileBytes(file, bytes) {
  let target, content;
  try { target=path.resolve(file);content=Buffer.from(bytes); }
  catch(error) { return Promise.reject(error); }
  const previous = pendingWrites.get(target) || Promise.resolve();
  const result = previous.then(() => replaceFile(target, content));
  // Keep the failure on the caller's promise without blocking later saves.
  const settled = result.then(() => {}, () => {});
  pendingWrites.set(target, settled);
  settled.then(() => {
    if (pendingWrites.get(target) === settled) pendingWrites.delete(target);
  });
  return result;
}
