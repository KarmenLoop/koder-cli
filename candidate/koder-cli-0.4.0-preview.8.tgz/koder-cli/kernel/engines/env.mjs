const SECRET_NAME = /(API_?KEY|ACCESS_KEY|SECRET|TOKEN|PASSWORD|PASSWD|CREDENTIAL|PRIVATE_KEY)/i;
const ENGINE_SETTING = /^(OPENAI|ANTHROPIC|DEEPSEEK|CODEX|DSH|HERMES)_/;

export function engineEnv(base = process.env, extra = {}) {
  const env = {};
  for (const [name, value] of Object.entries(base)) {
    if (value === undefined || SECRET_NAME.test(name) || ENGINE_SETTING.test(name)) continue;
    env[name] = value;
  }
  return { ...env, ...extra };
}
