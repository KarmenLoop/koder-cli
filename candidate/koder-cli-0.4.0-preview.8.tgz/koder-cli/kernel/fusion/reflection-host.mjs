import crypto from 'node:crypto';
import {acquireHostLease} from './host-maintenance.mjs';
import {createDailyReflection,reflectionDate} from './daily-reflection.mjs';
import {zonedDay,addDays} from './personalization-time.mjs';
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const failure=code=>Object.assign(new Error(code),{code});

export function createReflectionHost({subject,policy,profile,transport,automation,model,current,clock=Date.now}){
 let active=null,lastResult=null,closed=false,catching=null;const receipts=new WeakMap();let controller=new AbortController();
 const acquire=()=>acquireHostLease({transport,input:{purpose:'reflection',spaceId:subject.spaceId,key:'daily'},current:async()=>!closed&&await current(),onLost:()=>controller.abort()});
 const readProgress=async()=>{if(active)return active.call('read');const lease=await acquire();try{return await lease.call('read');}finally{await lease.release();}};
 const owner={async acquire(){
  if(controller.signal.aborted&&!closed)controller=new AbortController();let lease;try{lease=await acquire();}catch(error){if(error.code==='HOST_LEASE_BUSY')return null;throw error;}active=lease;
  return {...lease,async receipt({inputDigest,outputDigest}){
   await lease.requireCurrent();if(!lastResult||lastResult.inputDigest!==inputDigest||hash(lastResult.evidence)!==outputDigest)throw failure('REFLECTION_RESULT_UNBOUND');
   const receipt=Object.freeze(await lease.call('record',{inputDigest,outputDigest}));receipts.set(receipt,lastResult);lastResult=null;return receipt;
  },async release(){if(active===lease)active=null;lastResult=null;await lease.release();}};
 }};
 const source={snapshot:({date})=>active.call('snapshot',{date}),readPage:({snapshot,cursor})=>active.call('page',{snapshot,cursor}),
  async verify(candidate,receipt){const result=receipts.get(receipt);if(!result||!await current()||!result.evidence.some(e=>JSON.stringify(e)===JSON.stringify(candidate)))return null;
   return {direct:true,explicit:/I (?:prefer|like|am|work)|my (?:role|job)|我(?:喜欢|偏好|习惯|是|从事)/i.test(candidate.text),authorSubjectId:subject.subjectId,receiptRef:receipt.receiptId,evidence:candidate,platform:result.input.platform,createdAt:result.input.createdAt};
  }};
 const extractor={contextWindow:model.contextWindow,maxOutput:model.maxOutput,
  async extract({input,messages,maxOutput,signal}){
   const result=await model.complete({messages:[{role:'system',content:messages[0].content+' Return only JSON {"evidence":[{"category":"explicit-preference|explicit-background|behavior|temporary|daily-state","quote":"verbatim substring of the user text"}]}. Include only statements by this user; do not treat quoted or forwarded material as their preferences.'},messages[1]],tools:[],maxOutput,signal:signal?AbortSignal.any([signal,controller.signal]):controller.signal});
   if(typeof result?.text!=='string'||Buffer.byteLength(result.text)>65536||result.toolCalls?.length)throw failure('REFLECTION_RESULT_INVALID');
   let parsed;try{parsed=JSON.parse(result.text.replace(/^```(?:json)?\s*|\s*```$/g,''));}catch{throw failure('REFLECTION_RESULT_INVALID');}
   if(!Array.isArray(parsed?.evidence)||parsed.evidence.length>64)throw failure('REFLECTION_RESULT_INVALID');
   const evidence=[];
   for(const row of parsed.evidence){if(!['explicit-preference','explicit-background','behavior','temporary','daily-state'].includes(row?.category)||typeof row.quote!=='string'||!row.quote.trim()||row.quote.length>1000||!input.text.includes(row.quote))continue;
    evidence.push({...input,category:row.category,text:row.quote});
   }
   lastResult={input:structuredClone(input),inputDigest:hash(input),evidence};return {evidence};
  }};
 const reflection=createDailyReflection({subject,policy,profile,source,model:extractor,owner,clock,automation:{createReflection:input=>automation.createReflection(input),readReflection:readProgress,updateReflection:(_id,expectedRevision,progress)=>active.call('write',{expectedRevision,progress})}});
 async function discover(){
  const consent=await policy.status();if(!consent.learning&&!consent.dailyState)return;
  const lease=await acquire();try{const progress=await lease.call('read');
   const completed=Object.keys(progress.days).filter(d=>progress.days[d].state==='complete'&&!progress.days[d].dirty).sort();for(const date of completed.slice(0,-30))delete progress.days[date];
   const cutoff=addDays(zonedDay(clock(),consent.timezone),-30);for(const date of Object.keys(progress.budget))if(date<cutoff)delete progress.budget[date];
   if(Object.keys(progress.days).length<300){
    const page=await lease.call('discover',{cursor:progress.discovery?.policyRevision===consent.revision?progress.discovery.cursor:0});
    for(const [date,sequence] of Object.entries(page.days)){
     const day=progress.days[date];if(!day)progress.days[date]={state:'pending',cursor:{page:null,index:0,offset:0}};
     else if(day.snapshot&&(sequence>day.snapshot.upperSeq||day.snapshot.policyRevision!==consent.revision))day.dirty=true;
    }
    progress.discovery={cursor:page.nextCursor,hasMore:page.hasMore,policyRevision:page.policyRevision};
   }
   await lease.call('write',{expectedRevision:progress.revision,progress});
  }finally{await lease.release();}
 }
 async function catchUp(){
  if(closed)return {state:'stopped'};const consent=await policy.status();if(!consent.learning&&!consent.dailyState)return {state:consent.evolution?'waiting-evolution-host':'disabled'};
  try{await discover();const result=await reflection.catchUp();if(result.state!=='complete')return result;
   const progress=await readProgress(),ready=reflectionDate(clock(),consent.timezone);return progress.discovery?.hasMore||Object.entries(progress.days).some(([date,day])=>date<=ready&&(day.dirty||day.state!=='complete'))?{...result,state:'pending'}:result;
  }catch(error){if(error.code==='HOST_LEASE_BUSY')return {state:'waiting-owner'};throw error;}
 }
 return {source,reflection:{...reflection,run:options=>reflection.run({...options}),catchUp(){return catching||=(catchUp().finally(()=>{catching=null;}));}},
  async close(){closed=true;controller.abort();await reflection.stop()?.catch(()=>{});await catching?.catch(()=>{});if(active)await active.release().catch(()=>{});active=null;},
 };
}
