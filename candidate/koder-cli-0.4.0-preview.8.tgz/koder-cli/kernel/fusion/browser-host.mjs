import crypto from 'node:crypto';

const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const BROWSER_HOST_PATH='/internal/browser-host';
export function browserHostError(code,message,status=409){return Object.assign(new Error(message),{code,status});}
export function validateBrowserHost(input){
 if(!input||typeof input!=='object'||!UUID.test(input.generation||''))throw browserHostError('BAD_BROWSER_HOST','无效浏览器宿主绑定',400);
 if(input.detach===true)return {generation:input.generation,detach:true};
 let url;try{url=new URL(input.url);}catch{throw browserHostError('BAD_BROWSER_HOST','无效浏览器宿主地址',400);}
 if(url.protocol!=='http:'||url.hostname!=='127.0.0.1'||!url.port||url.username||url.password||url.pathname!=='/'||url.search||url.hash||typeof input.token!=='string'||!/^[A-Za-z0-9_-]{32,128}$/.test(input.token))throw browserHostError('BAD_BROWSER_HOST','无效浏览器宿主绑定',400);
 return {generation:input.generation,url:url.origin,token:input.token};
}
export function browserHostFromEnv(env){
 if(!env.KODER_CHROMIUM_URL||!env.KODER_CHROMIUM_TOKEN)return null;
 return validateBrowserHost({generation:env.KODER_CHROMIUM_GENERATION||crypto.randomUUID(),url:env.KODER_CHROMIUM_URL,token:env.KODER_CHROMIUM_TOKEN});
}
export function browserHostStatus(binding){return {available:Boolean(binding&&!binding.detach),engine:'chromium',generation:binding?.generation||null};}
export function browserOpenUrl(value){
 if(value===undefined||value===null||value==='')return null;
 let url;try{url=new URL(value);}catch{throw browserHostError('BAD_URL','请输入有效网页地址',400);}
 const local=['127.0.0.1','localhost','[::1]'].includes(url.hostname);
 if(typeof value!=='string'||value.length>8192||url.username||url.password||!(url.protocol==='https:'||(url.protocol==='http:'&&local)))throw browserHostError('BAD_URL','网页地址需要 HTTPS，本机地址可用 HTTP，且不能包含登录凭据',400);
 return url.href;
}
export async function probeBrowserHost(binding,{fetchImpl=fetch,signal}={}){
 const checked=validateBrowserHost(binding);
 const response=await fetchImpl(`${checked.url}/v1/status`,{redirect:'error',headers:{authorization:`Bearer ${checked.token}`},signal:AbortSignal.any([AbortSignal.timeout(3000),...(signal?[signal]:[])])});
 if(response.status!==200||!String(response.headers.get('content-type')||'').startsWith('application/json')){await response.body?.cancel();throw browserHostError('BROWSER_HOST_PROBE','浏览器宿主未通过就绪检查',503);}
 let size=0;const chunks=[];
 for await(const chunk of response.body){size+=chunk.length;if(size>4096){await response.body?.cancel().catch(()=>{});throw browserHostError('BROWSER_HOST_PROBE','浏览器宿主就绪响应过大',503);}chunks.push(chunk);}
 let result;try{result=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw browserHostError('BROWSER_HOST_PROBE','浏览器宿主就绪响应无效',503);}
 if(result?.ok!==true||result.engine!=='chromium')throw browserHostError('BROWSER_HOST_PROBE','浏览器宿主未通过就绪检查',503);
}

// Only the ChildProcess returned by this server's spawn is allowed to register.
// Capabilities stay on the IPC wire and authenticated core route, never SSE.
export function bindAttachedBrowser(child,{nonce,generation=crypto.randomUUID(),isCurrent=()=>true,configure,configureOffice=async()=>{},probe=probeBrowserHost,onUnavailable=()=>{},onError=()=>{}}){
 if(!/^[a-f0-9]{64}$/.test(nonce||'')||!UUID.test(generation)||typeof configure!=='function')throw new Error('Invalid browser attachment owner');
 let disconnected=false,registered=false,detached=false,tail=Promise.resolve();const seen=new Map(),aborts=new Set(),readyWaiters=new Set();
 const settleReady=error=>{for(const finish of [...readyWaiters])finish(error);};
 const current=()=>!disconnected&&isCurrent()&&child.connected!==false;
 const send=reply=>new Promise((resolve,reject)=>{if(!current())return reject(browserHostError('BROWSER_HOST_GONE','浏览器宿主已断开'));try{child.send(reply,error=>error?reject(error):resolve());}catch(error){reject(error);}});
 const valid=message=>{
  if(!current()||!message||!['koder-browser-host-register','koder-browser-host-detach'].includes(message.type)||message.version!==1||!UUID.test(message.requestId||''))return false;
  const expected=Buffer.from(nonce),given=Buffer.from(typeof message.nonce==='string'?message.nonce:'');
  return given.length===expected.length&&crypto.timingSafeEqual(given,expected);
 };
 async function processMessage(message){
  const reply={type:'koder-browser-host-receipt',version:1,requestId:message.requestId};
  let applying=false;
  try{
   if(!current())return;
   if(message.type==='koder-browser-host-register'){
    if(detached)throw browserHostError('BROWSER_HOST_DETACHED','浏览器宿主已停止，请重新打开');
    const config=validateBrowserHost({generation,url:message.url,token:message.token});
    const controller=new AbortController();aborts.add(controller);
    try{
      await probe(config,{signal:controller.signal});
      if(!current())return;
      applying=true;const result=await configure(config,{signal:controller.signal});
      if(message.office)await configureOffice({...message.office,generation},{signal:controller.signal});
      // Disconnect while configure is pending must revoke that exact generation.
      if(!current()){await Promise.all([configure({generation,detach:true}),configureOffice({generation,detach:true})]);return;}
      registered=true;settleReady();Object.assign(reply,{ok:true,...result});
    }finally{aborts.delete(controller);}
   }else{
    await Promise.all([configure({generation,detach:true}),configureOffice({generation,detach:true})]);registered=false;detached=true;
    Object.assign(reply,{ok:true,...browserHostStatus({generation,detach:true})});
   }
  }catch(error){settleReady(error);if(applying){registered=false;await Promise.allSettled([configure({generation,detach:true}),configureOffice({generation,detach:true})]);}Object.assign(reply,{ok:false,code:typeof error.code==='string'?error.code:'BROWSER_HOST_FAILED',error:'桌面编辑器接线未完成，请重试'});}
  seen.set(message.requestId,reply);if(seen.size>64)seen.delete(seen.keys().next().value);
  await send(reply).catch(()=>{});
 }
 function receive(message){
  if(!valid(message))return;
  if(seen.has(message.requestId)){const reply=seen.get(message.requestId);if(reply)void send(reply).catch(()=>{});return;}
  if(seen.size>=64&&!seen.values().next().value)return;
  // Reserve pending IDs as well: a duplicate cannot enqueue another mutation.
  seen.set(message.requestId,null);
  tail=tail.then(()=>processMessage(message)).catch(()=>{onError('BROWSER_HOST_FAILED');});
 }
 async function revoke(){
  if(disconnected)return tail;disconnected=true;settleReady(browserHostError('BROWSER_HOST_GONE','桌面编辑器已断开'));
  for(const controller of aborts)controller.abort();
  onUnavailable();
  // configureBrowser revocation fences new calls before awaiting delivery.
  const revoked=Promise.resolve().then(()=>Promise.all([configure({generation,detach:true}),configureOffice({generation,detach:true})]));
  tail=Promise.allSettled([tail,revoked]).then(results=>{const failed=results.find(x=>x.status==='rejected');if(failed){onError(failed.reason?.code||'BROWSER_HOST_DETACH_FAILED');throw failed.reason;}});
  return tail;
 }
 const disconnectedEvent=()=>{void revoke().catch(()=>{});};
 child.on('message',receive);child.once('disconnect',disconnectedEvent);child.once('exit',disconnectedEvent);child.once('error',disconnectedEvent);
 return {
  generation,
  available:()=>registered&&current(),
  async open(url){if(!registered||!current())throw browserHostError('BROWSER_HOST_NOT_READY','桌面浏览器还没有就绪',503);await send({type:'koder-browser-open',version:1,nonce,url:browserOpenUrl(url)});return {started:true,already:true,requested:true,loaded:false};},
  async openOffice(target){
    if(!current()||detached)throw browserHostError('BROWSER_HOST_GONE','桌面编辑器已断开',503);
    if(!registered)await new Promise((resolve,reject)=>{
      if(readyWaiters.size>=32)return reject(browserHostError('BROWSER_HOST_BUSY','办公窗口正在打开，请稍后再试',503));
      const finish=error=>{if(!readyWaiters.delete(finish))return;clearTimeout(timer);error?reject(error):resolve();};
      const timer=setTimeout(()=>finish(browserHostError('BROWSER_HOST_NOT_READY','桌面编辑器还没有就绪，请稍后重试',503)),15000);
      readyWaiters.add(finish);
    });
    if(!registered||!current())throw browserHostError('BROWSER_HOST_GONE','桌面编辑器已断开',503);
    await send({type:'koder-office-open',version:1,nonce,target});return {started:true,already:true,requested:true,loaded:false};},
  async close(){try{await revoke();}finally{child.off('message',receive);child.off('disconnect',disconnectedEvent);child.off('exit',disconnectedEvent);child.off('error',disconnectedEvent);}},
 };
}
