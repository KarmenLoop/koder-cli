import {subjectKey} from './personalization-policy.mjs';
import {zonedParts,zonedDay,zonedTime} from './personalization-time.mjs';
const scope=s=>s&&JSON.stringify(['server','tenantId','accountId','spaceId','subjectId','memoryEpoch'].map(k=>s[k]??null));
const sameDestination=(a,b)=>a&&b&&['platform','chatId','threadId'].every(k=>a[k]===b[k]);
function reminderAt(text,timezone,now){
 const match=/^(?:(上午|下午|晚上)\s*)?([一二三四五六七八九十两]{1,2}|\d{1,2})(?::([0-5]\d)|点(?:整)?)$/.exec(text.trim());if(!match)return null;
 const numbers={一:1,二:2,两:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9,十:10,十一:11,十二:12};let hour=numbers[match[2]]??Number(match[2]);if(['下午','晚上'].includes(match[1])&&hour<12)hour+=12;if(!Number.isInteger(hour)||hour<0||hour>23)return null;
 const at=zonedTime(zonedDay(now,timezone),`${String(hour).padStart(2,'0')}:${match[3]||'00'}`,timezone);return at>now?at:null;
}
export function createProactiveService({subject,policy,tasks,channel,owner,clock=Date.now}={}){
 const current=()=>typeof subject==='function'?subject():subject;
 async function enabled(snapshot){return await policy?.require('proactive',snapshot)===true;}
 const ownRows=async()=>((await tasks?.listQuestions?.({subject:current()}))||[]).filter(q=>scope(q.subject)===scope(current()));
 async function patch(row,value,snapshot){return tasks.updateQuestion(row.questionId,row.revision,value,{guard:()=>enabled(snapshot)});}
 return {
  async propose({topic,text,expectedAnswer='text',destination,kind='checkin'}={}){
   const snapshot=await policy?.status(),s=current(),key=subjectKey(s);if(!await enabled(snapshot)||typeof tasks?.createQuestion!=='function')return null;
   if(typeof text!=='string'||!text.trim()||text.length>2000||typeof topic!=='string'||topic.length>120||!['text','choice','reminder-time'].includes(expectedAnswer)||!['checkin','clarification','task'].includes(kind))throw new Error('QUESTION_INVALID');
   const selected=await owner?.destination?.(destination,{subject:s});if(!selected||!sameDestination(selected,destination)||subjectKey(current())!==key||!await enabled(snapshot))return null;
   return tasks.createQuestion({subject:s,topic,text:text.trim(),expectedAnswer,kind,destination:selected,state:'draft',createdAt:clock(),policyRevision:snapshot.revision},{guard:()=>enabled(snapshot)});
  },
  async send(questionId){
   const snapshot=await policy?.status();if(!await enabled(snapshot))return {state:'disabled'};
   let rows=await ownRows(),row=rows.find(q=>q.questionId===questionId);if(!row)return {state:'missing'};
   if(['sent','answered','unknown','sending','cancelled'].includes(row.state))return {...row,state:row.state==='sending'?'unknown':row.state};
   const state=await tasks.state?.({subject:current()})||{};if(state.snoozedUntil>clock())return {state:'snoozed'};
   const hour=Number(zonedParts(clock(),snapshot.timezone).hour),quiet=snapshot.quietHours||{start:22,end:8};
   if(quiet.start!==quiet.end&&(quiet.start>quiet.end?hour>=quiet.start||hour<quiet.end:hour>=quiet.start&&hour<quiet.end))return {state:'quiet-hours'};
   if(rows.filter(q=>q.state==='ignored').length>=2)return {state:'paused-ignored'};
   if(row.kind==='checkin'&&rows.some(q=>{const at=Math.max(q.sentAt||0,q.attemptedAt||0);return at&&clock()-at<86400000;}))return {state:'rate-limited'};
   const destination=await owner?.destination?.(row.destination,{subject:current()});if(!sameDestination(row.destination,destination))return {state:'waiting-destination'};
   const lease=await owner?.acquire?.({taskId:row.taskId,subject:current(),purpose:'proactive-send'});if(!lease)return {state:'waiting-owner'};
   try{
    await lease.requireCurrent();row=await patch(row,{state:'sending',attemptedAt:clock()},snapshot);let result;
    try{result=await channel.send({destination,text:row.text,effectKey:row.questionId,taskId:row.taskId});}catch{result={state:'unknown'};}
    await lease.requireCurrent();if(!await enabled(snapshot))return {state:'revoked',questionId:row.questionId};
    const sent=result?.state==='sent'&&typeof result.messageId==='string'&&result.messageId.length>0;
    row=await patch(row,{state:sent?'sent':'unknown',...(sent?{messageId:result.messageId,sentAt:clock()}:{})},snapshot);return row;
   }finally{await lease.release();}
  },
  async matchReply(inbound){
   const snapshot=await policy?.status();if(!await enabled(snapshot)||!inbound||typeof inbound.text!=='string'||inbound.text.length>8000||!inbound.messageId)return {state:'unmatched'};
   const sender=await owner?.subjectForInbound?.(inbound);if(scope(sender)!==scope(current()))return {state:'unmatched'};
   const rows=await ownRows(),same=q=>sameDestination(q.destination,inbound);
   const duplicate=rows.find(q=>same(q)&&q.answer?.messageId===inbound.messageId);if(duplicate&&(!duplicate.answer.reminderAt||duplicate.reminder))return {state:'matched',question:duplicate,duplicate:true,...(duplicate.reminder?{reminder:duplicate.reminder}:{})};
   const pending=rows.filter(q=>q.state==='sent'&&same(q));let row;
   if(duplicate)row=duplicate;else if(inbound.replyTo)row=pending.find(q=>q.messageId===inbound.replyTo);else if(pending.length===1)row=pending[0];else if(pending.length>1)return {state:'clarify',questionIds:pending.map(q=>q.questionId)};
   if(!row)return {state:'unmatched'};
   let dueAt=duplicate?.answer.reminderAt||null;const timezone=duplicate?.answer.reminderTimezone||snapshot.timezone;if(row.expectedAnswer==='reminder-time'&&!duplicate){dueAt=reminderAt(inbound.text,timezone,clock());if(!dueAt)return {state:'clarify',questionIds:[row.questionId],reasonCode:'REMINDER_TIME_REQUIRED'};}
   const lease=await owner?.acquire?.({taskId:row.taskId,subject:current(),purpose:'proactive-reply'});if(!lease)return {state:'waiting-owner'};
   try{await lease.requireCurrent();if(!duplicate)row=await patch(row,{state:'answered',answer:{messageId:inbound.messageId,text:inbound.text,at:clock(),...(dueAt?{reminderAt:dueAt,reminderTimezone:timezone}:{})}},snapshot);
    if(dueAt){
     const reminder=await tasks.createReminder?.({taskId:row.taskId,questionId:row.questionId,idempotencyKey:row.questionId+':'+inbound.messageId,dueAt,timezone,text:row.text,sourceMessageId:inbound.messageId,subject:current()});
     if(reminder?.id&&reminder.state==='scheduled'){await lease.requireCurrent();row=await patch(row,{reminder},snapshot);return {state:'matched',question:row,reminder};}
     return {state:'matched',question:row,reminder:{state:'waiting-receipt'}};
    }
    return {state:'matched',question:row};
   }finally{await lease.release();}
  },
  async snooze(until){if(!Number.isSafeInteger(until)||until<clock())throw new Error('QUESTION_SNOOZE_INVALID');if(!await owner?.confirmConfiguration?.({subject:current(),snoozedUntil:until}))throw new Error('QUESTION_OWNER_REQUIRED');return tasks.snooze(until,{subject:current()});},
  async status(){const rows=await ownRows();return {enabled:await enabled(),pending:rows.filter(q=>q.state==='sent').length,unknown:rows.filter(q=>['unknown','sending'].includes(q.state)).length,...await tasks?.state?.({subject:current()})};},
 };
}
