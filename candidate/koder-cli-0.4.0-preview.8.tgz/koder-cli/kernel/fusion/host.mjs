import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import {createAppTools} from './app-tools.mjs';
import {createDevelopmentTools} from './development-tools.mjs';

const fusionRoot = path.dirname(fileURLToPath(import.meta.url));

export const FUSION = {
  core: "Koder 自研 Node 内核：会话、工具、模型调用和确认流程都在本机执行。",
  harness: "工具插件由 Koder 内核加载。",
  hermes: "提问、登录和成果工具按 Hermes 的 register(ctx) 形状编写。没有包含 Hermes 的上游代码。",
  codex: "没有接入 Codex。",
};

export function readFlatYaml(text) {
  const out = {};
  for (const line of String(text || "").split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const index = trimmed.indexOf(":");
    if (index < 0) continue;
    out[trimmed.slice(0, index).trim()] = trimmed.slice(index + 1).trim();
  }
  return out;
}

export async function loadFusion({ workspace, builtin, computerDriver=null, skillMaintenance=null,apps=null,researchFetchImpl }) {
  const tools = [];
  const skills = [];
  const disposers = [];
  const services = {
    tools: {
      register(definition) {
        if (!definition?.name || typeof definition.execute !== "function") {
          throw new Error("Harness 插件注册的工具缺少 name 或 execute");
        }
        tools.push(definition);
      },
      runBuiltin(name, args) {
        return builtin.run(name, args);
      },
    },
  };
  const ctx = {
    root: workspace,
    tools: services.tools,
    effect(start) {
      const stop = start();
      if (typeof stop === "function") disposers.push(stop);
    },
    register_tool(definition) {
      services.tools.register(definition);
    },
    register_skill(name, body, metadata = {}) {
      skills.push({ ...metadata, name, body });
    },
  };

  if(computerDriver && ['inspect','capture','act'].every(name=>typeof computerDriver[name]==='function')) {
    for(const name of ['inspect','capture','act']) ctx.register_tool({
      id:`computer.${name}`,name:`computer_${name}`,mutates:name==='act',modes:['standard','code','execute'],
      description:name==='act'?'操作最近截图中的元素；需要原执行审批。':'读取实际电脑驱动状态与当前目标。',
      parameters:{type:'object',properties:name==='capture'?{app:{type:'string'}}:name==='act'?{snapshotId:{type:'string'},element:{type:'string'},action:{type:'string',enum:['click','type','press','scroll','select','focus']},args:{type:'object'}}:{},required:name==='act'?['snapshotId','element','action']:[],additionalProperties:false},
      execute:async args=>name==='act'?builtin.run('computer_act',args):{content:JSON.stringify(await computerDriver[name](args||{}))},
    });
  }
  if(skillMaintenance && ['propose','test','activate','rollback'].every(name=>typeof skillMaintenance[name]==='function')) {
    for(const name of ['propose','test','activate','rollback']) ctx.register_tool({
      id:`skills.${name}`,name:`skill_${name}`,mutates:name!=='test',modes:['standard','code','execute'],description:'受控技能版本接口；激活与回退核对 owner 授权和 expectedVersion。',
      parameters:{type:'object',properties:{sourceTask:{type:'string'},skillId:{type:'string'},candidateId:{type:'string'},expectedVersion:{type:'string'},targetVersion:{type:'string'}},additionalProperties:false},
      execute:async args=>({content:JSON.stringify(await skillMaintenance[name](name==='test'?args.candidateId:args))}),
    });
  }
  await mountHarness(ctx, services);
  for(const tool of createDevelopmentTools({fetchImpl:researchFetchImpl}))ctx.register_tool(tool);
  if(apps)for(const tool of createAppTools({apps}))ctx.register_tool(tool);
  await mountHermes(ctx);
  return {
    tools: () => tools.slice(),
    skills: () => skills.slice(),
    async invoke(name, args, context) {
      const tool = tools.find((item) => item.name === name);
      if (!tool) return { content: `没有这个工具：${name}` };
      try {
        return await tool.execute(args || {},context);
      } catch (error) {
        if(apps&&name.startsWith('app_'))return {content:JSON.stringify({ok:false,state:'failed',errorCode:error?.code||'APP_UNAVAILABLE',content:[]})};
        return { content: error?.message || "工具没有完成" };
      }
    },
    dispose() {
      while (disposers.length) disposers.pop()();
    },
  };
}

async function mountHarness(ctx, services) {
  const dir = path.join(fusionRoot, "plugins");
  const names = (await fs.readdir(dir)).filter((name) => name.endsWith(".mjs")).sort();
  for (const name of names) {
    const plugin = await import(pathToFileURL(path.join(dir, name)).href);
    const inject = plugin.inject || plugin.default?.inject || [];
    for (const key of inject) {
      if (!services[key]) throw new Error(`Harness 插件 ${name} 依赖未提供的服务 ${key}`);
    }
    const apply = plugin.apply || plugin.default?.apply;
    if (typeof apply !== "function") throw new Error(`Harness 插件 ${name} 没有 apply`);
    apply(ctx);
  }
}

async function mountHermes(ctx) {
  const dir = path.join(fusionRoot, "hermes");
  const names = (await fs.readdir(dir)).sort();
  for (const name of names) {
    const folder = path.join(dir, name);
    const stat = await fs.stat(folder);
    if (!stat.isDirectory()) continue;
    const manifest = readFlatYaml(await fs.readFile(path.join(folder, "plugin.yaml"), "utf8").catch(() => ""));
    ctx.plugin = { id: name, ...manifest };
    const plugin = await import(pathToFileURL(path.join(folder, "plugin.mjs")).href);
    if (typeof plugin.register !== "function") throw new Error(`Hermes 插件 ${name} 没有 register`);
    plugin.register(ctx);
  }
}
