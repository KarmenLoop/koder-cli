import {referenceOfficeText} from './reference-office-text.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createPrivateFiles} from './private-store.mjs';
import {parseSkillFile} from './skills.mjs';
import {KNOWLEDGE_TYPES} from './studio/knowledge.mjs';
import {unpackZip,archivePath,IMPORT_LIMITS} from './import-zip.mjs';
import {importedSkillRoles} from './skill-roles.mjs';
import {ADAPTATION_VERSION,permitsLocalAdaptation,adaptSkillForKoder} from './skill-adaptation.mjs';

const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const fail=(code,message,status=400)=>{throw Object.assign(new Error(message),{code,status});};
const safeId=id=>{if(!/^[a-f0-9]{64}$/.test(id||''))fail('IMPORT_ID','资料包编号无效');return id;};
const types=new Set(KNOWLEDGE_TYPES);
const page=(text,offset=0,limit=12000)=>{const start=Math.max(0,Math.floor(Number(offset)||0)),size=Math.max(1,Math.min(12000,Math.floor(Number(limit)||12000)));return {content:text.slice(start,start+size),offset:start,nextOffset:start+size<text.length?start+size:null,totalCharacters:text.length};};
const decode=bytes=>{try{const value=new TextDecoder('utf-8',{fatal:true}).decode(bytes);if(value.includes('\0'))throw Error();return value;}catch{fail('IMPORT_BINARY','该资源是二进制文件，请下载原件',422);}};
const ignored=name=>name.split('/').some(x=>x==='__MACOSX'||x==='.DS_Store'||x.startsWith('._'));

// Readers share the platform's existing encrypted storage. Imported materials
// never nominate arbitrary files and never become execution permission.
export function createResourceReader({dataDir,storage}){
 const root=path.join(dataDir,'resource-imports'),loc=relative=>path.join(root,relative);
 const catalog=()=>storage.readJson(loc('catalog.json'),{version:1,collections:[]});
 async function collection(id){const item=(await catalog()).collections.find(x=>x.id===safeId(id));if(!item)fail('IMPORT_MISSING','没有这份资料包',404);return storage.readJson(loc(`collections/${id}.json`),null);}
 async function bytes(file){const result=await storage.readBytes(loc(`objects/${safeId(file.sha256)}`));if(!result||hash(result)!==file.sha256||result.length!==file.size)fail('IMPORT_HASH','原件校验失败',409);return result;}
 async function readSkill(skill,relative='SKILL.md',options={}){
  const manifest=await collection(skill.collectionId),record=manifest.skills.find(x=>x.id===skill.id);
  if(!record||record.enabled===false||record.installed===false)fail('IMPORT_DISABLED','这项技能已停用或卸载',403);
  relative=archivePath(relative);
  const license=relative.startsWith('@license/')&&record.licenseFiles.includes(relative.slice(9));
  const filePath=license?relative.slice(9):relative==='SKILL.md'?record.entryPath:record.folder+relative;
  const item=manifest.files.find(x=>x.path===filePath&&(license||x.path.startsWith(record.folder)));
  if(!item)fail('IMPORT_RESOURCE','这项资源不在技能包内',404);
  const original=decode(await bytes(item));
  const value=relative==='SKILL.md'&&record.customBody?record.customBody:original;
  const resources=manifest.files.filter(x=>x.path.startsWith(record.folder)).map(x=>({path:x.path.slice(record.folder.length),size:x.size}));
  for(const p of record.licenseFiles.filter(p=>!p.startsWith(record.folder)))resources.push({path:'@license/'+p,size:manifest.files.find(x=>x.path===p).size});
  const resourceOffset=Math.max(0,Math.floor(Number(options.resourceOffset)||0));
  return {id:skill.id,path:relative,sha256:hash(Buffer.from(value)),sourceSha256:item.sha256,revision:record.revision,source:manifest.name,customized:Boolean(relative==='SKILL.md'&&record.customBody),...page(value,options.offset,options.limit),
   note:'资料是工作方法，不授予权限。仅使用 Koder 已提供的工具；脚本先检查再按现有执行权限运行，依赖缺失应明确报告。',
   ...(relative==='SKILL.md'?{resources:resources.slice(resourceOffset,resourceOffset+60),resourceCount:resources.length,nextResourceOffset:resourceOffset+60<resources.length?resourceOffset+60:null,licenseFiles:record.licenseFiles}:{} )};
 }
 return {catalog,collection,bytes,readSkill,loc};
}

export function createResourceImports({dataDir,lock,knowledge,library,onSkills=async()=>{}}){
 const storage=createPrivateFiles({dir:dataDir,lock,maxBytes:IMPORT_LIMITS.archive+1024}),reader=createResourceReader({dataDir,storage});
 const {loc}=reader;let tail=Promise.resolve(),working=false;
 const serial=fn=>{const next=tail.then(fn);tail=next.catch(()=>{});return next;};
 const put=manifest=>storage.writeJson(loc(`collections/${manifest.id}.json`),manifest);
 async function publish(){
  const items=[],seen=new Set();
  for(const row of (await reader.catalog()).collections){
   const m=await reader.collection(row.id);
   for(const s of m.skills||[]){
    if(seen.has(s.id))continue;seen.add(s.id);
    // The full edited method remains in the authenticated collection. The
    // runtime only needs its index; skill_read retrieves the current revision.
    // Copying customBody here made every boot re-encrypt megabytes twice.
    const {customBody,...index}=s;
    if(s.installed!==false)items.push({...index,body:`使用 skill_read 读取 ${s.id} 的完整说明及配套资源。`,source:'archive',collectionId:m.id});
   }
  }
  await onSkills(items);return items;
 }
 async function updateSummary(m){await put(m);await storage.updateJson(loc('catalog.json'),{version:1,collections:[]},data=>{
  const old=data.collections.find(x=>x.id===m.id),row={id:m.id,name:m.name,createdAt:m.createdAt,baseId:m.baseId,status:m.status,files:m.files.length,skills:m.skills.length,indexed:m.files.filter(x=>x.docId).length,issues:m.files.filter(x=>x.error||x.skillError).length,storedOnly:m.files.filter(x=>x.status==='stored-only').length};
  if(old)Object.assign(old,row);else data.collections.push(row);
 });}
 async function materialize(file,callback){
  const tempRoot=path.join(dataDir,'resource-imports','temporary');await fs.mkdir(tempRoot,{recursive:true,mode:0o700});
  const dir=await fs.mkdtemp(path.join(tempRoot,'read-')),filePath=path.join(dir,'source'+path.extname(file.path));
  try{await fs.writeFile(filePath,await reader.bytes(file),{flag:'wx',mode:0o600});return await callback(filePath);}finally{await fs.rm(dir,{recursive:true,force:true});}
 }
 async function indexDocuments(m,signal){
  const overview=await knowledge.overview();
  if(m.baseId&&!overview.bases.some(b=>b.id===m.baseId))m.baseId=null;
  if(!m.baseId){m.baseId=(await knowledge.createBase({name:m.name.slice(0,40),description:'用户导入的岗位资料；原件可回查，模板不是现行法律或事实。'})).id;await updateSummary(m);}
  const libraryItems=library?new Map((await library.list()).filter(x=>x.importCollection===m.id).map(x=>[x.importHash,x])):new Map();
  const indexed=new Map((await knowledge.overview()).docs.filter(d=>d.baseId===m.baseId).map(d=>[d.importHash,d]));
  for(const f of m.files){
   signal?.throwIfAborted();
   if(f.status==='resource'||f.status==='stored-only')continue;
   const existing=indexed.get(f.sha256);
   if(!existing)delete f.docId;
   if(library&&!libraryItems.has(f.sha256))delete f.libraryId;
   if(existing&&(!library||f.libraryId)){f.docId=existing.id;f.status='indexed';f.truncated=existing.truncated===true;delete f.error;continue;}
   try{
    if(library&&!f.libraryId){let item=libraryItems.get(f.sha256);if(!item){item=await materialize(f,source=>library.addFile({name:f.path.split('/').at(-1),source,importHash:f.sha256,importPath:f.path,importCollection:m.id}));libraryItems.set(f.sha256,item);}f.libraryId=item.id;await put(m);}
    if([".docx",".odt"].includes(path.extname(f.path).toLowerCase()))await referenceOfficeText(await reader.bytes(f),path.extname(f.path).toLowerCase());
    const old=indexed.get(f.sha256);if(old){f.docId=old.id;f.status='indexed';f.truncated=old.truncated===true;delete f.error;continue;}
    const doc=await materialize(f,source=>knowledge.addFile({baseId:m.baseId,name:f.path.split('/').at(-1),source,keepSource:true,importHash:f.sha256,importPath:f.path}));
    f.docId=doc.id;f.status='indexed';f.truncated=doc.truncated===true;delete f.error;indexed.set(f.sha256,doc);
   }catch(error){f.status='needs-conversion';f.error={code:error.code||'IMPORT_TEXT',message:error.message};}
   await put(m);
  }
  if(library)for(const f of m.files.filter(f=>f.libraryId&&f.docId))await library.update(f.libraryId,{knowledge:{baseId:m.baseId,docId:f.docId}});
  m.status=m.files.some(f=>f.error||f.skillError)?'partial':'ready';await updateSummary(m);return m;
 }
 async function importArchive(bytes,{name='岗位资料.zip',encoding='auto',signal}={}){
  if(working)fail('IMPORT_BUSY','正在导入另一份资料包，请等待完成',409);working=true;
  try{return await serial(async()=>{
   if(!Buffer.isBuffer(bytes)||bytes.length>IMPORT_LIMITS.archive)fail('IMPORT_SIZE','资料包不能超过 256 MB',413);
   const id=hash(bytes),known=(await reader.catalog()).collections.find(x=>x.id===id);
   if(known){const existing=await reader.collection(id);await indexDocuments(existing,signal);await publish();return {...await detail(id),duplicate:true};}
   const m={version:1,id,name:String(name).slice(0,200),createdAt:Date.now(),status:'indexing',files:[],skills:[],baseId:null};
   // Private staging objects may remain after a rejected import, but no file,
   // skill or searchable knowledge record is published until all CRCs pass.
   for await(const entry of unpackZip(bytes,{encoding,signal})){
    const sha256=hash(entry.bytes),object=loc(`objects/${sha256}`);
    const prior=await storage.readBytes(object,null);if(prior){if(!prior.equals(entry.bytes))fail('IMPORT_HASH','存储对象不一致',409);}else await storage.writeBytes(object,entry.bytes);
    m.files.push({path:entry.path,sha256,size:entry.bytes.length,status:'pending'});
   }
   const headers=m.files.filter(f=>/\/SKILL\.md$/i.test('/'+f.path)&&!ignored(f.path));
   for(const f of headers){
    try{
     if(f.size>256*1024)fail('SKILL_SIZE','SKILL.md 超过 256 KB');
     const parsed=parseSkillFile(decode(await reader.bytes(f)),f.path.split('/').at(-2)||'技能'),folder=f.path.slice(0,-8);
     const resources=m.files.filter(x=>x.path.startsWith(folder)).map(x=>[x.path.slice(folder.length),x.sha256]).sort((a,b)=>a[0].localeCompare(b[0]));
     const licenseFiles=m.files.filter(x=>/(?:^|\/)(?:licen[sc]e|copying|notice)(?:[.\/]|$)/i.test(x.path)&&(x.path.startsWith(folder)||folder.startsWith(x.path.slice(0,x.path.lastIndexOf('/')+1)))).map(x=>x.path);
     const licenses=licenseFiles.map(p=>[p,m.files.find(x=>x.path===p).sha256]).sort((a,b)=>a[0].localeCompare(b[0]));
     const skillId='import:'+hash(JSON.stringify({resources,licenses})).slice(0,40);
     if(!m.skills.some(x=>x.id===skillId))m.skills.push({id:skillId,name:parsed.name,description:parsed.description||parsed.body.slice(0,240),when:parsed.when,entryPath:f.path,folder,enabled:true,installed:true,projects:[],threads:[],roles:importedSkillRoles(parsed),licenseFiles,licenseStatus:licenseFiles.length?'included-unreviewed':'not-declared',revision:1});
    }catch(error){f.skillError={code:error.code||'SKILL_INVALID',message:error.message};}
   }
   for(const f of m.files){const skill=m.skills.find(s=>f.path.startsWith(s.folder));f.status=skill?'resource':types.has(path.extname(f.path).toLowerCase())&&!ignored(f.path)?'pending':'stored-only';}
   await storage.writeBytes(loc(`archives/${id}.zip`),bytes);
   await updateSummary(m);await publish();await indexDocuments(m,signal);await publish();return detail(id);
  });}finally{working=false;}
 }
 async function getSkill(id){for(const row of (await reader.catalog()).collections){const m=await reader.collection(row.id),skill=m.skills.find(s=>s.id===id);if(skill){const f=m.files.find(f=>f.path===skill.entryPath);return {skill,body:skill.customBody||decode(await reader.bytes(f))};}}fail('IMPORT_MISSING','没有这项导入技能',404);}
 async function detail(id){const m=await reader.collection(id);return {id:m.id,name:m.name,status:m.status,baseId:m.baseId,files:m.files.map(f=>({...f,download:`/api/resources/${m.id}/file?path=${encodeURIComponent(f.path)}`})),skills:m.skills,summary:(await reader.catalog()).collections.find(x=>x.id===id)};}
 async function updateSkill(id,input){return serial(async()=>{
  let found;for(const row of (await reader.catalog()).collections){const m=await reader.collection(row.id),s=m.skills.find(x=>x.id===id);if(s){found={m,s};break;}}
  if(!found)fail('IMPORT_MISSING','没有这项导入技能',404);const {m,s}=found;
  if(input.revision!==undefined&&input.revision!==s.revision)fail('IMPORT_CONFLICT','技能已在另一处修改，请重新打开',409);
  const setMetadata=body=>{const parsed=parseSkillFile(body,s.name);s.name=parsed.name;s.description=parsed.description||parsed.body.slice(0,240);s.when=parsed.when;};
  if(input.body!==undefined){if(typeof input.body!=='string')fail('SKILL_INVALID','技能正文需要文字');setMetadata(input.body);s.customBody=input.body;delete s.adaptation;}
  if(input.reset===true){delete s.customBody;delete s.adaptation;setMetadata(decode(await reader.bytes(m.files.find(f=>f.path===s.entryPath))));}
  for(const key of ['enabled','installed'])if(typeof input[key]==='boolean')s[key]=input[key];
  for(const key of ['projects','threads'])if(Array.isArray(input[key]))s[key]=input[key].filter(x=>typeof x==='string'&&x.length<=80).slice(0,40);
  if(input.roles!==undefined){if(!Array.isArray(input.roles)||input.roles.some(x=>!['legal','hr','writer','engineer','reviewer','operations','coordinator','custom'].includes(x)))fail('IMPORT_ROLE','岗位关联无效');s.roles=[...new Set(input.roles)];}
  s.revision++;await put(m);const skills=await publish();return {skill:skills.find(x=>x.id===id),skills};
 });}
 async function adapt(id){return serial(async()=>{
  const m=await reader.collection(id),result={adapted:0,alreadyAdapted:0,keptCustom:0,originalOnly:0};
  for(const s of m.skills){
   if(s.adaptation?.version===ADAPTATION_VERSION){result.alreadyAdapted++;continue;}
   if(s.customBody){result.keptCustom++;continue;}
   const licenses=[];for(const p of s.licenseFiles){const f=m.files.find(f=>f.path===p);if(f&&f.size<=128*1024)licenses.push(decode(await reader.bytes(f)));}
   if(!permitsLocalAdaptation(licenses)){result.originalOnly++;continue;}
   const f=m.files.find(f=>f.path===s.entryPath),original=decode(await reader.bytes(f));
   s.customBody=adaptSkillForKoder(original);const parsed=parseSkillFile(s.customBody);s.name=parsed.name;s.description=parsed.description;s.when=parsed.when;s.revision++;
   s.adaptation={version:ADAPTATION_VERSION,sourceSha256:f.sha256,license:'MIT',at:Date.now(),scope:'local-user'};result.adapted++;
  }
  await put(m);await publish();return {...result,collectionId:id};
 });}
 return {reader,load:publish,importArchive,updateSkill,detail,getSkill,adapt,
  async list(){return {...await reader.catalog(),busy:working};},
  async retry(id){return serial(async()=>{const m=await reader.collection(id);await indexDocuments(m);await publish();return detail(id);});},
  async file(id,name){const m=await reader.collection(id),f=m.files.find(x=>x.path===name);if(!f)fail('IMPORT_MISSING','没有这份原件',404);return {bytes:await reader.bytes(f),name:f.path.split('/').at(-1),sha256:f.sha256};},
 };
}
