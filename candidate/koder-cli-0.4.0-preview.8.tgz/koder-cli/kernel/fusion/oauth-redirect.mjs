// Validates a callback delivered by the original listener. No second server,
// browser, forwarding service or deployment is created by this adapter.
import {timingSafeEqual} from 'node:crypto';
import {appDigest} from './app-binding.mjs';
const error=code=>Object.assign(new Error(code),{code,status:400});
export function createOAuthRedirect({redirectUri,listener,scope=null,current=()=>scope,now=Date.now,timeoutMs=120000}) {
 const uri=new URL(redirectUri);let active=false,consumed=false,started=false,state,deadline,timer,resolve,reject,signal,abort;
 const clear=()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);};
 const cancel=(reason=error('OAUTH_CANCELLED'))=>{if(active){active=false;clear();reject(reason);listener?.cancel?.();}};
 return {
  start(input){
   if(started)throw error('OAUTH_ALREADY_STARTED');started=true;
   state=String(input.state||'');if(state.length<16||state.length>512)throw error('OAUTH_STATE');
   signal=input.signal;signal?.throwIfAborted();active=true;deadline=now()+timeoutMs;
   const done=new Promise((yes,no)=>{resolve=yes;reject=no;});done.catch(()=>{});
   abort=()=>cancel(error('OAUTH_CANCELLED'));signal?.addEventListener('abort',abort,{once:true});timer=setTimeout(()=>cancel(error('OAUTH_EXPIRED')),timeoutMs);
   return {done,redirectUri:uri.href};
  },
  async complete(input){
   if(!active||consumed||now()>=deadline)throw error('OAUTH_EXPIRED');
   const u=new URL(String(input),uri);
   if(u.origin!==uri.origin||u.pathname!==uri.pathname||[...u.searchParams.keys()].some(k=>u.searchParams.getAll(k).length!==1))throw error('OAUTH_CALLBACK');
   const candidate=u.searchParams.get('state')||'';
   if(Buffer.byteLength(candidate)!==Buffer.byteLength(state)||!timingSafeEqual(Buffer.from(candidate),Buffer.from(state)))throw error('OAUTH_STATE');
   const currentScope=await current();
   if(!active||consumed||now()>=deadline)throw error('OAUTH_EXPIRED');
   if(appDigest(currentScope)!==appDigest(scope)){cancel(error('OAUTH_SCOPE_CHANGED'));throw error('OAUTH_SCOPE_CHANGED');}
   const code=u.searchParams.get('code');if(u.searchParams.has('error')||!code||code.length>2048){cancel(error('OAUTH_DENIED'));throw error('OAUTH_DENIED');}
   consumed=true;active=false;clear();resolve(code);return code;
  },cancel,
 };
}
