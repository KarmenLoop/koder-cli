const CJK = /[\u3400-\u9fff]/;

export function estimateTokens(text) {
  let tokens = 0;
  for (const char of String(text || "")) tokens += CJK.test(char) ? 1 : 0.25;
  return Math.ceil(tokens);
}

export function estimateMessages(messages) {
  return messages.reduce((sum, message) => {
    let next = sum + estimateTokens(message.content) + 4;
    // Opaque/signed reasoning is still part of the provider's input window.
    next += estimateTokens(message.providerReasoning);
    if (Array.isArray(message.providerBlocks)) next += estimateTokens(JSON.stringify(message.providerBlocks));
    for (const call of message.toolCalls || []) {
      next += estimateTokens(call.name) + estimateTokens(JSON.stringify(call.arguments || {}));
    }
    return next;
  }, 0);
}

export function contextBudget(profile = {}, ratio = 0.5) {
  const window = Math.max(2048, Number(profile.contextWindow) || 8192);
  const output = Math.min(window - 512, Math.max(256, Number(profile.maxOutput) || 4096));
  const allowed = [0.25, 0.5, 0.75, 1];
  const picked = allowed.includes(Number(ratio)) ? Number(ratio) : 0.5;
  const inputBudget = Math.max(512, Math.floor((window - output) * picked));
  return { window, output, inputBudget, ratio: picked };
}

export const CONTEXT_CATEGORIES = Object.freeze([
  ["system", "系统提示", "#9a9ca3"],
  ["tools", "工具定义", "#7b68ee"],
  ["rules", "规则", "#3cba7a"],
  ["skills", "技能", "#e2a23b"],
  ["mcp", "MCP 与动态工具", "#c084fc"],
  ["subagents", "子代理定义", "#5aa2f0"],
  ["summary", "已压缩的对话", "#ef5d8a"],
  ["conversation", "对话", "#f0a08a"],
]);

// Category estimates are aligned to the provider prompt when one exists, so the
// bar and the legend describe the same total.
export function contextBreakdown({ windowSize = 8192, parts = {}, providerPrompt = null } = {}) {
  const raw = CONTEXT_CATEGORIES.map(([id, label, color]) => ({ id, label, color, tokens: Math.max(0, Math.round(Number(parts[id]) || 0)) }));
  const estimated = raw.reduce((sum, item) => sum + item.tokens, 0);
  const reported = Number.isFinite(Number(providerPrompt)) && Number(providerPrompt) > 0 ? Math.round(Number(providerPrompt)) : 0;
  let categories = raw;
  if (reported && estimated) {
    categories = raw.map((item) => ({ ...item, tokens: Math.round(item.tokens * reported / estimated) }));
    const drift = reported - categories.reduce((sum, item) => sum + item.tokens, 0);
    if (drift) {
      let index = 0;
      categories.forEach((item, i) => { if (item.tokens > categories[index].tokens) index = i; });
      categories[index] = { ...categories[index], tokens: Math.max(0, categories[index].tokens + drift) };
    }
  }
  const total = reported || estimated;
  const window = Math.max(1, Math.round(Number(windowSize) || 8192));
  return { total, window, percent: Math.min(100, Math.round((total / window) * 100)), source: reported ? "provider" : "estimate", categories };
}

export function trimMessages(messages, inputBudget, {protectedToolCallIds = []} = {}) {
  const system = messages.filter((message) => message.role === "system");
  const rest = messages.filter((message) => message.role !== "system" && message.role !== "notice");
  // Keep user turns atomic: the request, assistant calls and their results must
  // travel together. Trimming is only a model projection; disk history is intact.
  const groups = [];
  let lastObservation = -1;
  for (const message of rest) {
    if (!groups.length || message.role === 'user') groups.push([]);
    groups.at(-1).push(message);
    if (Array.isArray(message.images)) lastObservation = groups.length - 1;
  }
  const protectedIds = new Set(protectedToolCallIds.filter(id => typeof id === 'string' && id));
  const selected = new Set();
  const costs = groups.map(group => estimateMessages(group));
  let used = estimateMessages(system);
  groups.forEach((group, index) => {
    if (index === groups.length - 1 || index === lastObservation || group.some(message =>
      protectedIds.has(message.toolCallId) || message.toolCalls?.some(call => protectedIds.has(call.id)))) {
      selected.add(index);
      used += costs[index];
    }
  });
  for (let index = groups.length - 1; index >= 0; index -= 1) {
    if (selected.has(index)) continue;
    if (used + costs[index] > inputBudget) break;
    selected.add(index);
    used += costs[index];
  }
  const kept = groups.flatMap((group, index) => selected.has(index) ? group : []);
  return {
    messages: [...system, ...kept],
    estimated: used,
    dropped: rest.length - kept.length,
    overflow: used > inputBudget,
  };
}
