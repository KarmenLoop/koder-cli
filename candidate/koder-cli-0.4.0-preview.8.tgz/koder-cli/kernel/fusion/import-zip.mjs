// Archive input is data: validate names, sizes and CRCs before publishing it.
// No archive paths are ever used as filesystem destinations.
import {inflateRaw} from 'node:zlib';
import {promisify} from 'node:util';
const inflate=promisify(inflateRaw);
const fail=(code,message)=>{throw Object.assign(new Error(message),{code,status:422});};
export const IMPORT_LIMITS={archive:256*1024*1024,file:64*1024*1024,total:1024*1024*1024,files:20000,depth:3};
const table=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
export function archiveCRC(bytes){let c=0xffffffff;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
export function archivePath(name){
 if(typeof name!=='string'||!name||name.length>2048||/[\\\x00-\x1f\x7f:]/.test(name)||name.startsWith('/')||name.split('/').some(p=>!p||p==='.'||p==='..'||/[. ]$/.test(p)))fail('IMPORT_PATH','压缩包包含无效或越界路径');
 return name.normalize('NFC');
}
function filename(bytes,flags,encoding){
 const choices=flags&0x800?['utf-8']:encoding==='auto'?['utf-8','gb18030']:[encoding];
 for(const choice of choices)try{return new TextDecoder(choice,{fatal:true}).decode(bytes);}catch{}
 fail('IMPORT_ENCODING','文件名编码无法识别，请选择 GB18030 或重新导出 UTF-8 ZIP');
}
export function inspectZip(bytes,{encoding='auto',limits=IMPORT_LIMITS}={}){
 if(!Buffer.isBuffer(bytes)||bytes.length<22||bytes.length>limits.archive)fail('IMPORT_SIZE','ZIP 为空或超过 256 MB');
 if(!['auto','utf-8','gb18030'].includes(encoding))fail('IMPORT_ENCODING','不支持这个文件名编码');
 let end=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(bytes.readUInt32LE(i)===0x06054b50&&i+22+bytes.readUInt16LE(i+20)===bytes.length){end=i;break;}
 if(end<0)fail('IMPORT_ZIP','压缩包目录损坏');
 const count=bytes.readUInt16LE(end+10),size=bytes.readUInt32LE(end+12),start=bytes.readUInt32LE(end+16);
 if(bytes.readUInt16LE(end+4)||bytes.readUInt16LE(end+6)||bytes.readUInt16LE(end+8)!==count||count===65535||size===0xffffffff||start===0xffffffff)fail('IMPORT_ZIP','请使用非分卷、非 ZIP64 的普通 ZIP');
 if(count>limits.files||start+size!==end)fail('IMPORT_ZIP','压缩包目录数量或位置无效');
 let cursor=start,total=0;const seen=new Set(),entries=[],ranges=[];
 for(let n=0;n<count;n++){
  if(cursor+46>end||bytes.readUInt32LE(cursor)!==0x02014b50)fail('IMPORT_ZIP','压缩包目录不完整');
  const flags=bytes.readUInt16LE(cursor+8),method=bytes.readUInt16LE(cursor+10),crc=bytes.readUInt32LE(cursor+16),compressed=bytes.readUInt32LE(cursor+20),length=bytes.readUInt32LE(cursor+24);
  const names=bytes.readUInt16LE(cursor+28),extra=bytes.readUInt16LE(cursor+30),comment=bytes.readUInt16LE(cursor+32),local=bytes.readUInt32LE(cursor+42),mode=bytes.readUInt32LE(cursor+38)>>>16;
  if(cursor+46+names+extra+comment>end||flags&1||![0,8].includes(method)||bytes.readUInt16LE(cursor+34))fail('IMPORT_ZIP','加密或不支持的压缩方式，请解密后重新上传');
  if((mode&0xf000)&&![0x8000,0x4000].includes(mode&0xf000))fail('IMPORT_LINK','压缩包包含链接或设备文件，未导入');
  const rawName=bytes.subarray(cursor+46,cursor+46+names),decoded=filename(rawName,flags,encoding),directory=decoded.endsWith('/');
  const name=archivePath(directory?decoded.slice(0,-1):decoded),fold=name.toLocaleLowerCase();
  if(seen.has(fold))fail('IMPORT_COLLISION','压缩包存在大小写或 Unicode 重名，未覆盖');seen.add(fold);
  if(length>limits.file||(total+=length)>limits.total||length>1024*1024&&length>Math.max(1,compressed)*1000)fail('IMPORT_SIZE','压缩包展开容量超出限制');
  if(local+30>start||bytes.readUInt32LE(local)!==0x04034b50||bytes.readUInt16LE(local+6)!==flags||bytes.readUInt16LE(local+8)!==method)fail('IMPORT_ZIP','文件头与目录不一致');
  const ln=bytes.readUInt16LE(local+26),le=bytes.readUInt16LE(local+28),from=local+30+ln+le,to=from+compressed;
  if(from>start||to>start||!rawName.equals(bytes.subarray(local+30,local+30+ln)))fail('IMPORT_ZIP','压缩包文件边界或名称不一致');
  ranges.push([local,to]);cursor+=46+names+extra+comment;
  if(!directory)entries.push({path:name,size:length,compressed,crc,method,from,to});
 }
 if(cursor!==end)fail('IMPORT_ZIP','压缩包目录尾部不一致');
 ranges.sort((a,b)=>a[0]-b[0]);for(let i=1;i<ranges.length;i++)if(ranges[i][0]<ranges[i-1][1])fail('IMPORT_ZIP','压缩包文件相互重叠');
 return entries;
}
export async function* unpackZip(bytes,options={},budget={files:0,bytes:0,paths:new Set()},prefix='',depth=0){
 const limits=options.limits||IMPORT_LIMITS,entries=inspectZip(bytes,options);
 for(const entry of entries){
  options.signal?.throwIfAborted();
  if(++budget.files>limits.files||(budget.bytes+=entry.size)>limits.total)fail('IMPORT_SIZE','嵌套压缩包展开容量超出限制');
  const compressed=bytes.subarray(entry.from,entry.to);
  let data;try{data=entry.method===0?compressed:await inflate(compressed,{maxOutputLength:Math.max(1,entry.size)});}catch{fail('IMPORT_ZIP','文件解压失败或展开大小不符');}
  if(data.length!==entry.size||archiveCRC(data)!==entry.crc)fail('IMPORT_CRC','文件校验失败，未发布这份资料包');
  const name=prefix+entry.path,key=name.toLowerCase();
  if(budget.paths.has(key))fail('IMPORT_COLLISION','嵌套资料路径重名，未覆盖');budget.paths.add(key);
  yield {path:name,bytes:data};
  if(/\.zip$/i.test(name)){
   if(depth>=limits.depth)fail('IMPORT_DEPTH','嵌套 ZIP 超过三层，请拆开后上传');
   yield* unpackZip(data,options,budget,name+'!/',depth+1);
  }
 }
}
