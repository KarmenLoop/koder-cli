const failure=code=>Object.assign(new Error(code),{code,status:409});
const features=['learning','dailyState','evolution','proactive'];
const fields=['server','tenantId','accountId','spaceId','subjectId','deviceId','generation','memoryEpoch'];
export const subjectKey=s=>s&&JSON.stringify(fields.map(k=>s[k]??null));
const stableKey=s=>s&&JSON.stringify(['server','tenantId','accountId','spaceId','subjectId','memoryEpoch'].map(k=>s[k]??null));
const validSubject=s=>s&&['server','tenantId','accountId','spaceId','subjectId','deviceId'].every(k=>typeof s[k]==='string'&&s[k].length>0&&s[k].length<=2048)&&(Number.isSafeInteger(s.generation)||(typeof s.generation==='string'&&s.generation.length>0&&s.generation.length<=200))&&Number.isSafeInteger(s.memoryEpoch);
const copy=value=>structuredClone(value);
function defaults(subject,clock){return {revision:0,subject:copy(subject),learning:false,dailyState:false,evolution:false,proactive:false,sources:['terminal','acp','desktop','mobile','weixin','feishu','wecom'],from:clock(),timezone:Intl.DateTimeFormat().resolvedOptions().timeZone,budget:4,quietHours:{start:22,end:8},updatedAt:null};}
function validate(patch){
 if(!patch||Object.getPrototypeOf(patch)!==Object.prototype||Object.keys(patch).some(k=>![...features,'sources','from','timezone','budget','quietHours'].includes(k)))throw failure('PERSONALIZATION_PATCH_INVALID');
 for(const k of features)if(k in patch&&typeof patch[k]!=='boolean')throw failure('PERSONALIZATION_PATCH_INVALID');
 if('budget'in patch&&(!Number.isInteger(patch.budget)||patch.budget<1||patch.budget>24))throw failure('PERSONALIZATION_PATCH_INVALID');
 if('from'in patch&&(!Number.isSafeInteger(patch.from)||patch.from<0))throw failure('PERSONALIZATION_PATCH_INVALID');
 if('timezone'in patch){try{new Intl.DateTimeFormat('en',{timeZone:patch.timezone}).format();}catch{throw failure('PERSONALIZATION_PATCH_INVALID');}}
 if('sources'in patch&&(!Array.isArray(patch.sources)||patch.sources.length>16||patch.sources.some(x=>!['terminal','acp','desktop','mobile','weixin','feishu','wecom'].includes(x))))throw failure('PERSONALIZATION_PATCH_INVALID');
 if('quietHours'in patch&&(!patch.quietHours||Object.keys(patch.quietHours).some(k=>!['start','end'].includes(k))||!['start','end'].every(k=>Number.isInteger(patch.quietHours[k])&&patch.quietHours[k]>=0&&patch.quietHours[k]<24)))throw failure('PERSONALIZATION_PATCH_INVALID');
}
export function createPersonalizationPolicy({identity,store,owner,clock=Date.now}={}) {
 let cached=null;
 const current=()=>typeof identity==='function'?identity():identity?.current?.();
 const guard=s=>validSubject(current())&&subjectKey(current())===subjectKey(s);
 async function status(){const s=current();if(!validSubject(s))return {...defaults(null,clock),state:'waiting-identity'};
  const row=await store?.read?.(s);if(!guard(s))throw failure('PERSONALIZATION_SUBJECT_CHANGED');
  cached=row&&stableKey(row.subject)===stableKey(s)?{...copy(row),subject:copy(s)}:defaults(s,clock);
  return {...copy(cached),state:store&&owner?'ready':'waiting-owner'};
 }
 async function require(feature,snapshot){if(!features.includes(feature))return false;const s=await status();return s[feature]===true&&(!snapshot||(snapshot.revision===s.revision&&subjectKey(snapshot.subject)===subjectKey(s.subject)))&&guard(s.subject);}
 async function configure(patch,{expectedRevision}={}){
  if(typeof owner?.confirm!=='function'||typeof store?.compareAndSwap!=='function')throw failure('PERSONALIZATION_OWNER_REQUIRED');validate(patch);
  const before=await status();if(!validSubject(before.subject))throw failure('PERSONALIZATION_IDENTITY_REQUIRED');
  if(before.revision!==expectedRevision)throw failure('PERSONALIZATION_CONFLICT');
  const accepted=await owner.confirm({subject:copy(before.subject),patch:copy(patch),expectedRevision});
  if(!guard(before.subject))throw failure('PERSONALIZATION_SUBJECT_CHANGED');if(accepted!==true)throw failure('PERSONALIZATION_OWNER_REQUIRED');
  const next={...before,...copy(patch),revision:before.revision+1,updatedAt:clock()};delete next.state;
  await store.compareAndSwap(before.revision,next,{subject:before.subject,guard:()=>guard(before.subject)});
  if(!guard(before.subject))throw failure('PERSONALIZATION_SUBJECT_CHANGED');cached=next;return copy(next);
 }
 return {status,configure,require,
  can(feature,subject){return Boolean(cached?.[feature]===true&&subjectKey(subject)===subjectKey(cached.subject)&&guard(cached.subject));},
  revoke(feature,options){if(!features.includes(feature))throw failure('PERSONALIZATION_PATCH_INVALID');return configure({[feature]:false},options);},
 };
}
export async function eligiblePersonalizationSkills({skills,policy,subject}={}){
 const out=[];for(const skill of skills||[]){if(skill.requiredPolicy){if(skill.userDisabled||!policy||!await policy.require(skill.requiredPolicy)||!policy.can(skill.requiredPolicy,subject))continue;out.push({...skill,enabled:true});}else if(skill.enabled!==false)out.push(skill);}return out;
}
