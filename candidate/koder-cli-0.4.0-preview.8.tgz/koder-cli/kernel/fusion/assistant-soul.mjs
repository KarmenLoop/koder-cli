import crypto from 'node:crypto';
import {subjectKey} from './personalization-policy.mjs';
export const SOUL_STYLES=['concise','formal','friendly','analytical','coaching','creative'];
const fields=['name','address','role','style','interests','answerLength','proactivity','topics','avoidTopics','scenarios'];
const failure=code=>Object.assign(new Error(code),{code});
const stable=s=>s&&JSON.stringify(['server','tenantId','accountId','spaceId','subjectId','memoryEpoch'].map(k=>s[k]??null));
function validate(input,nested=false){
 if(!input||Object.getPrototypeOf(input)!==Object.prototype||Object.keys(input).some(k=>!fields.includes(k)||(nested&&k==='scenarios')))throw failure('SOUL_INVALID');
 let bytes;try{bytes=Buffer.byteLength(JSON.stringify(input));}catch{throw failure('SOUL_INVALID');}if(bytes>8192)throw failure('SOUL_LIMIT');
 for(const key of ['name','address','role'])if(key in input&&(typeof input[key]!=='string'||input[key].includes('\0')||(key!=='role'&&input[key].length>80)))throw failure('SOUL_INVALID');
 if(input.style!==undefined&&!SOUL_STYLES.includes(input.style))throw failure('SOUL_INVALID');
 if(input.answerLength!==undefined&&!['short','balanced','detailed'].includes(input.answerLength))throw failure('SOUL_INVALID');
 if(input.proactivity!==undefined&&(!Number.isInteger(input.proactivity)||input.proactivity<0||input.proactivity>3))throw failure('SOUL_INVALID');
 for(const key of ['interests','topics','avoidTopics'])if(key in input&&(!Array.isArray(input[key])||input[key].length>20||input[key].some(x=>typeof x!=='string'||x.length>120)))throw failure('SOUL_INVALID');
 if(input.scenarios!==undefined){if(!input.scenarios||Object.getPrototypeOf(input.scenarios)!==Object.prototype||Object.keys(input.scenarios).length>12)throw failure('SOUL_INVALID');for(const [scenario,value]of Object.entries(input.scenarios)){if(!/^[a-zA-Z0-9_-]{1,64}$/.test(scenario))throw failure('SOUL_INVALID');validate(value,true);}}
 return structuredClone(input);
}
function markdown(input){return '# Assistant soul\n\nUser-edited style data; this file confers no tool permission.\n\n```json\n'+JSON.stringify(input,null,2)+'\n```\n';}
function truncate(text,max){let out='',size=0;for(const c of text){const n=Buffer.byteLength(c);if(size+n>max)break;size+=n;out+=c;}return out;}
export function openAssistantSoul({subject,policy,store,owner}={}){
 const current=()=>typeof subject==='function'?subject():subject,initialKey=subjectKey(current());
 const active=()=>subjectKey(current())===initialKey;
 async function read(){if(!active())return {version:0,input:{},history:[]};const record=await store?.read?.(current());if(!active()||record&&stable(record.subject)!==stable(current()))return {version:0,input:{},history:[]};return structuredClone(record||{version:0,input:{},history:[]});}
 function preview(input){const data=typeof input==='string'?parseImport(input):validate(input);const document=validate(data),md=markdown(document);if(Buffer.byteLength(md)>8192)throw failure('SOUL_LIMIT');return {document,markdown:md};}
 function parseImport(text){if(Buffer.byteLength(text)>8192)throw failure('SOUL_LIMIT');try{return JSON.parse(/```json\s*([\s\S]*?)```/.exec(text)?.[1]||text);}catch{throw failure('SOUL_INVALID');}}
 async function save(input,{expectedVersion}={}){
  if(typeof owner?.confirm!=='function'||typeof store?.compareAndSwap!=='function')throw failure('SOUL_OWNER_REQUIRED');
  const {document,markdown:md}=preview(input),s=structuredClone(current()),key=subjectKey(s);if(!active())throw failure('SOUL_SUBJECT_CHANGED');
  const before=await read();if(before.version!==expectedVersion)throw failure('SOUL_CONFLICT');
  const digest=crypto.createHash('sha256').update(JSON.stringify(document)).digest('hex');
  if(!await owner.confirm({subject:s,operation:'soul-edit',digest,expectedVersion}))throw failure('SOUL_OWNER_REQUIRED');
  const guard=()=>active()&&subjectKey(current())===key;if(!guard())throw failure('SOUL_SUBJECT_CHANGED');
  const next={version:before.version+1,subject:s,input:document,manual:true,history:[...(before.history||[]),{version:before.version,input:before.input}].slice(-20)};
  await store.compareAndSwap(expectedVersion,next,{subject:s,guard,projections:{'SOUL.md':md}});if(!guard())throw failure('SOUL_SUBJECT_CHANGED');return structuredClone(next);
 }
 return {read,preview,save,
  async rollback(version){const before=await read(),prior=before.history.find(x=>x.version===version);if(!prior)throw failure('SOUL_VERSION_MISSING');return save(prior.input,{expectedVersion:before.version});},
  async project({scenario='work',maxBytes=4000}={}){const record=await read();if(!record.manual||!active())return '';const input=validate(record.input),style={...input,...input.scenarios?.[scenario]};delete style.scenarios;return truncate('Assistant style data; current user instructions take precedence; no tool permissions: '+JSON.stringify(style),Math.max(0,Math.min(4000,maxBytes)));},
 };
}
