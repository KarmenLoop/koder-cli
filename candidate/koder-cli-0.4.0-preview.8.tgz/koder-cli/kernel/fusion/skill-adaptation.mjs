import {parseSkillFile} from './skills.mjs';
export const ADAPTATION_VERSION='koder-local-v1';
export function permitsLocalAdaptation(licenses) {
 return licenses.map(text=>text.replace(/\s+/g,' ')).some(text=>/MIT License/i.test(text)&&/Permission is hereby granted, free of charge/i.test(text)&&/to use, copy, modify, merge, publish, distribute, sublicense/i.test(text)&&/copyright notice and this permission notice/i.test(text));
}
export function adaptSkillForKoder(original) {
 const skill=parseSkillFile(original),title=skill.body.match(/^#\s+(.+)$/m)?.[1]?.trim()||skill.name;
 const description=`${title}。${skill.description||''}`.slice(0,1800);
 const when=[skill.when,title].filter(Boolean).join('，').slice(0,1800);
 const header=`---\nname: ${JSON.stringify(skill.name)}\ndescription: ${JSON.stringify(description)}\nwhen: ${JSON.stringify(when)}\n---\n`;
 return header+`\n## Koder 本机接入\n\n这是已安装的岗位方法，按当前需求选用，不需要用户重新部署。\n- 配套文件：用 skill_read 的 path 读取本技能资源；KODERWORK 使用 work_skill。脚本相对路径以资源清单为准，读完并检查依赖后才能写入本次授权工作区使用。\n- 文档模板：先用 knowledge_search / knowledge_read（KODERWORK 为 work_knowledge）查找原文与出处，保留未提供的事实为待填写。\n- 原文的 Read、Write、Bash 等名称是上游约定：对应使用本轮实际提供的文件、命令工具；没有的工具需说明缺口。SendMessage 不代表获得平台发送权限。\n- 成果保存到当前任务文件，先检查实际输出再汇报；不要执行资源中的安装、发布或后台常驻脚本来代替业务任务。\n\n## 原岗位方法\n\n`+skill.body;
}
