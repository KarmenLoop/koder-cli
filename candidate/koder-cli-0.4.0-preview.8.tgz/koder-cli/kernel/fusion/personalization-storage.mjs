import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createPrivateStore} from './private-store.mjs';
import {withPrivateLease} from './private-lease.mjs';
import {writeFileBytes} from '../loop/json-store.mjs';
import {subjectKey} from './personalization-policy.mjs';
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const failure=code=>Object.assign(new Error(code),{code});
const initial=()=>({schemaVersion:1,policy:null,profile:null,soul:null,ownerEdits:[],documents:{'MEMORY.md':'# Memory\n\nNo learned facts.\n','USER_SKILL.md':'# User collaboration guide\n\nLearning is off until selected.\n','SOUL.md':'# Assistant soul\n\nNo manual style configured.\n'}});
const documentName=name=>/^(MEMORY|USER_SKILL|SOUL)\.md$/.test(name)||/^(commands|reflections)\/\d{4}-\d{2}-\d{2}(?:-\d+)?\.md$/.test(name);
export function createPersonalizationStorage({dir,lock,identity,sourcePlatform='desktop'}={}) {
 if(!lock?.seal||!lock?.open||typeof identity!=='function')throw failure('PERSONALIZATION_STORAGE_REQUIRED');
 const subject=structuredClone(identity()),key=subjectKey(subject);
 if(!subject?.spaceId||!subject.subjectId)throw failure('PERSONALIZATION_IDENTITY_REQUIRED');
 const root=path.join(dir,hash([subject.server,subject.tenantId,subject.accountId,subject.spaceId]),hash(subject.subjectId));
 const files=createPrivateStore({dir:root,lock,maxBytes:32*1024*1024});
 const current=()=>subjectKey(identity())===key;
 async function safeDirectory(relative=''){
  const parts=[root,...relative.split('/').filter(Boolean)];let target=parts.shift();
  for(let i=0;i<=parts.length;i++){if(i)target=path.join(target,parts[i-1]);try{await fs.mkdir(target,{recursive:i===0,mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}const s=await fs.lstat(target);if(s.isSymbolicLink()||!s.isDirectory())throw failure('PERSONALIZATION_PATH_UNSAFE');}
 }
 async function project(record){
  await safeDirectory();const docs=record.documents||{};
  for(const [name,text]of Object.entries(docs)){
   if(!documentName(name)||typeof text!=='string'||Buffer.byteLength(text)>(name==='MEMORY.md'?65536:name==='USER_SKILL.md'?16384:name==='SOUL.md'?8192:1048576))throw failure('PERSONALIZATION_PROJECTION_INVALID');
   const parent=path.posix.dirname(name);if(parent!=='.')await safeDirectory(parent);
   const file=path.join(root,...name.split('/'));const stat=await fs.lstat(file).catch(e=>{if(e.code==='ENOENT')return null;throw e;});if(stat&&(stat.isSymbolicLink()||!stat.isFile()))throw failure('PERSONALIZATION_PATH_UNSAFE');
   await writeFileBytes(file,text);
  }
  // Remove only generated journals absent from the committed source snapshot.
  for(const folder of ['commands','reflections']){
   let names;try{names=await fs.readdir(path.join(root,folder));}catch(e){if(e.code==='ENOENT')continue;throw e;}
   for(const name of names){const rel=folder+'/'+name;if(documentName(rel)&&!Object.hasOwn(docs,rel)){const file=path.join(root,rel),s=await fs.lstat(file);if(!s.isFile()||s.isSymbolicLink())throw failure('PERSONALIZATION_PATH_UNSAFE');await fs.unlink(file);}}
  }
 }
 const exclusive=work=>withPrivateLease(root,'personalization-source-and-projections',work,{assertActive:()=>{lock.assertAlive?.();if(!current())throw failure('PERSONALIZATION_SUBJECT_CHANGED');}});
 async function recover(){const recovery=await files.readJson('recovery.json',null);if(!recovery)return;if(recovery.schemaVersion!==1||!recovery.before)throw failure('PERSONALIZATION_RECOVERY_REQUIRED');await project(recovery.before);await files.writeJson('state.json',recovery.before);await files.remove('recovery.json');}
 async function read(){return exclusive(async()=>{await recover();const row=await files.readJson('state.json',initial());if(row.schemaVersion!==1)throw failure('PERSONALIZATION_STORAGE_INVALID');return row;});}
 async function change(kind,expected,next,options={}){
  if(options.guard&&!await options.guard())throw failure('PERSONALIZATION_SUBJECT_CHANGED');
  return exclusive(async()=>{
   await recover();const before=await files.readJson('state.json',initial());const version=before[kind]?.[kind==='policy'?'revision':'version']??0;
   if(version!==expected)throw failure(kind==='policy'?'PERSONALIZATION_CONFLICT':kind==='soul'?'SOUL_CONFLICT':'PROFILE_CONFLICT');
   if(kind==='profile'&&options.ownerAction){const action=options.ownerAction;if(action.operation!=='forget'||!Array.isArray(action.ids)||!action.ids.length||!(before.ownerEdits||[]).some(e=>e.receipt===action.receipt&&e.evidence.category==='owner-edit'&&e.evidence.operation==='forget'&&action.ids.every(id=>e.evidence.ids?.includes(id))))throw failure('PROFILE_SOURCE_REQUIRED');}
   else if(kind==='profile'&&options.policySnapshot){const p=before.policy;if(p?.revision!==options.policySnapshot.revision||(!p.learning&&!p.dailyState))throw failure('PROFILE_REVOKED');}
   const updated=structuredClone(before);updated[kind]=structuredClone(next);
   if(kind==='profile'&&next.forgotten?.length)updated.ownerEdits=(updated.ownerEdits||[]).filter(e=>!next.forgotten.includes(e.evidence.eventId));
   if(options.projections){for(const [name,text]of Object.entries(options.projections)){if(!documentName(name))throw failure('PERSONALIZATION_PROJECTION_INVALID');updated.documents[name]=text;}
    if(kind==='profile')for(const name of Object.keys(updated.documents))if(name.startsWith('commands/')&&!Object.hasOwn(options.projections,name))delete updated.documents[name];}
   await files.writeJson('recovery.json',{schemaVersion:1,before});
   try{await project(updated);if(!current())throw failure('PERSONALIZATION_SUBJECT_CHANGED');await files.writeJson('state.json',updated);const saved=await files.readJson('state.json');if(hash(saved)!==hash(updated))throw failure('PERSONALIZATION_READBACK_FAILED');await files.remove('recovery.json');return structuredClone(next);}
   catch(e){try{await project(before);await files.writeJson('state.json',before);await files.remove('recovery.json');e.rollbackComplete=true;}catch(rollback){throw Object.assign(failure('PERSONALIZATION_RECOVERY_REQUIRED'),{cause:new AggregateError([e,rollback])});}throw e;}
  });
 }
 return {
  async authorizeEdit(evidence,owner){
   if(!evidence||evidence.subjectId!==subject.subjectId||typeof evidence.eventId!=='string'||typeof evidence.text!=='string'||evidence.text.length>2000)throw failure('PERSONALIZATION_EDIT_INVALID');
   if(!await owner?.confirm?.({subject,operation:'memory-edit',evidence:structuredClone(evidence)}))throw failure('PERSONALIZATION_OWNER_REQUIRED');
   const receipt='owner-edit:'+crypto.randomUUID();
   await exclusive(async()=>{await recover();const record=await files.readJson('state.json',initial());record.ownerEdits=[...(record.ownerEdits||[]),{receipt,evidence:structuredClone(evidence),subject:structuredClone(subject),platform:sourcePlatform,createdAt:Date.now()}].slice(-128);await files.writeJson('state.json',record);});return receipt;
  },
  async verifyOwnerEdit(candidate,receipt){if(typeof receipt!=='string')return null;const record=await read(),row=(record.ownerEdits||[]).find(e=>e.receipt===receipt&&e.evidence.eventId===candidate?.eventId);return row?{evidence:structuredClone(row.evidence),direct:true,explicit:true,authorSubjectId:subject.subjectId,receiptRef:receipt,platform:row.platform,createdAt:row.createdAt}:null;},
  async authorizeOwnerAction({receipt,ids}){const record=await read();return (record.ownerEdits||[]).some(e=>e.receipt===receipt&&e.evidence.category==='owner-edit'&&e.evidence.operation==='forget'&&ids.every(id=>e.evidence.ids?.includes(id)));},
  policyStore:{async read(){return (await read()).policy;},compareAndSwap:(expected,next,options)=>change('policy',expected,next,options)},
  versions:{async read(){return (await read()).profile;},commit:(expected,next,options)=>change('profile',expected,next,options)},
  soulStore:{async read(){return (await read()).soul;},compareAndSwap:(expected,next,options)=>change('soul',expected,next,options)},
  async mirror(kind,value,projections={}){
   if(!['policy','profile','soul'].includes(kind))throw failure('PERSONALIZATION_STORAGE_INVALID');
   const before=await read(),key=kind==='policy'?'revision':'version',prior=before[kind];
   if(prior?.shared&&prior.subject?.memoryEpoch===value.subject?.memoryEpoch&&prior[key]>value[key])throw failure('PERSONALIZATION_REMOTE_STALE');
   const next={...structuredClone(value),shared:true};if(hash(prior)===hash(next))return next;
   return change(kind,prior?.[key]??0,next,{projections});
  },
  async repair(){return exclusive(async()=>{await recover();const row=await files.readJson('state.json',initial());await project(row);return {state:'ready',directory:root};});},
  async status(){const row=await read();return {directory:root,encrypted:true,policyRevision:row.policy?.revision??0,profileVersion:row.profile?.version??0,soulVersion:row.soul?.version??0};},
 };
}
