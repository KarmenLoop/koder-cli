import fs from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";
import { openInside, resolveInside } from "../harness/paths.mjs";
import { parseCsv } from "./studio/professional-audit.mjs";

const MAX_REPORT_BYTES = 4 * 1024 * 1024;
const stamp = s => `${s.dev}:${s.ino}:${s.size}:${s.mtimeMs}:${s.ctimeMs}`;
async function readSnapshot(located) {
  const opened = await openInside(located, constants.O_RDONLY | (constants.O_NONBLOCK || 0));
  try {
    const before = await opened.file.stat();
    if (!before.isFile() || before.nlink > 1) throw new Error("只处理工作区内普通文件");
    if (before.size > MAX_REPORT_BYTES) throw new Error("本地报表一次支持 4 MiB 以内的文本，请分批处理");
    const bytes = Buffer.alloc(before.size);
    let offset = 0;
    while (offset < bytes.length) {
      const { bytesRead } = await opened.file.read(bytes, offset, bytes.length - offset, offset);
      if (!bytesRead) throw new Error("读取期间文件发生变化，请重新处理");
      offset += bytesRead;
    }
    await opened.recheck();
    const after = await opened.file.stat(), current = await fs.lstat(located.target);
    if (current.isSymbolicLink() || current.nlink > 1 || stamp(before) !== stamp(after) || stamp(after) !== stamp(current)) throw new Error("读取期间文件或路径发生变化，请重新处理");
    let raw;
    try { raw = new TextDecoder("utf-8", { fatal: true }).decode(bytes); }
    catch { throw new Error("文件不是 UTF-8 文本，请先从 Office 导出 UTF-8 CSV"); }
    if (raw.includes("\0")) throw new Error("二进制内容不能当作文本报表读取");
    return raw;
  } finally { await opened.close(); }
}

export async function buildReport(root, input) {
  let located;
  try {
    located = await resolveInside(root, input);
  } catch (error) {
    return { content: error.message || "路径不能读" };
  }
  if (!located.exists) return { content: "文件不存在，没有生成成果" };
  try {
    const raw = await readSnapshot(located);
    const after = path.extname(located.rel).toLowerCase() === ".csv" ? csvReport(located.rel, raw) : textReport(located.rel, raw);
    const outRel = outputPath(located.rel);
    const out = await resolveInside(root, outRel);
    const before = out.exists ? await readSnapshot(out) : "";
    return { pause: { kind: "change", path: out.rel, before, after } };
  } catch (error) {
    return { content: `${error.message || "文件无法读取"}；没有生成成果。` };
  }
}

function outputPath(rel) {
  const parsed = path.parse(rel);
  return path.join(parsed.dir || ".", `${parsed.name}-结果.md`).split(path.sep).join("/");
}

function csvReport(rel, raw) {
  const parsed = parseCsv(raw), header = parsed.headers;
  for (const row of parsed.rows) if (row.cells.length !== header.length) throw new Error(`CSV 第 ${row.line} 行列数与表头不同，请核对原文件`);
  const rows = parsed.rows.map(row => row.cells);
  const last = header.length - 1;
  const counts = new Map();
  for (const row of rows) {
    const key = row[last] || "（空）";
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  const display = value => value.replaceAll("\\", "\\\\").replaceAll("\r", "\\r").replaceAll("\n", "\\n");
  const tally = [...counts.entries()].map(([key, count]) => `- ${display(key)}：${count}`).join("\n");
  const listed = rows.map((row) => `- ${row.map(display).join(" / ")}`).join("\n");
  return [
    `# ${rel} 的本地结果`,
    "",
    "这些数字直接来自文件原文，没有补造。",
    "",
    `- 表头：${header.join(" / ") || "（无）"}`,
    `- 数据行：${rows.length}`,
    "",
    "## 末列计数",
    tally || "- （无）",
    "",
    "## 原文逐条（单元格内换行显示为 \\r / \\n）",
    listed || "- （无）",
    "",
  ].join("\n");
}

function textReport(rel, raw) {
  const lines = raw.split(/\r?\n/);
  const used = lines.filter((line) => line.trim());
  return [
    `# ${rel} 的本地结果`,
    "",
    "下面只引用文件里已经有的行。",
    "",
    `- 总行数：${lines.length}`,
    `- 非空行：${used.length}`,
    "",
    "## 原文",
    raw.trim() || "（空文件）",
    "",
  ].join("\n");
}

