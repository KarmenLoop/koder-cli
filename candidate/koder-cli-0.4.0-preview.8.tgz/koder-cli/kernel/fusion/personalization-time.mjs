export function zonedParts(ms,timeZone){const parts=new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(ms);return Object.fromEntries(parts.filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));}
export function zonedDay(ms,timeZone){const p=zonedParts(ms,timeZone);return `${p.year}-${p.month}-${p.day}`;}
export function addDays(day,n){return new Date(Date.parse(day+'T12:00:00Z')+n*86400000).toISOString().slice(0,10);}
export function zonedTime(day,time,timeZone){
 const target=Date.parse(day+'T'+time+':00Z'),wanted=day+'T'+time;let candidate=target;const seen=[];
 for(let i=0;i<5;i++){const p=zonedParts(candidate,timeZone),local=`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;
  if(local===wanted){for(const offset of [-7200000,-3600000]){const earlier=candidate+offset,q=zonedParts(earlier,timeZone);if(`${q.year}-${q.month}-${q.day}T${q.hour}:${q.minute}`===wanted)return earlier;}return candidate;}
  seen.push(candidate);candidate+=target-Date.parse(local+':00Z');
 }
 // A nonexistent wall time advances to the first existing minute of that day.
 const low=Math.min(...seen)-3600000,high=Math.max(...seen)+3600000;
 for(let ms=low;ms<=high;ms+=60000){const p=zonedParts(ms,timeZone),local=`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;if(local>=wanted&&local.startsWith(day))return ms;}
 throw new Error('PERSONALIZATION_TIME_INVALID');
}
