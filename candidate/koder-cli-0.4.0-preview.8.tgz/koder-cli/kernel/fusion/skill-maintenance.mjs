import crypto from 'node:crypto';
import {types} from 'node:util';
const fail=code=>{throw Object.assign(new Error(code),{code});};
const digest=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const scopeOf=x=>Object.fromEntries(['requiredCapabilities','roots','dependencies','communications','tools'].map(k=>{
 const values=x[k];if(!Array.isArray(values)||values.length>64||values.some(v=>typeof v!=='string'||v.length>4096))fail('SKILL_SCOPE_INVALID');return [k,[...new Set(values)].sort()];
}));
const copy=x=>structuredClone(x);
const bodyOf=x=>{if(typeof x!=='string'||!x.trim()||Buffer.byteLength(x)>32768)fail('SKILL_CONTENT_INVALID');return x;};
// Only digest-bound, successfully replayed versions can replace pinned instructions.
export function verifiedMaintenance(skill){
 try{
  const a=skill?.activeMaintenance,r=a?.testReceipt;
  if(!a||bodyOf(a.body)!==skill.body||a.contentDigest!==digest({body:a.body,scope:scopeOf(a.scope)})||!r?.ok||r.contentDigest!==a.contentDigest||r.scopeDigest!==digest(scopeOf(a.scope))||!Number.isSafeInteger(r.cases)||r.cases<1||r.passed!==r.cases||r.sideEffects!==0)return null;
  return a;
 }catch{return null;}
}
export function createSkillMaintenance({registry,capabilities,testRunner,versionStore}={}) {
 if(!registry?.getSkill||!registry?.getTask||!registry?.extractMethod||!capabilities?.authorize||!testRunner?.replay||!versionStore?.compareAndSwap)throw new TypeError('Skill maintenance requires original host ports');
 async function state(){const s=await versionStore.read();if(!Number.isSafeInteger(s?.revision)||!s.candidates||!s.versions||!s.active)fail('SKILL_STATE_INVALID');return copy(s);}
 const authorize=()=>capabilities.authorize({tool:'skills.activate'});
 async function candidate(id){const s=await state(),c=s.candidates[id];if(!c)fail('SKILL_CANDIDATE_MISSING');if(c.contentDigest!==digest({body:c.body,scope:c.scope})||c.scopeDigest!==digest(c.scope))fail('SKILL_CONTENT_CHANGED');return {s,c};}
 async function commit(s){const old=s.revision;s.revision++;await versionStore.compareAndSwap(old,s);}
 return {
  async propose({sourceTask,skillId}={}){
   if(typeof sourceTask!=='string'||sourceTask.length>200||typeof skillId!=='string'||skillId.length>100)fail('SKILL_INPUT_INVALID');
   const original=await registry.getTask(sourceTask);if(original?.id!==sourceTask||original.status!=='completed'||!original.receiptId||!/^([a-f0-9]{40}|[a-f0-9]{64})$/.test(original.sourceCommit||''))fail('SKILL_TASK_UNVERIFIED');
   const base=await registry.getSkill(skillId);if(base?.id!==skillId||typeof base.version!=='string')fail('SKILL_MISSING');
   const method=await registry.extractMethod(original,base);if(!method||types.isProxy(method))fail('SKILL_CONTENT_INVALID');
   const scope=scopeOf(method);if(digest(scope)!==digest(scopeOf(base)))fail('SKILL_SCOPE_EXPANSION');
   const body=bodyOf(method.body),s=await state();if(Object.keys(s.candidates).length>=64)fail('SKILL_CANDIDATE_LIMIT');
   const c={candidateId:crypto.randomUUID(),skillId,sourceTask,sourceReceiptId:original.receiptId,sourceCommit:original.sourceCommit,body,scope,requiredCapabilities:scope.requiredCapabilities,baseVersion:s.active[skillId]?.version||base.version,contentDigest:digest({body,scope}),scopeDigest:digest(scope),testReceipt:null,createdAt:Date.now()};
   s.versions[skillId]||={};s.versions[skillId][base.version]||={version:base.version,body:base.body,scope:scopeOf(base),contentDigest:digest({body:base.body,scope:scopeOf(base)})};
   s.candidates[c.candidateId]=c;await commit(s);return copy(c);
  },
  async test(candidateId){
   const {c}=await candidate(candidateId);let timer;
   const receipt=await Promise.race([Promise.resolve().then(()=>testRunner.replay(copy(c))),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Object.assign(new Error('SKILL_TEST_TIMEOUT'),{code:'SKILL_TEST_TIMEOUT'})),20000);})]).finally(()=>clearTimeout(timer));
   if(!receipt||receipt.contentDigest!==c.contentDigest||receipt.scopeDigest!==c.scopeDigest||!Number.isSafeInteger(receipt.cases)||receipt.cases<1||!Number.isSafeInteger(receipt.passed)||receipt.passed<0||receipt.passed>receipt.cases||receipt.sideEffects!==0||(receipt.ok===true&&receipt.passed!==receipt.cases))fail('SKILL_TEST_RECEIPT_INVALID');
   const {s,c:fresh}=await candidate(candidateId);fresh.testReceipt={ok:receipt.ok===true,cases:receipt.cases,passed:receipt.passed,sideEffects:0,contentDigest:c.contentDigest,scopeDigest:c.scopeDigest,at:Date.now()};await commit(s);return copy(fresh.testReceipt);
  },
  async activate({candidateId,expectedVersion}={}){
   await authorize();const {s,c}=await candidate(candidateId),base=await registry.getSkill(c.skillId),current=s.active[c.skillId]?.version||base.version;
   if(current!==expectedVersion||current!==c.baseVersion)fail('SKILL_VERSION_CONFLICT');
   if(!c.testReceipt?.ok||c.testReceipt.contentDigest!==c.contentDigest||c.testReceipt.scopeDigest!==c.scopeDigest)fail('SKILL_TEST_REQUIRED');
   if(digest(scopeOf(base))!==c.scopeDigest)fail('SKILL_SCOPE_EXPANSION');
   if(Object.keys(s.versions[c.skillId]||{}).length>=64)fail('SKILL_VERSION_LIMIT');
   const active={version:c.candidateId,body:c.body,scope:c.scope,contentDigest:c.contentDigest,sourceTask:c.sourceTask,testReceipt:c.testReceipt};
   s.versions[c.skillId][active.version]=active;s.active[c.skillId]=active;await authorize();await commit(s);return copy(active);
  },
  async rollback({skillId,targetVersion,expectedVersion}={}){
   await authorize();const s=await state();if(s.active[skillId]?.version!==expectedVersion)fail('SKILL_VERSION_CONFLICT');const target=s.versions[skillId]?.[targetVersion];if(!target)fail('SKILL_VERSION_MISSING');
   const base=await registry.getSkill(skillId);if(digest(scopeOf(base))!==digest(target.scope))fail('SKILL_SCOPE_EXPANSION');
   s.active[skillId]=copy(target);await authorize();await commit(s);return copy(target);
  },
 };
}
// Existing encrypted skills bag and its original owner lease remain the only writer.
export function createSkillVersionStore({store,exclusive}={}) {
 if(!store?.saveSkills||!store?.skills||typeof exclusive!=='function')throw new TypeError('Original store and exclusive lease required');
 const id='internal:skill-maintenance-state';
 const read=()=>copy(store.skills().find(s=>s.id===id)?.maintenance||{revision:0,candidates:{},versions:{},active:{}});
 return {async read(){return read();},async compareAndSwap(revision,next){return exclusive(async()=>{
  if(read().revision!==revision||next.revision!==revision+1)fail('SKILL_VERSION_CONFLICT');
  const skills=copy(store.skills()).filter(s=>s.id!==id).map(s=>next.active[s.id]?{...s,body:next.active[s.id].body,activeMaintenance:copy(next.active[s.id])}:s);
  for(const [skillId,active] of Object.entries(next.active))if(!skills.some(s=>s.id===skillId))skills.push({id:skillId,name:skillId,source:'maintenance-overlay',body:active.body,activeMaintenance:copy(active)});
  skills.push({id,name:'Skill maintenance state',body:'Internal version history',source:'internal',enabled:false,maintenance:copy(next)});await store.saveSkills(skills);
 });}};
}
