// Categories for the skill library. A skill can match more than one.
// `query` is added to a GitHub search when an update is aimed at that category.

export const SKILL_TOPICS = [
  { id: "office", label: "办公", query: "office OR document OR email OR calendar OR meeting", words: ["office", "document", "spreadsheet", "email", "calendar", "meeting", "slide", "办公", "邮件", "会议", "文档", "表格", "周报"] },
  { id: "personal", label: "个人", query: "personal OR habit OR journal OR lifestyle", words: ["personal", "habit", "journal", "lifestyle", "个人", "习惯", "日记", "生活"] },
  { id: "writing", label: "写作", query: "writing OR copywriting OR blog", words: ["writing", "copywriting", "blog", "editor", "写作", "文案", "文章"] },
  { id: "research", label: "研究", query: "research OR paper OR citation", words: ["research", "paper", "citation", "academic", "研究", "论文"] },
  { id: "design", label: "设计", query: "design OR figma OR interface", words: ["design", "figma", "interface", "设计", "界面"] },
  { id: "coding", label: "开发", query: "code OR debug OR refactor OR testing", words: ["code", "debug", "refactor", "testing", "开发", "编程", "测试"] },
  { id: "data", label: "数据", query: "data OR analytics OR sql", words: ["analytics", "sql", "csv", "数据", "分析"] },
  { id: "product", label: "产品", query: "product OR roadmap OR specification", words: ["product", "roadmap", "specification", "产品", "需求"] },
];

const KNOWN = new Set(SKILL_TOPICS.map((topic) => topic.id));

export function skillTopicQuery(id) {
  return SKILL_TOPICS.find((topic) => topic.id === id)?.query || "";
}

export function skillTopicIds(item) {
  const hay = `${item?.name || ""} ${item?.description || ""} ${item?.repository || ""} ${item?.when || ""}`.toLocaleLowerCase();
  const inferred = SKILL_TOPICS.filter((topic) => topic.words.some((word) => hay.includes(word.toLocaleLowerCase()))).map((topic) => topic.id);
  const stored = Array.isArray(item?.topics) ? item.topics.filter((id) => KNOWN.has(id)) : [];
  return [...new Set([...stored, ...inferred])];
}
