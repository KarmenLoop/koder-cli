import path from 'node:path';
import {appDigest} from './app-binding.mjs';
import {withPrivateLease} from './private-lease.mjs';

// The source host has already stopped its old writers before this function.
// Prepare/readback precedes source retirement; commit can be resumed after a crash.
export async function migrateApplicationConnections({dir,storage,scope,source,request,assertCurrent=()=>{}}){
 const markerFile=path.join(dir,'app-connection-migration.json'),backupFile=path.join(dir,'app-connection-migration-backup.json');
 return withPrivateLease(dir,'app-connection-migration',async()=>{
  await assertCurrent();let marker=await storage.readJson(markerFile,null);
  if(marker?.state==='committed')return marker;
  const target=appDigest([scope.profileId,scope.accountId]);
  if(marker&&marker.target!==target)throw problem('APP_MIGRATION_ACCOUNT','旧连接的迁移属于另一账户，请恢复原账户完成迁移');
  if(!marker){
   const exported=await source();await assertCurrent();
   if(exported?.cleanupComplete!==true)throw problem('APP_MIGRATION_BUSY','旧应用宿主尚未确认停止');
   const snapshot=exported.snapshot,digest=appDigest(snapshot),sourceId=appDigest(path.resolve(dir));
   const empty=!snapshot?.mcp?.servers?.length&&!Object.keys(snapshot?.auth?.servers||{}).length&&!snapshot?.gamma?.gamma;
   if(empty){marker={state:'committed',sourceId,digest,target,empty:true};await storage.writeJson(markerFile,marker);return marker;}
   const prepared=await request('prepare',{sourceId,digest,snapshot});
   if(prepared.digest!==digest||prepared.sourceId!==sourceId)throw problem('APP_MIGRATION_VERIFY','迁移目标读回不一致');
   await storage.writeJson(backupFile,{sourceId,digest,snapshot});
   if(appDigest((await storage.readJson(backupFile)).snapshot)!==digest)throw problem('APP_MIGRATION_VERIFY','旧连接的加密备份读回不一致');
   await assertCurrent();marker={state:'retired',sourceId,digest,target};await storage.writeJson(markerFile,marker);
  }
  await assertCurrent();const result=await request('commit',{sourceId:marker.sourceId,digest:marker.digest});
  if(result.state!=='committed'||result.digest!==marker.digest)throw problem('APP_MIGRATION_VERIFY','迁移尚未完成，请恢复原连接宿主');
  marker={...marker,state:'committed'};await storage.writeJson(markerFile,marker);return marker;
 },{assertActive:assertCurrent});
}
const problem=(code,message)=>Object.assign(new Error(message),{code,status:409});

// One durable import journal is replayed before any transport or OAuth owner is
// constructed. A crash between encrypted files cannot expose a partial import.
export function createConnectionMigrationStore({dir,storage}){
 const pendingFile=path.join(dir,'app-import-pending.json');
 const stageFile=id=>{if(!/^[a-f0-9]{64}$/.test(id||''))throw problem('APP_MIGRATION_INVALID','迁移来源无效');return path.join(dir,'app-imports',id+'.json');};
 const locations={mcp:'loop/mcp.json',auth:'mcp-auth.json',gamma:'app-connect.json'};
 const defaults={mcp:{servers:[]},auth:{servers:{}},gamma:{}};
 async function commit(stage){
  if(stage.state==='committed'){await storage.writeJson(pendingFile,null);return {state:stage.state,sourceId:stage.sourceId,digest:stage.digest};}
  await storage.writeJson(pendingFile,{sourceId:stage.sourceId});
  for(const entry of stage.files){
   const file=path.join(dir,locations[entry.kind]),current=await storage.readJson(file,defaults[entry.kind]),hash=appDigest(current);
   if(hash!==entry.before&&hash!==appDigest(entry.value))throw problem('APP_MIGRATION_CONFLICT','应用配置在迁移中发生变化，已保留原件');
   if(hash!==appDigest(entry.value))await storage.writeJson(file,entry.value);
   if(appDigest(await storage.readJson(file,defaults[entry.kind]))!==appDigest(entry.value))throw problem('APP_MIGRATION_VERIFY','应用配置迁移读回不一致');
  }
  stage.state='committed';await storage.writeJson(stageFile(stage.sourceId),stage);await storage.writeJson(pendingFile,null);
  return {state:stage.state,sourceId:stage.sourceId,digest:stage.digest};
 }
 return {
  async recover(){const pending=await storage.readJson(pendingFile,null);if(pending){const stage=await storage.readJson(stageFile(pending.sourceId),null);if(!stage)throw problem('APP_MIGRATION_VERIFY','迁移记录缺失');await commit(stage);}},
  async request(action,{sourceId,digest,snapshot}){
   const file=stageFile(sourceId),existing=await storage.readJson(file,null);
   if(existing){if(existing.digest!==digest)throw problem('APP_MIGRATION_CONFLICT','迁移来源已变化');return action==='commit'?commit(existing):{state:existing.state,sourceId,digest};}
   if(action!=='prepare'||appDigest(snapshot)!==digest||!Array.isArray(snapshot?.mcp?.servers)||typeof snapshot?.auth?.servers!=='object'||!snapshot?.gamma||Buffer.byteLength(JSON.stringify(snapshot))>800000)throw problem('APP_MIGRATION_INVALID','迁移记录无效');
   const files=[];
   for(const kind of Object.keys(locations)){
    const current=await storage.readJson(path.join(dir,locations[kind]),defaults[kind]);let value;
    if(kind==='mcp'){
     const incoming=snapshot.mcp.servers.filter(entry=>entry.protocol!=='native').map(entry=>({...entry,tools:[],verifiedAt:null}));
     const ids=new Set(),names=new Set();
     if(incoming.some(entry=>{const invalid=!/^[-a-f0-9]{36}$/.test(entry.id||'')||!entry.serverName||ids.has(entry.id)||names.has(entry.serverName)||current.servers.some(old=>old.id===entry.id||old.serverName===entry.serverName);ids.add(entry.id);names.add(entry.serverName);return invalid;}))throw problem('APP_MIGRATION_CONFLICT','已有同名应用配置，请先核对旧连接');
     value={...current,servers:[...current.servers,...incoming]};
    }else if(kind==='auth'){
     if(Object.keys(snapshot.auth.servers).some(id=>Object.hasOwn(current.servers,id)))throw problem('APP_MIGRATION_CONFLICT','已有同名应用授权，未覆盖');
     value={...current,servers:{...current.servers,...snapshot.auth.servers}};
    }else{
     if(current.gamma&&snapshot.gamma.gamma)throw problem('APP_MIGRATION_CONFLICT','已有 Gamma 授权，未覆盖');
     value={...current,...snapshot.gamma};
     if(value.gamma)value.gamma={...value.gamma,verifiedAt:null,connectionId:null};
    }
    files.push({kind,before:appDigest(current),value});
   }
   const stage={state:'prepared',sourceId,digest,files};await storage.writeJson(file,stage);
   if(appDigest(await storage.readJson(file,null))!==appDigest(stage))throw problem('APP_MIGRATION_VERIFY','迁移暂存读回失败');
   return {state:'prepared',sourceId,digest};
  },
 };
}
