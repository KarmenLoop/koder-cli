// Attach to one original KARMEN LOOP connections process per local profile.
// The private lease serializes startup. Only ESRCH permits replacement; age
// and an unresponsive/live PID never authorize taking over another process.
import fs from 'node:fs/promises';
import {constants} from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {withPrivateLease} from './private-lease.mjs';
import {appScope,scopeIdentity} from './app-profile.mjs';
import {writeFileJson,writeFileBytes} from '../loop/json-store.mjs';
import {openMemoryCredentials} from './native-credentials.mjs';
import {koderEnv,startKoder} from '../bin/koder.mjs';

const fail=(code,message='应用宿主归属无法确认，请稍后重试')=>Object.assign(new Error(message),{code});
async function readRecord(file) {
  let fd;
  try {
    fd=await fs.open(file,constants.O_RDONLY|(constants.O_NOFOLLOW||0));
    const stat=await fd.stat();if(!stat.isFile()||stat.size>16384||(process.platform!=='win32'&&(stat.mode&0o077)!==0))throw fail('APP_HOST_RECORD_INVALID');
    return JSON.parse(await fd.readFile('utf8'));
  } catch(error){if(error.code==='ENOENT')return null;throw error;}
  finally {await fd?.close();}
}
function ownerAlive(record) {
  if(record?.host!==os.hostname()||!Number.isSafeInteger(record.pid)||record.pid<=0||typeof record.generation!=='string'||!/^[a-f0-9]{64}$/.test(record.generation))throw fail('APP_HOST_RECORD_INVALID');
  try{process.kill(record.pid,0);return true;}catch(error){if(error.code==='ESRCH')return false;throw fail('APP_OWNER_UNCONFIRMED');}
}
async function request(record,method,route,body,{signal,clientId,timeout=30000}={}) {
  if(!Number.isSafeInteger(record.port)||record.port<1||record.port>65535||typeof record.gate!=='string'||!/^[a-f0-9]{64}$/.test(record.gate))throw fail('APP_HOST_RECORD_INVALID');
  const response=await fetch(`http://127.0.0.1:${record.port}${route}`,{method,redirect:'error',headers:{'x-koder-gate':record.gate,...(clientId?{'x-koder-app-client':clientId}:{}),...(body===undefined?{}:{'content-type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.any([AbortSignal.timeout(timeout),...(signal?[signal]:[])])});
  return {status:response.status,json:await response.json()};
}
export async function openAppHost({profile,scope,signal,currentScope=()=>scope,env=process.env,startImpl=startKoder,clearCredentials}={}) {
  scope=appScope(scope);signal?.throwIfAborted();
  const dir=path.resolve(profile.profileDir),infoFile=path.join(dir,'app-host.json'),launchFile=path.join(dir,'app-host-launch.json');
  const client={id:crypto.randomUUID(),host:os.hostname(),pid:process.pid,scope};
  const assertCurrent=()=>{signal?.throwIfAborted();if(JSON.stringify(appScope(currentScope()))!==JSON.stringify(scope))throw fail('APP_CONNECTION_CHANGED','应用账户或会话已变化');};
  const record=await withPrivateLease(dir,'app-host-start',async()=>{
    assertCurrent();
    let launch=await readRecord(launchFile),info=await readRecord(infoFile);
    const active=launch||info;
    if(active&&ownerAlive(active)) {
      launch=active;
      if(scopeIdentity(active.scope)!==scopeIdentity(scope))throw fail('APP_CONNECTION_CHANGED','应用宿主属于另一账户或设备');
    } else {
      const generation=crypto.randomBytes(32).toString('hex'),gate=crypto.randomBytes(32).toString('hex');
      const gateFile=path.join(dir,'app-host-gate');
      await writeFileBytes(gateFile,gate);
      const fullEnv=koderEnv(env,{KODER_RUNTIME_KIND:'connections',KODER_DATA:dir,KODER_WORKSPACE:dir,KODER_PORT:'0',KODER_GATE_FILE:gateFile,KODER_WORKBENCH_TOKEN:gate,KODER_APP_GENERATION:generation,KODER_APP_SCOPE:JSON.stringify(scope),KODER_APP_INITIAL_CLIENT:JSON.stringify(client)});
      const child=startImpl([],fullEnv,'ignore',{detached:true});
      let spawnError;child.on('error',error=>{spawnError=error;});
      if(!Number.isSafeInteger(child.pid))throw fail('APP_HOST_START_FAILED','应用宿主未能启动');
      launch={version:1,host:os.hostname(),pid:child.pid,generation,scope,gate};
      await writeFileJson(launchFile,launch);child.unref?.();
      if(spawnError)throw fail('APP_HOST_START_FAILED','应用宿主未能启动');
    }
    // Bounded startup wait. A still-live failed owner remains recorded for
    // diagnosis; no second owner or automatic unknown-effect replay starts.
    const end=Date.now()+30000;
    for(;;) {
      assertCurrent();info=await readRecord(infoFile);
      if(info?.generation===launch?.generation&&info.pid===launch.pid)break;
      if(!ownerAlive(launch))throw fail('APP_HOST_START_FAILED','应用宿主启动失败，请检查本机凭据存储是否已解锁');
      if(Date.now()>=end)throw fail('APP_HOST_START_PENDING','应用宿主尚未就绪，已保留原进程，请稍后重试');
      await delay(25,undefined,{signal});
    }
    if(scopeIdentity(info.scope)!==scopeIdentity(scope))throw fail('APP_CONNECTION_CHANGED');
    const identity=await request(info,'GET','/internal/apps-host/identity',undefined,{signal,timeout:5000});
    if(identity.status!==200||identity.json.generation!==info.generation||scopeIdentity(identity.json.scope)!==scopeIdentity(scope))throw fail('APP_OWNER_UNCONFIRMED');
    const acquired=await request(info,'POST','/internal/apps-host/acquire',client,{signal});
    if(acquired.status!==200)throw fail(acquired.json.code||'APP_OWNER_UNCONFIRMED',acquired.json.error);
    return info;
  },{assertActive:assertCurrent});
  let released=false,releaseJob;
  const handle={
    scope,bridgeToken:record.gate,
    isCurrent(){try{assertCurrent();return !released;}catch{return false;}},
    kernel:{
      async call(method,route,body,options={}) {
        try{if(released)throw fail('APP_CONNECTION_CHANGED','应用连接已释放');assertCurrent();}
        catch(error){return {status:409,json:{code:error.code,error:error.message}};}
        if(typeof route!=='string'||!route.startsWith('/')||route.startsWith('//'))throw fail('APP_ROUTE_INVALID');
        const result=await request(record,method,route,body,{...options,clientId:client.id});
        try{if(released)throw fail('APP_CONNECTION_CHANGED');assertCurrent();}
        catch(error){return {status:409,json:{code:error.code,error:error.message}};}
        return result;
      },
      info:()=>({state:released?'released':'ready',pid:record.pid,port:record.port}),
    },
    release(){return releaseJob||=(async()=>{
      released=true;
      const result=await request(record,'POST','/internal/apps-host/release',{id:client.id},{clientId:client.id});
      if(result.status!==200)throw fail(result.json.code||'APP_RELEASE_FAILED');
      if(result.json.clients>0)return {cleanupComplete:true,shared:true};
      const end=Date.now()+10000;
      while(ownerAlive(record)&&Date.now()<end)await delay(25);
      const dead=!ownerAlive(record),closed=dead?await readRecord(path.join(dir,'app-host-closed.json')):null;
      const matching=closed?.generation===record.generation&&closed.pid===record.pid&&closed.host===record.host;
      return {cleanupComplete:dead&&matching&&closed.receipt?.ok===true,shared:false,...(matching?{receipt:closed.receipt}:{})};
    })();},
    async erase(){return withPrivateLease(dir,'app-host-start',async()=>{
      if(released)throw fail('APP_CONNECTION_CHANGED');assertCurrent();
      const before=await fs.lstat(dir);
      const prepared=await handle.kernel.call('POST','/internal/apps-host/prepare-erase',{});
      if(prepared.status!==200)throw fail(prepared.json.code||'APP_ERASE_BUSY',prepared.json.error);
      const stopped=await handle.release();if(!stopped.cleanupComplete)throw fail('APP_CLEANUP_PENDING','应用宿主停止尚未确认，未删除凭据');
      const after=await fs.lstat(dir);if(after.isSymbolicLink()||!after.isDirectory()||before.dev!==after.dev||before.ino!==after.ino)throw fail('APP_ERASE_UNSAFE');
      assertCurrent();await (clearCredentials||(()=>openMemoryCredentials({dir,namespace:'apps'}).clear()))();
      try{for(const name of await fs.readdir(dir))if(name!=='.private-locks')await fs.rm(path.join(dir,name),{recursive:true,force:true});}
      catch(error){throw Object.assign(error,{code:'APP_ERASE_PARTIAL',keyRevoked:true});}
      return {cleanupComplete:true,keyRevoked:true,erased:true};
    },{assertActive:assertCurrent});},
  };
  return handle;
}
