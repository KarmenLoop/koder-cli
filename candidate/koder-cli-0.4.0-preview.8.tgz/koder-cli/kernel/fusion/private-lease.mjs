import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
// Cross-process exclusion for an existing private file. Unknown/live owners
// are never expired by age; a crashed local owner's exact record is reclaimed.
export async function withPrivateLease(root,key,work,{assertActive=()=>{}}={}) {
 assertActive();
 await fs.mkdir(root,{recursive:true,mode:0o700});const rootStat=await fs.lstat(root);if(!rootStat.isDirectory()||rootStat.isSymbolicLink())throw new Error('私有存储根目录无效');
 const directory=path.join(root,'.private-locks');await fs.mkdir(directory,{recursive:true,mode:0o700});const stat=await fs.lstat(directory);if(!stat.isDirectory()||stat.isSymbolicLink())throw new Error('私有存储锁目录无效');
 const file=path.join(directory,`${crypto.createHash('sha256').update(key).digest('hex')}.lock`);const owner={host:os.hostname(),pid:process.pid,token:crypto.randomUUID()};const deadline=Date.now()+5000;let handle;
 while(!handle) {
  assertActive();
  try{handle=await fs.open(file,'wx',0o600);await handle.writeFile(JSON.stringify(owner));await handle.close();}
  catch(error){if(handle){try{await handle.close();}catch{}throw error;}if(error.code!=='EEXIST')throw error;
   let raw,current;try{const stat=await fs.lstat(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>4096)throw new Error('私有存储锁无效');raw=await fs.readFile(file,'utf8');current=JSON.parse(raw);}catch(readError){if(readError.code==='ENOENT')continue;if(Date.now()>=deadline)throw readError;await new Promise(r=>setTimeout(r,10));continue;}
   if(current.host!==owner.host||!Number.isSafeInteger(current.pid)||current.pid<=0||!current.token)throw new Error('不能确认私有存储锁归属');
   try{process.kill(current.pid,0);}catch(check){if(check.code==='ESRCH'){if(await fs.readFile(file,'utf8').catch(()=>null)===raw)await fs.unlink(file).catch(e=>{if(e.code!=='ENOENT')throw e;});continue;}throw check;}
   if(Date.now()>=deadline)throw Object.assign(new Error('私有存储正在被其他进程修改'),{code:'STORAGE_BUSY'});await new Promise(r=>setTimeout(r,10));
  }
 }
 try{assertActive();return await work();}finally{const raw=await fs.readFile(file,'utf8').catch(error=>{if(error.code==='ENOENT')return null;throw error;});if(raw!==null){const current=JSON.parse(raw);if(current.token!==owner.token)throw new Error('私有存储锁已更换');await fs.unlink(file).catch(error=>{if(error.code!=='ENOENT')throw error;});}}
}
