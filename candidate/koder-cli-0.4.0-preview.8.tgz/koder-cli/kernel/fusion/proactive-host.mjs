import crypto from 'node:crypto';
import {acquireHostLease} from './host-maintenance.mjs';
import {createProactiveService} from './proactive-service.mjs';
const failure=code=>Object.assign(new Error(code),{code});
export function createProactiveHost({subject,policy,transport,automation,channel,current,profile,language='zh',clock=Date.now,platform='terminal'}){
 const leases=new Map();let closed=false;
 const local=destination=>destination?.platform===platform&&destination.chatId==='local'&&destination.threadId==='local';
 const decorate=row=>({...row,subject});
 const tasks={
  async listQuestions(){if(!await policy.require('proactive'))return [];const items=[];let cursor=null;for(let page=0;page<64;page++){const result=await transport('question-list',{spaceId:subject.spaceId,...(cursor?{cursor}:{})});items.push(...result.items.map(decorate));if(!result.hasMore)return items;if(!result.nextCursor||result.nextCursor===cursor)throw failure('QUESTION_CURSOR_STALLED');cursor=result.nextCursor;}throw failure('QUESTION_LIST_LIMIT');},
  async createQuestion(row,{guard}){if(!await guard()||!await current())throw failure('QUESTION_REVOKED');const question=Object.fromEntries(['topic','text','expectedAnswer','kind','destination'].map(k=>[k,row[k]]));return decorate(await transport('question-create',{spaceId:subject.spaceId,question}));},
  async updateQuestion(id,revision,patch,{guard}){if(!await guard()||!await current())throw failure('QUESTION_REVOKED');const lease=leases.get(id);if(!lease)throw failure('QUESTION_OWNER_REQUIRED');return decorate(await lease.call('question-update',{expectedRevision:revision,patch}));},
  async createReminder({questionId,idempotencyKey,dueAt,text,timezone}){const id=crypto.createHash('sha256').update(idempotencyKey).digest('hex');await automation.createReminder({id,questionId,dueAt,text,timezone});return {id,dueAt,text,timezone,state:'scheduled'};},
  async state(){return {};},
  async snooze(){throw failure('QUESTION_SNOOZE_HOST_UNAVAILABLE');},
 };
 const owner={
  async destination(value){return !closed&&local(value)&&await current()?structuredClone(value):null;},
  async subjectForInbound(value){return !closed&&local(value)&&value.actorId===subject.subjectId&&await current()?subject:null;},
  async acquire({taskId}){if(closed)return null;let lease;try{lease=await acquireHostLease({transport,input:{purpose:'proactive',spaceId:subject.spaceId,key:taskId},current:async()=>!closed&&await current()});}catch(error){if(error.code==='HOST_LEASE_BUSY')return null;throw error;}leases.set(taskId,lease);return {...lease,async release(){if(leases.get(taskId)===lease)leases.delete(taskId);await lease.release();}};},
 };
 const service=createProactiveService({subject,policy,tasks,channel,owner,clock});
 return {service,
  async checkIn(){
   if(!await policy.require('proactive')||!await current())return {state:'disabled'};
   const rows=await tasks.listQuestions();
   if(rows.some(q=>q.kind==='checkin'&&q.topic==='daily-checkin'&&local(q.destination)&&['sending','unknown'].includes(q.state)))return {state:'waiting-reconciliation'};
   if(rows.some(q=>{const at=Math.max(q.sentAt||0,q.attemptedAt||0);return at&&clock()-at<86400000;}))return {state:'rate-limited'};
   if(rows.some(q=>q.state==='sent'&&q.kind==='checkin'))return {state:'waiting-answer'};
   const identity=(await profile?.query({text:'work',limit:5})||[]).some(row=>row.category==='explicit-background');
   const text=language==='en'?(identity?'What work would you like me to help with today?':'How can I help today? You can also tell me what you like to be called and how you prefer to communicate.'):(identity?'今天有什么工作需要交给我处理？':'今天想让我帮你什么？也可以告诉我你希望的称呼和交流方式。');
   const q=await service.propose({topic:'daily-checkin',text,destination:{platform,chatId:'local',threadId:'local'}});return q?service.send(q.questionId):{state:'disabled'};
  },
  async restoreReminders(){for(const q of await tasks.listQuestions()){
   if(q.reminder?.state==='scheduled')await automation.createReminder({...q.reminder,questionId:q.questionId});
   else if(q.answer?.reminderAt&&!q.reminder)await service.matchReply({...q.destination,actorId:subject.subjectId,messageId:q.answer.messageId,text:q.answer.text});
  }},
  async remind(questionId){
   if(!await policy.require('proactive'))return {state:'disabled'};
   let row=(await tasks.listQuestions()).find(q=>q.questionId===questionId);if(!row?.reminder||row.reminder.state!=='scheduled'||row.reminder.dueAt>clock())return {state:row?.reminder?.state||'missing'};
   const lease=await owner.acquire({taskId:row.taskId});if(!lease)return {state:'waiting-owner'};
   try{const snapshot=await policy.status();row=await tasks.updateQuestion(questionId,row.revision,{reminder:{...row.reminder,state:'sending'}},{guard:()=>policy.require('proactive',snapshot)});
    let receipt;try{receipt=await channel.send({destination:row.destination,text:row.reminder.text,effectKey:row.reminder.id,taskId:row.taskId});}catch{receipt={state:'unknown'};}
    const sent=receipt?.state==='sent'&&typeof receipt.messageId==='string';return await tasks.updateQuestion(questionId,row.revision,{reminder:{...row.reminder,state:sent?'sent':'unknown',...(sent?{messageId:receipt.messageId}:{})}},{guard:()=>policy.require('proactive',snapshot)});
   }finally{await lease.release();}
  },
  async close(){closed=true;await Promise.allSettled([...leases.values()].map(x=>x.release()));leases.clear();},
 };
}
