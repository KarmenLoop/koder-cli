import path from 'node:path';
import { createJsonStore } from './studio/store.mjs';
const queues = new WeakMap();
export function createMcpAuthStore({ dir, lock, storage }) {
  if (!storage && (!lock?.seal || !lock?.open)) throw new Error('MCP 授权需要数据加密锁');
  const file = path.join(dir, 'mcp-auth.json');
  // The connections runtime is the only writer; its existing storage worker
  // owns encryption and atomic replacement. No credential key crosses IPC.
  const store = storage ? {
    file, read:()=>storage.readJson(file,{servers:{}}),
    update(change) {
      let lanes=queues.get(storage);if(!lanes){lanes=new Map();queues.set(storage,lanes);}
      const job=(lanes.get(file)||Promise.resolve()).then(async()=>{
        const value=await storage.readJson(file,{servers:{}}),result=await change(value);
        await storage.writeJson(file,value);return result;
      });lanes.set(file,job.catch(()=>{}));return job;
    },
  } : createJsonStore(file, { servers: {} }, { lock });
  const key = (id) => {
    if (typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(id)) throw new Error('MCP 授权 ID 不合法');
    return id;
  };
  return {
    file: store.file,
    async get(id) { return (await store.read()).servers[key(id)] || {}; },
    update(id, change) { return store.update(async (data) => { const record = data.servers[key(id)] ||= {}; return change(record); }); },
    delete(id) { return store.update((data) => { delete data.servers[key(id)]; }); },
  };
}
