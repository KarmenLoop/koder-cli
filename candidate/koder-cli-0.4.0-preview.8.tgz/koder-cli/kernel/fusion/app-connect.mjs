// Gamma API credentials owned by the original protected application service.
import crypto from "node:crypto";
import http from "node:http";
import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import {loadGammaConnectionConfig,publicOAuthRedirect} from './gamma-config.mjs';
import {createOAuthRedirect} from './oauth-redirect.mjs';
import {appDigest} from './app-binding.mjs';

export const GAMMA = Object.freeze({
  id: "gamma",
  registerUrl: "https://auth.gamma.app/oauth/register",
  authorizeUrl: "https://auth.gamma.app/oauth/authorize",
  tokenUrl: "https://auth.gamma.app/oauth/token",
  apiBase: "https://public-api.gamma.app/v1.0",
  resource: "https://public-api.gamma.app",
  scope: "generate",
});

export const APP_NOTE = "应用授权由服务方提供。Gamma API 支持 API Key 或已登记的 Koder OAuth 客户端；Gamma MCP 使用单独的 OAuth 授权与公开 HTTPS 回调。凭据只加密保存在本机，连接状态以实际验证为准。";

export const APP_CATALOG = Object.freeze([
  {
    id: "gamma",
    name: "Gamma",
    oneClick: false,
    summary: "连接 Gamma API 后可生成演示、文档、网页或社交帖；生成需要批准并消耗 Gamma 额度。OAuth 登录需要 Koder 已登记的客户端与回调，或使用自己的 API Key。",
  },
]);

export const APP_CALL_TOOL = {
  name: "app_call",
  description: "调用已验证的 Gamma API。action 为 status、create 或 poll。create 需要用户批准且消耗 Gamma 额度；返回 pending 或 unknown 时保留 generationId 并查询，不重复创建。未连接时引导用户到应用设置选择 API Key 或 OAuth。API 与 Gamma MCP 的授权分别验证。",
  parameters: {
    type: "object",
    properties: {
      app: { type: "string" },
      action: { type: "string" },
      text: { type: "string" },
      format: { type: "string" },
      cards: { type: "integer" },
      generationId: { type: "string" },
    },
    required: ["app", "action"],
  },
};

const CALLBACK_PATH = "/gamma/callback";
const FORMATS = new Set(["presentation", "document", "social", "webpage"]);
const fail = (code, message, status = 400) => Object.assign(new Error(message), { code, status });

export function gammaRedirectUri(port) {
  return `http://127.0.0.1:${port}${CALLBACK_PATH}`;
}

export function gammaPkce() {
  const verifier = crypto.randomBytes(32).toString("base64url");
  const challenge = crypto.createHash("sha256").update(verifier).digest("base64url");
  return { verifier, challenge, method: "S256" };
}

export function gammaRegisterBody(redirectUri) {
  const redirect = new URL(redirectUri);
  if (redirect.protocol !== "http:" || redirect.hostname !== "127.0.0.1" || redirect.pathname !== CALLBACK_PATH || redirect.search || redirect.username) throw fail("GAMMA_REDIRECT", "Gamma 回调只能是本机地址");
  return {
    client_name: "Koder",
    redirect_uris: [redirectUri],
    grant_types: ["authorization_code", "refresh_token"],
    response_types: ["code"],
    token_endpoint_auth_method: "none",
  };
}

export function gammaAuthorizeUrl({ clientId, redirectUri, state, challenge }) {
  if (!/^[\w.-]{8,200}$/.test(clientId || "")) throw fail("GAMMA_CLIENT", "Gamma 没有返回可用的登录程序");
  if(!publicOAuthRedirect(redirectUri))gammaRegisterBody(redirectUri);
  if (!/^[A-Za-z0-9_-]{43,128}$/.test(challenge || "")) throw fail("GAMMA_PKCE", "登录校验没有生成");
  const url = new URL(GAMMA.authorizeUrl);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("code_challenge", challenge);
  url.searchParams.set("code_challenge_method", "S256");
  url.searchParams.set("state", state);
  url.searchParams.set("scope", GAMMA.scope);
  url.searchParams.set("resource", GAMMA.resource);
  return url.toString();
}

export function parseGammaCallback(target, expectedState) {
  const url = new URL(String(target || ""), "http://127.0.0.1");
  if (url.pathname !== CALLBACK_PATH) return null;
  if([...url.searchParams.keys()].some(key=>url.searchParams.getAll(key).length!==1))throw fail('GAMMA_STATE','Gamma 回调参数重复');
  const state = url.searchParams.get("state") || "";
  const expected = Buffer.from(String(expectedState || ""));
  const got = Buffer.from(state);
  if (expected.length < 16 || got.length !== expected.length || !crypto.timingSafeEqual(got, expected)) throw fail("GAMMA_STATE", "Gamma 登录被中断，请再点一次");
  const error = url.searchParams.get("error");
  if (error) throw fail("GAMMA_DENIED", error === "access_denied" ? "你取消了 Gamma 授权" : "Gamma 没有完成授权");
  const code = url.searchParams.get("code") || "";
  if (!/^[A-Za-z0-9._~-]{8,512}$/.test(code)) throw fail("GAMMA_CODE", "Gamma 没有返回可用的登录码");
  return code;
}

export function openGammaAuthorize(url, { platform = process.platform, spawnImpl = spawn } = {}) {
  const parsed = new URL(url);
  if (parsed.protocol !== "https:" || parsed.hostname !== "auth.gamma.app" || parsed.pathname !== "/oauth/authorize") throw fail("GAMMA_URL", "只能打开 Gamma 官方授权页");
  const command = platform === "darwin" ? ["open", [parsed.toString()]]
    : platform === "win32" ? ["rundll32", ["url.dll,FileProtocolHandler", parsed.toString()]]
    : ["xdg-open", [parsed.toString()]];
  const child = spawnImpl(command[0], command[1], { detached: true, stdio: "ignore", windowsHide: true });
  child.unref?.();
  child.stdin?.end?.();
  return parsed.toString();
}

export function listenGammaCallback({ port = 0, state, signal, timeoutMs = 180000,redirectUri,scope=null,current=()=>scope } = {}) {
  signal?.throwIfAborted();
  let settled = false;
  let redirect;
  const server = http.createServer(async(req, res) => {
    if(req.method!=='GET'||req.headers.host!==`127.0.0.1:${server.address().port}`){res.writeHead(400).end();return;}
    let code = null, error = null;
    try { code = parseGammaCallback(req.url, state);if(code!==null)await redirect.complete(new URL(req.url,redirectUri||gammaRedirectUri(server.address().port)).href); }
    catch (caught) { error = caught; }
    if (code === null && !error) { res.writeHead(404, { "content-type": "text/plain; charset=utf-8" }); res.end("没有这个地址"); return; }
    const page = error ? "Gamma 登录没有完成。请回到 Koder 再点一次。" : "Gamma 已授权。请回到 Koder，登录会在那里完成。";
    res.writeHead(error ? 400 : 200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
    res.end(`<!doctype html><meta charset="utf-8"><title>Gamma</title><p>${page}</p>`);
    if(!error)finish(null,code);
  });
  const finish = (error, code) => {
    if (settled) return;
    settled = true;
    clearTimeout(timer);
    server.close();
    redirect?.cancel();
    signal?.removeEventListener('abort',abort);
    error ? rejectDone(error) : resolveDone(code);
  };
  let resolveDone = () => {}, rejectDone = () => {};
  const done = new Promise((resolve, reject) => { resolveDone = resolve; rejectDone = reject; });
  done.catch(() => {});
  const timer = setTimeout(() => finish(fail("GAMMA_TIMEOUT", "Gamma 登录超时，请再点一次", 408)), timeoutMs);
  const ready = new Promise((resolve, reject) => {
    server.once("error", (error) => {
      const wrapped = error.code === "EADDRINUSE" ? fail("GAMMA_PORT", "本机登录端口正被占用，请再点一次", 409) : error;
      reject(wrapped);
      finish(wrapped);
    });
    server.listen(port, "127.0.0.1", () => {
      redirect=createOAuthRedirect({redirectUri:redirectUri||gammaRedirectUri(server.address().port),scope,current,timeoutMs});
      redirect.start({state,signal}).done.catch(error=>finish(error));
      resolve(server.address().port);
    });
  });
  const abort=()=>finish(fail("GAMMA_CANCELLED", "Gamma 登录已取消", 499));
  signal?.addEventListener("abort",abort, { once: true });
  return { ready, done, cancel: () => finish(fail("GAMMA_CANCELLED", "Gamma 登录已取消", 499)) };
}

async function readJson(response) {
  const text = typeof response.text === "function" ? await response.text() : "";
  if (text.length > 200000) throw fail("GAMMA", "Gamma 返回过长", 502);
  let json;
  try { json = JSON.parse(text); }
  catch { throw fail("GAMMA", "Gamma 返回无法解析", 502); }
  if (response.ok === false || (Number(response.status) >= 400)) throw fail("GAMMA", gammaPublicMessage(json), response.status || 502);
  return json;
}

function gammaPublicMessage(json) {
  const code = String(json?.error_description || json?.error || json?.message || "").replace(/\s+/g, " ").trim();
  if (!code || code.length > 160 || /bearer\s+\S{8,}|sk-|xox[pab]-|access_token|refresh_token|client_secret/i.test(code)) return "Gamma 没有完成这次请求";
  return code;
}

function seal(lock, text, label) { return lock.seal(Buffer.from(text, "utf8"), label).toString("base64"); }
function unseal(lock, box, label) {
  try { return box ? lock.open(Buffer.from(box, "base64"), label).toString("utf8") : ""; }
  catch { return ""; }
}

function gammaLink(value) {
  try {
    const url = new URL(String(value || ""));
    if (url.protocol !== "https:" || (url.hostname !== "gamma.app" && !url.hostname.endsWith(".gamma.app"))) return "";
    return url.toString();
  } catch { return ""; }
}

export function createAppConnect({ dir, lock, storage, fetchImpl = fetch, openUrl = openGammaAuthorize, sleepImpl = null,config=loadGammaConnectionConfig(),scope=null,currentScope=()=>scope } = {}) {
  if (!dir || (!lock&&!storage)) throw new Error("App login needs protected storage");
  const file = path.join(dir, "app-connect.json");
  let record = null, loaded = false, pending = false, chain = Promise.resolve();
  let epoch=0,loginController;
  const encode=(text,label)=>storage?text:seal(lock,text,label);
  const decode=(text,label)=>storage?(typeof text==='string'?text:''):unseal(lock,text,label);
  const check=async(revision,signal)=>{signal?.throwIfAborted();if(revision!==epoch||appDigest(await currentScope())!==appDigest(scope))throw fail('APP_CONNECTION_CHANGED','应用账户或任务已变化',409);};
  const queue = (fn) => {
    const run = chain.then(fn, fn);
    chain = run.then(() => {}, () => {});
    return run;
  };
  async function load() {
    if (loaded) return;
    try { record = storage?await storage.readJson(file,{}):JSON.parse(await fs.readFile(file, "utf8")); }
    catch (error) { if (error.code !== "ENOENT") throw error; record = {}; }
    if (!record || typeof record !== "object") record = {};
    loaded = true;
  }
  async function save(next) {
    if(storage){await storage.writeJson(file,next);record=next;return;}
    await fs.mkdir(dir, { recursive: true });
    const tmp=file+'.'+crypto.randomUUID()+'.tmp';let handle;
    try{handle=await fs.open(tmp,'wx',0o600);await handle.writeFile(JSON.stringify(next));await handle.sync();await handle.close();handle=null;await fs.rename(tmp,file);}finally{await handle?.close();await fs.rm(tmp,{force:true});}
    record = next;
  }
  const gamma = () => (record?.gamma && typeof record.gamma === "object" ? record.gamma : null);
  const accessOf = () => decode(gamma()?.access, "app-gamma-access");
  const refreshOf = () => decode(gamma()?.refresh, "app-gamma-refresh");
  const keyOf = () => decode(gamma()?.key, "app-gamma-key");
  async function exportForMigration(){
    ++epoch;loginController?.abort();await chain;await load();const snapshot=structuredClone(record);
    if(snapshot.gamma)for(const [key,label]of [['key','app-gamma-key'],['access','app-gamma-access'],['refresh','app-gamma-refresh']]){
      if(snapshot.gamma[key])snapshot.gamma[key]=storage?snapshot.gamma[key]:lock.open(Buffer.from(snapshot.gamma[key],'base64'),label).toString('utf8');
    }
    return snapshot;
  }
  const connection = () => (accessOf() || keyOf())&&gamma()?.verifiedAt ? { id: "gamma", generation: gamma().connectionId || gamma().connectedAt || "legacy" } : null;
  function view() {
    const token = accessOf();
    const key = keyOf();
    return {
      note: APP_NOTE,
      apps: APP_CATALOG.map((item) => ({
        id: item.id,
        name: item.name,
        oneClick: Boolean(config.apiClientId&&config.apiRedirect),
        summary: item.summary,
        connected: item.id === "gamma" ? Boolean((token || key)&&gamma()?.verifiedAt) : false,
        state:pending?'authorizing':gamma()?.authError==='GAMMA_AUTH_EXPIRED'?'expired':gamma()?.authError?'error':connection()?'verified':(token||key)?'unverified':config.apiClientId&&config.apiRedirect?'not-configured':'providerSetupRequired',
        verifiedAt:gamma()?.verifiedAt||null,workspaceLabel:gamma()?.workspaceLabel||null,methods:['api-key','oauth'],
        errorCode:gamma()?.authError||(connection()?null:(!config.apiClientId||!config.apiRedirect)?'APP_PROVIDER_SETUP_REQUIRED':null),
        mode: item.id === "gamma" ? (key ? "key" : token ? "oauth" : "") : "",
      })),
    };
  }
  async function sleep(ms, signal) {
    signal?.throwIfAborted();
    if (sleepImpl) return sleepImpl(ms, signal);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(resolve, ms);
      signal?.addEventListener("abort", () => { clearTimeout(timer); reject(fail("GAMMA_CANCELLED", "Gamma 生成已取消", 499)); }, { once: true });
    });
  }
  async function gammaFetch(target, init, secret) {
    const headers = { accept: "application/json", ...(init.headers || {}) };
    if (secret.kind === "key") headers["X-API-KEY"] = secret.value;
    else headers.authorization = `Bearer ${secret.value}`;
    const response=await fetchImpl(target, { ...init, signal:AbortSignal.any([AbortSignal.timeout(30000),...(init.signal?[init.signal]:[])]),headers, redirect: "error" });
    if(response.redirected)throw fail('GAMMA_PROTOCOL','Gamma 返回了未预期的重定向',502);
    return response;
  }
  async function refresh(signal,revision=epoch) {
    const current = gamma();
    const refreshToken = refreshOf();
    if (!current?.clientId || !refreshToken) throw fail("GAMMA_LOGIN", "Gamma 登录已失效，请再点一次一键登录", 401);
    const body = new URLSearchParams({ grant_type: "refresh_token", refresh_token: refreshToken, client_id: current.clientId, resource: GAMMA.resource });
    const response = await fetchImpl(GAMMA.tokenUrl, { method: "POST", redirect: "error", headers: { "content-type": "application/x-www-form-urlencoded", accept: "application/json" }, body, signal:AbortSignal.any([AbortSignal.timeout(30000),...(signal?[signal]:[])]) });
    const json = await readJson(response);
    const access = String(json.access_token || "");
    if (!/^[\w.~+/=-]{8,4000}$/.test(access)) throw fail("GAMMA_LOGIN", "Gamma 登录已失效，请再点一次一键登录", 401);
    await check(revision,signal);
    await save({ ...record, gamma: { ...current, access: encode(access, "app-gamma-access"), ...(json.refresh_token && String(json.refresh_token).length <= 4000 ? { refresh: encode(String(json.refresh_token), "app-gamma-refresh") } : {}) } });
  }
  async function authorized(signal) {
    if(gamma()?.authError)throw fail(gamma().authError,'Gamma 授权已不可用，请在应用设置重新验证。',401);
    const key = keyOf();
    if (key) return { kind: "key", value: key };
    if (accessOf()) return { kind: "bearer", value: accessOf() };
    throw fail("GAMMA_LOGIN", "Gamma 尚未连接，请在应用设置使用 API Key 或已配置的 OAuth 登录。", 409);
  }
  async function probe(secret,signal){const response=await gammaFetch(`${GAMMA.apiBase}/themes`,{method:'GET',signal},secret);if(response.status===401||response.status===403)throw fail('GAMMA_AUTH_REQUIRED','Gamma 凭据未通过验证，请检查账户与 API 权限',response.status);await readJson(response);}
  const result=(state,text,extra={})=>({ok:state==='succeeded',state,content:[{type:'text',text}],text,cleanupComplete:true,...extra});
  return {
    exportForMigration,
    async status() { return queue(async () => { await load(); return view(); }); },
    async connection() { return queue(async () => { await load(); return connection(); }); },
    async disconnect(app) {
      epoch++;loginController?.abort();
      return queue(async () => {
        await load();
        if (app !== "gamma") throw fail("APP", "还没有接入这个应用");
        const next = { ...(record || {}) };
        delete next.gamma;
        await save(next);
        return view();
      });
    },
    async saveKey({ app, key,signal }) {
      const revision=++epoch;loginController?.abort();
      return queue(async () => {
        await load();
        if (app !== "gamma") throw fail("APP", "还没有接入这个应用");
        const value = String(key || "").trim();
        if (!/^[A-Za-z0-9._-]{12,200}$/.test(value)) throw fail("GAMMA_KEY", "Gamma API Key 格式不对");
        await probe({kind:'key',value},signal);await check(revision,signal);
        await save({ ...(record || {}), gamma: { mode: "key", key: encode(value, "app-gamma-key"), connectionId: crypto.randomUUID(), connectedAt: new Date().toISOString(),verifiedAt:new Date().toISOString() } });
        return view();
      });
    },
    async login({ app = "gamma", signal } = {}) {
      const revision=++epoch;loginController?.abort();const controller=new AbortController();loginController=controller;
      return queue(() => loginOne(app,AbortSignal.any([controller.signal,AbortSignal.timeout(180000),...(signal?[signal]:[])]),revision));
    },
    async call(args = {}, { signal, connection: expected } = {}) {
      return queue(async () => {
        await load();
        const current = connection();
        if (expected && (!current || expected.id !== current.id || expected.generation !== current.generation)) throw fail("APP_CONNECTION_CHANGED", "应用连接已改变，请重新发起操作", 409);
        return callOne(args, signal,epoch);
      });
    },
    async close(){epoch++;loginController?.abort();await chain;return {cleanupComplete:true};},
  };

  async function loginOne(app, signal,revision) {
    if (app !== "gamma") throw fail("APP", "这个应用还不能一点登录");
    if(!config.apiClientId||!config.apiRedirect)throw fail('APP_PROVIDER_SETUP_REQUIRED','Gamma OAuth 需要已登记的 Koder client_id 和回调；可先使用 API Key',409);
    await check(revision,signal);
    if (pending) throw fail("GAMMA_BUSY", "已经在等 Gamma 登录", 409);
    const state = crypto.randomBytes(32).toString("base64url");
    const pkce = gammaPkce();
    const configured=new URL(config.apiRedirect),isLoopback=configured.protocol==='http:'&&configured.hostname==='127.0.0.1';
    if(!isLoopback&&(!publicOAuthRedirect(config.apiRedirect)||!config.apiListenPort))throw fail('APP_PROVIDER_SETUP_REQUIRED','Gamma 公开回调尚未配置本机接收端口',409);
    let listener;
    try {
      pending=true;
      listener = listenGammaCallback({ state, signal,port:isLoopback?Number(configured.port):config.apiListenPort,redirectUri:isLoopback?undefined:config.apiRedirect,scope,current:currentScope });
      const port = await listener.ready;
      const redirectUri = isLoopback?gammaRedirectUri(port):config.apiRedirect;
      const clientId = config.apiClientId;
      const url = gammaAuthorizeUrl({ clientId, redirectUri, state, challenge: pkce.challenge });
      await openUrl(url);
      const code = await listener.done;
      const body = new URLSearchParams({
        grant_type: "authorization_code", code, redirect_uri: redirectUri, client_id: clientId,
        code_verifier: pkce.verifier, resource: GAMMA.resource,
      });
      const exchanged = await fetchImpl(GAMMA.tokenUrl, {
        method: "POST", redirect: "error", headers: { "content-type": "application/x-www-form-urlencoded", accept: "application/json" },
        body, signal: AbortSignal.any([signal,AbortSignal.timeout(20000)]),
      });
      const token = await readJson(exchanged);
      const access = String(token.access_token || "");
      if (!/^[\w.~+/=-]{8,4000}$/.test(access)) throw fail("GAMMA_TOKEN", "Gamma 没有返回可用的登录", 502);
      await probe({kind:'bearer',value:access},signal);await check(revision,signal);
      await load();
      await save({
        ...(record || {}),
        gamma: {
          mode: "oauth",
          connectionId: crypto.randomUUID(),
          clientId,
          access: encode(access, "app-gamma-access"),
          ...(token.refresh_token && String(token.refresh_token).length <= 4000 ? { refresh: encode(String(token.refresh_token), "app-gamma-refresh") } : {}),
          connectedAt: new Date().toISOString(),
          verifiedAt:new Date().toISOString(),
        },
      });
      return view();
    } finally {
      pending = false;
      listener?.cancel();
    }
  }

  async function request(route,init,revision){
    try{
      await check(revision,init.signal);let secret=await authorized(init.signal);
      let response=await gammaFetch(GAMMA.apiBase+route,init,secret);
      if(response.status===401&&secret.kind==='bearer'){
        await refresh(init.signal,revision);await check(revision,init.signal);
        response=await gammaFetch(GAMMA.apiBase+route,init,{kind:'bearer',value:accessOf()});
      }
      return await readJson(response);
    }catch(error){
      if([401,403].includes(error.status)){
        await check(revision,init.signal);await save({...record,gamma:{...gamma(),verifiedAt:null,authError:error.status===401?'GAMMA_AUTH_EXPIRED':'GAMMA_PERMISSION_DENIED'}});
      }throw error;
    }
  }
  async function callOne(args,signal,revision){
    let effect,dispatched=false;
    try{
      await check(revision,signal);
      if(args.app!=='gamma')throw fail('APP_ARGUMENTS','没有这个应用');
      if(args.action==='status')return result(connection()?'succeeded':'failed',connection()?'Gamma 已验证，生成会消耗 Gamma 额度。':'Gamma 尚未连接，请在应用设置连接。',{notStarted:true});
      if(args.action==='poll')return await poll(String(args.generationId||''),signal,revision);
      if(args.action!=='create'||typeof args.text!=='string'||!args.text.trim()||args.text.length>8000)throw fail('APP_ARGUMENTS','请提供不超过 8000 字的生成说明');
      await authorized(signal);
      const payload={inputText:args.text.trim(),textMode:'generate',format:FORMATS.has(args.format)?args.format:'presentation'};
      if(payload.format==='presentation')payload.numCards=Math.max(1,Math.min(60,Math.floor(Number(args.cards)||10)));
      const fingerprint=appDigest({connection:connection(),payload});
      const previous=(record.generations||[]).find(row=>row.fingerprint===fingerprint&&['started','unknown','pending'].includes(row.state));
      if(previous){if(previous.remoteId)return await poll(previous.remoteId,signal,revision);return result('unknown','此前生成的结果未知，请先在 Gamma 核实，不自动重新生成。',{errorCode:'APP_PRIOR_RESULT_UNKNOWN'});}
      const rows=(record.generations||[]).filter(row=>!['failed','succeeded'].includes(row.state));
      if(rows.length>=128)throw fail('APP_PRIOR_RESULT_UNKNOWN','存在过多待核对生成，请先核对 Gamma 记录',409);
      effect={fingerprint,state:'started',connection:connection(),at:Date.now()};
      await save({...record,generations:[...rows,effect]});
      await check(revision,signal);dispatched=true;
      const json=await request('/generations',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload),signal},revision);
      const id=String(json.generationId||'');if(!/^[A-Za-z0-9_-]{4,80}$/.test(id))throw fail('GAMMA_RESULT_UNKNOWN','Gamma 未返回可核对的生成编号',502);
      // Persist the remote identity before polling; a lost GET must not POST again.
      effect.remoteId=id;effect.state='pending';await save({...record});
      return await poll(id,signal,revision);
    }catch(error){
      const notStarted=!dispatched||[400,401,402,403,404,422,429].includes(error.status);
      if(effect){effect.state=notStarted?'failed':'unknown';await save({...record});}
      return result(notStarted?'failed':'unknown',notStarted?'Gamma 请求未完成，请检查连接、参数或额度。':'Gamma 生成结果未确认，请先核对现有任务。',{errorCode:error.code||'GAMMA_NETWORK',notStarted,cleanupComplete:notStarted,...(effect?.remoteId?{remoteId:effect.remoteId}:{})});
    }
  }
  async function poll(id,signal,revision){
    if(!/^[A-Za-z0-9_-]{4,80}$/.test(id))throw fail('APP_ARGUMENTS','需要有效 generationId');
    const row=(record.generations||[]).find(r=>r.remoteId===id);
    const keep=async(state)=>{if(row){row.state=state;await save({...record});}};
    try{
      for(let attempt=0;attempt<8;attempt++){
        const json=await request('/generations/'+id,{method:'GET',signal},revision);
        if(json.status==='failed'){await keep('failed');return result('failed','Gamma 没有生成成功。',{remoteId:id,errorCode:'GAMMA_GENERATION_FAILED'});}
        if(['completed','complete'].includes(json.status)){
          await keep('succeeded');const link=gammaLink(json.gammaUrl),cost=Number.isFinite(json.credits?.deducted)?` 使用 ${json.credits.deducted} 点额度。`:'';
          return result('succeeded',link?`Gamma 已生成：${link}。${cost}`:`Gamma 已完成，但没有返回 gamma.app 上的链接。编号 ${id}。`,{remoteId:id,links:link?[link]:[]});
        }
        if(attempt<7)await sleep(2000,signal);
      }
      await keep('pending');return result('unknown','Gamma 仍在生成，请用现有编号查询。',{remoteId:id,remoteStatus:'pending',errorCode:'GAMMA_PENDING'});
    }catch(error){await keep('unknown');return result('unknown','Gamma 查询未完成，保留生成编号，请稍后查询。',{remoteId:id,errorCode:error.code||'GAMMA_POLL_UNAVAILABLE'});}
  }
}

export function createGammaProvider(service){
  return {id:'gamma',async discover(){const connection=await service.connection();return connection?[{name:'app__gamma__call',description:'Gamma API：查询状态、生成与查询已提交任务。生成消耗 Gamma 额度。',parameters:APP_CALL_TOOL.parameters,schemaDigest:appDigest(APP_CALL_TOOL.parameters),catalogVersion:'gamma-api-v1',connection}]:[];},call:(bound,options)=>service.call(bound.arguments,{...options,connection:bound.connection})};
}

export async function callConnectedApp({ args, signal, url = process.env.KODER_WORKBENCH_URL, token = process.env.KODER_WORKBENCH_TOKEN, fetchImpl = fetch, timeoutMs = 90000, inspectConnection = false, connection,structured=false,task } = {}) {
  if (!url || !token) return "应用服务没有连接。请从 Koder 桌面启动后再让 AI 调用。";
  let target;
  try { target = new URL(url); }
  catch { return "应用服务地址无效。"; }
  if (target.protocol !== "http:" || target.hostname !== "127.0.0.1" || target.pathname !== "/api/internal/workbench" || target.username || target.password || target.search || target.hash) return "应用服务地址无效。";
  target.pathname = "/api/internal/apps";
  const deadline = AbortSignal.timeout(timeoutMs);
  const joined = signal ? AbortSignal.any([signal, deadline]) : deadline;
  const response = await fetchImpl(target, {
    method: "POST", redirect: "error",
    headers: { "content-type": "application/json", "x-koder-workbench": token },
    body: JSON.stringify(inspectConnection ? { inspectConnection: true } : { app: args?.app, action: args?.action, text: args?.text, format: args?.format, cards: args?.cards, generationId: args?.generationId, connection,task }),
    signal: joined,
  });
  const text = await response.text();
  const json = JSON.parse(text);
  if (response.status >= 400) throw fail(json.code || "APP_CALL_FAILED", json.error || "应用操作未完成", response.status);
  if (inspectConnection) return json.connection || null;
  if(structured){if(json.result&&typeof json.result.ok==='boolean')return json.result;throw fail('APP_PROTOCOL','应用宿主没有返回结构化回执',502);}
  return String(json.text || json.message || "应用没有返回结果").slice(0, 4000);
}
