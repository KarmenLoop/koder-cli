import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { randomUUID, createHash } from 'node:crypto';
import { createMcpRegistry, boundedJson } from './mcp-registry.mjs';
import { runWorkerFile } from '../loop/worker-process.mjs';
const require = createRequire(import.meta.url);
const digest = (v) => createHash('sha256').update(v).digest('hex');
const npmName = /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/;
const fixedVersion = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/;

export function createMcpInstaller({ dir, registry = createMcpRegistry(), fetchImpl = fetch, run = runWorkerFile, now = Date.now } = {}) {
  const plans = new Map(), installs = new Map(), controllers = new Set();
  let closed = false;
  async function plan({ name, version = 'latest', packageIndex = 0, signal } = {}) {
    if (closed) throw new Error('MCP 安装器已关闭');
    if (plans.size >= 128) plans.delete(plans.keys().next().value);
    const { server } = await registry.details({ name, version, signal });
    const remote = server.remotes?.find((item) => item.type === 'streamable-http');
    const pkg = server.packages?.[packageIndex];
    if (!pkg && remote) {
      const target = new URL(remote.url);
      if (target.protocol !== 'https:' || target.username || target.password || /[{}]/.test(remote.url)) throw new Error('此远程 MCP 需要先配置地址变量');
      const value = { planId: randomUUID(), name, title: server.title || name, description: server.description || '', kind: 'remote', url: target.href, version: server.version, expiresAt: now() + 30 * 60_000 };
      plans.set(value.planId, value); return value;
    }
    if (pkg?.registryType !== 'npm') throw new Error('目前一键安装支持固定版本 npm 或远程 Streamable HTTP；其它类型可手动配置');
    if (!npmName.test(pkg.identifier) || !fixedVersion.test(pkg.version) || (pkg.registryBaseUrl && pkg.registryBaseUrl.replace(/\/$/, '') !== 'https://registry.npmjs.org')) throw new Error('仅支持官方 npm 目录中的固定版本');
    if (pkg.transport?.type !== 'stdio') throw new Error('本地 npm MCP 必须使用 stdio');
    const response = await fetchImpl(`https://registry.npmjs.org/${encodeURIComponent(pkg.identifier)}/${encodeURIComponent(pkg.version)}`, { redirect: 'error', signal: AbortSignal.any([AbortSignal.timeout(20_000), ...(signal ? [signal] : [])]) });
    const metadata = await boundedJson(response);
    if (response.redirected || metadata.name !== pkg.identifier || metadata.version !== pkg.version || !/^sha512-[A-Za-z0-9+/=]+$/.test(metadata.dist?.integrity || '')) throw new Error('npm 版本或完整性元数据不正确');
    const bins = typeof metadata.bin === 'string' ? { [pkg.identifier.split('/').pop()]: metadata.bin } : metadata.bin || {};
    if (!Object.keys(bins).length) throw new Error('这个 npm 包没有可执行 MCP 入口');
    const value = { planId: randomUUID(), name, title: server.title || name, description: server.description || '', kind: 'npm', package: pkg.identifier, version: pkg.version, integrity: metadata.dist.integrity, bins, requiredInputs: pkg.environmentVariables || [], arguments: pkg.packageArguments || [], scriptsDisabled: true, expiresAt: now() + 30 * 60_000 };
    plans.set(value.planId, value); return structuredClone(value);
  }
  async function install({ planId, confirmed = false, bin, args = [], signal } = {}) {
    if (closed) throw new Error('MCP 安装器已关闭');
    const selected = plans.get(planId);
    if (!selected || selected.expiresAt < now()) throw new Error('安装计划已过期，请重新查看');
    if (confirmed !== true) throw new Error('请确认固定版本、来源及程序权限后安装');
    if (installs.has(planId)) return installs.get(planId);
    if (!Array.isArray(args) || args.length > 100 || args.some((v) => typeof v !== 'string' || v.length > 4096 || v.includes('\0'))) throw new Error('MCP 参数不合法');
    if (selected.kind === 'remote') return { id: randomUUID(), name: selected.title, serverName: `registry_${digest(selected.name).slice(0, 12)}`, transport: 'streamable-http', url: selected.url, enabled: false, allowAll: false, allowed: [], registry: { name: selected.name, version: selected.version } };
    const chosen = bin || (Object.keys(selected.bins).length === 1 ? Object.keys(selected.bins)[0] : '');
    if (!Object.hasOwn(selected.bins, chosen)) throw new Error('请选择这个包的 MCP 入口');
    const controller = new AbortController(); controllers.add(controller);
    signal = AbortSignal.any([controller.signal, ...(signal ? [signal] : [])]);
    const job = (async () => {
      const requestedRoot = path.join(dir, 'mcp-packages');
      await fs.mkdir(requestedRoot, { recursive: true });
      const root = await fs.realpath(requestedRoot), key = digest(`${selected.package}@${selected.version}:${selected.integrity}`), final = path.join(root, key), staging = path.join(root, `.install-${randomUUID()}`);
      await fs.mkdir(staging, { recursive: false, mode: 0o700 });
      let cleanup = true;
      try {
        await fs.writeFile(path.join(staging, 'package.json'), JSON.stringify({ name: 'koder-mcp-local', version: '1.0.0', private: true, dependencies: { [selected.package]: selected.version } }), { mode: 0o600 });
        await fs.writeFile(path.join(staging, '.npmrc'), '', { mode: 0o600 });
        await fs.writeFile(path.join(staging, '.npm-globalrc'), '', { mode: 0o600 });
        const safeEnv = Object.fromEntries(['PATH', 'HOME', 'USERPROFILE', 'SystemRoot', 'TEMP', 'TMP', 'COMSPEC'].filter((key) => process.env[key]).map((key) => [key, process.env[key]]));
        let npmCli;
        try { npmCli = path.join(path.dirname(require.resolve('npm/package.json')), 'bin/npm-cli.js'); } catch { throw new Error('此安装包缺少固定 npm 安装组件，请重新安装 Koder'); }
        await run(process.execPath, [npmCli, 'install', '--ignore-scripts', '--no-audit', '--no-fund', '--registry=https://registry.npmjs.org', '--package-lock=true', `--userconfig=${path.join(staging, '.npmrc')}`, `--globalconfig=${path.join(staging, '.npm-globalrc')}`], { cwd: staging, env: { ...safeEnv, ELECTRON_RUN_AS_NODE: '1', npm_config_cache: path.join(root, '.cache') }, signal, timeout: 120_000, maxBuffer: 1024 * 1024 });
        signal?.throwIfAborted();
        const lock = JSON.parse(await fs.readFile(path.join(staging, 'package-lock.json'), 'utf8'));
        const record = lock.packages?.[`node_modules/${selected.package}`];
        if (record?.version !== selected.version || record?.integrity !== selected.integrity) throw new Error('已安装包与确认的版本或完整性不一致');
        const packageRoot = await fs.realpath(path.join(staging, 'node_modules', selected.package));
        const executable = await fs.realpath(path.join(packageRoot, selected.bins[chosen]));
        if (!executable.startsWith(`${packageRoot}${path.sep}`) || !/\.(?:c?js|mjs)$/.test(executable)) throw new Error('仅支持包内 JavaScript MCP 入口');
        const executableSHA256 = digest(await fs.readFile(executable));
        const relative = path.relative(staging, executable);
        await fs.writeFile(path.join(staging, 'koder-install.json'), JSON.stringify({ package: selected.package, version: selected.version, integrity: selected.integrity, executableSHA256, scriptsDisabled: true, installedAt: now() }), { mode: 0o600 });
        try { await fs.rename(staging, final); } catch (error) { if (!['EEXIST', 'ENOTEMPTY'].includes(error.code)) throw error; const existing = JSON.parse(await fs.readFile(path.join(final, 'koder-install.json'), 'utf8')); if (existing.integrity !== selected.integrity || existing.executableSHA256 !== executableSHA256) throw new Error('已安装目录不一致'); }
        return { id: randomUUID(), name: selected.title, serverName: `registry_${digest(selected.name).slice(0, 12)}`, transport: 'stdio', command: process.execPath, args: [path.join(final, relative), ...args], cwd: final, env: {}, enabled: false, allowAll: false, allowed: [], registry: { name: selected.name, package: selected.package, version: selected.version, integrity: selected.integrity, executableSHA256 }, installed: true };
      } catch (error) { cleanup = error.cleanupComplete !== false; throw error; }
      finally { if (cleanup) await fs.rm(staging, { recursive: true, force: true }); }
    })();
    installs.set(planId, job);
    try { return await job; } finally { installs.delete(planId); controllers.delete(controller); }
  }
  return { plan, install, async close() { closed = true; for (const controller of controllers) controller.abort(); await Promise.allSettled([...installs.values()]); } };
}
