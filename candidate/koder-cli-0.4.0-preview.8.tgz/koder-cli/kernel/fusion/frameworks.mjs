// Code frameworks for the model behind the user's API. These tell that model
// which files to write. They are not a tour for the person using Koder.
import fs from "node:fs/promises";
import path from "node:path";

const PRESETS = {
  website: {
    title: "网站",
    patterns: [/网站/, /网页/, /官网/, /落地页/, /website/i, /web\s*page/i],
    lines: [
      "代码框架：网站。按这个写文件，不要向用户复述这些条文。",
      "先把主路径写成一句可观察的话，例如访客留下邮箱后看到已收到。整站只服务这一句。再列出这句话经过的页面。",
      "旧项目先读现有页面、组件、颜色和字体，新页面沿用它们。新站只选一套间距、一种标题阶梯和一组颜色。",
      "目录固定为 index.html、styles.css、app.js。用户没有点名构建工具时，不要加打包步骤。",
      "每个页面只有一个主要动作。导航把主路径上的页面连起来。先让这条路走通，再补空数据、提交中、失败和成功。",
      "用浏览器完成点击、输入和提交。桌面和手机宽度各走一次。截图只用来看布局。主路径没有走完，就不算完成。",
      "没有要求后端时，数据放在 app.js 里。用用户说话的语言写页面上的字。浏览器直接打开 index.html 就要能看。",
    ],
  },
  tool: {
    title: "工具",
    patterns: [/命令行工具/, /小工具/, /制作工具/, /做一个工具/, /写一个工具/, /写个工具/, /工具程序/, /\bCLI\b/],
    lines: [
      "代码框架：工具。按这个写文件，不要向用户复述这些条文。",
      "只放一个入口。用户要 Python 就用 python3（Koder 自带的环境）；否则用 node，文件名为 tool.mjs 或按用途命名的 .py。",
      "参数用语言自带的解析，不另装命令行库。运行方式写在文件开头的短注释里。",
      "写完用 shell 跑一次这个入口。成功时打印一行结果。错误输入打印原因并以非零退出。两条命令的退出码和输出都要留下。",
    ],
  },
  app: {
    title: "手机应用",
    patterns: [/手机应用/, /手机\s*APP/i, /移动应用/, /\biOS\b/, /Android/i, /iPhone/i, /安卓/, /\bAPP\b/],
    lines: [
      "你在做手机应用。完成标准是：在手机宽度上走完主任务，离开再进入后该留的状态仍在，拒绝权限时也能看见说明。不要向用户复述这些条文。",
      "主任务写成一句可观察的话。列出要经过的屏，以及哪一份状态必须保留。能留在本机的，不先做账户和同步。",
      "主任务的屏通过底部或顶部的主导航到达。更深的一步做完要能返回。每屏一个主要动作，放在拇指够得到的位置，并避开屏幕圆角和系统手势区。",
      "权限出现在要用的那一步。用户拒绝时给出说明，不要停在空白页。",
      "补上加载、空列表、断网和成功。竖屏必须走通，再看横屏或分屏。",
      "验收在手机宽度上完成点击和输入，并包含重新进入和拒绝权限。截图只用来看布局。",
      "用户没有点名已有的 iOS 或 Android 工程时，做成可安装的网页应用：index.html、styles.css、app.js、manifest.webmanifest。点名了 Swift、Kotlin 或已有工程时，就在那个工程里改。",
    ],
  },
  application: {
    title: "应用",
    patterns: [/做应用/, /做一个应用/, /写一个应用/, /应用界面/],
    lines: [
      "你在做应用。完成标准是：用户走完主任务，离开这个界面再进入，该保留的结果仍在。不要向用户复述这些条文。",
      "先写出主任务的一句话、经过的屏，以及哪一份状态必须保留。能留在内存或本机文件里的，不先做账户和同步。",
      "旧项目沿用现有导航、存储和组件。新界面接进原来的入口，不另做一个壳。每屏一个主要动作。",
      "补上空数据、进行中、失败和成功。",
      "验收时走完主路径，然后重新进入，核对保留下来的结果。只看到一个成功画面还不算完成。",
    ],
  },
  desktop: {
    title: "电脑端应用",
    patterns: [/电脑端/, /桌面应用/, /桌面软件/, /桌面程序/, /电脑应用/, /desktop app/i],
    lines: [
      "你在做桌面应用。完成标准是：在主窗口里用键盘走完主任务，保存后重新打开，内容仍在。不要向用户复述这些条文。",
      "主任务放在主窗口。设置和预览用同一窗口里的面板，或从主窗口打开的另一扇窗。主要动作放进菜单或快捷键，焦点落在正在改的那一块。",
      "存储落到本机文件。未保存、已保存和打开失败都要看得见。关闭窗口时，未保存的修改先得到去向。",
      "窗口在最小尺寸下仍能完成主任务。放大后多出来的空间留给工作区，不要把按钮拉散。",
      "验收包含键盘路径、保存后重新打开，以及最小和放大两种尺寸。",
      "没有现成桌面工程时，窗口用 index.html、styles.css、app.js，再用 node 只监听 127.0.0.1。不下载新的桌面框架。",
    ],
  },
};

export const FRAMEWORK_IDS = Object.keys(PRESETS);

export function frameworkText(id) {
  const preset = PRESETS[id];
  return preset ? preset.lines.join("\n") : "";
}

export function matchFramework(text) {
  const source = String(text ?? "");
  let found = null;
  for (const id of FRAMEWORK_IDS) {
    for (const pattern of PRESETS[id].patterns) {
      const at = source.search(pattern);
      if (at >= 0 && (found === null || at < found.at)) found = { id, at };
    }
  }
  return found?.id ?? "";
}

export function frameworkFor(text) {
  return frameworkText(matchFramework(text));
}

export function clientShape(hints) {
  const blob = Array.isArray(hints) ? hints.join("\n") : String(hints || "");
  const desktop = /electron|tauri|src-tauri|wails|BrowserWindow|NSWindow|MainWindow|QMainWindow|applicationMenu/i.test(blob);
  const mobile = /AndroidManifest|Info\.plist|capacitor|react-native|safe-area|safeArea|UITabBar|SwiftUI/i.test(blob);
  if (desktop && !mobile) return "desktop";
  if (mobile && !desktop) return "mobile";
  if (desktop && mobile) return "desktop";
  if (/index\.html/i.test(blob)) return "website";
  return "";
}

export function chooseFramework(text, shape) {
  const spoken = matchFramework(text);
  if (spoken === "desktop" || spoken === "app" || spoken === "website" || spoken === "tool") return spoken;
  if (shape === "desktop") return "desktop";
  if (shape === "mobile") return "app";
  if (shape === "website") return "website";
  return spoken;
}

const SKIP = new Set(["node_modules", ".git", "dist", "vendor"]);

export async function scanClientShape(cwd) {
  const hints = [];
  async function walk(dir, depth) {
    if (depth > 3 || hints.length > 400) return;
    const entries = await fs.readdir(dir, { withFileTypes: true }).catch(() => []);
    for (const entry of entries) {
      if (entry.name.startsWith(".") || SKIP.has(entry.name)) continue;
      hints.push(entry.name);
      const full = path.join(dir, entry.name);
      if (entry.name === "package.json") hints.push(await fs.readFile(full, "utf8").then((text) => text.slice(0, 4000), () => ""));
      if (entry.isDirectory()) await walk(full, depth + 1);
    }
  }
  if (cwd) await walk(cwd, 0);
  return clientShape(hints);
}
