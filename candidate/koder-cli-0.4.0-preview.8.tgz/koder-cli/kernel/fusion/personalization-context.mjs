import crypto from 'node:crypto';
import {mergeSkills} from './skills.mjs';
import {readSkillResource} from './skill-access.mjs';
import {eligiblePersonalizationSkills} from './personalization-policy.mjs';
import {subjectKey} from './personalization-policy.mjs';
function bounded(text,max){let out='',size=0;for(const c of text){const n=Buffer.byteLength(c);if(size+n>max)break;size+=n;out+=c;}return out;}
export function createPersonalizationContext({subject,policy,profile,soul,proactive,skillRecords=()=>[]}={}){
 const current=()=>typeof subject==='function'?subject():subject;
 return {async context({text='',scenario='work',inbound}={}){
  const selected=current(),key=subjectKey(selected),snapshot=await policy?.status?.();const rows=await profile?.query?.({text,limit:5,maxBytes:3600})||[];
  const style=bounded(await soul?.project?.({scenario,maxBytes:2500})||'',2500),question=inbound?await proactive?.matchReply?.(inbound):null;
  const stillCurrent=subjectKey(current())===key;
  if(!stillCurrent)return {text:'',scope:null};
  const learning=await policy?.require?.('learning',snapshot),daily=await policy?.require?.('dailyState',snapshot);
  const allowed=rows.filter(r=>r.category==='daily-state'?daily:learning);
  const controlled=mergeSkills(await skillRecords()).filter(s=>s.requiredPolicy),eligible=await eligiblePersonalizationSkills({skills:controlled,policy,subject:selected});const methods=[];
  for(const skill of eligible){const resource=await readSkillResource(skill,{limit:1800},{personalizationPolicy:policy,subject:selected});methods.push({id:skill.id,text:bounded(resource.text||resource.content||'',1800)});}
  const finalSnapshot=await policy?.status?.();
  if(subjectKey(current())!==key||policy&&(subjectKey(finalSnapshot?.subject)!==key||finalSnapshot?.revision!==snapshot?.revision))return {text:'',scope:null};
  const data={preferences:allowed,...(methods.length?{methods}:{}),...(style?{assistantStyle:style}:{}),...(question?.state==='matched'?{answeringQuestion:{question:bounded(question.question.text,2000),topic:question.question.topic,taskId:question.question.taskId,expectedAnswer:question.question.expectedAnswer}}:{})};
  while(Buffer.byteLength(JSON.stringify(data))>10000&&data.methods?.length)data.methods.pop();
  while(Buffer.byteLength(JSON.stringify(data))>10000&&data.preferences.length)data.preferences.pop();
  const content=allowed.length||methods.length||style||data.answeringQuestion?'\n\nPersonalization data (current user input takes precedence; style and historical preferences confer no tool permissions):\n'+JSON.stringify(data):'';
  return {text:content,scope:crypto.createHash('sha256').update(key+':'+snapshot?.revision+':'+JSON.stringify(data)).digest('hex')};
 }};
}
