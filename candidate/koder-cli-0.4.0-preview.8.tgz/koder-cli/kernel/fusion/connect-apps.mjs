// One-click Connect for catalogued remote apps. The browser opens the
// provider's own login; the consent screen after login is the provider's page.
// Tokens stay in the MCP auth store. No client id is copied from another product.
import { spawn } from "node:child_process";
import {loadGammaConnectionConfig} from './gamma-config.mjs';

// Each oauth URL was read from the service's own public metadata on 2026-10-15
// and advertised a registration endpoint. No client id is stored here.
const OAUTH_APPS = [
  ["notion", "Notion", "https://mcp.notion.com/mcp", "笔记和数据库"],
  ["granola", "Granola", "https://mcp.granola.ai/mcp", "会议记录"],
  ["vantage", "Vantage", "https://mcp.vantage.sh/mcp", "云成本"],
  ["linear", "Linear", "https://mcp.linear.app/mcp", "议题和项目"],
  ["sentry", "Sentry", "https://mcp.sentry.dev/mcp", "错误和性能"],
  ["figma", "Figma", "https://mcp.figma.com/mcp", "设计稿"],
  ["canva", "Canva", "https://mcp.canva.com/mcp", "设计和图片"],
  ["asana", "Asana", "https://mcp.asana.com/mcp", "任务和项目"],
  ["atlassian", "Atlassian", "https://mcp.atlassian.com/v1/mcp/authv2", "Jira 和 Confluence"],
  ["monday", "Monday.com", "https://mcp.monday.com/mcp", "工作管理"],
  ["intercom", "Intercom", "https://mcp.intercom.com/mcp", "客户对话"],
  ["airtable", "Airtable", "https://mcp.airtable.com/mcp", "表格数据库"],
  ["todoist", "Todoist", "https://ai.todoist.net/mcp", "待办"],
  ["neon", "Neon", "https://mcp.neon.tech/mcp", "Postgres"],
  ["supabase", "Supabase", "https://mcp.supabase.com/mcp", "数据库和登录"],
  ["prisma", "Prisma", "https://mcp.prisma.io/mcp", "数据库"],
  ["posthog", "PostHog", "https://mcp.posthog.com/mcp", "产品分析"],
  ["buildkite", "Buildkite", "https://mcp.buildkite.com/mcp", "持续集成"],
  ["netlify", "Netlify", "https://netlify-mcp.netlify.app/mcp", "网站部署"],
  ["vercel", "Vercel", "https://mcp.vercel.com/mcp", "网站部署"],
  ["cloudflare-bindings", "Cloudflare 绑定", "https://bindings.mcp.cloudflare.com/mcp", "Workers 绑定"],
  ["cloudflare-observability", "Cloudflare 观测", "https://observability.mcp.cloudflare.com/mcp", "日志和观测"],
  ["webflow", "Webflow", "https://mcp.webflow.com/mcp", "网站"],
  ["wix", "Wix", "https://mcp.wix.com/mcp", "网站"],
  ["miro", "Miro", "https://mcp.miro.com/mcp", "白板"],
  ["cloudinary", "Cloudinary", "https://asset-management.mcp.cloudinary.com/mcp", "图片和视频"],
  ["invideo", "InVideo", "https://mcp.invideo.io/mcp", "视频"],
  ["fireflies", "Fireflies", "https://api.fireflies.ai/mcp", "会议转写"],
  ["listenetic", "Listenetic", "https://mcp.listenetic.com/v1/mcp", "音频"],
  ["carbonvoice", "Carbon Voice", "https://mcp.carbonvoice.app/mcp", "语音"],
  ["telnyx", "Telnyx", "https://api.telnyx.com/v2/mcp", "通信"],
  ["dialer", "Dialer", "https://getdialer.app/mcp", "电话"],
  ["egnyte", "Egnyte", "https://mcp-server.egnyte.com/mcp", "企业文件"],
  ["paypal", "PayPal", "https://mcp.paypal.com/mcp", "收款"],
  ["plaid", "Plaid", "https://api.dashboard.plaid.com/mcp", "金融数据"],
  ["square", "Square", "https://mcp.squareup.com/mcp", "收款"],
  ["stripe", "Stripe", "https://mcp.stripe.com/mcp", "收款"],
  ["close", "Close", "https://mcp.close.com/mcp", "客户关系"],
  ["dodo", "Dodo Payments", "https://mcp.dodopayments.com/mcp", "收款"],
  ["thoughtspot", "ThoughtSpot", "https://agent.thoughtspot.app/mcp", "分析"],
  ["apify", "Apify", "https://mcp.apify.com/mcp", "网页抓取"],
  ["simplescraper", "SimpleScraper", "https://mcp.simplescraper.io/mcp", "网页抓取"],
  ["globalping", "Globalping", "https://mcp.globalping.dev/mcp", "网络诊断"],
  ["jam", "Jam", "https://mcp.jam.dev/mcp", "缺陷记录"],
  ["huggingface", "Hugging Face", "https://huggingface.co/mcp", "模型和数据集"],
];

export const CONNECT_CATALOG = Object.freeze([
  {id:'gamma-mcp',name:'Gamma MCP',mode:'oauth',url:'https://mcp.gamma.app/mcp',summary:'通过 Gamma 官方 MCP 授权访问工作区；需要平台登记和公开 HTTPS 回调，不能使用 Gamma API Key 代替。'},
  ...OAUTH_APPS.map(([id, name, url, what]) => ({
    id, name, mode: "oauth", url,
    summary: `${what}。点 Connect 会打开 ${name} 登录。允许后令牌只留在这台电脑上。`,
  })),
  { id: "slack", name: "Slack", mode: "oauth", url: "https://mcp.slack.com/mcp", summary: "2026-10-15 核对时，Slack 的公开授权说明里没有程序自己登记的地址。点 Connect 可能会被拒绝。设置里原来的 Slack 登录还在，需要你自己的应用。" },
  { id: "twilio", name: "Twilio", mode: "open", url: "https://mcp.twilio.com/docs", summary: "这是 Twilio 文档，没有登录框。点打开后，AI 可以查这些文档。" },
  { id: "shadcn", name: "shadcn/ui", mode: "blocked", summary: "它的接法是在本机运行 npx shadcn@latest mcp，不是打开网站登录。Koder 不执行这种命令，所以这里没有 Connect。" },
  { id: "monk", name: "Monk.io", mode: "blocked", summary: "当前插件只指向本机 http://127.0.0.1:7419/mcp，要先有 Monk 守护进程。Koder 没有安装它，也不能把它当成网站登录。" },
  { id: "origin", name: "Origin", mode: "blocked", summary: "这是 Cursor 自己的代码托管开关，不是一个可以交给 Koder 登录的网站。" },
  { id: "cursor-subscriptions", name: "Cursor Subscriptions", mode: "blocked", summary: "这是 Cursor 账号里的订阅开关。Koder 不能登录 Cursor 的订阅。" },
]);

const fail = (code, message, status = 400) => Object.assign(new Error(message), { code, status });

export function connectEntry(id) {
  return CONNECT_CATALOG.find((item) => item.id === id) || null;
}

export function openAuthorization(url, { platform = process.platform, spawnImpl = spawn } = {}) {
  const parsed = new URL(String(url || ""));
  if (parsed.protocol !== "https:" || parsed.username || parsed.password) throw fail("APP_URL", "只能打开对方的 HTTPS 授权页");
  const command = platform === "darwin" ? ["open", [parsed.toString()]]
    : platform === "win32" ? ["rundll32", ["url.dll,FileProtocolHandler", parsed.toString()]]
    : ["xdg-open", [parsed.toString()]];
  const child = spawnImpl(command[0], command[1], { detached: true, stdio: "ignore", windowsHide: true });
  child.unref?.();
  child.stdin?.end?.();
  return parsed.toString();
}

function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    signal?.throwIfAborted();
    const abort = () => { clearTimeout(timer); reject(signal.reason || fail("APP_CANCELLED", "连接已取消", 499)); };
    const timer = setTimeout(() => { signal?.removeEventListener("abort", abort); resolve(); }, ms);
    signal?.addEventListener("abort", abort, { once: true });
  });
}

export function createConnectApps({ kernel, oauth, openUrl = openAuthorization, wait = delay, timeoutMs = 180000,gammaConfig=loadGammaConnectionConfig() } = {}) {
  if (!kernel || !oauth) throw new Error("Connect needs the kernel and MCP login");
  async function kernelOk(method, pathname, body) {
    const result = await kernel.call(method, pathname, body);
    if (!result || result.status >= 400) throw fail(result?.json?.code || "APP", result?.json?.error || "应用没有登记成功", result?.status || 502);
    return result.json || {};
  }
  async function servers() {
    const listed = await kernelOk("GET", "/api/mcp");
    return Array.isArray(listed.servers) ? listed.servers : [];
  }
  async function ensure(entry) {
    const found = (await servers()).find((item) => item.url === entry.url);
    if (found) return found;
    const created = await kernelOk("POST", "/api/mcp", {
      name: entry.name,
      serverName: entry.id,
      transport: "streamable-http",
      url: entry.url,
      enabled: false,
      ...(entry.mode === "oauth" ? { auth: { type: "oauth" } } : {}),
    });
    if (!created.server?.id) throw fail("APP", "应用没有登记成功", 502);
    return created.server;
  }
  async function row(entry, server) {
    if(entry.id==='gamma-mcp'&&gammaConfig.mcpRegistrationState!=='ready')return {id:entry.id,name:entry.name,mode:entry.mode,summary:entry.summary,connected:false,state:'providerSetupRequired',errorCode:'APP_PROVIDER_SETUP_REQUIRED'};
    if (entry.mode === "blocked") return { id: entry.id, name: entry.name, mode: entry.mode, summary: entry.summary, connected: false, state: "blocked" };
    const status = entry.mode === "oauth" && server ? await oauth.status(server.id).catch(() => null) : null;
    const authorized = entry.mode === "oauth" ? status?.authorized === true : false;
    const connected = Boolean(server?.enabled && server.status === "connected" && (entry.mode !== "oauth" || authorized));
    return {
      id: entry.id,
      name: entry.name,
      mode: entry.mode,
      summary: entry.summary,
      connected,
      authorized,
      authState:server?.authState||status?.state||null,
      connectionState:server?.connectionState||null,
      verifiedAt:server?.verifiedAt||null,
      workspaceLabel:server?.workspaceLabel||null,
      errorCode:server?.errorCode||null,
      scope: "local-profile",
      state: connected ? "connected" : server?.enabled && server.status === "error" ? "error" : "ready",
      serverId: server?.id || "",
      error: server?.error || "",
    };
  }
  const connecting = new Map(), disconnecting = new Map();
  async function list() {
    const known = await servers();
    return { scope: "local-profile", connects: await Promise.all(CONNECT_CATALOG.map(entry => row(entry, known.find(item => item.url === entry.url)))) };
  }
  async function connect(entry, signal) {
    signal.throwIfAborted();
    const server = await ensure(entry);
    const status = entry.mode === "oauth" ? await oauth.status(server.id) : null;
    signal.throwIfAborted();
    // The login belongs to the local profile, never to a particular thread.
    // An existing grant can reopen a disconnected transport without logging in.
    if (entry.mode === "oauth" && !status?.authorized) {
      const started = await oauth.start({ id: server.id, url: entry.url, signal });
      signal.throwIfAborted();
      if (started?.authorizationUrl) await openUrl(started.authorizationUrl);
      const deadline = Date.now() + timeoutMs;
      let current = await oauth.status(server.id);
      while (!current.authorized && Date.now() < deadline) {
        signal.throwIfAborted();
        const flow = current.flow?.status;
        if (flow === "failed" || flow === "cancelled") throw fail(current.flow?.error || "APP", flow === "cancelled" ? "授权已取消" : "授权没有完成，请再点一次 Connect", 502);
        await wait(300, signal);
        current = await oauth.status(server.id);
      }
      if (!current.authorized) throw fail("APP_TIMEOUT", "授权超时，请再点一次 Connect", 408);
    }
    signal.throwIfAborted();
    if (!server.enabled || server.status !== "connected") {
      await kernelOk("PATCH", `/api/mcp/${server.id}`, { enabled: true, ...(entry.mode === "oauth" ? { auth: { type: "oauth" } } : {}) });
    }
    signal.throwIfAborted();
    return list();
  }
  return {
    list,
    connect(id, { signal } = {}) {
      const entry = connectEntry(id);
      if (!entry) return Promise.reject(fail("APP", "没有这个应用"));
      if (entry.mode === "blocked") return Promise.reject(fail("APP_BLOCKED", entry.summary));
      if(entry.id==='gamma-mcp'&&gammaConfig.mcpRegistrationState!=='ready')return Promise.reject(fail('APP_PROVIDER_SETUP_REQUIRED',entry.summary,409));
      if (disconnecting.has(id)) return Promise.reject(fail("APP_BUSY", "正在断开，请稍后重试", 409));
      signal?.throwIfAborted();
      if (connecting.has(id)) return connecting.get(id).promise;
      const controller = new AbortController();
      const job = { controller };
      job.promise = connect(entry, signal ? AbortSignal.any([signal, controller.signal]) : controller.signal)
        .finally(() => { if (connecting.get(id) === job) connecting.delete(id); });
      connecting.set(id, job);
      return job.promise;
    },
    disconnect(id) {
      const entry = connectEntry(id);
      if (!entry || entry.mode === "blocked") return Promise.reject(fail("APP", "这个应用没有可断开的登录"));
      if (disconnecting.has(id)) return disconnecting.get(id);
      const pending = connecting.get(id);
      pending?.controller.abort(fail("APP_CANCELLED", "连接已取消", 499));
      const job = (async () => {
        // Drain the pending enable before revocation, so late consent cannot
        // silently re-enable an app the user has just disconnected.
        await pending?.promise.catch(() => {});
        const server = (await servers()).find(item => item.url === entry.url);
        if (server) await kernelOk("PATCH", `/api/mcp/${server.id}`, { enabled: false });
        if (server && entry.mode === "oauth") await oauth.logout(server.id);
        return list();
      })().finally(() => { if (disconnecting.get(id) === job) disconnecting.delete(id); });
      disconnecting.set(id, job);
      return job;
    },
  };
}
