import fs from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { inside } from './works.mjs';
import { StudioError } from './store.mjs';
export const digest = value => crypto.createHash('sha256').update(value).digest('hex');
export function relativeFile(value) {
 if(typeof value!=='string'||!value.trim()||value.length>1024||/[\x00-\x1f\\]/.test(value)||path.isAbsolute(value)||value.split('/').some(x=>x==='..'||x==='.'||!x)||/^[a-z]:/i.test(value)) throw new StudioError(400,'FILE_PATH','请使用项目内的相对文件路径');
 return value;
}
// Hash the open regular file; bounded reads and a second identity check reject changing inputs.
export async function inspectFile(root, name, {content=false,maxBytes=64*1024*1024}={}) {
 relativeFile(name);
 const target=await inside(root,name);
 const handle=await fs.open(target,constants.O_RDONLY|constants.O_NOFOLLOW|constants.O_NONBLOCK);
 try {
  const before=await handle.stat();
  if(!before.isFile()||before.size===0||before.size>maxBytes)throw new StudioError(400,'FILE_SIZE',`文件为空、过大或不是普通文件：${name}`);
  const chunks=[],hash=crypto.createHash('sha256');let total=0;
  for(;;){const b=Buffer.alloc(65536);const {bytesRead}=await handle.read(b,0,b.length,null);if(!bytesRead)break;total+=bytesRead;if(total>maxBytes)throw new StudioError(413,'FILE_SIZE','文件超过检查上限');hash.update(b.subarray(0,bytesRead));if(content)chunks.push(b.subarray(0,bytesRead));}
  const after=await handle.stat(), current=await fs.stat(await inside(root,name));
  if(before.size!==total||before.size!==after.size||before.mtimeMs!==after.mtimeMs||before.ctimeMs!==after.ctimeMs||after.ino!==current.ino||after.dev!==current.dev)throw new StudioError(409,'FILE_CHANGED',`检查期间文件发生变化：${name}`);
  return {path:name,size:total,sha256:hash.digest('hex'),...(content?{bytes:Buffer.concat(chunks)}:{})};
 }finally{await handle.close();}
}
export async function inspectSources(root,names) {
 if(!Array.isArray(names)||!names.length||names.length>40)throw new StudioError(400,'SOURCES','请选择 1–40 个项目内材料文件');
 const out=[];let bytes=0;
 for(const name of [...new Set(names)]){const r=await inspectFile(root,name);bytes+=r.size;if(bytes>256*1024*1024)throw new StudioError(413,'SOURCES_SIZE','材料合计超过 256 MB，请分批处理');out.push(r);}
 return out;
}
export async function createOutputFolder(root,prefix,id) {
 const base=await fs.realpath(root), name=`${prefix}-${id}`;
 await fs.mkdir(path.join(base,name),{mode:0o700});
 return name;
}
export async function writeOutput(root,folder,name,body) {
 relativeFile(`${folder}/${name}`);
 const parent=await inside(root,folder);
 const file=path.join(parent,name);
 // Exclusive files: a repeat or existing symlink never overwrites user material.
 await fs.writeFile(file,body,{flag:'wx',mode:0o600});
 return inspectFile(root,`${folder}/${name}`);
}
export function utf8(bytes) {
 try{return new TextDecoder('utf-8',{fatal:true}).decode(bytes).replace(/^\uFEFF/,'');}
 catch{throw new StudioError(400,'ENCODING','请先把表格导出为 UTF-8 CSV，不能把二进制表格当文本读取');}
}

export async function inspectDeliverable(root,name) {
 const ext=path.extname(name).toLowerCase();
 const native={'.docx':'word/document.xml','.xlsx':'xl/workbook.xml','.pptx':'ppt/presentation.xml'}[ext];
 const data=await inspectFile(root,name,{content:Boolean(native),maxBytes:64*1024*1024});
 if(native){
  const b=data.bytes;let end=-1;
  for(let i=b.length-22;i>=Math.max(0,b.length-65557);i--)if(b.readUInt32LE(i)===0x06054b50){end=i;break;}
  let good=end>=0,names=[];
  if(good){let n=b.readUInt16LE(end+10),p=b.readUInt32LE(end+16);good=n>0&&n<=10000&&p<end;
   for(let i=0;good&&i<n;i++){if(p+46>end||b.readUInt32LE(p)!==0x02014b50){good=false;break;}const len=b.readUInt16LE(p+28),extra=b.readUInt16LE(p+30),comment=b.readUInt16LE(p+32);if(p+46+len+extra+comment>end){good=false;break;}names.push(b.subarray(p+46,p+46+len).toString('utf8'));p+=46+len+extra+comment;}
  }
  if(!good||!names.includes('[Content_Types].xml')||!names.includes(native))throw new StudioError(400,'OFFICE_CONTAINER',`文件不是可识别的 Office 容器：${name}`);
 }
 const {bytes,...receipt}=data;return receipt;
}
