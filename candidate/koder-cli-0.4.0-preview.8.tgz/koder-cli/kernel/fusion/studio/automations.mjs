// 自动化: prompts and workflows that start by themselves on a schedule while
// Koder is open. A run is an ordinary task, so its commands and file changes
// still ask unless 设置 → 工具 says otherwise.
import path from "node:path";
import {zonedDay,zonedTime,addDays} from "../personalization-time.mjs";
import { createJsonStore, line, newId, oneOf, StudioError, text } from "./store.mjs";

export const SCHEDULES = ["daily", "weekly", "interval", "once", "finish"];
const TIME = /^([01]\d|2[0-3]):([0-5]\d)$/;
const HOUR = 3_600_000;
// A run later than this (Koder was closed, the Mac asleep) counts as missed.
const LATE_MS = 2 * 60_000;
const KEEP = 20;

function atTime(day, time) {
  const [hours, minutes] = time.split(":").map(Number);
  const at = new Date(day);
  at.setHours(hours, minutes, 0, 0);
  return at.getTime();
}

// When the schedule next comes round after `after` (ms), or null if never.
export function nextRun(schedule, after, last = null) {
  if (schedule.type === "once") return schedule.at > after ? schedule.at : null;
  if (schedule.type === "finish") return null;
  if (schedule.type === "interval") {
    const step = schedule.minutes ? schedule.minutes * 60_000 : schedule.every * HOUR;
    let next = (last ?? after) + step;
    while (next <= after) next += step;
    return next;
  }
  if(schedule.timezone && schedule.type==='daily'){
    for(let offset=0;offset<=2;offset++){const day=addDays(zonedDay(after,schedule.timezone),offset),at=zonedTime(day,schedule.time,schedule.timezone);if(at>after)return at;}return null;
  }
  for (let offset = 0; offset <= 7; offset += 1) {
    const day = new Date(after);
    day.setDate(day.getDate() + offset);
    const at = atTime(day, schedule.time);
    if (at > after && (schedule.type === "daily" || schedule.days.includes(new Date(at).getDay()))) return at;
  }
  return null;
}

function schedule(body, current) {
  const type = oneOf(body?.type, SCHEDULES, current?.type ?? "daily");
  const time = TIME.test(body?.time ?? "") ? body.time : current?.time ?? "09:00";
  const days = Array.isArray(body?.days) ? [...new Set(body.days.map(Number).filter((day) => Number.isInteger(day) && day >= 0 && day <= 6))].sort() : current?.days ?? [1, 2, 3, 4, 5];
  const every = Number.isInteger(Number(body?.every)) && Number(body.every) >= 1 && Number(body.every) <= 168 ? Number(body.every) : current?.every ?? 24;
  const at = Number.isFinite(Number(body?.at)) && Number(body.at) > 0 ? Number(body.at) : current?.at ?? 0;
  const minutes = Number.isInteger(Number(body?.minutes)) && Number(body.minutes) >= 1 && Number(body.minutes) <= 180 ? Number(body.minutes) : null;
  if (type === "weekly" && !days.length) throw new StudioError(400, "NO_DAYS", "每周要至少选一天");
  if (type === "once" && !at) throw new StudioError(400, "NO_TIME", "一次性的自动化要选好时间");
  const timezone=body?.timezone??current?.timezone;
  if(timezone){try{new Intl.DateTimeFormat('en',{timeZone:timezone}).format();}catch{throw new StudioError(400,'TIMEZONE','Invalid IANA timezone');}}
  return { type, time, days, every, at, ...(timezone?{timezone}:{}), minutes: type === "interval" ? minutes : null };
}

const STEP_KINDS = ["ask", "list", "check", "todo", "event", "note"];
const LOCAL_KINDS = new Set(["todo", "event", "note"]);
const NOTE_KINDS = ["knowledge", "evidence", "task", "context"];
const DATE = /^\d{4}-\d{2}-\d{2}$/;

function cleanSteps(list) {
  if (!Array.isArray(list)) return [];
  return list.slice(0, 8).map((step, index) => ({
    kind: STEP_KINDS.includes(step?.kind) ? step.kind : "ask",
    title: line(step?.title, 40, `步骤 ${index + 1}`),
    prompt: text(step?.prompt ?? step?.text, 2000),
    due: DATE.test(step?.due || "") ? step.due : "",
    time: TIME.test(step?.time || "") ? step.time : "",
    noteKind: NOTE_KINDS.includes(step?.noteKind) ? step.noteKind : "knowledge",
  })).filter((step) => step.prompt);
}

function localDay(ms) {
  const date = new Date(ms);
  const pad = (value) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function localStart(day, time) {
  const [year, month, date] = day.split("-").map(Number);
  const [hours, minutes] = (time || "09:00").split(":").map(Number);
  return new Date(year, month - 1, date, hours, minutes, 0, 0).getTime();
}

export async function runAutomation(item, { start, runWorkflow, createTodo, createEvent, createNote, now = () => Date.now() }) {
  const todos = [];
  const events = [];
  const notes = [];
  for (const step of item?.action?.steps || []) {
    if (step.kind === "todo" && createTodo) todos.push(await createTodo({ text: step.prompt, due: step.due || "", note: step.title || "" }));
    if (step.kind === "event" && createEvent) {
      const day = step.due || localDay(now());
      events.push(await createEvent({ title: step.prompt, start: localStart(day, step.time || "09:00"), notes: step.title || "" }));
    }
    if (step.kind === "note" && createNote) notes.push(await createNote({ kind: step.noteKind || "knowledge", title: step.title, body: step.prompt }));
  }
  if (item?.action?.type === "workflow") return { thread: await runWorkflow(item), todos, events, notes };
  if (!String(item?.action?.prompt || "").trim()) return { thread: null, todos, events, notes };
  return { thread: await start(item), todos, events, notes };
}

function action(body, current) {
  const type = oneOf(body?.type, ["prompt", "workflow"], current?.type ?? "prompt");
  const steps = body?.steps !== undefined ? cleanSteps(body.steps) : cleanSteps(current?.steps);
  const modelSteps = steps.filter((step) => !LOCAL_KINDS.has(step.kind));
  const joined = modelSteps.map((step, index) => {
    const name = step.kind === "list" ? `列出：${step.title}` : step.kind === "check" ? `核对：${step.title}` : step.title;
    return `${index + 1}. ${name}\n${step.prompt}`;
  }).join("\n\n");
  const next = {
    type,
    prompt: steps.length ? joined : (body?.prompt !== undefined ? text(body.prompt, 4000) : current?.prompt ?? ""),
    steps,
    workflowId: body?.workflowId !== undefined ? line(body.workflowId, 64) : current?.workflowId ?? "",
    values: body?.values && typeof body.values === "object" ? Object.fromEntries(Object.entries(body.values).slice(0, 8).map(([key, value]) => [line(key, 20), line(value, 2000)])) : current?.values ?? {},
    projectId: body?.projectId !== undefined ? (typeof body.projectId === "string" && body.projectId ? body.projectId : null) : current?.projectId ?? null,
  };
  if (type === "prompt" && !next.prompt && !steps.some((step) => LOCAL_KINDS.has(step.kind))) throw new StudioError(400, "EMPTY", "写下到时要让 AI 做什么，或加一条待办、日程、备忘");
  if (type === "workflow" && !next.workflowId) throw new StudioError(400, "NO_WORKFLOW", "选一个要运行的工作流");
  return next;
}

export function createAutomations({ dir, execute, now = () => Date.now(), paused = () => false, lock = null }) {
  const store = createJsonStore(path.join(dir, "automations.json"), { version: 1, automations: [] }, { lock });
  let timer = null;
  let ticking = null;

  function itemOf(data, id) {
    const item = data.automations.find((entry) => entry.id === id);
    if (!item) throw new StudioError(404, "MISSING", "没有这个自动化");
    return item;
  }

  async function perform(id, trigger) {
    const item = itemOf(await store.read(), id);
    if (trigger !== "manual" && (!item.enabled || paused())) return null;
    const at = now();
    let entry;
    try {
      const thread = await execute(item, trigger);
      entry = { at, trigger, threadId: thread?.id ?? null };
      if(['reflection','reminder'].includes(item.action.type)){entry.state=thread?.reminder?.state||thread?.state||'unavailable';entry.retry=['waiting-owner','waiting-destination','pending','error','unavailable'].includes(entry.state);}
    } catch (error) {
      entry = { at, trigger, error: error.message || "没有启动" };
      if(['reflection','reminder'].includes(item.action.type))entry.retry=true;
    }
    return store.update((data) => {
      const current = itemOf(data, id);
      current.lastRun = at;
      current.history = [entry, ...(current.history ?? [])].slice(0, KEEP);
      return { ...current, ran: entry };
    });
  }

  async function tick() {
    if (ticking) return ticking;
    ticking = (async () => {
      if (paused()) return [];
      const at = now();
      const due = (await store.read()).automations.filter((item) => item.enabled && item.nextRun && item.nextRun <= at);
      const done = [];
      for (const item of due) {
        if (at - item.nextRun > LATE_MS && !item.catchUp) {
          await store.update((data) => {
            const current = itemOf(data, item.id);
            current.history = [{ at, trigger: "schedule", missed: current.nextRun }, ...(current.history ?? [])].slice(0, KEEP);
          });
        } else { const result=await perform(item.id, "schedule"); if(result)done.push(result); }
        await store.update((data) => {
          const current = itemOf(data, item.id);
          current.nextRun = current.enabled ? (current.history[0]?.retry?now()+30000:nextRun(current.schedule, now(), current.lastRun ?? null)) : null;
          if (!current.nextRun) current.enabled = false;
        });
      }
      return done;
    })().finally(() => {
      ticking = null;
    });
    return ticking;
  }

  return {
    async createReminder({id,questionId,dueAt,text,timezone}){
      if(typeof id!=='string'||!id||!Number.isSafeInteger(dueAt)||!questionId)throw new StudioError(400,'REMINDER_INVALID','Invalid reminder');
      return store.update(data=>{const found=data.automations.find(x=>x.action?.type==='reminder'&&x.action.reminderId===id);if(found)return structuredClone(found);
        const at=now(),item={id:newId(),name:'Personal reminder',enabled:true,catchUp:true,schedule:{type:'once',at:dueAt,timezone},action:{type:'reminder',reminderId:id,questionId,text},createdAt:at,updatedAt:at,lastRun:null,history:[],nextRun:dueAt};data.automations.unshift(item);return structuredClone(item);});
    },
    async createReflection({key,subject,timezone}) {
      return store.update(data=>{
        const existing=data.automations.find(x=>x.action?.type==='reflection'&&x.action.subjectKey===key);
        if(existing)return structuredClone(existing);
        const at=now(),timing=schedule({type:'daily',time:'02:00',timezone});
        const item={id:newId(),name:'Daily authorized reflection',enabled:true,catchUp:true,schedule:timing,action:{type:'reflection',subjectKey:key,subject:structuredClone(subject)},progress:{revision:0,days:{},budget:{}},createdAt:at,updatedAt:at,lastRun:null,history:[],nextRun:nextRun(timing,at)};
        data.automations.unshift(item);return structuredClone(item);
      });
    },
    async readReflection(id){const item=itemOf(await store.read(),id);if(item.action.type!=='reflection')throw new StudioError(409,'REFLECTION_TASK_REQUIRED','Wrong task');return structuredClone(item.progress);},
    async updateReflection(id,expectedRevision,progress){return store.update(data=>{const item=itemOf(data,id);if(item.action.type!=='reflection'||item.progress.revision!==expectedRevision)throw new StudioError(409,'REFLECTION_CONFLICT','Stale reflection progress');const next=structuredClone(progress);next.revision=expectedRevision+1;item.progress=next;item.updatedAt=now();return structuredClone(next);});},
    async list() {
      return (await store.read()).automations;
    },
    async create(body) {
      const at = now();
      const item = {
        id: newId(),
        name: line(body?.name, 60, "新的自动化"),
        enabled: body?.enabled !== false,
        schedule: schedule(body?.schedule),
        action: action(body?.action),
        catchUp: body?.catchUp === true,
        lastRun: null,
        history: [],
        createdAt: at,
        updatedAt: at,
      };
      item.nextRun = item.enabled ? nextRun(item.schedule, at) : null;
      await store.update((data) => {
        data.automations.unshift(item);
      });
      return item;
    },
    async update(id, change) {
      return store.update((data) => {
        const item = itemOf(data, id);
        if (typeof change?.name === "string") item.name = line(change.name, 60, item.name);
        if (change?.schedule !== undefined) item.schedule = schedule(change.schedule, item.schedule);
        if (change?.action !== undefined) item.action = action(change.action, item.action);
        if (typeof change?.catchUp === "boolean") item.catchUp = change.catchUp;
        if (typeof change?.enabled === "boolean") item.enabled = change.enabled;
        item.nextRun = item.enabled ? nextRun(item.schedule, now(), item.lastRun ?? null) : null;
        if (item.enabled && !item.nextRun && item.schedule.type !== "finish") throw new StudioError(400, "PAST", "这个时间已经过了，换一个以后的时间");
        item.updatedAt = now();
        return { ...item };
      });
    },
    async remove(id) {
      await store.update((data) => {
        itemOf(data, id);
        data.automations = data.automations.filter((item) => item.id !== id);
      });
    },
    runNow: (id) => perform(id, "manual"),
    runOnFinish: (id) => perform(id, "finish"),
    tick,
    start(everyMs = 30_000) {
      if (timer) return;
      tick().catch(() => {});
      timer = setInterval(() => tick().catch(() => {}), everyMs);
      timer.unref?.();
    },
    stop() {
      clearInterval(timer);
      timer = null;
    },
  };
}
