export const MARK_COLORS = ["#fde68a", "#bbf7d0", "#bfdbfe", "#fecaca"];

export function findQuote(source, quote) {
  const wanted = String(quote || "").replace(/\s+/g, " ").trim().slice(0, 240);
  if (wanted.length < 2) return null;
  const flat = [];
  let spaced = false;
  const text = String(source || "");
  for (let index = 0; index < text.length; index += 1) {
    if (/\s/.test(text[index])) {
      if (!spaced && flat.length) flat.push({ ch: " ", at: index });
      spaced = true;
      continue;
    }
    spaced = false;
    flat.push({ ch: text[index], at: index });
  }
  const hay = flat.map((item) => item.ch).join("");
  const at = hay.indexOf(wanted);
  if (at < 0) return null;
  return { start: flat[at].at, end: flat[at + wanted.length - 1].at + 1, quote: wanted };
}

export function applyMarks(text, marks) {
  const source = String(text || "");
  const ranges = [];
  for (const mark of marks || []) {
    const found = findQuote(source, mark?.quote);
    if (!found) continue;
    ranges.push({ ...found, color: MARK_COLORS.includes(mark.color) ? mark.color : MARK_COLORS[0] });
  }
  ranges.sort((a, b) => a.start - b.start || b.end - a.end);
  const parts = [];
  let cursor = 0;
  for (const range of ranges) {
    if (range.start < cursor) continue;
    if (range.start > cursor) parts.push({ text: source.slice(cursor, range.start), color: "" });
    parts.push({ text: source.slice(range.start, range.end), color: range.color });
    cursor = range.end;
  }
  if (cursor < source.length || !parts.length) parts.push({ text: source.slice(cursor), color: "" });
  return parts;
}
