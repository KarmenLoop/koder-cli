// One JSON file per collection, shared by the shell and the kernel. Every
// change re-reads the file while holding a lock file and replaces it whole, so
// neither process writes over the other's change.
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { isLocked, LockError } from "../private-format.mjs";

const STALE_MS = 10_000;

async function acquire(file) {
  const lock = `${file}.lock`;
  for (let attempt = 0; ; attempt += 1) {
    try {
      await (await fs.open(lock, "wx")).close();
      return () => fs.rm(lock, { force: true });
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      const info = await fs.stat(lock).catch(() => null);
      if (info && Date.now() - info.mtimeMs > STALE_MS) await fs.rm(lock, { force: true });
      else if (attempt > 500) throw Object.assign(new Error("数据正在被另一处修改，请稍后再试"), { status: 503, code: "BUSY" });
      await new Promise((resolve) => setTimeout(resolve, 5 + Math.random() * 15));
    }
  }
}

// With a data lock (fusion/data-lock.mjs) the file is sealed; a plain file
// from before is read as it is and sealed the next time it is saved. A sealed
// file that will not open is an error, never a reason to start over.
export function createJsonStore(file, defaults, { lock = null } = {}) {
  const fresh = () => structuredClone(defaults);
  const label = path.basename(file);
  let queue = Promise.resolve();

  async function read() {
    let bytes;
    try {
      bytes = await fs.readFile(file);
    } catch (error) {
      if (error.code === "ENOENT") return fresh();
      throw error;
    }
    if ((typeof lock?.isLocked==='function'?lock.isLocked(bytes):isLocked(bytes))||isLocked(bytes)) {
      if (!lock) throw new LockError("NO_KEY", "这个文件是加密的，但没有拿到数据锁");
      return { ...fresh(), ...JSON.parse(lock.open(bytes, label).toString("utf8")) };
    }
    try {
      return { ...fresh(), ...JSON.parse(bytes.toString("utf8")) };
    } catch {
      // Kept aside rather than lost; the collection starts again empty.
      await fs.rename(file, `${file}.broken-${Date.now()}`).catch(() => {});
      return fresh();
    }
  }

  function update(change) {
    const next = queue.then(async () => {
      await fs.mkdir(path.dirname(file), { recursive: true });
      const release = await acquire(file);
      try {
        const data = await read();
        const result = await change(data);
        const temp = `${file}.${process.pid}.${crypto.randomUUID()}.tmp`;
        const text = `${JSON.stringify(data, null, 2)}\n`;
        await fs.writeFile(temp, lock ? lock.seal(text, label) : text, { mode: 0o600 });
        await fs.rename(temp, file);
        return result;
      } finally {
        await release();
      }
    });
    queue = next.catch(() => {});
    return next;
  }

  return { file, read, update };
}

export class StudioError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export const newId = () => crypto.randomUUID();

// Trimmed text no longer than `max`, or the fallback when nothing is left.
export function text(value, max, fallback = "") {
  const clean = typeof value === "string" ? value.replace(/\r\n?/g, "\n").trim().slice(0, max) : "";
  return clean || fallback;
}

export function line(value, max, fallback = "") {
  return text(typeof value === "string" ? value.replace(/\s+/g, " ") : value, max, fallback);
}

export function oneOf(value, values, fallback) {
  return values.includes(value) ? value : fallback;
}

// A file name that is safe inside one of Koder's own folders.
export function safeName(name, fallback = "file") {
  const base = path.basename(String(name ?? "")).replace(/[\u0000-\u001f<>:"/\\|?*]/g, "_").replace(/^\.+/, "").trim().slice(0, 120);
  return base || fallback;
}
