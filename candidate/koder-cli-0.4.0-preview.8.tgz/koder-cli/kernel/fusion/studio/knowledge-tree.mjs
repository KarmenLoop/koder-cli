// Adapted from VectifyAI/PageIndex's Markdown extraction and stack-based tree
// assembly. Changes: local line/character citations, stable node IDs, bounded
// parsing and no external model or PDF service. See loop/vendor/bot-foundations.
import { createHash } from 'node:crypto';
export function outline(text, title = '正文') {
  const lines = String(text).replace(/\r\n?/g, '\n').split('\n'), flat = [];
  let fence = null, offset = 0;
  for (let n = 0; n < lines.length; n++) {
    const line = lines[n].trim(), marker = /^(\x60{3,}|~{3,})/.exec(line);
    if (marker) { if (!fence) fence = marker[1][0]; else if (marker[1][0] === fence) fence = null; }
    else if (!fence) {
      const header = /^(#{1,6})\s+(.+?)(?:\s+#+)?$/.exec(line), bold = /^\*\*(.+?)\*\*$/.exec(line);
      if ((header || bold) && flat.length < 2000) flat.push({ title: (header?.[2] || bold[1]).slice(0, 250), level: header ? header[1].length : 1, startLine: n + 1, offset });
    }
    offset += lines[n].length + 1;
  }
  if (!flat.length || flat[0].startLine > 1) flat.unshift({ title, level: 0, startLine: 1, offset: 0 });
  const nodes = [], stack = [];
  for (let i = 0; i < flat.length; i++) {
    const node = flat[i]; node.id = createHash('sha256').update(`${node.startLine}:${node.title}`).digest('hex').slice(0, 16);
    node.ownEndLine = (flat[i + 1]?.startLine || lines.length + 1) - 1;
    node.endLine = node.ownEndLine; node.nodes = [];
    while (stack.length && stack.at(-1).level >= node.level) stack.pop();
    node.path = [...stack.map(p => p.title), node.title];
    if (stack.length) stack.at(-1).nodes.push(node); else nodes.push(node);
    stack.push(node);
  }
  const promote = node => { for (const child of node.nodes) { promote(child); node.endLine = Math.max(node.endLine, child.endLine); } };
  nodes.forEach(promote);
  return { nodes, flat, lines };
}
export function treeChunks(text, title) {
  const tree = outline(text, title), chunks = [];
  for (const node of tree.flat) {
    const content = tree.lines.slice(node.startLine - 1, node.ownEndLine).join('\n');
    for (let start = 0; start < content.length; start += 580) {
      const part = content.slice(start, start + 700); if (!part.trim()) continue;
      const first = node.startLine + (content.slice(0, start).match(/\n/g)?.length || 0);
      chunks.push({ text: part, nodeId: node.id, sectionPath: node.path, startLine: first, endLine: first + (part.match(/\n/g)?.length || 0) });
      if (start + 700 >= content.length) break;
    }
  }
  return chunks;
}
