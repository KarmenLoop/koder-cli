// Deterministic checks. They never call a model, overwrite inputs, fetch URLs or decide professional conclusions.
import { newId, StudioError } from './store.mjs';
import { createOutputFolder, digest, inspectFile, utf8, writeOutput } from './professional-files.mjs';
const fail=message=>{throw new StudioError(400,'AUDIT_INPUT',message);};
export function parseCsv(text) {
 if(typeof text!=='string'||text.length>8*1024*1024)fail('CSV 超过 8 MB');
 text=text.replace(/^\uFEFF/,'');const rows=[];let row=[],cell='',quoted=false,closed=false,line=1,start=1;
 const endCell=()=>{if(row.length>=200)fail('CSV 超过 200 列');row.push(cell);cell='';closed=false;};
 const endRow=()=>{endCell();if(row.length!==1||row[0]!=='')rows.push({cells:row,line:start});row=[];if(rows.length>50001)fail('CSV 超过 50000 行');};
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(quoted){if(c==='"'){if(text[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else{cell+=c;if(c==='\r'||(c==='\n'&&text[i-1]!=='\r'))line++;}if(cell.length>200000)fail('CSV 单元格过长');continue;}
  if(c==='"'){if(cell||closed)fail(`第 ${line} 行引号格式错误`);quoted=true;continue;}
  if(c===','){endCell();continue;}
  if(c==='\r'||c==='\n'){if(c==='\r'&&text[i+1]==='\n')i++;endRow();line++;start=line;continue;}
  if(closed)fail(`第 ${line} 行引号后存在多余字符`);
  cell+=c;if(cell.length>200000)fail('CSV 单元格过长');
 }
 if(quoted)fail('CSV 存在未闭合的引号');
 if(cell||closed||row.length)endRow();
 if(!rows.length)fail('CSV 没有表头');
 const headers=rows.shift().cells.map(x=>x.trim());
 if(headers.length>200||headers.some(x=>!x||x.length>100)||new Set(headers).size!==headers.length)fail('表头须非空、唯一，最多 200 列');
 return {headers,rows};
}
export function csvText(headers,rows) {
 const encode=v=>{let s=String(v??'');if((/^[\s]*[=+@-]/.test(s)&&!/^-[0-9]+(?:\.[0-9]+)?$/.test(s))||/^[\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};
 return '\uFEFF'+[headers,...rows].map(row=>row.map(encode).join(',')).join('\r\n')+'\r\n';
}
const list=(v,max=40)=>{if(v===undefined)return [];if(!Array.isArray(v)||v.length>max||v.some(x=>typeof x!=='string'||!x||x.length>100))fail('规则字段须为有限字符串列表');if(new Set(v).size!==v.length)fail('检查规则中的字段不能重复');return v;};
const decimal=(v,scale)=>{if(!/^-?\d+(?:\.\d+)?$/.test(v)||v.length>40)return null;let [a,b='']=v.replace(/^-/,'').split('.');if(b.length>scale)return null;return (v.startsWith('-')?-1n:1n)*BigInt(a+b.padEnd(scale,'0'));};
const money=(n,scale)=>{const s=(n<0n?-n:n).toString().padStart(scale+1,'0');return (n<0n?'-':'')+(scale?s.slice(0,-scale)+'.'+s.slice(-scale):s);};
const validDate=v=>/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;
function tableAudit(tables,rules={}) {
 if(!rules||typeof rules!=='object'||Array.isArray(rules))fail('检查规则格式不正确');
 const required=list(rules.required),key=list(rules.key),dates=list(rules.dates),amounts=list(rules.decimals),scale=rules.scale??2;
 if(!Number.isInteger(scale)||scale<0||scale>6)fail('小数精度须为 0–6');
 const enums=rules.enums??{};
 if(!enums||typeof enums!=='object'||Array.isArray(enums)||Object.keys(enums).length>40)fail('枚举规则格式不正确');
 for(const [k,v] of Object.entries(enums)){if(!k||k.length>100)fail('枚举字段无效');list(v,100);}
 const wanted=[...new Set([...required,...key,...dates,...amounts,...Object.keys(enums)])];
 if(!wanted.length)fail('请至少设置一项必填、主键、日期、金额或枚举规则');
 const issues=[],normalized=[],allHeaders=[...new Set(tables.flatMap(t=>t.headers))],seen=new Map(),sums=Object.fromEntries(amounts.map(k=>[k,0n])),invalid=new Set();
 const add=(t,row,field,code,detail)=>{if(issues.length>=50000)fail('异常超过 50000 项，请拆小批次并检查规则字段');issues.push({source:t.path,row,field,code,detail});};
 for(const t of tables){
  for(const col of wanted)if(!t.headers.includes(col)){add(t,1,col,'MISSING_COLUMN','原表缺少规则字段');if(amounts.includes(col))invalid.add(col);}
  for(const r of t.rows){
   const values=Object.fromEntries(t.headers.map((k,i)=>[k,(r.cells[i]??'').trim()]));
   if(r.cells.length!==t.headers.length)add(t,r.line,'','COLUMN_COUNT','单元格数量与表头不同；请核对原行');
   for(const col of required)if(!values[col])add(t,r.line,col,'REQUIRED','必填值缺失');
   for(const col of dates)if(values[col]&&!validDate(values[col]))add(t,r.line,col,'DATE','日期须为有效 YYYY-MM-DD');
   for(const [col,allowed]of Object.entries(enums))if(values[col]&&!allowed.includes(values[col]))add(t,r.line,col,'ENUM','值不在确认的字典中');
   for(const col of amounts){const n=decimal(values[col]??'',scale);if(n===null){invalid.add(col);add(t,r.line,col,'DECIMAL','金额缺失或格式/精度不符，未计入有效值小计');}else sums[col]+=n;}
   if(key.length){if(key.some(k=>!values[k]))add(t,r.line,key.join('+'),'MISSING_KEY','主键缺失');else{const id=JSON.stringify(key.map(k=>values[k]));if(seen.has(id))add(t,r.line,key.join('+'),'DUPLICATE',`与 ${seen.get(id)} 重复，保留双方记录`);else seen.set(id,`${t.path}:${r.line}`);}}
   normalized.push([t.path,r.line,...allHeaders.map(k=>values[k]??'')]);
  }
 }
 return {issues,headers:['来源文件','原始行号',...allHeaders],rows:normalized,summary:{inputRows:normalized.length,outputRows:normalized.length,totals:Object.fromEntries(amounts.map(k=>[k,{validSubtotal:money(sums[k],scale),complete:!invalid.has(k)}]))}};
}
function coverageAudit(tables) {
 if(tables.length!==2)fail('覆盖检查需要要求表和响应表两个 CSV（按此顺序）');
 const [req,res]=tables;
 for(const [t,cols]of [[req,['id','requirement','source','locator']],[res,['id','response','evidence']]])for(const c of cols)if(!t.headers.includes(c))fail(`覆盖检查缺列：${c}`);
 const objects=t=>t.rows.map(r=>({...Object.fromEntries(t.headers.map((k,i)=>[k,(r.cells[i]??'').trim()])),row:r.line}));
 const requirements=objects(req),responses=objects(res),issues=[],seen=new Set(),rows=[],byId=new Map();
 for(const response of responses){const hits=byId.get(response.id)??[];hits.push(response);byId.set(response.id,hits);}
 for(const t of tables)for(const r of t.rows)if(r.cells.length!==t.headers.length)issues.push({source:t.path,row:r.line,field:'',code:'COLUMN_COUNT',detail:'列数与表头不同'});
 for(const r of requirements){let status='已填写，待内容复核';if(!r.id||seen.has(r.id)){issues.push({source:req.path,row:r.row,field:'id',code:'REQUIREMENT_ID',detail:'要求编号缺失或重复'});status='编号异常';}seen.add(r.id);
  if(!r.requirement||!r.source||!r.locator){issues.push({source:req.path,row:r.row,field:'source/locator/requirement',code:'NO_SOURCE',detail:'要求正文或来源定位缺失'});status='来源不全';}
  const hits=byId.get(r.id)??[];if(hits.length!==1||!hits[0].response||!hits[0].evidence){issues.push({source:req.path,row:r.row,field:r.id,code:'UNCOVERED',detail:hits.length>1?'存在多个响应，需消除歧义':'响应或证明材料缺失'});status='响应不全';}
  rows.push([r.id,r.requirement,r.source,r.locator,hits[0]?.response??'',hits[0]?.evidence??'',status]);
 }
 for(const r of responses)if(!seen.has(r.id))issues.push({source:res.path,row:r.row,field:'id',code:'UNKNOWN_REQUIREMENT',detail:'响应未对应要求表中的编号'});
 return {issues,headers:['编号','要求','来源','定位','响应','证明材料','状态'],rows,summary:{requirements:requirements.length,responses:responses.length,contentVerified:false}};
}
async function citationAudit(root,tables) {
 if(tables.length!==1)fail('引用检查需要一个 CSV');
 const t=tables[0];for(const c of ['source','quote','startLine','endLine'])if(!t.headers.includes(c))fail(`引用检查缺列：${c}`);
 if(t.rows.length>200)fail('一次最多检查 200 条引用');
 const sources=new Map(),issues=[],rows=[];
 for(const r of t.rows){const v=Object.fromEntries(t.headers.map((k,i)=>[k,r.cells[i]??'']));let status='未匹配',sha='';
  try{
   if(r.cells.length!==t.headers.length||!v.quote.trim()||!/^\d+$/.test(v.startLine)||!/^\d+$/.test(v.endLine))throw Error('引用内容或行号缺失/无效');
   if(!/\.(txt|md|csv|json)$/i.test(v.source))throw Error('先把 PDF/Office 原文通过读取工具提取为带来源定位的 UTF-8 文本，再核对引文；本检查不做 OCR');
   if(!sources.has(v.source)){if(sources.size>=20)throw Error('最多引用 20 个来源');const s=await inspectFile(root,v.source,{content:true,maxBytes:1024*1024});sources.set(v.source,{...s,lines:utf8(s.bytes).replace(/\r\n?/g,'\n').split('\n')});}
   const s=sources.get(v.source),a=Number(v.startLine),b=Number(v.endLine);sha=s.sha256;
   if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<1||b<a||b>s.lines.length||b-a>300)throw Error('行号超出来源范围');
   if(!s.lines.slice(a-1,b).join('\n').includes(v.quote.replace(/\r\n?/g,'\n')))throw Error('指定原文行未找到该引文');
   status='原文匹配；效力待复核';
  }catch(e){issues.push({source:t.path,row:r.line,field:'quote',code:'UNVERIFIED_CITATION',detail:e.message});}
  rows.push([v.source,v.startLine,v.endLine,status,sha]);
 }
 return {issues,headers:['来源','起始行','结束行','核对状态','来源SHA256'],rows,summary:{citations:t.rows.length,legalValidityVerified:false},extraSources:[...sources.values()].map(({path,size,sha256})=>({path,size,sha256}))};
}
export const AUDIT_HELP={
 table:{files:'1–10 个 UTF-8 CSV',rules:{key:['工号'],required:['姓名'],dates:['入职日期'],decimals:['金额'],scale:2,enums:{部门:['研发','市场']}}},
 coverage:{files:'要求表、响应表，依次提供两个 UTF-8 CSV',headers:{requirements:['id','requirement','source','locator'],responses:['id','response','evidence']}},
 citations:{files:'一个引用 CSV；来源须为项目内 UTF-8 文本',headers:['source','quote','startLine','endLine']},
 scope:'输出新目录、原文件不改；只验证明确规则、填写覆盖和原文匹配，不替代业务、法律效力或渲染复核。XLSX 先通过 Office 的 CSV 导出接口提取明确范围，核对表头、行数与日期/金额格式。'
};
export async function runProfessionalAudit(root,body={}) {
 if(!Object.hasOwn(AUDIT_HELP,body.kind)||body.kind==='scope')fail('检查类型应为 table、coverage 或 citations');
 const files=body.files;if(!Array.isArray(files)||!files.length||files.length>10||new Set(files).size!==files.length)fail('请提供 1–10 个不重复的 CSV 路径');
 const tables=[],sources=[];let bytes=0,rows=0;
 for(const file of files){if(typeof file!=='string'||!file.toLowerCase().endsWith('.csv'))fail('检查输入须为 CSV');const s=await inspectFile(root,file,{content:true,maxBytes:8*1024*1024});bytes+=s.size;if(bytes>16*1024*1024)fail('本批表格超过 16 MB');const t=parseCsv(utf8(s.bytes));if(!t.rows.length)fail('CSV 只有表头，没有可检查的数据');rows+=t.rows.length;if(rows>50000)fail('本批合计超过 50000 行');tables.push({path:file,...t});sources.push({path:file,size:s.size,sha256:s.sha256});}
 const result=body.kind==='table'?tableAudit(tables,body.rules):body.kind==='coverage'?coverageAudit(tables):await citationAudit(root,tables);
 sources.push(...(result.extraSources??[]));
 // Check inputs once more before committing results. A changing file invalidates this audit.
 for(const s of sources)if((await inspectFile(root,s.path)).sha256!==s.sha256)throw new StudioError(409,'FILE_CHANGED',`材料已变化：${s.path}`);
 const id=newId(),folder=await createOutputFolder(root,'Koder-核验',id),artifacts=[];
 artifacts.push(await writeOutput(root,folder,'结果.csv',csvText(result.headers,result.rows)));
 artifacts.push(await writeOutput(root,folder,'异常.csv',csvText(['来源文件','原始行号','字段','规则','说明'],result.issues.map(i=>[i.source,i.row,i.field,i.code,i.detail]))));
 const report={version:1,id,kind:body.kind,at:new Date().toISOString(),sources,rules:body.rules??{},ruleHash:digest(JSON.stringify(body.rules??{})),summary:result.summary,issueCount:result.issues.length,status:result.issues.length?'needs_review':'checks_passed',limits:AUDIT_HELP.scope,artifacts};
 artifacts.push(await writeOutput(root,folder,'核验记录.json',JSON.stringify({...report,artifacts:[...artifacts]},null,2)+'\n'));
 return {...report,folder,artifacts};
}
