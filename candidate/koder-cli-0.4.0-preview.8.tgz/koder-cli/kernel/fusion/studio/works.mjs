// 作品: what the work produced, found in the project folders — images, web
// pages, documents, media — with the files the AI wrote marked. Code shows up
// only when the AI wrote it, so a repository does not bury the gallery.
import fs from "node:fs/promises";
import path from "node:path";
import { createJsonStore, StudioError } from "./store.mjs";

const KINDS = {
  image: [".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp", ".avif", ".heic", ".ico"],
  web: [".html", ".htm"],
  doc: [".md", ".markdown", ".pdf", ".txt", ".csv", ".docx", ".doc", ".pptx", ".ppt", ".xlsx", ".xls", ".key", ".pages", ".numbers", ".rtf", ".json"],
  media: [".mp4", ".mov", ".webm", ".m4v", ".mp3", ".wav", ".m4a", ".ogg", ".flac"],
  code: [".js", ".mjs", ".ts", ".tsx", ".jsx", ".py", ".go", ".rs", ".java", ".kt", ".swift", ".c", ".cpp", ".h", ".rb", ".php", ".sh", ".css", ".scss", ".vue", ".svelte", ".sql", ".yaml", ".yml"],
};
const KIND_OF = new Map(Object.entries(KINDS).flatMap(([kind, exts]) => exts.map((ext) => [ext, kind])));
const SKIP = new Set(["node_modules", "dist", "build", "out", "target", "vendor", "Pods", "DerivedData", "__pycache__", "venv", "coverage"]);
const MAX_FILES = 4000;
const MAX_DEPTH = 8;
const FRESH_MS = 15_000;

export const kindOf = (file) => KIND_OF.get(path.extname(file).toLowerCase()) ?? null;

export async function scanFolder(root) {
  const found = [];
  async function walk(dir, depth) {
    if (depth > MAX_DEPTH || found.length >= MAX_FILES) return;
    const entries = await fs.readdir(dir, { withFileTypes: true }).catch(() => []);
    for (const entry of entries) {
      if (found.length >= MAX_FILES) return;
      if (entry.name.startsWith(".")) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (!SKIP.has(entry.name)) await walk(full, depth + 1);
        continue;
      }
      const kind = entry.isFile() ? kindOf(entry.name) : null;
      if (!kind) continue;
      const info = await fs.stat(full).catch(() => null);
      if (info) found.push({ path: path.relative(root, full).split(path.sep).join("/"), name: entry.name, kind, size: info.size, modifiedAt: Math.round(info.mtimeMs) });
    }
  }
  await walk(root, 0);
  return found;
}

// The absolute path of `rel` inside `root`, refusing anything that leaves it.
export async function inside(root, rel) {
  const base = await fs.realpath(root);
  const target = await fs.realpath(path.resolve(base, String(rel ?? ""))).catch(() => null);
  if (!target || (target !== base && !target.startsWith(base + path.sep))) throw new StudioError(404, "MISSING", "没有这个文件");
  return target;
}

export function createWorks({ dir, folders, threads = async () => [], loadThread = async () => null, lock = null }) {
  const store = createJsonStore(path.join(dir, "works.json"), { version: 1, made: {}, starred: [], scanned: [] }, { lock });
  const scans = new Map();
  const keyOf = (folderId, rel) => `${folderId}|${rel}`;
  const folderFor = (cwd) => folders.list().find((item) => item.path === cwd)?.id ?? null;

  // Counts elsewhere may use a recent scan; the gallery itself always looks again.
  async function scan(folder, fresh) {
    const hit = scans.get(folder.id);
    if (!fresh && hit && Date.now() - hit.at < FRESH_MS) return hit.items;
    const items = await scanFolder(folder.path);
    scans.set(folder.id, { at: Date.now(), items });
    return items;
  }

  // Files a task wrote through accepted changes.
  async function record(thread) {
    const folderId = thread?.cwd ? folderFor(thread.cwd) : null;
    const written = (thread?.changes ?? []).filter((change) => change.status === "accepted" && change.path);
    if (!folderId || !written.length) return;
    await store.update((data) => {
      for (const change of written) {
        const rel = path.normalize(change.path).split(path.sep).join("/");
        data.made[keyOf(folderId, rel)] ??= { threadId: thread.id, title: thread.title || "", at: Date.now() };
      }
      if (!data.scanned.includes(thread.id)) data.scanned.push(thread.id);
    });
    scans.delete(folderId);
  }

  // Tasks from before the workbench, read once each.
  async function backfill() {
    const seen = new Set((await store.read()).scanned);
    const todo = (await threads()).filter((item) => item.kind !== "karmen" && !item.legacy && !seen.has(item.id)).slice(0, 200);
    for (const summary of todo) {
      const thread = await loadThread(summary.id).catch(() => null);
      if (thread) await record(thread);
      await store.update((data) => {
        if (!data.scanned.includes(summary.id)) data.scanned.push(summary.id);
      });
    }
  }

  return {
    record,
    async list({ folderId = null, kind = null, query = "", starred = false, limit = 400, fresh = false } = {}) {
      await backfill().catch(() => {});
      const marks = await store.read();
      const stars = new Set(marks.starred);
      const wanted = String(query).trim().toLowerCase();
      const out = [];
      for (const folder of folders.list()) {
        if (folderId && folder.id !== folderId) continue;
        for (const item of await scan(folder, fresh)) {
          const key = keyOf(folder.id, item.path);
          const made = marks.made[key] ?? null;
          if (item.kind === "code" && !made) continue;
          if (kind && item.kind !== kind) continue;
          if (starred && !stars.has(key)) continue;
          if (wanted && !item.path.toLowerCase().includes(wanted)) continue;
          out.push({ ...item, key, folderId: folder.id, folderName: folder.name, made, starred: stars.has(key) });
        }
      }
      return out.sort((a, b) => b.modifiedAt - a.modifiedAt).slice(0, limit);
    },
    async star(folderId, rel, on) {
      const key = keyOf(folderId, rel);
      await store.update((data) => {
        data.starred = data.starred.filter((item) => item !== key);
        if (on) data.starred.unshift(key);
      });
      return { key, starred: Boolean(on) };
    },
    async resolve(folderId, rel) {
      const folder = folders.get(folderId);
      if (!folder) throw new StudioError(404, "MISSING", "没有这个项目");
      return inside(folder.path, rel);
    },
  };
}
