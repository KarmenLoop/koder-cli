// WeKnora weighted reciprocal-rank fusion, ported from Go and adapted to
// Koder's local full-text/section channels (not labelled as vector search).
// Each independent list is ranked independently. Copyright Tencent, MIT.
export function fuseRetrieval(channels, { k = 60 } = {}) {
  const scores = new Map(), max = channels.reduce((sum, c) => sum + c.weight / (k + 1), 0);
  for (const channel of channels) {
    const best = new Map();
    for (const list of channel.lists) {
      const unique = new Map();
      for (const item of list) { const id = `${item.baseId}:${item.doc}:${item.n}`; if (!unique.has(id) || unique.get(id).score < item.score) unique.set(id, item); }
      [...unique].sort((a, b) => b[1].score - a[1].score).forEach(([id, item], i) => { if (!best.has(id) || i + 1 < best.get(id).rank) best.set(id, { item, rank: i + 1 }); });
    }
    for (const [id, { item, rank }] of best) {
      const old = scores.get(id) || { ...item, score: 0, retrieval: [] };
      old.score += channel.weight / (k + rank); old.retrieval.push(channel.name); scores.set(id, old);
    }
  }
  return [...scores.values()].map(item => ({ ...item, score: max ? item.score / max : 0 })).sort((a, b) => b.score - a.score || a.doc.localeCompare(b.doc) || a.n - b.n);
}
