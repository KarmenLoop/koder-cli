import {referenceOfficeText} from '../reference-office-text.mjs';
// 知识库: documents the person adds, read into text, split into passages and
// indexed. The shell adds and removes; the kernel's knowledge_search tool reads
// the same files. Ranking is BM25 over words (with light English stemming) and
// over Chinese, Japanese and Korean characters and character pairs.
import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import { helperArgv } from "../helper-argv.mjs";
import { officeText, pdfPlainText, rtfToText } from "../office-text.mjs";
import { MARK_COLORS, findQuote } from "./marks.mjs";
import { createJsonStore, line, newId, safeName, StudioError, text } from "./store.mjs";
import { createPrivateFiles } from "../private-store.mjs";
import { outline, treeChunks } from './knowledge-tree.mjs';
import { fuseRetrieval } from './retrieval-fusion.mjs';

const PERSONAL = "personal";
const MAX_TEXT = 5_000_000;
const CHUNK = 700;
const OVERLAP = 120;
const PLAIN = new Set([
  ".txt", ".md", ".markdown", ".mdx", ".csv", ".tsv", ".json", ".jsonl", ".yaml", ".yml", ".toml", ".ini", ".xml", ".log", ".rst",
  ".tex", ".srt", ".vtt", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".py", ".rb", ".go", ".rs", ".java", ".kt", ".swift", ".c",
  ".h", ".cc", ".cpp", ".hpp", ".cs", ".php", ".sh", ".zsh", ".bash", ".sql", ".css", ".scss", ".less", ".vue", ".svelte", ".lua",
  ".r", ".dart", ".scala", ".pl",
]);
const HTML = new Set([".html", ".htm", ".xhtml"]);
const TEXTUTIL = new Set([".docx", ".doc", ".rtf", ".odt", ".wordml", ".webarchive"]);
const IMAGES = new Set([".png", ".jpg", ".jpeg", ".heic", ".tif", ".tiff", ".bmp", ".gif", ".webp"]);
export const KNOWLEDGE_TYPES = [...PLAIN, ...HTML, ...TEXTUTIL, ".pptx", ".xlsx", ".xlsm", ".pdf", ...IMAGES];

const CJK = "\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uf900-\\ufaff\\uac00-\\ud7af";
const TOKENS = new RegExp(`[a-z0-9_]+|[${CJK}]+`, "g");

function stem(word) {
  if (word.length > 4 && word.endsWith("ies")) return `${word.slice(0, -3)}y`;
  if (word.length > 5 && word.endsWith("ing")) return word.slice(0, -3);
  if (word.length > 4 && word.endsWith("ed")) return word.slice(0, -2);
  if (word.length > 3 && /(s|x|z|ch|sh)es$/.test(word)) return word.slice(0, -2);
  if (word.length > 3 && word.endsWith("s") && !word.endsWith("ss")) return word.slice(0, -1);
  return word;
}

// In a query, a run of two or more Chinese characters is looked up by its
// pairs only; single characters would match almost every passage.
export function tokenize(value, { query = false } = {}) {
  const tokens = [];
  for (const [piece] of String(value ?? "").toLowerCase().matchAll(TOKENS)) {
    if (/^[a-z0-9_]/.test(piece)) {
      tokens.push(stem(piece));
      continue;
    }
    const chars = [...piece];
    for (let i = 0; i < chars.length; i += 1) {
      if (!query || chars.length === 1) tokens.push(chars[i]);
      if (i + 1 < chars.length) tokens.push(chars[i] + chars[i + 1]);
    }
  }
  return tokens;
}

export function chunkText(value, size = CHUNK, overlap = OVERLAP) {
  const clean = String(value ?? "").replace(/\r\n?/g, "\n").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  if (!clean) return [];
  const chunks = [];
  let current = "";
  for (const paragraph of clean.split(/\n\s*\n/).map((item) => item.trim()).filter(Boolean)) {
    if (paragraph.length > size) {
      if (current) chunks.push(current);
      current = "";
      for (let start = 0; start < paragraph.length; start += size - overlap) {
        chunks.push(paragraph.slice(start, start + size));
        if (start + size >= paragraph.length) break;
      }
      continue;
    }
    if (current && current.length + 2 + paragraph.length > size) {
      chunks.push(current);
      current = paragraph;
    } else current = current ? `${current}\n\n${paragraph}` : paragraph;
  }
  if (current) chunks.push(current);
  return chunks;
}

function buildIndex(chunks) {
  const postings = new Map();
  const lengths = [];
  chunks.forEach((chunk, index) => {
    const tokens = tokenize(chunk.text);
    lengths.push(tokens.length);
    const counts = new Map();
    for (const token of tokens) counts.set(token, (counts.get(token) ?? 0) + 1);
    for (const [token, count] of counts) {
      let list = postings.get(token);
      if (!list) postings.set(token, (list = []));
      list.push([index, count]);
    }
  });
  const average = lengths.reduce((sum, length) => sum + length, 0) / (lengths.length || 1);
  return { chunks, postings, lengths, average };
}

function rank(index, query, limit) {
  const terms = [...new Set(tokenize(query, { query: true }))];
  const total = index.chunks.length;
  const scores = new Map();
  for (const term of terms) {
    const list = index.postings.get(term);
    if (!list) continue;
    const idf = Math.log(1 + (total - list.length + 0.5) / (list.length + 0.5));
    for (const [at, count] of list) {
      const weight = (count * 2.2) / (count + 1.2 * (0.25 + (0.75 * index.lengths[at]) / (index.average || 1)));
      scores.set(at, (scores.get(at) ?? 0) + idf * weight);
    }
  }
  return [...scores].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([at, score]) => ({ ...index.chunks[at], score: Math.round(score * 1000) / 1000 }));
}

function decodeEntities(value) {
  const named = { nbsp: " ", amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", mdash: "—", ndash: "–", hellip: "…", copy: "©" };
  return value.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (match, code) => {
    if (code[0] === "#") {
      const point = code[1] === "x" || code[1] === "X" ? parseInt(code.slice(2), 16) : Number(code.slice(1));
      return Number.isFinite(point) && point > 0 && point < 0x110000 ? String.fromCodePoint(point) : match;
    }
    return named[code.toLowerCase()] ?? match;
  });
}

export function htmlToText(html) {
  return decodeEntities(String(html)
    .replace(/<(script|style|noscript|template|svg)\b[\s\S]*?<\/\1>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<(br|hr)\b[^>]*>/gi, "\n")
    .replace(/<\/(p|div|li|tr|h[1-6]|section|article|header|footer|blockquote|pre|table|ul|ol)>/gi, "\n\n")
    .replace(/<[^>]+>/g, " "))
    .replace(/[ \t\f\v]+/g, " ")
    .replace(/ *\n */g, "\n")
    .trim();
}

function decode(buffer) {
  const head = buffer.subarray(0, 8192);
  if (head.includes(0)) throw new StudioError(422, "BINARY", "这个文件不是文本，读不出文字");
  return buffer.toString("utf8").replace(/^\uFEFF/, "");
}

function helperCall(helper, execFileImpl, command, args) {
  return new Promise((resolve, reject) => {
    const [file, argv] = helperArgv(helper, [command, JSON.stringify(args)]);
    execFileImpl(file, argv, { timeout: 120_000, maxBuffer: 64 * 1024 * 1024 }, (error, stdout) => {
      let answer = null;
      try {
        answer = JSON.parse(String(stdout || "").trim().split("\n").pop() || "null");
      } catch {}
      if (answer && !answer.error) resolve(answer);
      else reject(new StudioError(422, "READ", answer?.error || `没有读出文字：${error?.message || "助手没有回答"}`));
    });
  });
}

export function createKnowledge({ dir, helper = null, platform = process.platform, execFileImpl = execFile, blobs = null, lock = null, storage = null }) {
  storage ||= lock ? createPrivateFiles({dir:path.dirname(dir),lock}) : null;
  const store = createJsonStore(path.join(dir, "bases.json"), { version: 1, bases: [], docs: [] }, { lock });
  const passages = (baseId) => createJsonStore(path.join(dir, baseId, "chunks.json"), { chunks: [] }, { lock });
  const cache = new Map();

  async function read() {
    const data = await store.read();
    if (!data.bases.some((base) => base.id === PERSONAL)) {
      return store.update((next) => {
        if (!next.bases.some((base) => base.id === PERSONAL)) {
          next.bases.unshift({ id: PERSONAL, name: "个人知识库", description: "你自己的笔记、文档和资料", enabled: true, createdAt: Date.now() });
        }
        return next;
      });
    }
    return data;
  }

  function baseOf(data, id) {
    const base = data.bases.find((item) => item.id === id);
    if (!base) throw new StudioError(404, "MISSING", "没有这个知识库");
    return base;
  }

  async function extract(file, ext) {
    const bytes = () => blobs ? blobs.read(file) : fs.readFile(file);
    const native = run => blobs?.encrypted ? blobs.withPlainFile(file,run) : run(file);
    if (PLAIN.has(ext)) return decode(await bytes());
    if (HTML.has(ext)) return htmlToText(decode(await bytes()));
    const mac = platform === "darwin";
    if ([".pptx", ".xlsx", ".xlsm"].includes(ext)) {
      const body=await referenceOfficeText(await bytes(),ext);
      if(body.trim())return body;
      throw new StudioError(422,"EMPTY","文档中没有可检索文字");
    }
    if (ext === ".docx" || ext === ".odt") {
      try {
        const body = officeText(await bytes(), ext);
        if (body.trim()) return body;
      } catch {
        // A damaged package falls through to the platform reader.
      }
    }
    if (ext === ".rtf") return rtfToText(decode(await bytes()));
    if (TEXTUTIL.has(ext)) {
      if (!mac) throw new StudioError(422, "PLATFORM", "这种旧版 Word 文档请另存为 docx 后再上传");
      return native(plain => new Promise((resolve, reject) => {
        execFileImpl("/usr/bin/textutil", ["-convert", "txt", "-stdout", plain], { timeout: 60_000, maxBuffer: 64 * 1024 * 1024 }, (error, stdout) => {
          if (error) reject(new StudioError(422, "READ", `没有读出文字：${error.message}`));
          else resolve(String(stdout));
        });
      }));
    }
    if (ext === ".pdf" || IMAGES.has(ext)) {
      if (helper) {
        try {
          if (ext === ".pdf") {
            const body = await native(async plain => (await helperCall(helper, execFileImpl, "pdf-text", { path: plain, ocr: true, maxOcrPages: 40 })).text ?? "");
            if (body.trim()) return body;
          }
          else return await native(async plain => ((await helperCall(helper, execFileImpl, "ocr", { path: plain })).lines ?? []).map((item) => item.text).join("\n"));
        } catch (error) {
          if (ext !== ".pdf") throw error;
        }
      }
      if (ext === ".pdf") {
        const body = pdfPlainText(await bytes());
        if (body.trim()) return body;
      }
      if (!helper) throw new StudioError(501, "NO_HELPER", "缺少电脑操作助手，读不了 PDF 和图片里的文字");
      throw new StudioError(422, "READ", ext === ".pdf" ? "这个 PDF 里没有可复制的文字" : "没有读出图片里的文字");
    }
    throw new StudioError(415, "UNSUPPORTED", `不支持 ${ext || "没有扩展名的"} 文件。可以上传文本、Markdown、网页、代码、Word、PDF 或图片`);
  }

  // Passages first, then the record, so a document is never listed without them.
  async function index(baseId, docId, name, type, body, extra) {
    const clean = body.length > MAX_TEXT ? body.slice(0, MAX_TEXT) : body;
    const chunks = treeChunks(clean, name);
    if (!chunks.length) throw new StudioError(422, "EMPTY", "这份资料里没有读到文字");
    await fs.mkdir(path.join(dir, baseId, "text"), { recursive: true });
    const file=path.join(dir,baseId,"text",`${docId}.txt`);
    if(storage)await storage.writeBytes(file,Buffer.from(clean));
    else await fs.writeFile(file, clean, { mode: 0o600 });
    await passages(baseId).update((data) => {
      data.chunks.push(...chunks.map((chunk, n) => ({ doc: docId, n, ...chunk })));
    });
    const doc = { id: docId, baseId, name, type, chars: clean.length, chunks: chunks.length, truncated: body.length > MAX_TEXT, addedAt: Date.now(), ...extra };
    await store.update((data) => {
      data.docs.push(doc);
    });
    return doc;
  }

  async function loadIndex(baseId) {
    const file = path.join(dir, baseId, "chunks.json");
    const info = await fs.stat(file).catch(() => null);
    if (!info) return null;
    const hit = cache.get(baseId);
    if (hit && hit.mtimeMs === info.mtimeMs && hit.size === info.size) return hit.index;
    const built = buildIndex((await passages(baseId).read()).chunks);
    cache.set(baseId, { mtimeMs: info.mtimeMs, size: info.size, index: built });
    return built;
  }

  return {
    async overview() {
      const data = await read();
      return {
        bases: data.bases.map((base) => {
          const docs = data.docs.filter((doc) => doc.baseId === base.id);
          return { ...base, docs: docs.length, chars: docs.reduce((sum, doc) => sum + doc.chars, 0) };
        }),
        docs: data.docs,
      };
    },
    async createBase({ name, description }) {
      const base = { id: newId(), name: line(name, 40, "新知识库"), description: line(description, 200), enabled: true, createdAt: Date.now() };
      await store.update((data) => {
        data.bases.push(base);
      });
      return base;
    },
    async updateBase(id, change) {
      return store.update((data) => {
        const base = baseOf(data, id);
        if (typeof change?.name === "string") base.name = line(change.name, 40, base.name);
        if (typeof change?.description === "string") base.description = line(change.description, 200);
        if (typeof change?.enabled === "boolean") base.enabled = change.enabled;
        return { ...base };
      });
    },
    async removeBase(id) {
      if (id === PERSONAL) throw new StudioError(409, "KEEP", "个人知识库不能删除，可以删除里面的资料");
      await store.update((data) => {
        baseOf(data, id);
        data.bases = data.bases.filter((base) => base.id !== id);
        data.docs = data.docs.filter((doc) => doc.baseId !== id);
      });
      cache.delete(id);
      await fs.rm(path.join(dir, id), { recursive: true, force: true });
    },
    async addText({ baseId, name, text: body }) {
      baseOf(await read(), baseId);
      const value = text(body, MAX_TEXT);
      if (!value) throw new StudioError(400, "EMPTY", "没有填写内容");
      return index(baseId, newId(), line(name, 120, "笔记"), "text", value, { source: "text" });
    },
    // `source` is a file Koder already holds (an upload or a library item); it is moved in.
    async addFile({ baseId, name, source, keepSource = false, importHash = null, importPath = null }) {
      baseOf(await read(), baseId);
      const docId = newId();
      const fileName = safeName(name);
      const ext = path.extname(fileName).toLowerCase();
      const home = path.join(dir, baseId, "files", docId);
      const target = path.join(home, fileName);
      try {
        await fs.mkdir(home, { recursive: true });
        if (blobs) await blobs.store(source, target, { keep: keepSource });
        else if (keepSource) await fs.copyFile(source, target);
        else await fs.rename(source, target).catch(async () => {
          await fs.copyFile(source, target);
          await fs.rm(source, { force: true });
        });
        const info = blobs ? await blobs.stat(target) : await fs.stat(target);
        return await index(baseId, docId, fileName, ext.slice(1) || "file", await extract(target, ext), { source: "file", size: info.size, file: path.relative(dir, target), ...(importHash ? {importHash, importPath} : {}) });
      } catch (error) {
        await fs.rm(home, { recursive: true, force: true });
        throw error;
      }
    },
    async addMark(id, input) {
      const reading = await this.docText(id);
      const found = findQuote(reading.text, input?.quote);
      if (!found) throw new StudioError(400, "MARK", "这句话不在这份资料里");
      const color = MARK_COLORS.includes(input?.color) ? input.color : MARK_COLORS[0];
      return store.update((data) => {
        const doc = data.docs.find((item) => item.id === id);
        if (!doc) throw new StudioError(404, "MISSING", "没有这份资料");
        const marks = Array.isArray(doc.marks) ? doc.marks.filter((item) => item.quote !== found.quote) : [];
        marks.push({ quote: found.quote, color });
        doc.marks = marks.slice(-40);
        return { ...doc, marks: doc.marks };
      });
    },
    async removeMark(id, quote) {
      const wanted = String(quote || "").replace(/\s+/g, " ").trim();
      return store.update((data) => {
        const doc = data.docs.find((item) => item.id === id);
        if (!doc) throw new StudioError(404, "MISSING", "没有这份资料");
        doc.marks = (Array.isArray(doc.marks) ? doc.marks : []).filter((item) => item.quote !== wanted);
        return { ...doc, marks: doc.marks };
      });
    },
    async removeDoc(id) {
      const doc = await store.update((data) => {
        const found = data.docs.find((item) => item.id === id);
        if (!found) throw new StudioError(404, "MISSING", "没有这份资料");
        data.docs = data.docs.filter((item) => item.id !== id);
        return found;
      });
      await passages(doc.baseId).update((data) => {
        data.chunks = data.chunks.filter((chunk) => chunk.doc !== id);
      });
      await fs.rm(path.join(dir, doc.baseId, "files", id), { recursive: true, force: true });
      await fs.rm(path.join(dir, doc.baseId, "text", `${id}.txt`), { force: true });
    },
    async docText(id, max = 200_000, { forAi = false } = {}) {
      const data = await read();
      const doc = data.docs.find((item) => item.id === id);
      if (!doc) throw new StudioError(404, "MISSING", "没有这份资料");
      if (forAi && !data.bases.find(base => base.id === doc.baseId)?.enabled) throw new StudioError(403, 'KNOWLEDGE_DISABLED', '这个知识库已关闭 AI 使用');
      const file=path.join(dir,doc.baseId,"text",`${id}.txt`);
      const body = storage ? (await storage.readBytes(file)).toString('utf8') : await fs.readFile(file,"utf8");
      return { doc: { ...doc, marks: Array.isArray(doc.marks) ? doc.marks : [] }, text: body.slice(0, max), truncated: body.length > max };
    },
    // `forAi`: only the bases the person lets the AI use.
    async tree(id, { forAi = false } = {}) {
      const data = await read(), doc = data.docs.find(item => item.id === id);
      if (!doc) throw new StudioError(404, 'MISSING', '没有这份资料');
      if (forAi && !data.bases.find(base => base.id === doc.baseId)?.enabled) throw new StudioError(403, 'KNOWLEDGE_DISABLED', '这个知识库已关闭 AI 使用');
      const { text: body } = await this.docText(id, MAX_TEXT, { forAi });
      const tree = outline(body, doc.name);
      const view = node => ({ id: node.id, title: node.title, startLine: node.startLine, endLine: node.endLine, nodes: node.nodes.map(view) });
      return { docId: id, name: doc.name, nodes: tree.nodes.map(view), totalLines: tree.lines.length };
    },
    async section(id, nodeId, options = {}) {
      await this.tree(id, options); // Same enabled-base boundary for tree and content.
      const { doc, text: body } = await this.docText(id, MAX_TEXT, options), tree = outline(body, doc.name);
      const node = tree.flat.find(item => item.id === nodeId);
      if (!node) throw new StudioError(404, 'MISSING', '章节已变化，请重新读取目录');
      const content = tree.lines.slice(node.startLine - 1, node.endLine).join('\n');
      return { docId: id, nodeId, name: doc.name, path: node.path, startLine: node.startLine, endLine: node.endLine, text: content.slice(0, 20000), truncated: content.length > 20000 };
    },
    async search(query, { bases = null, limit = 6, forAi = false } = {}) {
      if (!String(query ?? "").trim()) return [];
      const data = await read();
      const chosen = data.bases.filter((base) => (bases ? bases.includes(base.id) : true) && (!forAi || base.enabled));
      const names = new Map(data.docs.map((doc) => [doc.id, doc.name]));
      limit = Number.isInteger(limit) ? Math.min(30, Math.max(1, limit)) : 6;
      const keywordLists = [], sectionLists = [];
      for (const base of chosen) {
        const built = await loadIndex(base.id);
        if (!built) continue;
        const enrich = hit => ({ ...hit, baseId: base.id, baseName: base.name, docName: names.get(hit.doc), citation: { docId: hit.doc, nodeId: hit.nodeId || null, startLine: hit.startLine || null, endLine: hit.endLine || null } });
        keywordLists.push(rank(built, query, limit * 3).filter(hit => names.has(hit.doc)).map(enrich));
        const titleIndex = buildIndex(built.chunks.map(chunk => ({ ...chunk, text: `${names.get(chunk.doc) || ''} ${(chunk.sectionPath || []).join(' ')}` })));
        sectionLists.push(rank(titleIndex, query, limit * 3).filter(hit => names.has(hit.doc)).map(hit => enrich({ ...built.chunks.find(c => c.doc === hit.doc && c.n === hit.n), score: hit.score })));
      }
      const sectionPresent = sectionLists.some(list => list.length);
      return fuseRetrieval([{ name: 'full-text', weight: 0.8, lists: keywordLists }, ...(sectionPresent ? [{ name: 'section-tree', weight: 0.2, lists: sectionLists }] : [])]).slice(0, limit);
    },
  };
}
