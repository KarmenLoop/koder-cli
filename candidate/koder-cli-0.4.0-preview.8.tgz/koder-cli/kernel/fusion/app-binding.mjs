import {createHash} from 'node:crypto';
export function appDigest(value) {
 const stable=v=>Array.isArray(v)?v.map(stable):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):v;
 return createHash('sha256').update(JSON.stringify(stable(value))).digest('hex');
}
export function appTask(value) {
 if(!value||['threadId','callId','attemptId'].some(key=>typeof value[key]!=='string'||!value[key]||value[key].length>160))throw Object.assign(new Error('应用操作缺少当前任务身份'),{code:'APP_TASK_INVALID',status:400});
 const task=Object.fromEntries(['threadId','callId','attemptId'].map(key=>[key,value[key]]));
 if(value.actor) {
  task.actor={};
  for(const key of ['platform','chatId','actorId','bindingId']){const field=value.actor[key];if(field!==undefined){if(typeof field!=='string'||field.length>300)throw Object.assign(new Error('渠道身份无效'),{code:'APP_TASK_INVALID',status:400});task.actor[key]=field;}}
 }
 return task;
}
