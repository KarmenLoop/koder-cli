// Only task-specific headings determine the initial recommendation. Collection
// labels such as "Codex Skills" and generic compliance footers are not a job.
export function importedSkillRoles(parsed) {
 const heading=parsed.body?.match(/^#\s+(.+)$/m)?.[1]||'';
 const topic=`${parsed.name} ${heading}`.toLowerCase();
 if(/1688|ali1688|京东|jd-|快手|kuaishou|拼多多|pdd-|闲鱼|xianyu|抖音|douyin|tiktok|电商|commerce|短视频|content-creator/.test(topic))return ['operations'];
 if(/法律|合同|诉讼|律师|legal|lawyer|law-verifier|contract/.test(topic))return ['legal'];
 if(/招聘|人力|入职|绩效|human-resource|recruit|hr-/.test(topic))return ['hr'];
 if(/小说|写作|文案|写稿|蒸书|writing|writer|novel|book-skill/.test(topic))return ['writer'];
 if(/股票|股价|交易|投资|金融|stock|finance|trading|chanlun/.test(topic))return ['custom'];
 if(/cad|制图|编程|开发|调试|代码|coding|debug|code-review/.test(topic))return ['engineer'];
 if(/项目|计划|协作|project|plan/.test(topic))return ['coordinator'];
 const detail=String(parsed.description||'').toLowerCase();
 if(/legal|合同|法律/.test(detail))return ['legal'];
 if(/writing|文案|写作/.test(detail))return ['writer'];
 if(/marketing|sales|运营|采购/.test(detail))return ['operations'];
 return ['custom'];
}
