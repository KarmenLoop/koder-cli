const REGISTRY = 'https://registry.modelcontextprotocol.io';
export async function boundedJson(response, maxBytes = 2 * 1024 * 1024) {
  if (!response.ok) throw new Error(`MCP 目录请求失败：HTTP ${response.status}`);
  const reader = response.body.getReader(); let size = 0; const chunks = [];
  try { for (;;) { const { done, value } = await reader.read(); if (done) break; size += value.byteLength; if (size > maxBytes) throw new Error('MCP 目录响应过大'); chunks.push(value); } }
  finally { await reader.cancel().catch(() => {}); }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}
export function createMcpRegistry({ fetchImpl = fetch } = {}) {
  async function read(path, { signal } = {}) {
    const response = await fetchImpl(`${REGISTRY}${path}`, { redirect: 'error', signal: AbortSignal.any([AbortSignal.timeout(20_000), ...(signal ? [signal] : [])]), headers: { accept: 'application/json' } });
    if (response.redirected) throw new Error('MCP 目录拒绝重定向');
    return boundedJson(response);
  }
  return {
    async search({ query = '', cursor = '', limit = 20, signal } = {}) {
      const params = new URLSearchParams({ search: String(query).slice(0, 200), version: 'latest', limit: String(Math.min(50, Math.max(1, Number(limit) || 20))) });
      if (cursor) params.set('cursor', String(cursor).slice(0, 1000));
      const result = await read(`/v0.1/servers?${params}`, { signal });
      if (!Array.isArray(result.servers)) throw new Error('MCP 目录格式不正确');
      return { servers: result.servers, nextCursor: result.metadata?.nextCursor || '', source: REGISTRY };
    },
    async details({ name, version = 'latest', signal } = {}) {
      if (typeof name !== 'string' || !name || name.length > 300) throw new Error('MCP 目录名称不合法');
      const result = await read(`/v0.1/servers/${encodeURIComponent(name)}/versions/${encodeURIComponent(version)}`, { signal });
      if (!result.server || result.server.name !== name) throw new Error('MCP 目录条目不匹配');
      return result;
    },
  };
}
