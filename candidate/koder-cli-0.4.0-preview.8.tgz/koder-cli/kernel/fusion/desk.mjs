// Four kinds of notes, kept apart. Markdown is the note. Git keeps the history
// when git is available. Search uses the words you add as aliases.
import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";

export const KINDS = ["evidence", "knowledge", "task", "context"];
const KIND_NAME = { evidence: "原始依据", knowledge: "长期知识", task: "任务状态", context: "当前上下文" };

const slug = (value) => String(value ?? "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "").slice(0, 40) || "note";

function front(note) {
  return [
    "---",
    `kind: ${note.kind}`,
    `title: ${note.title}`,
    `aliases: ${(note.aliases || []).join(", ")}`,
    `source: ${note.source || ""}`,
    `status: ${note.status || ""}`,
    `next: ${note.next || ""}`,
    "---",
    "",
    note.body || "",
    "",
  ].join("\n");
}

export function safeNoteFile(file) {
  const rel = String(file || "").replace(/\\/g, "/").replace(/^\/+/, "");
  const parts = rel.split("/");
  if (parts.length !== 2) return "";
  const [kind, name] = parts;
  if (!KINDS.includes(kind) || !name || name.includes("..") || !name.endsWith(".md") || name.length > 80) return "";
  return `${kind}/${name}`;
}

export function parseNote(text, file = "") {
  const raw = String(text ?? "");
  const matched = /^---\n([\s\S]*?)\n---\n([\s\S]*)$/.exec(raw);
  const meta = {};
  const body = matched ? matched[2].trim() : raw.trim();
  if (matched) {
    for (const line of matched[1].split("\n")) {
      const cut = line.indexOf(":");
      if (cut > 0) meta[line.slice(0, cut).trim()] = line.slice(cut + 1).trim();
    }
  }
  return {
    file,
    kind: KINDS.includes(meta.kind) ? meta.kind : "knowledge",
    title: meta.title || path.basename(file, ".md"),
    aliases: String(meta.aliases || "").split(/[,，]/).map((item) => item.trim()).filter(Boolean),
    source: meta.source || "",
    status: meta.status || "",
    next: meta.next || "",
    body,
  };
}

async function git(dir, args) {
  await new Promise((resolve, reject) => {
    execFile("git", ["-C", dir, "-c", "user.name=Koder", "-c", "user.email=koder@localhost", ...args], { timeout: 15_000 }, (error) => (error ? reject(error) : resolve()));
  });
}

export function createDesk({ dir, storage = null }) {
  const read = async file => storage ? (await storage.readBytes(file)).toString('utf8') : fs.readFile(file, 'utf8');
  const write = (file, text) => storage ? storage.writeBytes(file, Buffer.from(text)) : fs.writeFile(file, text);
  const remove = file => storage ? storage.remove(file) : fs.rm(file, {force:true});
  const stat = file => storage ? storage.stat(file) : fs.stat(file);
  const names = folder => storage ? storage.list(folder) : fs.readdir(folder);
  let initializing;
  async function migratePrivate() {
    async function sealTree(folder,{notes=false}={}) {
      let entries;try{entries=await fs.readdir(folder,{withFileTypes:true});}catch(error){if(error.code==='ENOENT')return;throw error;}
      for(const entry of entries) {
        if(entry.isSymbolicLink())throw Object.assign(new Error('私人笔记与历史目录不能包含符号链接'),{code:'BAD_PATH'});
        const file=path.join(folder,entry.name);
        if(entry.isDirectory()) {if(!notes)await sealTree(file);}
        else if(entry.isFile()&&(!notes||entry.name.endsWith('.md')))await storage.readBytes(file);
      }
    }
    // This is Koder's old note repository, never the user's project repository.
    // Private storage verifies a sealed backup before replacing each original;
    // no Git command is run on the encrypted history.
    await sealTree(path.join(dir,'.git'));
    for(const kind of KINDS)await sealTree(path.join(dir,kind),{notes:true});
  }
  async function ensure() {
    if(storage) {
      initializing ||= migratePrivate().catch(error=>{initializing=null;throw error;});
      return initializing;
    }
    for (const kind of KINDS) await fs.mkdir(path.join(dir, kind), { recursive: true });
    const mark = path.join(dir, ".git");
    if (!await fs.stat(mark).then(() => true, () => false)) await git(dir, ["init"]).catch(() => {});
  }

  async function commit(message) {
    if(storage)return;
    await git(dir, ["add", "-A"]).catch(() => {});
    await git(dir, ["commit", "-m", message]).catch(() => {});
  }

  return {
    initialize: ensure,
    async write({ kind = "knowledge", title, body = "", aliases = [], source = "", status = "", next = "" }) {
      if (!KINDS.includes(kind)) throw Object.assign(new Error("笔记只分成依据、知识、任务和上下文"), { code: "KIND" });
      const name = String(title || "").trim().slice(0, 80);
      if (!name) throw Object.assign(new Error("笔记要有标题"), { code: "EMPTY" });
      await ensure();
      const note = {
        kind,
        title: name,
        body: String(body).slice(0, 8000),
        aliases: (Array.isArray(aliases) ? aliases : String(aliases).split(/[,，]/)).map((item) => String(item).trim()).filter(Boolean).slice(0, 12),
        source: String(source).slice(0, 200),
        status: String(status).slice(0, 40),
        next: String(next).slice(0, 200),
      };
      const file = path.join(dir, kind, `${slug(name)}.md`);
      await write(file, front(note));
      await commit(`${KIND_NAME[kind]}：${name}`);
      return { ...note, file: `${kind}/${slug(name)}.md` };
    },
    async list(kind) {
      await ensure();
      const kinds = kind ? [kind] : KINDS;
      const notes = [];
      for (const item of kinds) {
        const folder = path.join(dir, item);
        for (const name of await names(folder).catch(error=>{if(error.code==="ENOENT")return [];throw error;})) {
          if (!name.endsWith(".md")) continue;
          const full = path.join(folder, name);
          const info = await stat(full);
          notes.push({ ...parseNote(await read(full), path.join(item, name)), updatedAt: info?.mtimeMs || 0 });
        }
      }
      return notes.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    },
    async revise(input) {
      const rel = safeNoteFile(input?.file);
      if (!rel) throw Object.assign(new Error("没有这条笔记"), { code: "MISSING" });
      await ensure();
      const full = path.join(dir, rel);
      const existing = parseNote(await read(full).catch(error => { if(error.code!=="ENOENT")throw error;throw Object.assign(new Error("没有这条笔记"), { code: "MISSING" }); }), rel);
      const kind = KINDS.includes(input.kind) ? input.kind : existing.kind;
      const title = String(input.title ?? existing.title).trim().slice(0, 80);
      if (!title) throw Object.assign(new Error("笔记要有标题"), { code: "EMPTY" });
      const note = {
        kind,
        title,
        body: String(input.body ?? existing.body).slice(0, 8000),
        aliases: (Array.isArray(input.aliases) ? input.aliases : String(input.aliases ?? existing.aliases.join(",")).split(/[,，]/)).map((item) => String(item).trim()).filter(Boolean).slice(0, 12),
        source: input.source !== undefined ? String(input.source).slice(0, 200) : existing.source,
        status: input.status !== undefined ? String(input.status).slice(0, 40) : existing.status,
        next: input.next !== undefined ? String(input.next).slice(0, 200) : existing.next,
      };
      const nextRel = `${kind}/${slug(title)}.md`;
      await write(path.join(dir, nextRel), front(note));
      if (nextRel !== rel) await remove(full);
      await commit(`${KIND_NAME[kind]}：${title}`);
      const info = await stat(path.join(dir, nextRel));
      return { ...note, file: nextRel, updatedAt: info.mtimeMs };
    },
    async remove(file) {
      const rel = safeNoteFile(file);
      if (!rel) throw Object.assign(new Error("没有这条笔记"), { code: "MISSING" });
      await remove(path.join(dir, rel));
      await commit(`删除：${rel}`);
    },
    async search(query) {
      const words = String(query ?? "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((item) => item.length > 1);
      if (!words.length) return [];
      const notes = await this.list();
      return notes.map((note) => {
        const hay = `${note.title}\n${note.body}\n${note.aliases.join(" ")}\n${note.status}\n${note.next}`.toLowerCase();
        const score = words.reduce((sum, word) => sum + (hay.includes(word) || note.aliases.some((alias) => alias.toLowerCase().includes(word)) ? 1 : 0), 0);
        return { ...note, score };
      }).filter((note) => note.score > 0).sort((a, b) => b.score - a.score).slice(0, 12);
    },
    async brief() {
      const notes = await this.list("knowledge");
      if (!notes.length) return "";
      return `用户背景（只要这一小段；细节用笔记去查）：\n${notes.slice(0, 6).map((note) => `- ${note.title}：${note.body.split("\n")[0].slice(0, 80)}`).join("\n")}`;
    },
  };
}

export function planReady(people = []) {
  const missing = people.filter((person) => !person?.time || !person?.budget).map((person) => person?.name || "未命名");
  if (!people.length || missing.length) return { ok: false, missing };
  return {
    ok: true,
    conditions: people.map((person) => `${person.name}：时间 ${person.time}，预算 ${person.budget}`),
  };
}

// A check on a timer is not a reminder. No change: write it down and wait.
// A change reminds only when it matches the rule the person wrote.
export const WATCH_MS = 12 * 60 * 60 * 1000;

export function judgeWatch({ previous = "", current = "", interesting = true, rule = "" } = {}) {
  const record = String(current);
  if (String(previous) === record) return { changed: false, remind: false, record };
  const matches = !String(rule) || record.includes(String(rule));
  return { changed: true, remind: Boolean(interesting) && matches, record };
}

export function tickWatch(watch, now = Date.now()) {
  const every = Number(watch?.everyMs) > 0 ? Number(watch.everyMs) : WATCH_MS;
  if (watch?.lastCheck && now - watch.lastCheck < every) return { due: false, remind: false, changed: false, watch };
  const judged = judgeWatch({
    previous: watch?.previous ?? "",
    current: watch?.current ?? "",
    interesting: watch?.interesting !== false,
    rule: watch?.rule || "",
  });
  const next = {
    ...watch,
    lastCheck: now,
    previous: judged.record,
    lastResult: judged.changed ? (judged.remind ? "有变化，已提醒" : "有变化，但不在要提醒的范围内") : "没有变化，先记下，不提醒",
  };
  return { due: true, remind: judged.remind, changed: judged.changed, watch: next };
}

export function applyWatches(watches, now = Date.now()) {
  const next = [];
  const reminded = [];
  for (const watch of watches || []) {
    const result = tickWatch(watch, now);
    const item = result.watch || watch;
    next.push(item);
    if (result.remind) reminded.push(item);
  }
  return { watches: next, reminded };
}
