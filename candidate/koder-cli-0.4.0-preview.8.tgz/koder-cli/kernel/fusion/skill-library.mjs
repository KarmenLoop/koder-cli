import fs from "node:fs/promises";
import path from "node:path";
import { skillTopicIds, skillTopicQuery } from "./skill-topics.mjs";
import { createHash, randomUUID } from "node:crypto";
import { parseSkillFile, skillRecord } from "./skills.mjs";
import { writeFileJson } from "../loop/json-store.mjs";

const DAY = 86400000;
const digest = (bytes, algorithm = "sha256") => createHash(algorithm).update(bytes).digest("hex");
const blobHash = (bytes) => createHash("sha1").update(`blob ${bytes.length}\0`).update(bytes).digest("hex");
const fail = (code, message, extra = {}) => Object.assign(new Error(message), { code, ...extra });
const sha = (value) => typeof value === "string" && /^[a-f0-9]{40}$/.test(value);
const repoName = (value) => typeof value === "string" && /^[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+$/.test(value);
const iso = (stamp) => new Date(stamp).toISOString();
const clone = (value) => structuredClone(value);
const exists = async (file) => { try { return await fs.lstat(file); } catch (error) { if (error.code === "ENOENT") return null; throw error; } };

function safePath(value) {
  if (typeof value !== "string" || !value || value.length > 2048 || /[\\\0-\x1f:]/.test(value) || value.startsWith("/") || value.split("/").some((part) => !part || part === "." || part === ".." || /[. ]$/.test(part))) {
    throw fail("UNSAFE_PATH", "技能包含不安全的资源路径");
  }
  return value;
}
function publicItem(item, state) {
  const { resources, body, when, ...rest } = item;
  return { ...rest, downloaded: Boolean(state.downloads[item.id]?.[item.ref]), installed: Boolean(state.installed[item.id]), installedRef: state.installed[item.id]?.ref || null };
}
function errorRecord(error, stamp) {
  return { code: error.code || error.name || "ERROR", message: error.message, at: stamp, ...(error.status ? { status: error.status } : {}), ...(error.retryAt ? { retryAt: error.retryAt, retryAfter: error.retryAt, retryAfterMs: error.retryAfterMs } : {}) };
}

// Public repositories only. Every downloaded byte is pinned to a verified commit
// and git blob, and is stored as inert data; this module never runs skill code.
export function createSkillLibrary(options = {}) {
  const { dir, fetchImpl = globalThis.fetch, now = Date.now } = options;
  if (!dir || typeof fetchImpl !== "function") throw new TypeError("Skill library requires dir and fetchImpl");
  const root = path.resolve(dir);
  const limit = (key, fallback, cap = fallback) => Math.max(1, Math.min(cap, Number(options[key]) || fallback));
  const limits = {
    repos: limit("maxRepositories", 12, 20), skills: limit("maxSkillsPerRepository", 2, 8),
    core: limit("maxCoreRequests", 40, 40), search: limit("maxSearchRequests", 3, 3), requests: limit("maxRequests", 80, 128),
    time: limit("timeoutMs", 90000, 120000), response: limit("maxResponseBytes", 4 * 1024 * 1024, 8 * 1024 * 1024),
    files: limit("maxFiles", 64, 128), file: limit("maxFileBytes", 1024 * 1024, 4 * 1024 * 1024),
    package: limit("maxPackageBytes", 8 * 1024 * 1024, 32 * 1024 * 1024), skill: limit("maxSkillBytes", 256 * 1024, 256 * 1024),
  };
  const catalogFile = path.join(root, "catalog.json");
  let state = null;
  let loading = null;
  let tail = Promise.resolve();
  const queue = (fn) => {
    const promise = tail.then(fn);
    tail = promise.then(() => {}, () => {});
    return promise;
  };
  async function load() {
    if (state) return;
    if (!loading) loading = (async () => {
      let stored;
      try { stored = JSON.parse(await fs.readFile(catalogFile, "utf8")); }
      catch (error) { if (error.code !== "ENOENT") throw error; }
      if (stored && (stored.schemaVersion !== 1 || !Array.isArray(stored.items))) throw fail("CATALOG", "技能库索引格式无效");
      state = { schemaVersion: 1, items: [], downloads: {}, installed: {}, repositoryCursor: 0, skillCursors: {}, lastFetched: null, lastAttempt: null, error: null, retryAfter: null, warnings: [], partial: false, ...stored };
    })();
    try { await loading; } finally { loading = null; }
  }

  async function save(next) {
    await writeFileJson(catalogFile, next);
    state = next;
  }
  function view({ sort = "newest", query = "", limit: count = 100 } = {}) {
    const term = String(query).toLocaleLowerCase().slice(0, 200);
    const items = state.items.filter((item) => !term || `${item.name}\n${item.description}\n${item.repository}`.toLocaleLowerCase().includes(term));
    items.sort((a, b) => (sort === "stars" ? b.stars - a.stars : sort === "hot" ? Number(b.hotBasis === "star-growth-per-day") - Number(a.hotBasis === "star-growth-per-day") || b.hotScore - a.hotScore : Date.parse(b.createdAt) - Date.parse(a.createdAt)) || a.id.localeCompare(b.id));
    return { items: items.slice(0, Math.max(1, Math.min(5000, Number(count) || 2000))).map((item) => publicItem(item, state)), lastFetched: state.lastFetched, lastAttempt: state.lastAttempt, error: clone(state.error), retryAfter: state.retryAfter, retryAt: state.retryAfter, warnings: clone(state.warnings), partial: state.partial, total: state.items.length };
  }
  function transport(signal) {
    const timeout = new AbortController();
    const timer = setTimeout(() => timeout.abort(fail("TIMEOUT", "技能库请求超过时间预算")), limits.time);
    const combined = signal ? AbortSignal.any([signal, timeout.signal]) : timeout.signal;
    let total = 0, core = 0, search = 0;
    function check() { combined.throwIfAborted(); }
    function aborted(promise) {
      check();
      return new Promise((resolve, reject) => {
        const stop = () => reject(combined.reason);
        combined.addEventListener("abort", stop, { once: true });
        promise.then(resolve, reject).finally(() => combined.removeEventListener("abort", stop));
      });
    }
    return {
      close() { clearTimeout(timer); }, check,
      canCore(count = 1) { return core + count <= limits.core && total + count <= limits.requests; },
      async get(url, bytesLimit = limits.response) {
        check();
        const target = new URL(url);
        if (target.protocol !== "https:" || !["api.github.com", "raw.githubusercontent.com"].includes(target.hostname) || target.username || target.password || target.port || target.hash) throw fail("HOST", "不允许访问此技能下载来源");
        const isSearch = target.hostname === "api.github.com" && target.pathname === "/search/repositories";
        const isCore = target.hostname === "api.github.com" && !isSearch;
        if (++total > limits.requests || (isSearch && ++search > limits.search) || (isCore && ++core > limits.core)) throw fail("BUDGET", "技能库本轮请求预算已用尽");
        const response = await aborted(Promise.resolve().then(() => fetchImpl(url, { signal: combined, redirect: "manual", headers: { Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "Koder-Skill-Library" } })));
        if (response.status >= 300 && response.status < 400) { await response.body?.cancel(); throw fail("REDIRECT", "技能来源返回重定向，已停止下载"); }
        if (response.url && new URL(response.url).origin !== target.origin) { await response.body?.cancel(); throw fail("HOST", "技能来源响应跨域"); }
        if (response.status === 403 || response.status === 429) {
          const stamp = Number(now());
          const retry = response.headers.get("retry-after");
          const reset = Number(response.headers.get("x-ratelimit-reset")) * 1000;
          const retryAt = Math.max(stamp + 1000, retry ? (/^\d+(\.\d+)?$/.test(retry) ? stamp + Number(retry) * 1000 : Date.parse(retry)) || stamp + 60000 : reset > stamp ? reset : stamp + 60000);
          await response.body?.cancel();
          throw fail("RATE_LIMIT", "GitHub 请求限流，请稍后重试", { status: response.status, retryAt, retryAfter: retryAt, retryAfterMs: retryAt - stamp });
        }
        if (!response.ok) { await response.body?.cancel(); throw fail("HTTP", `GitHub 返回 HTTP ${response.status}`, { status: response.status }); }
        const maximum = Math.min(bytesLimit, limits.response);
        if (Number(response.headers.get("content-length")) > maximum) { await response.body?.cancel(); throw fail("RESPONSE_SIZE", "技能来源响应超过容量限制"); }
        const reader = response.body?.getReader();
        if (!reader) return Buffer.alloc(0);
        const chunks = []; let length = 0;
        try {
          while (true) {
            const { value, done } = await aborted(reader.read());
            if (done) break;
            length += value.byteLength;
            if (length > maximum) throw fail("RESPONSE_SIZE", "技能来源响应超过容量限制");
            chunks.push(Buffer.from(value));
          }
        } catch (error) { await reader.cancel().catch(() => {}); throw error; }
        finally { reader.releaseLock(); }
        return Buffer.concat(chunks, length);
      },
      async json(url) { return JSON.parse((await this.get(url)).toString("utf8")); },
    };
  }
  const rawURL = (repository, ref, sourcePath) => `https://raw.githubusercontent.com/${repository}/${ref}/${sourcePath.split("/").map(encodeURIComponent).join("/")}`;
  function resourcesFor(entries, sourcePath) {
    safePath(sourcePath);
    const folder = path.posix.dirname(sourcePath);
    const prefix = folder === "." ? "" : `${folder}/`;
    const found = [];
    let total = 0;
    for (const entry of entries) {
      if (!entry.path.startsWith(prefix)) continue;
      safePath(entry.path);
      if (entry.type === "tree" && entry.mode === "040000") continue;
      if (entry.type !== "blob" || !["100644", "100755"].includes(entry.mode) || !sha(entry.sha)) throw fail("UNSAFE_RESOURCE", "技能目录包含链接、子模块或不支持的资源");
      const relative = safePath(entry.path.slice(prefix.length));
      if (!Number.isSafeInteger(entry.size) || entry.size < 0 || entry.size > limits.file) throw fail("PACKAGE_SIZE", "技能资源文件超过容量限制");
      total += entry.size;
      if (found.length >= limits.files || total > limits.package) throw fail("PACKAGE_SIZE", "技能完整资源包超过容量限制");
      found.push({ path: relative, sourcePath: entry.path, gitSha: entry.sha, size: entry.size, mode: entry.mode });
    }
    if (!found.some((entry) => entry.sourcePath === sourcePath)) throw fail("SKILL_MISSING", "缺少真实 SKILL.md");
    const folded = found.map((entry) => entry.path.toLocaleLowerCase());
    if (new Set(folded).size !== found.length) throw fail("UNSAFE_PATH", "技能资源名称存在文件系统冲突");
    return found.sort((a, b) => a.path.localeCompare(b.path));
  }
  async function refresh({ signal, topic = "" } = {}) {
    return queue(async () => {
      await load();
      const io = transport(signal);
      const stamp = Number(now());
      const warnings = [];
      const focus = skillTopicQuery(topic) ? topic : "";
      try {
        io.check();
        const baseQuery = '"SKILL.md" in:readme archived:false fork:false';
        const focused = skillTopicQuery(focus);
        const searches = focused
          ? [[`${baseQuery} ${focused}`, "updated"], [`${baseQuery} ${focused}`, "stars"], [baseQuery, "stars"]]
          : [
            [baseQuery, "stars"],
            [`${baseQuery} pushed:>=${iso(stamp - 30 * DAY).slice(0, 10)}`, "updated"],
            [`${baseQuery} created:>=${iso(stamp - 90 * DAY).slice(0, 10)}`, "updated"],
          ];
        const groups = [];
        for (const [q, sort] of searches.slice(0, limits.search)) {
          const params = new URLSearchParams({ q, sort, order: "desc", per_page: "20" });
          const result = await io.json(`https://api.github.com/search/repositories?${params}`);
          groups.push(Array.isArray(result.items) ? result.items.slice(0, 20) : []);
        }
        const candidates = [], seen = new Set();
        for (let i = 0; i < 20; i++) for (const group of groups) {
          const repo = group[i];
          if (repoName(repo?.full_name) && !seen.has(repo.full_name) && candidates.length < 20) { seen.add(repo.full_name); candidates.push(repo); }
        }
        const offset = state.repositoryCursor % Math.max(1, candidates.length);
        const rotation = [...candidates.slice(offset), ...candidates.slice(0, offset)].slice(0, limits.repos);
        const nextItems = new Map(state.items.map((item) => [item.id, item]));
        const skillCursors = { ...state.skillCursors };
        let scanned = 0, partial = false;
        for (const repo of rotation) {
          io.check();
          if (!io.canCore(2)) { partial = true; break; }
          scanned++;
          try {
            const head = await io.json(`https://api.github.com/repos/${repo.full_name}/commits/${encodeURIComponent(repo.default_branch || "HEAD")}`);
            const ref = head.sha, treeSHA = head.commit?.tree?.sha;
            if (!sha(ref) || !sha(treeSHA)) throw fail("REF", "GitHub 没有返回固定提交与树标识");
            const tree = await io.json(`https://api.github.com/repos/${repo.full_name}/git/trees/${treeSHA}?recursive=1`);
            if (tree.truncated || tree.sha !== treeSHA || !Array.isArray(tree.tree)) throw fail("TREE", "仓库文件树不完整，无法验证完整技能包");
            const allSkillFiles = tree.tree.filter((entry) => typeof entry.path === "string" && path.posix.basename(entry.path) === "SKILL.md");
            const skillOffset = (skillCursors[repo.full_name] || 0) % Math.max(1, allSkillFiles.length);
            const skillFiles = [...allSkillFiles.slice(skillOffset), ...allSkillFiles.slice(0, skillOffset)].slice(0, limits.skills);
            // Save this cursor only when the whole refresh is committed; rate-limit
            // failure retains both the previous catalog and the previous position.
            skillCursors[repo.full_name] = (skillOffset + skillFiles.length) % Math.max(1, allSkillFiles.length);
            for (const entry of skillFiles) {
              try {
                const resources = resourcesFor(tree.tree, entry.path);
                const skillFile = resources.find((file) => file.sourcePath === entry.path);
                if (skillFile.size > limits.skill) throw fail("SKILL_SIZE", "SKILL.md 超过容量限制");
                const bytes = await io.get(rawURL(repo.full_name, ref, entry.path), limits.skill);
                if (blobHash(bytes) !== skillFile.gitSha || bytes.length !== skillFile.size) throw fail("HASH_MISMATCH", "技能内容与固定提交不一致");
                const parsed = parseSkillFile(new TextDecoder("utf-8", { fatal: true }).decode(bytes), path.posix.basename(path.posix.dirname(entry.path)));
                const id = `github:${digest(`${repo.full_name}\0${entry.path}`).slice(0, 24)}`;
                const previous = state.items.find((item) => item.id === id);
                const stars = Math.max(0, Number(repo.stargazers_count) || 0);
                const windowMs = previous ? stamp - Date.parse(previous.lastFetched) : 0;
                const hasHistory = windowMs > 0;
                nextItems.set(id, {
                  id, name: parsed.name, description: parsed.description, when: parsed.when, body: parsed.body,
                  repository: repo.full_name, url: `https://github.com/${repo.full_name}/blob/${ref}/${entry.path.split("/").map(encodeURIComponent).join("/")}`,
                  sourcePath: entry.path, ref, treeSHA, resources, stars, starScope: "repository",
                  previousStars: hasHistory ? previous.stars : null, starDelta: hasHistory ? stars - previous.stars : null, deltaWindowMs: hasHistory ? windowMs : null,
                  hotScore: hasHistory ? (stars - previous.stars) * DAY / windowMs : stars,
                  hotBasis: hasHistory ? "star-growth-per-day" : "repository-stars-no-history",
                  hotBasisLabel: hasHistory ? "仓库 Star 日均增长（两次采样）" : "待下次采样；按仓库 Star 排序",
                  createdAt: repo.created_at || iso(stamp), pushedAt: repo.pushed_at || null,
                  discoveredAt: previous?.discoveredAt || iso(stamp), lastFetched: iso(stamp), license: repo.license?.spdx_id || null,
                  topics: [...new Set([...(previous?.topics || []), ...(focus ? [focus] : []), ...skillTopicIds({ name: parsed.name, description: parsed.description, repository: repo.full_name, when: parsed.when })])],
                });
              } catch (error) {
                if (["RATE_LIMIT", "REDIRECT", "HOST", "RESPONSE_SIZE", "BUDGET", "TIMEOUT"].includes(error.code) || signal?.aborted) throw error;
                warnings.push({ repository: repo.full_name, sourcePath: entry.path, code: error.code || "INVALID_SKILL", message: error.message });
              }
            }
          } catch (error) {
            if (["RATE_LIMIT", "REDIRECT", "HOST", "RESPONSE_SIZE", "BUDGET", "TIMEOUT"].includes(error.code) || signal?.aborted) throw error;
            warnings.push({ repository: repo.full_name, code: error.code || "INVALID_REPOSITORY", message: error.message });
          }
        }
        io.check();
        const previousIds = new Set(state.items.map((item) => item.id));
        const values = [...nextItems.values()];
        const kept = values.filter((item) => previousIds.has(item.id));
        const added = values.filter((item) => !previousIds.has(item.id));
        const items = [...kept, ...added].slice(0, Math.max(kept.length, 5000));
        await save({ ...state, items, skillCursors, repositoryCursor: (offset + scanned) % Math.max(1, candidates.length), lastFetched: iso(stamp), lastAttempt: iso(stamp), error: null, retryAfter: null, warnings, partial });
        return view();
      } catch (error) {
        await save({ ...state, lastAttempt: iso(stamp), error: errorRecord(error, iso(stamp)), retryAfter: error.retryAt || null });
        throw error;
      } finally { io.close(); }
    });
  }
  function itemFor(id) {
    const item = state.items.find((candidate) => candidate.id === id);
    if (!item) throw fail("NOT_FOUND", "未找到此技能", { status: 404 });
    return item;
  }
  const keyFor = (id) => digest(id).slice(0, 32);
  async function packageAt(folder, item) {
    const stat = await exists(folder);
    if (!stat) return null;
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw fail("PACKAGE", "已存在的技能包目录无效");
    const manifestStat = await fs.lstat(path.join(folder, "manifest.json"));
    if (!manifestStat.isFile() || manifestStat.isSymbolicLink() || manifestStat.size > 1024 * 1024) throw fail("PACKAGE", "技能清单无效");
    const manifest = JSON.parse(await fs.readFile(path.join(folder, "manifest.json"), "utf8"));
    if (manifest.id !== item.id || manifest.ref !== item.ref || manifest.sourcePath !== item.sourcePath || !Array.isArray(manifest.files) || manifest.files.length > limits.files) throw fail("PACKAGE", "技能包清单与来源不一致");
    const fileRoot = path.join(folder, "files");
    const rootStat = await fs.lstat(fileRoot);
    if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw fail("PACKAGE", "技能包资源目录无效");
    let bytesTotal = 0;
    for (const file of manifest.files) {
      const relative = safePath(file.path);
      const parts = relative.split("/");
      for (let i = 1; i < parts.length; i++) {
        const parentStat = await fs.lstat(path.join(fileRoot, ...parts.slice(0, i)));
        if (!parentStat.isDirectory() || parentStat.isSymbolicLink()) throw fail("UNSAFE_PATH", "技能资源父目录无效");
      }
      const target = path.join(fileRoot, relative);
      const fileStat = await fs.lstat(target);
      if (!fileStat.isFile() || fileStat.isSymbolicLink() || fileStat.size > limits.file || (bytesTotal += fileStat.size) > limits.package) throw fail("PACKAGE", "技能包资源无效");
      const bytes = await fs.readFile(target);
      if (digest(bytes) !== file.sha256 || bytes.length !== file.size || blobHash(bytes) !== file.gitSha) throw fail("HASH_MISMATCH", "已下载的技能资源已改变");
    }
    const hash = digest(JSON.stringify(manifest.files.map(({ path, sha256 }) => [path, sha256])));
    if (hash !== manifest.hash) throw fail("HASH_MISMATCH", "技能包清单摘要不一致");
    return { path: fileRoot, manifest };
  }
  async function writeResource(folder, relative, bytes) {
    const target = path.join(folder, safePath(relative));
    await fs.mkdir(path.dirname(target), { recursive: true });
    const handle = await fs.open(target, "wx", 0o600);
    try { await handle.writeFile(bytes); await handle.sync(); } finally { await handle.close(); }
  }
  async function downloaded(item, io) {
    io.check();
    const folder = path.join(root, "downloads", `${keyFor(item.id)}-${item.ref}`);
    const cached = await packageAt(folder, item);
    if (cached) return { ...cached, alreadyDownloaded: true };
    const stage = `${folder}.stage-${randomUUID()}`;
    await fs.mkdir(path.dirname(folder), { recursive: true });
    await fs.mkdir(stage);
    try {
      const fileRoot = path.join(stage, "files");
      await fs.mkdir(fileRoot);
      const files = [];
      let total = 0, skillText;
      for (const file of item.resources) {
        io.check();
        const bytes = await io.get(rawURL(item.repository, item.ref, file.sourcePath), limits.file);
        if (bytes.length !== file.size || blobHash(bytes) !== file.gitSha) throw fail("HASH_MISMATCH", "下载的资源与固定提交不一致");
        total += bytes.length;
        if (total > limits.package) throw fail("PACKAGE_SIZE", "技能资源包超过容量限制");
        await writeResource(fileRoot, file.path, bytes);
        files.push({ ...file, sha256: digest(bytes) });
        if (file.sourcePath === item.sourcePath) skillText = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
      }
      const parsed = parseSkillFile(skillText, item.name);
      const manifest = { schemaVersion: 1, id: item.id, repository: item.repository, ref: item.ref, treeSHA: item.treeSHA, sourcePath: item.sourcePath, createdAt: iso(Number(now())), hash: digest(JSON.stringify(files.map(({ path, sha256 }) => [path, sha256]))), files, skill: { name: parsed.name, description: parsed.description, when: parsed.when, body: parsed.body, frontmatter: parsed.frontmatter } };
      await writeFileJson(path.join(stage, "manifest.json"), manifest);
      io.check();
      if (await exists(folder)) throw fail("PACKAGE_EXISTS", "下载目录已存在，未覆盖");
      await fs.rename(stage, folder);
      return { path: path.join(folder, "files"), manifest, alreadyDownloaded: false };
    } catch (error) { await fs.rm(stage, { recursive: true, force: true }); throw error; }
  }
  async function recordDownload(item, pack) {
    await save({ ...state, downloads: { ...state.downloads, [item.id]: { ...state.downloads[item.id], [item.ref]: { hash: pack.manifest.hash, at: pack.manifest.createdAt } } } });
  }
  async function download(id, { signal } = {}) {
    return queue(async () => {
      await load();
      const item = itemFor(id), io = transport(signal);
      try {
        const pack = await downloaded(item, io);
        await recordDownload(item, pack);
        return { item: publicItem(item, state), ...pack };
      } finally { io.close(); }
    });
  }
  async function install(id, { signal } = {}) {
    return queue(async () => {
      await load();
      const item = itemFor(id), io = transport(signal);
      try {
        io.check();
        const folder = path.join(root, "installed", keyFor(id));
        const old = state.installed[id];
        if (old) {
          await packageAt(folder, { ...item, ref: old.ref, sourcePath: old.sourcePath });
          return { item: publicItem(item, state), skill: clone(old), alreadyInstalled: true };
        }
        // Recover a completed rename if only the following catalog save failed.
        if (await exists(folder)) {
          const saved = JSON.parse(await fs.readFile(path.join(folder, "skill.json"), "utf8"));
          if (saved.id !== id || saved.installedPath !== path.join(folder, "files")) throw fail("PACKAGE_EXISTS", "安装目录已存在，未覆盖");
          await packageAt(folder, { ...item, ref: saved.ref, sourcePath: saved.sourcePath });
          await save({ ...state, installed: { ...state.installed, [id]: saved } });
          return { item: publicItem(item, state), skill: clone(saved), alreadyInstalled: true };
        }
        const pack = await downloaded(item, io);
        await recordDownload(item, pack);
        const stage = `${folder}.stage-${randomUUID()}`;
        await fs.mkdir(path.dirname(folder), { recursive: true });
        await fs.mkdir(stage);
        const skill = skillRecord({ ...pack.manifest.skill, id, source: "github", repository: item.repository, ref: item.ref, treeSHA: item.treeSHA, sourcePath: item.sourcePath, installedPath: path.join(folder, "files"), hash: pack.manifest.hash, resources: pack.manifest.files, license: item.license, url: item.url, installedAt: iso(Number(now())) }, "github");
        try {
          await fs.mkdir(path.join(stage, "files"));
          for (const file of pack.manifest.files) { io.check(); await writeResource(path.join(stage, "files"), file.path, await fs.readFile(path.join(pack.path, file.path))); }
          await writeFileJson(path.join(stage, "manifest.json"), pack.manifest);
          await writeFileJson(path.join(stage, "skill.json"), skill);
          io.check();
          if (await exists(folder)) throw fail("PACKAGE_EXISTS", "安装目录已存在，未覆盖");
          await fs.rename(stage, folder);
        } catch (error) { await fs.rm(stage, { recursive: true, force: true }); throw error; }
        await save({ ...state, installed: { ...state.installed, [id]: skill } });
        return { item: publicItem(item, state), skill: clone(skill), alreadyInstalled: false };
      } finally { io.close(); }
    });
  }
  return { list: async (filters) => { await load(); return view(filters); }, refresh, download, install };
}

// Kernel consumers must supply the configured library directory; the record
// cannot nominate an arbitrary filesystem root. Pages are UTF-8 character ranges.
export async function readInstalledResource(skill, relativePath = "SKILL.md", { dir, offset = 0, limit = 12000, maxFileBytes = 4 * 1024 * 1024 } = {}) {
  if (!dir || skill?.source !== "github" || typeof skill.id !== "string" || !sha(skill.ref) || !/^[a-f0-9]{64}$/.test(skill.hash || "")) throw fail("SKILL_RESOURCE", "技能安装来源无效");
  const relative = safePath(relativePath);
  const root = path.resolve(dir);
  const folder = path.join(root, "installed", digest(skill.id).slice(0, 32));
  const fileRoot = path.join(folder, "files");
  if (skill.installedPath !== fileRoot) throw fail("SKILL_RESOURCE", "技能资源不在配置的安装目录内");
  for (const parent of [root, path.join(root, "installed"), folder, fileRoot]) {
    const stat = await fs.lstat(parent);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw fail("UNSAFE_PATH", "技能安装目录包含链接或无效目录");
  }
  const manifestFile = path.join(folder, "manifest.json");
  const manifestStat = await fs.lstat(manifestFile);
  if (!manifestStat.isFile() || manifestStat.isSymbolicLink() || manifestStat.size > 1024 * 1024) throw fail("SKILL_RESOURCE", "技能安装清单无效");
  const manifest = JSON.parse(await fs.readFile(manifestFile, "utf8"));
  if (manifest.id !== skill.id || manifest.ref !== skill.ref || manifest.repository !== skill.repository || manifest.sourcePath !== skill.sourcePath || manifest.hash !== skill.hash || !Array.isArray(manifest.files) || manifest.files.length > 128) throw fail("SKILL_RESOURCE", "技能安装清单与记录不一致");
  if (digest(JSON.stringify(manifest.files.map(({ path, sha256 }) => [path, sha256]))) !== skill.hash) throw fail("HASH_MISMATCH", "技能资源清单摘要不一致");
  const resource = manifest.files.find((file) => file.path === relative);
  const savedResource = skill.resources?.find((file) => file.path === relative);
  if (!resource || !savedResource || resource.sha256 !== savedResource.sha256 || resource.gitSha !== savedResource.gitSha || resource.size !== savedResource.size) throw fail("SKILL_RESOURCE", "此资源不在技能固定安装清单内");
  const parts = relative.split("/");
  for (let i = 1; i < parts.length; i++) {
    const stat = await fs.lstat(path.join(fileRoot, ...parts.slice(0, i)));
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw fail("UNSAFE_PATH", "技能资源目录包含链接");
  }
  const file = path.join(fileRoot, relative);
  const stat = await fs.lstat(file);
  const cap = Math.max(1, Math.min(4 * 1024 * 1024, Number(maxFileBytes) || 4 * 1024 * 1024));
  if (!stat.isFile() || stat.isSymbolicLink() || stat.size > cap) throw fail("SKILL_RESOURCE", "技能资源文件无效或超过容量限制");
  const bytes = await fs.readFile(file);
  if (bytes.length !== resource.size || digest(bytes) !== resource.sha256 || blobHash(bytes) !== resource.gitSha) throw fail("HASH_MISMATCH", "技能资源已改变，不能作为固定来源读取");
  let text;
  try { text = new TextDecoder("utf-8", { fatal: true }).decode(bytes); }
  catch { throw fail("BINARY_RESOURCE", "此资源为二进制文件，请使用完整技能下载包"); }
  if (text.includes("\0")) throw fail("BINARY_RESOURCE", "此资源为二进制文件，请使用完整技能下载包");
  const start = Math.max(0, Math.floor(Number(offset) || 0));
  const length = Math.max(1, Math.min(32000, Math.floor(Number(limit) || 12000)));
  const content = text.slice(start, start + length);
  return { id: skill.id, path: relative, ref: skill.ref, sha256: resource.sha256, size: bytes.length, offset: start, nextOffset: start + content.length < text.length ? start + content.length : null, totalCharacters: text.length, content, text: content, truncated: start + content.length < text.length };
}

// Reuse the original skills bag and exclusive owner; no parallel installation index.
export {createSkillVersionStore} from './skill-maintenance.mjs';
