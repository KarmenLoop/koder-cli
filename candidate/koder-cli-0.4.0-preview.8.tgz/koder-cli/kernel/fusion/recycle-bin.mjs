// Recycle records use the existing authenticated private storage, one sealed
// journal per item. No process-local index is authoritative.
import path from 'node:path';
import crypto from 'node:crypto';
export const RETENTION_MS = 30 * 24 * 60 * 60 * 1000;
export const recycleError = (code, message, status = 409) => Object.assign(new Error(message), {code, status});
const ID = /^(?:thread-[A-Za-z0-9-]{1,80}|work-[a-f0-9-]{36}|library-[a-f0-9-]{36})$/;
export const recycleSummary = ({id,kind,title,deletedAt,expiresAt,source}) => ({id,kind,title,deletedAt,expiresAt,...(source ? {source} : {})});
export function createRecycleBin({dir,storage,now=Date.now}) {
 const home=path.join(dir,'recycle-bin');
 const file=id=>{if(!ID.test(id||''))throw recycleError('RECYCLE_ID','回收站项目无效',400);return path.join(home,`${id}.json`);};
 return {
  async get(id,{allowExpired=false}={}) {const item=await storage.readJson(file(id),null);if(!item)throw recycleError('RECYCLE_MISSING','回收站里没有这一项',404);if(item.id!==id||item.version!==1||!Number.isSafeInteger(item.deletedAt)||item.expiresAt!==item.deletedAt+RETENTION_MS)throw recycleError('RECYCLE_DAMAGED','回收站记录损坏');if(!allowExpired&&now()>=item.expiresAt)throw recycleError('RECYCLE_EXPIRED','这项已超过30天保留期',410);return item;},
  async has(id) {return (await storage.readJson(file(id),null))!==null;},
  async put({id,kind,title,payload,source}) {id ||= `${kind}-${crypto.randomUUID()}`;if(await this.has(id))throw recycleError('RECYCLE_EXISTS','这一项已在回收站');const deletedAt=now();const item={version:1,id,kind,title:String(title||'未命名').slice(0,160),deletedAt,expiresAt:deletedAt+RETENTION_MS,payload,...(source?{source}: {})};await storage.writeJson(file(id),item);return item;},
  async replace(item) {await storage.writeJson(file(item.id),item);},
  async remove(id) {await storage.remove(file(id));},
  async records() {const items=[];for(const name of await storage.list(home)){const id=name.endsWith('.json')?name.slice(0,-5):'';if(ID.test(id))items.push(await this.get(id,{allowExpired:true}));}return items.sort((a,b)=>b.deletedAt-a.deletedAt);},
  async sweep(purge) {let removed=0;for(const item of await this.records())if(now()>=item.expiresAt){await purge(item);removed++;}return {removed};},
  now,
 };
}
