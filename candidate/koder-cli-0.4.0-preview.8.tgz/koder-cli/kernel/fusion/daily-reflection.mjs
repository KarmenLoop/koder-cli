import crypto from 'node:crypto';
import {subjectKey} from './personalization-policy.mjs';
import {zonedDay,zonedParts,addDays} from './personalization-time.mjs';
import {estimateMessages} from './tokens.mjs';
export function reflectionDate(now,timezone){return addDays(zonedDay(now,timezone),Number(zonedParts(now,timezone).hour)>=2?-1:-2);}
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
export function createDailyReflection({subject,policy,automation,source,profile,model,owner,clock=Date.now}={}) {
 let stopped=false,last={state:'idle'},running=null;
 const current=()=>typeof subject==='function'?subject():subject;
 const enabled=async(snapshot)=>!stopped&&(await policy?.require('learning',snapshot)||await policy?.require('dailyState',snapshot)||await policy?.require('evolution',snapshot));
 async function ensureSchedule(){const snapshot=await policy?.status();if(!await enabled(snapshot))return null;if(!automation?.createReflection)return null;
  const s=current(),key=hash([s?.server,s?.tenantId,s?.accountId,s?.spaceId,s?.subjectId,s?.memoryEpoch]);return automation.createReflection({key,subject:s,timezone:snapshot.timezone});
 }
 async function perform({date,signal}={}){
  const snapshot=await policy?.status(),s=current(),key=subjectKey(s);if(!await enabled(snapshot))return last={state:'disabled'};
  const task=await ensureSchedule();if(!task)return last={state:'waiting-automation'};
  const lease=await owner?.acquire?.({taskId:task.id,purposeKey:task.action.subjectKey,subject:s});if(!lease)return last={state:'waiting-owner'};
  let progress,target,day;
  const commit=async()=>{await lease.requireCurrent();if(subjectKey(current())!==key||!await enabled(snapshot)||signal?.aborted)throw Object.assign(new Error('REFLECTION_REVOKED'),{code:'REFLECTION_REVOKED'});progress=await automation.updateReflection(task.id,progress.revision,progress);day=progress.days[target];};
  try{
   progress=await automation.readReflection(task.id);
   target=date||reflectionDate(clock(),snapshot.timezone);if(!/^\d{4}-\d{2}-\d{2}$/.test(target)||target>=zonedDay(clock(),snapshot.timezone))throw new Error('REFLECTION_DATE_INVALID');
   day=progress.days[target];if(day?.state==='complete'&&!day.dirty)return last={state:'complete',date:target,cursor:day.cursor,coverage:day.snapshot?.coverage};
   if(!day?.snapshot||day.dirty&&['complete','pending'].includes(day.state)){const previous=day?.snapshot,fixed=await source.snapshot({date:target,timezone:snapshot.timezone,sources:snapshot.sources,from:snapshot.from,subject:s});day=progress.days[target]={snapshot:fixed,cursor:{page:previous&&previous.policyRevision===fixed.policyRevision?previous.upperSeq:null,index:0,offset:0},state:'running'};await commit();}
   const budgetDay=zonedDay(clock(),snapshot.timezone),cap=Math.max(1,Math.min(24,snapshot.budget||4)),window=Math.max(2048,Math.min(1048576,Number(model?.contextWindow)||8192)),output=Math.min(1024,Number(model?.maxOutput)||512);
   for(;;){
    await lease.requireCurrent();if(!await enabled(snapshot)||signal?.aborted)return last={state:signal?.aborted?'cancelled':'revoked',date:target,cursor:day.cursor};
    let page;try{page=await source.readPage({snapshot:day.snapshot,cursor:day.cursor.page,date:target,subject:s,maxBytes:Math.min(262144,window)});}catch(error){
     if(error.code!=='HOST_SNAPSHOT_INVALID')throw error;
     day.snapshot=await source.snapshot({date:target,timezone:snapshot.timezone,sources:snapshot.sources,from:snapshot.from,subject:s});day.cursor={page:null,index:0,offset:0};day.state='pending';day.dirty=false;await commit();return last={state:'pending',reasonCode:'SOURCE_POLICY_CHANGED',date:target};
    }
    if(!Array.isArray(page?.items)||page.items.length>64||Buffer.byteLength(JSON.stringify(page))>1048576)throw new Error('REFLECTION_SOURCE_LIMIT');
    const sequenced=page.cursorMode==='server-sequence';
    if(sequenced){
     let after=day.cursor.page||0;for(const item of page.items){if(!Number.isSafeInteger(item.serverSeq)||item.serverSeq<=after||item.serverSeq>day.snapshot.upperSeq||typeof item.eventId!=='string')throw new Error('REFLECTION_SOURCE_INVALID');after=item.serverSeq;}
     // Tombstones can compact a page between reads. Persist the original Core
     // sequence, and bind a partial offset to its event rather than an array slot.
     if(day.cursor.index||day.cursor.offset&&day.cursor.eventId!==page.items[0]?.eventId){day.cursor={page:day.cursor.page,index:0,offset:0};await commit();}
    }
    if(day.cursor.index>=page.items.length){
     if(!page.hasMore){day.state=day.dirty?'pending':day.snapshot.missing?.length?'incomplete':'complete';await commit();return last={state:day.state,date:target,cursor:day.cursor,missing:day.snapshot.missing||[],coverage:day.snapshot.coverage};}
     if(page.nextCursor===day.cursor.page)throw new Error('REFLECTION_CURSOR_STALLED');day.cursor={page:page.nextCursor,index:0,offset:0};await commit();continue;
    }
    if((progress.budget[budgetDay]||0)>=cap){day.state='budget-exhausted';await commit();return last={state:'budget-exhausted',date:target,cursor:day.cursor};}
    const item=page.items[day.cursor.index];if(typeof item.text!=='string')throw new Error('REFLECTION_SOURCE_INVALID');
    const remaining=Array.from(item.text).slice(day.cursor.offset);let count=Math.min(remaining.length,window*2),messages,input;
    for(;;){input={...item,text:remaining.slice(0,count).join(''),part:{start:day.cursor.offset,end:day.cursor.offset+count,total:Array.from(item.text).length}};
     messages=[{role:'system',content:'Extract candidate user evidence from the supplied messages only. Distinguish explicit preferences, background, behavior, temporary wants and explicit daily state. Do not infer sensitive traits or execution authority. Return evidence with original source references; no hidden reasoning.'},{role:'user',content:JSON.stringify(input)}];
     if(estimateMessages(messages)+output<=window)break;if(count<=1)throw new Error('REFLECTION_MODEL_WINDOW_TOO_SMALL');count=Math.max(1,Math.floor(count/2));
    }
    progress.budget[budgetDay]=(progress.budget[budgetDay]||0)+1;await commit();
    const result=await model.extract({input,messages,maxOutput:output,subject:s,snapshot:day.snapshot,signal});
    await lease.requireCurrent();if(!await enabled(snapshot)||subjectKey(current())!==key||signal?.aborted)return last={state:signal?.aborted?'cancelled':'revoked',date:target,cursor:day.cursor};
    if(!Array.isArray(result?.evidence)||result.evidence.length>256)throw new Error('REFLECTION_RESULT_INVALID');
    const receipt=await lease.receipt?.({taskId:task.id,sourceSnapshot:day.snapshot,inputDigest:hash(input),outputDigest:hash(result.evidence)});if(!receipt)return last={state:'waiting-receipt',date:target,cursor:day.cursor};
    const profileStatus=await profile.status();await profile.apply(result.evidence,{expectedVersion:profileStatus.version,receipt});
    if(count>=remaining.length)day.cursor=sequenced?{page:item.serverSeq,index:0,offset:0}:{...day.cursor,index:day.cursor.index+1,offset:0};
    else {day.cursor.offset+=count;if(sequenced)day.cursor.eventId=item.eventId;}
    day.state='running';await commit();
   }
  }catch(e){if(e.code==='REFLECTION_REVOKED')return last={state:'revoked'};last={state:'error',errorCode:/^[A-Z0-9_]+$/.test(e.code||'')?e.code:'REFLECTION_FAILED'};throw e;}
  finally{await lease.release();}
 }
 return {ensureSchedule,run(options){if(running)return running;running=perform(options).finally(()=>{running=null;});return running;},
  async catchUp(){const snapshot=await policy?.status();if(!await enabled(snapshot))return last={state:'disabled'};const task=await ensureSchedule();if(!task)return last={state:'waiting-automation'};const progress=await automation.readReflection(task.id),ready=reflectionDate(clock(),snapshot.timezone);
   const pending=Object.keys(progress.days).filter(d=>d<=ready&&(progress.days[d].state!=='complete'||progress.days[d].dirty)).sort()[0];const complete=Object.keys(progress.days).filter(d=>progress.days[d].state==='complete').sort().at(-1);const date=pending||(complete&&complete<ready?addDays(complete,1):ready);return this.run({date});},
  status(){return structuredClone(last);},stop(){stopped=true;return running;},
 };
}
