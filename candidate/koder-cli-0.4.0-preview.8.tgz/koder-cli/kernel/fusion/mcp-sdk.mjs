import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { CallToolResultSchema, ToolListChangedNotificationSchema, ResourceListChangedNotificationSchema, PromptListChangedNotificationSchema } from '@modelcontextprotocol/sdk/types.js';

// Keep the old request interface while the official SDK owns initialization,
// protocol negotiation, request IDs, sessions, cancellation and validation.
export function sdkClient(transport, { timeoutMs = 20_000, closeTransport } = {}) {
  const client = new Client({ name: 'koder', version: '0.3.11' }, { capabilities: {} });
  client.onerror = () => {}; // SDK request promises carry errors; stdout stays protocol-only.
  const listeners = new Set();
  for (const [kind, schema] of [['tools',ToolListChangedNotificationSchema],['resources',ResourceListChangedNotificationSchema],['prompts',PromptListChangedNotificationSchema]]) {
    client.setNotificationHandler(schema, () => { for (const listener of listeners) listener(kind); });
  }
  let ready, closed = false, closing, protocolVersion;
  const setVersion = transport.setProtocolVersion?.bind(transport);
  transport.setProtocolVersion = (version) => { protocolVersion = version; return setVersion?.(version); };
  async function connect(options = {}) {
    if (closed) throw new Error('MCP 连接已关闭');
    ready ||= client.connect(transport, { timeout: timeoutMs, ...options }).then(() => ({
      protocolVersion: protocolVersion,
      capabilities: client.getServerCapabilities(), serverInfo: client.getServerVersion(),
      instructions: client.getInstructions(),
    }));
    return ready;
  }
  return {
    transport, client,
    onListChanged(listener) { listeners.add(listener); return () => listeners.delete(listener); },
    async request(method, params = {}, { signal, timeout = timeoutMs } = {}) {
      signal?.throwIfAborted();
      let dispatched = false;
      try {
        if (method === 'initialize') return await connect({ signal, timeout });
        await connect({ signal, timeout });
        signal?.throwIfAborted();
        const capability = method.split('/')[0];
        if (['tools','resources','prompts'].includes(capability) && !client.getServerCapabilities()?.[capability]) {
          throw Object.assign(new Error(`MCP 服务未提供 ${capability} 能力`), {code:'MCP_CAPABILITY_UNAVAILABLE'});
        }
        const options = { signal, timeout, maxTotalTimeout: timeout };
        if (method === 'tools/list') return await client.listTools(params, options);
        if (method === 'tools/call') { dispatched = true; return await client.callTool(params, CallToolResultSchema, options); }
        if (method === 'resources/list') return await client.listResources(params, options);
        if (method === 'resources/templates/list') return await client.listResourceTemplates(params, options);
        if (method === 'resources/read') return await client.readResource(params, options);
        if (method === 'prompts/list') return await client.listPrompts(params, options);
        if (method === 'prompts/get') return await client.getPrompt(params, options);
        throw new Error(`不支持的 MCP 方法：${method}`);
      } catch (error) {
        // MCP cancellation is a notification, not proof that a remote effect stopped.
        if (dispatched && method === 'tools/call') {
          error.cleanupComplete = false; error.effectsMayHaveCompleted = true;
        }
        throw error;
      }
    },
    async notify(method, params = {}) {
      if (method === 'notifications/initialized') return; // connect already sent it.
      await connect();
      return client.notification({ method, params });
    },
    close() {
      closing ||= (async () => {
        closed = true;
        let cleanupComplete = true;
        try { if (closeTransport) cleanupComplete = (await closeTransport(transport))?.cleanupComplete !== false; }
        catch { cleanupComplete = false; }
        try { await client.close(); } catch { cleanupComplete = false; }
        return { cleanupComplete };
      })();
      return closing;
    },
  };
}
