// CLI records use standard authenticated encryption and the existing native
// credential port. Desktop-specific algorithms and key files are not imported.
import crypto from 'node:crypto';
const MAGIC=Buffer.from('KPM1'),MAX=32*1024*1024;
const fail=code=>Object.assign(new Error(code),{code});
export async function createPersonalizationLock({credentials,scope,withLease=work=>work()}={}){
 if(typeof scope!=='string'||!scope||typeof credentials?.read!=='function'||typeof credentials?.write!=='function')throw fail('PERSONALIZATION_PROTECTED_KEY_REQUIRED');
 const key=await withLease(async()=>{
  let record=await credentials.read();
  if(!record){await credentials.write({key:crypto.randomBytes(32).toString('base64')});record=await credentials.read();}
  if(credentials.availability?.().mode!=='protected'||credentials.availability?.().nativeVerified!==true)throw fail('PERSONALIZATION_PROTECTED_KEY_REQUIRED');
  if(typeof record?.key!=='string'||!/^[A-Za-z0-9+/]{43}=$/.test(record.key))throw fail('PERSONALIZATION_KEY_DAMAGED');
  const value=Buffer.from(record.key,'base64');if(value.length!==32)throw fail('PERSONALIZATION_KEY_DAMAGED');return value;
 });
 let closed=false;
 const alive=()=>{if(closed)throw fail('PERSONALIZATION_LOCK_CLOSED');};
 const aad=label=>{if(typeof label!=='string'||label.length>8192)throw fail('PERSONALIZATION_RECORD_INVALID');return Buffer.from('Koder CLI personalization v1\0'+scope+'\0'+label);};
 const isLocked=box=>Buffer.isBuffer(box)&&box.length>=32&&box.subarray(0,4).equals(MAGIC);
 return {isLocked,assertAlive:alive,
  seal(plain,label){alive();const bytes=Buffer.from(plain);if(bytes.length>MAX)throw fail('PERSONALIZATION_RECORD_LIMIT');const nonce=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',key,nonce);cipher.setAAD(aad(label));const data=Buffer.concat([cipher.update(bytes),cipher.final()]);return Buffer.concat([MAGIC,nonce,cipher.getAuthTag(),data]);},
  open(box,label){alive();if(!isLocked(box)||box.length>MAX+32)throw fail('PERSONALIZATION_RECORD_DAMAGED');try{const cipher=crypto.createDecipheriv('aes-256-gcm',key,box.subarray(4,16));cipher.setAAD(aad(label));cipher.setAuthTag(box.subarray(16,32));return Buffer.concat([cipher.update(box.subarray(32)),cipher.final()]);}catch{throw fail('PERSONALIZATION_RECORD_DAMAGED');}},
  release(){if(!closed){closed=true;key.fill(0);}},
 };
}
