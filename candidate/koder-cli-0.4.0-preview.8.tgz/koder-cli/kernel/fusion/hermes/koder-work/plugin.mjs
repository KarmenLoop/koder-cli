import { BUNDLED_SKILLS } from "../../skills.mjs";
import { buildReport } from "../../work.mjs";

const parameters = {
  type: "object",
  properties: { path: { type: "string" } },
  required: ["path"],
  additionalProperties: false,
};

export function register(ctx) {
  ctx.register_tool({
    id: "hermes.workspace_report",
    name: "workspace_report",
    mutates: true,
    modes: ["standard", "code"],
    source: "hermes",
    description: "读取工作区里的真实表格或文本，生成一份只包含原文数据的 Markdown 成果。不会直接落盘。",
    parameters,
    execute(args) {
      return buildReport(ctx.root, args?.path);
    },
  });
  ctx.register_tool({
    id: "hermes.ask_user",
    name: "ask_user",
    mutates: false,
    modes: ["standard", "code", "minimal", "plan", "execute"],
    source: "hermes",
    description: "运行中发现必须由用户决定的问题时停下来，给出问题和 2 到 6 个选项。不要替用户做选择。",
    parameters: {
      type: "object",
      properties: {
        question: { type: "string" },
        options: { type: "array", items: { type: "string" } },
      },
      required: ["question", "options"],
      additionalProperties: false,
    },
    execute(args) {
      const question = String(args?.question || "").trim().slice(0, 400);
      const options = [...new Set((args?.options || []).map((item) => String(item).trim()).filter(Boolean))].slice(0, 6);
      if (!question || options.length < 2) return { content: "问题至少要有两个不同选项，没有停下询问。" };
      return { pause: { kind: "choice", question, options } };
    },
  });
  ctx.register_tool({
    id: "hermes.request_login",
    name: "request_login",
    mutates: false,
    modes: ["standard", "code", "minimal", "plan", "execute"],
    source: "hermes",
    description: "需要账号和密码时打开加密收集框。不要在回复、命令或文件里写出密码。",
    parameters: {
      type: "object",
      properties: {
        service: { type: "string" },
        reason: { type: "string" },
      },
      required: ["service"],
      additionalProperties: false,
    },
    execute(args) {
      const service = String(args?.service || "登录").trim().slice(0, 80);
      const reason = String(args?.reason || "").trim().slice(0, 200);
      return { pause: { kind: "secret", service, reason } };
    },
  });
  for (const skill of BUNDLED_SKILLS.filter(s=>s.enabled!==false&&!s.requiredPolicy)) ctx.register_skill(skill.name, skill.body, {id:skill.id,source:skill.source});
}
