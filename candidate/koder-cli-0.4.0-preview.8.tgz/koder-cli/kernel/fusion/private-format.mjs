// Shared record-format identification only. No key handling or cipher code.
export class LockError extends Error {
 constructor(code,message){super(message);this.code=code;}
}
const MAGIC=Buffer.from('KDLK');
export const isLocked=bytes=>Buffer.isBuffer(bytes)&&bytes.length>7&&bytes.subarray(0,4).equals(MAGIC);
