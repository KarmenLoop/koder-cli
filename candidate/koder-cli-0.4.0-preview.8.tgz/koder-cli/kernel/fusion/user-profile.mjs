import crypto from 'node:crypto';
import {zonedDay} from './personalization-time.mjs';
import {subjectKey} from './personalization-policy.mjs';
const failure=code=>Object.assign(new Error(code),{code});
const categories=['explicit-preference','explicit-background','behavior','temporary','daily-state'];
const redact=text=>String(text).replace(/\b(api[_-]?key|token|password|authorization)\s*[:=]\s*\S+/gi,'$1=[REDACTED]').replace(/\bsk-[a-zA-Z0-9_-]{8,}/g,'[REDACTED]');
const hash=text=>crypto.createHash('sha256').update(text).digest('hex');
const tomorrow=date=>new Date(Date.parse(date+'T00:00:00Z')+86400000).toISOString().slice(0,10);
const initial=()=>({version:0,evidence:[],forgotten:[],rules:[],history:[],commands:[]});
function derive(evidence,today){
 const rules=[],behaviors=new Map();
 for(const e of evidence){
  if(e.category==='behavior'){const key=e.text.normalize('NFKC').toLowerCase().trim();const group=behaviors.get(key)||[];group.push(e);behaviors.set(key,group);continue;}
  const temporary=['temporary','daily-state'].includes(e.category),expiresAt=temporary?(e.category==='daily-state'?tomorrow(e.date):(e.expiresAt||tomorrow(e.date))):null;
  if(expiresAt&&expiresAt<=today)continue;
  rules.push({...e,status:e.category==='daily-state'?'daily':temporary?'temporary':'confirmed',expiresAt});
 }
 for(const group of behaviors.values()){
  const distinct=new Set(group.map(e=>e.date+'|'+e.conversationId+'|'+e.taskId));
  const dates=new Set(group.map(e=>e.date));if(distinct.size<3||dates.size<2)continue;
  const last=group.at(-1),reviewAt=new Date(Date.parse(last.date+'T00:00:00Z')+30*86400000).toISOString().slice(0,10);if(reviewAt<=today)continue;
  rules.push({...last,status:'tentative',reviewAt,evidenceIds:group.map(e=>e.eventId),expiresAt:reviewAt});
 }
 return rules.slice(-30);
}
function markdown(state){
 const active=state.rules,guide=active.filter(r=>['confirmed','tentative'].includes(r.status));
 const line=r=>`- [${r.status}] ${r.text.replace(/\r?\n/g,' ')} (source: ${r.sourceRef}; ${r.date}${r.expiresAt?'; expires '+r.expiresAt:''})`;
 const docs={'USER_SKILL.md':'# User collaboration guide\n\nCurrent user instructions take precedence. These are sourced preferences, never execution authority.\n\n'+guide.map(line).join('\n')+'\n',
 'MEMORY.md':'# Memory\n\nVersion '+state.version+'\n\n'+active.map(line).join('\n')+'\n'};
 for(const command of state.commands||[]){const day=command.date||new Date(command.at).toISOString().slice(0,10);let part=1,key=`commands/${day}.md`;const row=`- ${command.purpose} | ${command.tool} exit=${command.exitCode} | task=${command.taskId} call=${command.callId} | digest=${command.resultDigest} artifacts=${JSON.stringify(command.artifacts)}\n`;while(Buffer.byteLength((docs[key]||'')+row)>1048576)key=`commands/${day}-${++part}.md`;docs[key]=(docs[key]||'# Executed command summaries\n\n')+row;}
 return docs;
}
export function openUserProfile({subject,policy,memory,source,versions,projections,clock=Date.now}={}) {
 const selected=()=>typeof subject==='function'?subject():subject;
 const key=subjectKey(selected());
 const today=snapshot=>zonedDay(clock(),snapshot?.timezone||'UTC');
 const inScope=(row,snapshot)=>!((Array.isArray(snapshot?.sources)&&!snapshot.sources.includes(row.platform))||(snapshot?.from>0&&(!Number.isSafeInteger(row.createdAt)||row.createdAt<snapshot.from)));
 async function allowed(feature='learning',snapshot){return subjectKey(selected())===key&&await policy?.require(feature,snapshot)===true;}
 async function read(){const state=await versions?.read?.(selected())||initial();if(!Number.isInteger(state.version)||!Array.isArray(state.evidence)||!Array.isArray(state.forgotten))throw failure('PROFILE_STORAGE_INVALID');return structuredClone({...initial(),...state});}
 async function persist(before,next,snapshot,ownerAction,sourceReceipt){
  if(ownerAction){if(subjectKey(selected())!==key||!await source?.authorizeEdit?.({...ownerAction,subject:selected()}))throw failure('PROFILE_SOURCE_REQUIRED');}
  else if(!await allowed('learning',snapshot)&&!await allowed('dailyState',snapshot))throw failure('PROFILE_REVOKED');
  if(typeof versions?.commit!=='function')throw failure('PROFILE_STORAGE_UNAVAILABLE');
  next.version=before.version+1;next.rules=derive(next.evidence,today(snapshot));
  next.history=[...(before.history||[]),{version:before.version,rules:before.rules}].slice(-20);
  const docs=markdown(next);if(Buffer.byteLength(docs['USER_SKILL.md'])>16384||Buffer.byteLength(docs['MEMORY.md'])>65536)throw failure('PROFILE_PROJECTION_LIMIT');
  if(next.evidence.length>2048||next.forgotten.length>8192)throw failure('PROFILE_STORAGE_LIMIT');
  const guard=async()=>subjectKey(selected())===key&&(ownerAction?await source?.authorizeEdit?.({...ownerAction,subject:selected()}):await allowed('learning',snapshot)||await allowed('dailyState',snapshot));
  // The original storage transaction commits facts, superseding notes, cursor
  // references and derived documents together. No ordinary note confers trust.
  await versions.commit(before.version,next,{subject:selected(),guard,policySnapshot:snapshot,ownerAction,sourceReceipt,projections:docs,notes:next.rules.map(r=>({kind:'note',payload:{noteId:'profile:'+hash(r.eventId),text:JSON.stringify(r)},supersedes:null})),memory,projectionPort:projections});
  return {version:next.version,rules:next.rules.length};
 }
 async function verified(input,receipt,snapshot){
  const out=[];for(const candidate of input){const proof=await source?.verify?.(candidate,receipt,{subject:selected(),snapshot});if(!proof?.direct||proof.authorSubjectId!==selected()?.subjectId||!proof.receiptRef)continue;
   const e=proof.evidence;if(!e||e.subjectId!==selected().subjectId||!categories.includes(e.category)||typeof e.eventId!=='string'||e.eventId.length>200||typeof e.text!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(e.date)||!Number.isFinite(Date.parse(e.date)))continue;
   if(e.category.startsWith('explicit-')&&!proof.explicit)continue;
   if(!await allowed(e.category==='daily-state'?'dailyState':'learning',snapshot))continue;
   const record={};for(const k of ['eventId','conversationId','messageId','taskId','date','subjectId','category','scope','sourceRef','expiresAt'])if(e[k]!==undefined)record[k]=e[k];
   record.platform=proof.platform||e.platform;record.createdAt=proof.createdAt??e.createdAt;if(!inScope(record,snapshot))continue;
   record.text=redact(e.text).slice(0,1000);if(!record.text||!record.sourceRef||String(record.sourceRef).length>512)continue;out.push(record);
  }return out;
 }
 async function apply(input,{expectedVersion,receipt}={}){
  const snapshot=await policy?.status?.();if(!await allowed('learning',snapshot)&&!await allowed('dailyState',snapshot))throw failure('PROFILE_REVOKED');
  if(!Array.isArray(input)||input.length>256)throw failure('PROFILE_INPUT_LIMIT');const before=await read();if(before.version!==expectedVersion)throw failure('PROFILE_CONFLICT');
  const next=structuredClone(before),seen=new Set(next.evidence.map(e=>e.eventId)),forgotten=new Set(next.forgotten);
  for(const e of await verified(input,receipt,snapshot))if(!seen.has(e.eventId)&&!forgotten.has(e.eventId)){seen.add(e.eventId);next.evidence.push(e);}
  if(next.evidence.length===before.evidence.length)return {version:before.version,rules:before.rules.length,unchanged:true};return persist(before,next,snapshot,undefined,receipt);
 }
 return {apply,
  async query({text='',limit=5,maxBytes=6000}={}){
   const snapshot=await policy?.status?.(),learning=await allowed('learning',snapshot),daily=await allowed('dailyState',snapshot);if(!learning&&!daily)return [];
   const state=await read(),terms=String(text).toLowerCase().split(/\s+/).filter(Boolean);let bytes=2;const out=[];
   const rows=derive(state.evidence,today(snapshot)).filter(r=>inScope(r,snapshot)).filter(r=>r.category==='daily-state'?daily:learning).map(r=>({r,score:terms.reduce((n,t)=>n+(r.text.toLowerCase().includes(t)?1:0),0)})).sort((a,b)=>b.score-a.score);
   for(const {r} of rows){const size=Buffer.byteLength(JSON.stringify(r))+1;if(bytes+size>Math.min(6000,Math.max(2,maxBytes)))continue;bytes+=size;out.push(r);if(out.length>=Math.max(1,Math.min(5,limit)))break;}
   const stillLearning=await allowed('learning',snapshot),stillDaily=await allowed('dailyState',snapshot);return out.filter(r=>r.category==='daily-state'?stillDaily:stillLearning);
  },
  async recordCommand(receipt,{expectedVersion}={}){
   const snapshot=await policy.status();if(!await allowed('learning',snapshot))throw failure('PROFILE_REVOKED');
   const proof=await source?.verifyCommand?.(receipt,{subject:selected()});if(!proof||!['taskId','callId','tool','purpose','resultDigest'].every(k=>typeof proof[k]==='string')||!Number.isInteger(proof.exitCode)||!Number.isSafeInteger(proof.at)||!/^[a-f0-9]{64}$/.test(proof.resultDigest))throw failure('PROFILE_SOURCE_REQUIRED');
   const before=await read();if(before.version!==expectedVersion)throw failure('PROFILE_CONFLICT');const next=structuredClone(before);
   if(next.commands.some(c=>c.taskId===proof.taskId&&c.callId===proof.callId))return {version:before.version,unchanged:true};
   const row={};for(const k of ['taskId','callId','tool','purpose','resultDigest'])row[k]=redact(proof[k]).slice(0,k==='purpose'?1000:200);row.exitCode=proof.exitCode;row.at=proof.at;row.date=zonedDay(proof.at,snapshot?.timezone||'UTC');row.artifacts=Array.isArray(proof.artifacts)?proof.artifacts.slice(0,16).map(v=>redact(v).slice(0,512)):[];
   next.commands=[...next.commands.filter(c=>c.at>=clock()-30*86400000),row];if(next.commands.length>8192)throw failure('PROFILE_STORAGE_LIMIT');return persist(before,next,snapshot);
  },
  async render(){const snapshot=await policy?.status?.(),state=await read();if(!await allowed()&&!await allowed('dailyState'))return markdown(initial());state.rules=derive(state.evidence,today(snapshot)).filter(r=>inScope(r,snapshot)).filter(r=>r.category==='daily-state'?policy.can?.('dailyState',selected())!==false:policy.can?.('learning',selected())!==false);return markdown(state);},
  async correct({eventId,replacement},{expectedVersion,receipt}={}){
   const snapshot=await policy.status();if(!await allowed('learning',snapshot))throw failure('PROFILE_REVOKED');const before=await read();if(before.version!==expectedVersion)throw failure('PROFILE_CONFLICT');
   const verifiedReplacement=await verified([replacement],receipt,snapshot);if(verifiedReplacement.length!==1)throw failure('PROFILE_SOURCE_REQUIRED');const next=structuredClone(before);next.forgotten=[...new Set([...next.forgotten,eventId])];next.evidence=next.evidence.filter(e=>e.eventId!==eventId);next.evidence.push(verifiedReplacement[0]);next.history=[];
   const clean={...before,history:[],rules:before.rules.filter(r=>r.eventId!==eventId)};return persist(clean,next,snapshot,undefined,receipt);
  },
  async forget(ids,{expectedVersion,receipt}={}){
   const snapshot=await policy.status();if(subjectKey(selected())!==key)throw failure('PROFILE_REVOKED');if(!Array.isArray(ids)||!ids.length||ids.some(id=>typeof id!=='string'||id.length>200)||ids.length>256||!receipt)throw failure('PROFILE_SOURCE_REQUIRED');
   if(typeof source?.authorizeEdit!=='function'||!await source.authorizeEdit({ids,receipt,subject:selected()}))throw failure('PROFILE_SOURCE_REQUIRED');
   const before=await read();if(before.version!==expectedVersion)throw failure('PROFILE_CONFLICT');const next=structuredClone(before);const remove=new Set(ids);next.forgotten=[...new Set([...next.forgotten,...ids])];next.evidence=next.evidence.filter(e=>!remove.has(e.eventId));next.history=[];
   // Old versions are scrubbed in the same storage transaction, including the
   // prior snapshot which persist normally retains for rollback.
   return persist({...before,history:[],rules:before.rules.filter(r=>!remove.has(r.eventId))},next,snapshot,{operation:'forget',receipt,ids});
  },
  async inspect(){if(subjectKey(selected())!==key)throw failure('PROFILE_REVOKED');const state=await read(),snapshot=await policy.status();return {version:state.version,rules:derive(state.evidence,today(snapshot)).slice(0,30)};},
  async status(){const s=await read();return {version:s.version,rules:s.rules.length,enabled:await allowed(),subject:selected()};},
 };
}

export function projectProfileRecord(record,{timezone='UTC',now=Date.now()}={}){const state={...initial(),...structuredClone(record)};state.rules=derive(state.evidence,zonedDay(now,timezone));return {state,documents:markdown(state)};}
