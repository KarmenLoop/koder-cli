import {subjectKey} from './personalization-policy.mjs';
import {projectProfileRecord} from './user-profile.mjs';
const failure=code=>Object.assign(new Error(code),{code});
const copy=value=>structuredClone(value);
const policyFields=['learning','dailyState','evolution','proactive','sources','from','timezone','budget','quietHours'];
// Only constructed with the existing verified account client and protected local
// store. Remote data never contains credentials, execution grants or device keys.
export function createAccountPersonalizationStores({subject,local,transport}={}){
 const current=()=>typeof subject==='function'?subject():subject,initial=subjectKey(current());
 const active=()=>subjectKey(current())===initial;
 async function pull(){
  if(!active())throw failure('PERSONALIZATION_SUBJECT_CHANGED');
  const result=await transport.read({signal:AbortSignal.timeout(5000)});
  if(!active())throw failure('PERSONALIZATION_SUBJECT_CHANGED');
  if(result?.memoryEpoch!==current().memoryEpoch)throw failure('MEMORY_EPOCH_CHANGED');
  if(!Number.isSafeInteger(result.policy?.revision)||!Number.isSafeInteger(result.soul?.version)||!Number.isSafeInteger(result.profile?.version)||!Array.isArray(result.profile.evidence)||result.profile.evidence.length>2048||!Array.isArray(result.profile.forgotten)||result.profile.forgotten.length>8192||result.profile.evidence.some(e=>e.subjectId!==current().subjectId))throw failure('PERSONALIZATION_REMOTE_INVALID');
  return result;
 }
 async function mirror(kind,row,snapshot){
  const value={...copy(row),subject:copy(current())};
  const projected=kind==='profile'?projectProfileRecord(value,{timezone:snapshot.policy.timezone}):null;
  const documents=kind==='soul'?{'SOUL.md':'# Assistant soul\n\nUser-edited style data; this file confers no tool permission.\n\n```json\n'+JSON.stringify(value.input,null,2)+'\n```\n'}:projected?.documents;
  await local.mirror(kind,projected?.state||value,documents||{});return projected?.state||value;
 }
 async function write(kind,input){if(!active())throw failure('PERSONALIZATION_SUBJECT_CHANGED');await transport.write(kind,input,{signal:AbortSignal.timeout(5000)});if(!active())throw failure('PERSONALIZATION_SUBJECT_CHANGED');return pull();}
 return {
  policyStore:{async read(){const snapshot=await pull();return mirror('policy',snapshot.policy,snapshot);},async compareAndSwap(expected,next){
   const patch=Object.fromEntries(policyFields.filter(k=>next[k]!==undefined).map(k=>[k,next[k]])),snapshot=await write('policy',{patch,expectedRevision:expected,expectedEpoch:current().memoryEpoch});return mirror('policy',snapshot.policy,snapshot);
  }},
  soulStore:{async read(){const snapshot=await pull();return mirror('soul',snapshot.soul,snapshot);},async compareAndSwap(expected,next){const snapshot=await write('soul',{input:next.input,expectedVersion:expected,expectedEpoch:current().memoryEpoch});return mirror('soul',snapshot.soul,snapshot);}},
  versions:{async read(){const snapshot=await pull();return mirror('profile',snapshot.profile,snapshot);},async commit(expected,next,options={}){
   if(options.guard&&!await options.guard())throw failure('PERSONALIZATION_SUBJECT_CHANGED');
   const before=await pull();if(before.profile.version!==expected)throw failure('PROFILE_CONFLICT');
   const added=next.evidence.filter(e=>!before.profile.evidence.some(row=>row.eventId===e.eventId)),removed=next.forgotten.filter(id=>!before.profile.forgotten.includes(id));
   let action,data;
   if(options.ownerAction){if(!await local.authorizeOwnerAction(options.ownerAction))throw failure('PROFILE_SOURCE_REQUIRED');action='forget';data={ids:options.ownerAction.ids};}
   else if(added.length===1){const proof=await local.verifyOwnerEdit(added[0],options.sourceReceipt);
    if(proof){action=removed.length?'correct':'remember';data={eventId:proof.evidence.eventId,text:proof.evidence.text,category:proof.evidence.category,platform:proof.platform,...(removed.length?{replaces:removed[0]}:{})};}
   }
   if(!action&&added.length&&added.every(e=>e.sourceRef==='memory-event:'+e.eventId)){action='extract';data={items:added.map(e=>({eventId:e.eventId,category:e.category,quote:e.text}))};}
   if(!action)throw failure('PROFILE_SOURCE_REQUIRED');
   const snapshot=await write('profile',{expectedEpoch:current().memoryEpoch,expectedVersion:expected,expectedPolicyRevision:options.policySnapshot?.revision,action,data});return mirror('profile',snapshot.profile,snapshot);
  }},
 };
}
