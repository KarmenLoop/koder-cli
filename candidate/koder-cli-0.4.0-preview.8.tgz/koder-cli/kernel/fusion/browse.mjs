// Each conversation loads pages through Koder, so a site that refuses to be
// embedded still shows. Cookies stay with that conversation. Private addresses
// are refused before anything is fetched.
import { isIP } from "node:net";

const HOP_LIMIT = 5;
const BYTE_LIMIT = 8_000_000;
export const CHROME_VERSION = "155.0.8059.40";

export function browserUserAgent(platform = process.platform) {
  const chrome = `Chrome/${CHROME_VERSION}`;
  if (platform === "win32") return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) ${chrome} Safari/537.36`;
  if (platform === "linux") return `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) ${chrome} Safari/537.36`;
  return `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) ${chrome} Safari/537.36`;
}

export function browserClientHints(platform = process.platform) {
  const major = CHROME_VERSION.split(".")[0];
  const name = platform === "win32" ? "Windows" : platform === "linux" ? "Linux" : "macOS";
  return {
    "sec-ch-ua": `"Chromium";v="${major}", "Not;A=Brand";v="24", "Google Chrome";v="${major}"`,
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": `"${name}"`,
  };
}

export const BROWSER_UA = browserUserAgent();
export const BROWSER_ACCEPT = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8";

export function isPrivateAddress(ip) {
  const kind = isIP(ip);
  if (kind === 4) {
    const [a, b] = ip.split(".").map(Number);
    if (a === 0 || a === 10 || a === 127) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    return false;
  }
  if (kind === 6) {
    const lower = ip.toLowerCase();
    return lower === "::" || lower === "::1" || lower.startsWith("fe80:") || lower.startsWith("fc") || lower.startsWith("fd");
  }
  return false;
}

function blockedHost(hostname) {
  const host = hostname.replace(/^\[|\]$/g, "").toLowerCase();
  if (!host || host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true;
  if (isIP(host) && isPrivateAddress(host)) return true;
  return false;
}

export function publicPageUrl(input) {
  let url;
  try {
    url = new URL(String(input || ""));
  } catch {
    throw Object.assign(new Error("这个网址打不开"), { code: "BAD_URL" });
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") throw Object.assign(new Error("只能打开 http 或 https"), { code: "BAD_URL" });
  if (blockedHost(url.hostname)) throw Object.assign(new Error("不打开本机或内网地址"), { code: "PRIVATE" });
  return url;
}

export async function assertPublic(url, lookup) {
  if (isIP(url.hostname)) return;
  const found = await lookup(url.hostname, { all: true }).catch(() => {
    throw Object.assign(new Error("这个网址找不到"), { code: "BAD_URL" });
  });
  if (found.some((item) => isPrivateAddress(item.address))) throw Object.assign(new Error("不打开本机或内网地址"), { code: "PRIVATE" });
}

export function siteOrigin(input) {
  return publicPageUrl(input).origin;
}

function cookieHeader(jar, url) {
  const now = Date.now();
  return jar.filter((item) => {
    const host = url.hostname;
    const domainOk = host === item.domain || host.endsWith(`.${item.domain}`);
    return domainOk && url.pathname.startsWith(item.path || "/") && (!item.expires || item.expires > now);
  }).map((item) => `${item.name}=${item.value}`).join("; ");
}

function storeCookies(jar, url, lines) {
  for (const line of lines) {
    const [pair, ...attrs] = String(line).split(";").map((part) => part.trim());
    const eq = pair.indexOf("=");
    if (eq < 1) continue;
    const name = pair.slice(0, eq);
    const value = pair.slice(eq + 1);
    let domain = url.hostname;
    let cookiePath = "/";
    let expires = 0;
    for (const attr of attrs) {
      const [key, raw] = attr.split("=");
      const lowered = key.toLowerCase();
      if (lowered === "domain" && raw) domain = raw.trim().replace(/^\./, "").toLowerCase();
      if (lowered === "path" && raw) cookiePath = raw.trim() || "/";
      if (lowered === "max-age") expires = Date.now() + Number(raw) * 1000;
      if (lowered === "expires" && !expires) expires = Date.parse(raw) || 0;
    }
    if (url.hostname !== domain && !url.hostname.endsWith(`.${domain}`)) domain = url.hostname;
    const item = { name, value, domain, path: cookiePath, expires };
    const index = jar.findIndex((cookie) => cookie.name === name && cookie.domain === domain && cookie.path === cookiePath);
    if (index >= 0) jar[index] = item;
    else jar.push(item);
  }
}

// Path-shaped so a script's relative import (./chunk.js) stays on this proxy.
export function assetPath(thread, href) {
  const url = new URL(href);
  if (url.protocol !== "http:" && url.protocol !== "https:") return href;
  return `/api/browse/s/${encodeURIComponent(threadId(thread))}/${url.protocol.slice(0, -1)}/${url.host}${url.pathname}${url.search}`;
}

export function parseAssetPath(pathname, search = "") {
  const rest = String(pathname || "").slice("/api/browse/s/".length);
  const parts = rest.split("/");
  if (parts.length < 4 || (parts[1] !== "http" && parts[1] !== "https") || !parts[2]) {
    throw Object.assign(new Error("这个资源地址打不开"), { code: "BAD_URL" });
  }
  return {
    thread: decodeURIComponent(parts[0]),
    target: `${parts[1]}://${parts[2]}/${parts.slice(3).join("/")}${search}`,
  };
}

function rewriteRemoteUrls(css, pageUrl, thread) {
  return String(css).replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (all, quote, value) => {
    const raw = value.trim();
    if (!raw || /^(?:data:|blob:|#)/i.test(raw)) return all;
    try {
      return `url(${quote}${assetPath(thread, new URL(raw, pageUrl).href)}${quote})`;
    } catch {
      return all;
    }
  }).replace(/@import\s+(['"])([^'"]+)\1/gi, (all, quote, value) => {
    try {
      return `@import ${quote}${assetPath(thread, new URL(value, pageUrl).href)}${quote}`;
    } catch {
      return all;
    }
  });
}

export function rewriteCss(css, pageUrl, thread) {
  return rewriteRemoteUrls(css, pageUrl, thread);
}

function assetBoot(pageUrl, thread) {
  return `(function(){
    var page=${JSON.stringify(pageUrl)};
    var prefix="/api/browse/s/${encodeURIComponent(threadId(thread))}/";
    function proxy(input){
      try {
        var abs=new URL(String(input), page);
        if (abs.protocol!=="http:" && abs.protocol!=="https:") return input;
        if (abs.pathname.indexOf("/api/browse")===0) return input;
        return prefix+abs.protocol.slice(0,-1)+"/"+abs.host+abs.pathname+abs.search;
      } catch (error) { return input; }
    }
    var origFetch=window.fetch;
    if (origFetch) window.fetch=function(input, init){
      if (typeof input==="string") return origFetch.call(this, proxy(input), init);
      if (input && input.url) return origFetch.call(this, new Request(proxy(input.url), input), init);
      return origFetch.call(this, input, init);
    };
    var open=XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open=function(method, url){
      arguments[1]=proxy(url);
      return open.apply(this, arguments);
    };
    var WorkerRef=window.Worker;
    if (WorkerRef) window.Worker=function(url, opts){ return new WorkerRef(proxy(url), opts); };
  })();`;
}

export function rewritePage(html, pageUrl, thread) {
  const page = new URL(pageUrl);
  let out = String(html)
    .replace(/<base\b[^>]*>/gi, "")
    .replace(/<meta\b[^>]*http-equiv=["'](?:content-security-policy|refresh)["'][^>]*>/gi, "");
  out = out.replace(/(\s(?:href|src|action|poster)=)(["'])([^"']+)\2/gi, (all, attr, quote, value) => {
    const raw = value.trim();
    if (!raw || /^(?:data:|mailto:|javascript:|#)/i.test(raw)) return all;
    try {
      return `${attr}${quote}${new URL(raw, page).href}${quote}`;
    } catch {
      return all;
    }
  });
  out = out.replace(/(\ssrcset=)(["'])([^"']+)\2/gi, (all, attr, quote, value) => {
    const next = value.split(",").map((part) => {
      const bits = part.trim().split(/\s+/);
      if (!bits[0] || /^(?:data:|blob:)/i.test(bits[0])) return part.trim();
      try {
        bits[0] = assetPath(thread, new URL(bits[0], page).href);
      } catch { /* keep the original candidate */ }
      return bits.join(" ");
    }).join(", ");
    return `${attr}${quote}${next}${quote}`;
  });
  out = rewriteRemoteUrls(out, page.href, thread);
  out = out.replace(/(<(?:script|link)\b[^>]*?\s(?:src|href)=)(["'])(https?:\/\/[^"']+)\2/gi, (_, pre, quote, href) => `${pre}${quote}${assetPath(thread, href)}${quote}`);
  const proxy = (href) => `/api/browse?thread=${encodeURIComponent(thread)}&url=${encodeURIComponent(href)}`;
  out = out
    .replace(/(<a\b[^>]*?\shref=)(["'])(https?:\/\/[^"']+)\2/gi, (_, pre, quote, href) => `${pre}${quote}${proxy(href)}${quote}`)
    .replace(/(<form\b[^>]*?\saction=)(["'])(https?:\/\/[^"']+)\2/gi, (_, pre, quote, href) => `${pre}${quote}${proxy(href)}${quote}`);
  const boot = `<script>${assetBoot(page.href, thread)}<\/script>`;
  out = /<head[^>]*>/i.test(out) ? out.replace(/<head[^>]*>/i, (head) => `${head}${boot}`) : `${boot}${out}`;
  const hook = `<script>${browserHook(page.href)}<\/script>`;
  return out.includes("</body>") ? out.replace("</body>", `${hook}</body>`) : `${out}${hook}`;
}

function browserHook(pageUrl) {
  return `(function(){
    var page=${JSON.stringify(pageUrl)};
    try {
      var ua=${JSON.stringify(BROWSER_UA)};
      Object.defineProperty(Navigator.prototype, "userAgent", { configurable: true, get: function() { return ua; } });
    } catch (error) {}
    var epoch=0;
    var zoom=1;
    var pinch=1;
    var touches=new Map();
    var pinchStart=0;
    parent.postMessage({type:"koder-browser-here",url:page},"*");
    function reportTitle(){
      parent.postMessage({type:"koder-browser-title",url:location.href,title:document.title||""},"*");
    }
    document.addEventListener("DOMContentLoaded", reportTitle);
    setTimeout(reportTitle, 600);
    function clampZoom(value){
      var next=Number(value);
      if(!isFinite(next)) return zoom;
      return Math.min(3, Math.max(0.5, next));
    }
    function applyZoom(value){
      zoom=clampZoom(value);
      document.documentElement.style.zoom=zoom===1?"":String(zoom);
      parent.postMessage({type:"koder-browser-zoom",zoom:zoom},"*");
    }
    window.addEventListener("wheel",function(event){
      if(!event.ctrlKey && !event.metaKey) return;
      event.preventDefault();
      applyZoom(zoom*Math.exp(-event.deltaY*0.0016));
    },{capture:true,passive:false});
    window.addEventListener("gesturestart",function(event){
      event.preventDefault();
      pinch=zoom;
    },{capture:true,passive:false});
    window.addEventListener("gesturechange",function(event){
      event.preventDefault();
      applyZoom(pinch*(event.scale||1));
    },{capture:true,passive:false});
    document.addEventListener("touchstart",function(event){
      for(var touch of event.changedTouches) touches.set(touch.identifier,{x:touch.clientX,y:touch.clientY});
      if(touches.size===2){
        var pts=[...touches.values()];
        pinchStart=Math.hypot(pts[0].x-pts[1].x, pts[0].y-pts[1].y);
        pinch=zoom;
      }
    },{passive:true});
    document.addEventListener("touchmove",function(event){
      for(var touch of event.changedTouches) touches.set(touch.identifier,{x:touch.clientX,y:touch.clientY});
      if(touches.size!==2 || pinchStart<=0) return;
      var pts=[...touches.values()];
      event.preventDefault();
      applyZoom(pinch*Math.hypot(pts[0].x-pts[1].x, pts[0].y-pts[1].y)/pinchStart);
    },{passive:false});
    document.addEventListener("touchend",function(event){
      for(var touch of event.changedTouches) touches.delete(touch.identifier);
      if(touches.size<2) pinchStart=0;
    },{passive:true});
    function visible(el){
      var r=el.getBoundingClientRect();
      var s=getComputedStyle(el);
      return r.width>0&&r.height>0&&s.visibility!=="hidden"&&s.display!=="none";
    }
    function snapshot(){
      epoch+=1;
      var nodes=[...document.querySelectorAll('a,button,input,textarea,select,[role="button"]')].filter(visible).slice(0,100);
      window.__koderNodes=nodes;
      return {type:"koder-browser-shot",url:location.href,title:document.title,epoch:epoch,text:(document.body&&document.body.innerText||"").slice(0,16000),
        elements:nodes.map(function(el,index){
          var r=el.getBoundingClientRect();
          return {ref:epoch+":"+index,tag:el.tagName,type:el.type||"",text:(el.innerText||el.getAttribute("aria-label")||el.getAttribute("placeholder")||"").slice(0,160),
            rect:{x:r.x,y:r.y,width:r.width,height:r.height}};
        })};
    }
    window.addEventListener("message",function(event){
      var data=event.data||{};
      if(data.type==="koder-fill"){
        var password=document.querySelector("input[type=password]");
        if(!password)return;
        var user=document.querySelector("input[type=email],input[type=text],input[name*=user i],input[name*=mail i]");
        if(user&&data.account)user.value=data.account;
        if(data.password)password.value=data.password;
        return;
      }
      if(data.type==="koder-zoom"){
        applyZoom(data.zoom!=null?data.zoom:zoom*(Number(data.factor)||1));
        return;
      }
      if(data.type==="koder-plugins"){
        var ids=Array.isArray(data.ids)?data.ids:[];
        var node=document.getElementById("koder-plugin-style");
        if(!node){ node=document.createElement("style"); node.id="koder-plugin-style"; (document.head||document.documentElement).appendChild(node); }
        var css="";
        if(ids.indexOf("reader")>=0) css+="body{max-width:46rem;margin:1.5rem auto!important;padding:0 1.25rem!important;line-height:1.7;font-size:1.125rem;background:#f6f3ec;color:#1c1915}";
        if(ids.indexOf("dim")>=0) css+="html{filter:brightness(.9) sepia(.12)}";
        if(ids.indexOf("type")>=0) css+="body,p,li{font-size:1.25rem!important;line-height:1.65!important}";
        node.textContent=css;
        return;
      }
      if(data.type==="koder-mark-arm"){
        window.__koderMark=!!data.on;
        return;
      }
      if(data.type==="koder-browser-cmd"){
        try{
          if(data.op==="snapshot") parent.postMessage(snapshot(),"*");
        }catch(error){
          parent.postMessage({type:"koder-browser-error",message:String(error&&error.message||"观察失败")},"*");
        }
      }
    });
    document.addEventListener("click",function(event){
      if(!window.__koderMark) return;
      event.preventDefault();
      event.stopPropagation();
      var box=document.documentElement.getBoundingClientRect();
      var width=box.width||window.innerWidth||1;
      var height=box.height||window.innerHeight||1;
      var label=(event.target&&(event.target.innerText||event.target.getAttribute("aria-label"))||"").replace(/\\s+/g," ").trim().slice(0,80);
      parent.postMessage({type:"koder-mark",x:event.clientX/width,y:event.clientY/height,label:label},"*");
    },true);
    document.addEventListener("submit",function(event){
      var form=event.target;
      if(!form||!form.querySelector)return;
      var password=form.querySelector("input[type=password]");
      if(!password||!password.value)return;
      var user=form.querySelector("input[type=email],input[type=text]");
      parent.postMessage({type:"koder-browser-login",account:user?user.value:"",password:password.value,url:page},"*");
    },true);
  })();`;
}

function threadId(value) {
  return /^[\w:-]{1,80}$/.test(String(value || "")) ? String(value) : "none";
}

export function createBrowseProxy({ fetchImpl = fetch, lookup } = {}) {
  const jars = new Map();
  const resolve = lookup || (async (hostname) => {
    const { lookup: dnsLookup } = await import("node:dns/promises");
    return dnsLookup(hostname, { all: true });
  });
  function jarFor(thread) {
    const id = threadId(thread);
    if (!jars.has(id)) jars.set(id, []);
    return jars.get(id);
  }
  return {
    jar(thread) {
      return jarFor(thread);
    },
    async open({ thread, target, method = "GET", body = null, contentType = "", extra = [] }) {
      let current = publicPageUrl(target);
      for (const [key, value] of extra) current.searchParams.append(key, value);
      let response;
      for (let hop = 0; hop < HOP_LIMIT; hop += 1) {
        await assertPublic(current, resolve);
        const headers = {
          "user-agent": BROWSER_UA,
          accept: BROWSER_ACCEPT,
          "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
          ...browserClientHints(),
          "sec-fetch-dest": "document",
          "sec-fetch-mode": "navigate",
          "sec-fetch-site": "none",
          "sec-fetch-user": "?1",
          "upgrade-insecure-requests": "1",
        };
        const cookie = cookieHeader(jarFor(thread), current);
        if (cookie) headers.cookie = cookie;
        if (contentType && method !== "GET") headers["content-type"] = contentType;
        response = await fetchImpl(current, {
          method: hop === 0 ? method : "GET",
          headers,
          body: hop === 0 && method !== "GET" ? body : undefined,
          redirect: "manual",
        });
        const setCookie = typeof response.headers.getSetCookie === "function" ? response.headers.getSetCookie() : [];
        storeCookies(jarFor(thread), current, setCookie);
        if (![301, 302, 303, 307, 308].includes(response.status)) break;
        const location = response.headers.get("location");
        if (!location) break;
        current = publicPageUrl(new URL(location, current).href);
        method = "GET";
      }
      const bytes = Buffer.from(await response.arrayBuffer());
      if (bytes.length > BYTE_LIMIT) throw Object.assign(new Error("这一页太大"), { code: "TOO_BIG" });
      const type = response.headers.get("content-type") || "application/octet-stream";
      if (/text\/html/i.test(type)) {
        return {
          status: response.status,
          type: "text/html; charset=utf-8",
          body: Buffer.from(rewritePage(bytes.toString("utf8"), current.href, threadId(thread))),
          finalUrl: current.href,
        };
      }
      return { status: response.status, type: type.split(";")[0], body: bytes, finalUrl: current.href };
    },
  };
}
