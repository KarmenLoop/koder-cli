import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';

export function appScope(scope) {
  if(!scope||!['profileId','deviceId'].every(key=>typeof scope[key]==='string'&&scope[key].length>0&&scope[key].length<=512)||!(scope.accountId===null||typeof scope.accountId==='string'&&scope.accountId.length>0&&scope.accountId.length<=512)||!(typeof scope.sessionGeneration==='string'&&scope.sessionGeneration.length>0&&scope.sessionGeneration.length<=128||Number.isSafeInteger(scope.sessionGeneration)&&scope.sessionGeneration>=0))throw Object.assign(new Error('应用配置归属无效'),{code:'APP_SCOPE_INVALID'});
  return Object.freeze({profileId:scope.profileId,accountId:scope.accountId,deviceId:scope.deviceId,sessionGeneration:scope.sessionGeneration});
}
export const scopeIdentity=scope=>JSON.stringify([scope.profileId,scope.accountId,scope.deviceId]);
export function connectionScope({identity=null,env=process.env}={}) {
  return appScope(identity?{
    profileId:crypto.createHash('sha256').update(identity.server+'\0'+identity.tenantId).digest('hex'),
    accountId:identity.accountId,deviceId:identity.deviceId,sessionGeneration:identity.generation,
  }:{profileId:'local',accountId:null,deviceId:crypto.createHash('sha256').update(os.hostname()+'\0'+path.resolve(env.KODER_CLI_HOME||path.join(os.homedir(),'.koder-cli'))).digest('hex'),sessionGeneration:0});
}
export function resolveAppProfile({env=process.env,scope}={}) {
  scope=appScope(scope);
  const root=path.resolve(env.KODER_CONNECTIONS_HOME||path.join(env.KODER_CLI_HOME||path.join(os.homedir(),'.koder-cli'),'apps'));
  const id=crypto.createHash('sha256').update(JSON.stringify([scope.profileId,scope.accountId])).digest('hex');
  const profileDir=path.join(root,'profiles',id);
  return {root,profileDir,credentialScope:profileDir};
}
