import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
export const COMPUTER_CAPABILITIES=['files.read','files.write','files.search','network','browser','desktop','channel.files','skills.update'];
const TOOLS={'file.read':'files.read','file.write':'files.write','file.copy':'files.write','file.move':'files.write','file.search':'files.search','network.fetch':'network','browser.act':'browser','desktop.act':'desktop','channel.sendFile':'channel.files','skills.activate':'skills.update'};
const states=new Set(['supported','granted','missing','denied','restricted','unknown']);
const fail=code=>{throw Object.assign(new Error(code),{code});};
const hostKey=h=>JSON.stringify([h?.uid,h?.executable,h?.signature??null]);
const inside=(root,target)=>{const relative=path.relative(root,target);return relative===''||relative!=='..'&&!relative.startsWith('..'+path.sep)&&!path.isAbsolute(relative);};
export function createComputerCapabilities({platform=process.platform,hostIdentity,systemProbe,consentStore,executionContext=()=>({kind:'local-owner'})}={}) {
 if(!hostIdentity||typeof hostIdentity.executable!=='string'||hostIdentity.uid===undefined)fail('COMPUTER_HOST_UNKNOWN');
 const host=structuredClone(hostIdentity),hostId=hostKey(host);
 const valid=grant=>grant?.version===1&&typeof grant.grantId==='string'&&grant.revoked===false&&Number.isSafeInteger(grant.issuedAt)&&hostKey(grant.hostIdentity)===hostId&&Array.isArray(grant.capabilities)&&grant.capabilities.every(c=>COMPUTER_CAPABILITIES.includes(c))&&Array.isArray(grant.roots)&&grant.roots.every(r=>typeof r.path==='string'&&path.isAbsolute(r.path)&&typeof r.device==='number'&&typeof r.inode==='number');
 async function grant(){const value=await consentStore?.read();return valid(value)?value:null;}
 async function probe(name,roots){
  try{const result=await systemProbe?.(name,{hostIdentity:host,roots,platform});
   if(!result||!states.has(result.state)||hostKey(result.hostIdentity)!==hostId)return {state:'unknown',reasonCode:'COMPUTER_HOST_PROBE_UNVERIFIED'};
   return {state:result.state,reasonCode:typeof result.reasonCode==='string'?result.reasonCode:null,repairAction:result.repairAction||null};
  }catch{return {state:'unknown',reasonCode:'COMPUTER_PROBE_UNAVAILABLE'};}
 }
 async function status(){
  const owned=await grant();const roots=owned?.roots.map(r=>r.path)||[];
  return Promise.all(COMPUTER_CAPABILITIES.map(async name=>{
   const result=await probe(name,roots),approved=owned?.capabilities.includes(name);
   return {name,state:!approved?'missing':result.state,hostIdentity:structuredClone(host),roots,checkedAt:Date.now(),reasonCode:approved?result.reasonCode:'COMPUTER_OWNER_GRANT_REQUIRED',repairAction:result.repairAction||'permissions request'};
  }));
 }
 return {
  status,
  async revoke(){
   if(executionContext()?.kind!=='local-owner'||typeof consentStore?.write!=='function')fail('COMPUTER_OWNER_REQUIRED');
   const before=structuredClone(await consentStore.read()??null);
   if(before){
    const next={...before,revoked:true,revokedAt:Date.now()};
    if(consentStore.compareAndSwap)await consentStore.compareAndSwap(before,next);
    else{if(JSON.stringify(await consentStore.read()??null)!==JSON.stringify(before))fail('COMPUTER_GRANT_CHANGED');await consentStore.write(next);}
   }
   return status();
  },
  async request({capabilities,roots=[],destinations=[],remoteActors=[],replace=false}={}){
   if(typeof replace!=='boolean')fail('COMPUTER_REQUEST_INVALID');
   if(!Array.isArray(capabilities)||!capabilities.length||capabilities.some(c=>!COMPUTER_CAPABILITIES.includes(c))||!Array.isArray(roots)||roots.length>16||!Array.isArray(destinations)||destinations.length>64)fail('COMPUTER_REQUEST_INVALID');
   if(executionContext()?.kind!=='local-owner'||typeof consentStore?.authorizeOwner!=='function')fail('COMPUTER_OWNER_REQUIRED');
   if(!Array.isArray(remoteActors)||remoteActors.length>64||remoteActors.some(a=>!a||!['platform','bindingId','chatId','actorId'].every(k=>typeof a[k]==='string'&&a[k]&&a[k].length<=200&&!/[\x00-\x1f\x7f]/.test(a[k]))||!Array.isArray(a.capabilities)||a.capabilities.some(c=>!capabilities.includes(c))))fail('COMPUTER_REQUEST_INVALID');
   const canonical=[];
   for(const input of roots){if(typeof input!=='string'||!path.isAbsolute(input))fail('COMPUTER_REQUEST_INVALID');const root=await fs.realpath(input),info=await fs.lstat(root);if(!info.isDirectory())fail('COMPUTER_REQUEST_INVALID');canonical.push({path:root,device:info.dev,inode:info.ino});}
   const before=structuredClone(await consentStore.read()??null),previous=valid(before)?before:null;
   const request={hostIdentity:structuredClone(host),capabilities:[...new Set(capabilities)],roots:canonical.map(r=>r.path),destinations:structuredClone(destinations),remoteActors:structuredClone(remoteActors),replace};
   // The trusted installer/settings callback owns this decision; request JSON cannot supply it.
   if(await consentStore.authorizeOwner(request)!==true)fail('COMPUTER_OWNER_REQUIRED');
   const next={version:1,grantId:crypto.randomUUID(),hostIdentity:host,issuedAt:Date.now(),revoked:false,
    capabilities:[...new Set([...(replace?[]:previous?.capabilities||[]),...request.capabilities])],roots:[...new Map([...(replace?[]:previous?.roots||[]),...canonical].map(r=>[r.path,r])).values()],destinations:[...(replace?[]:previous?.destinations||[]),...request.destinations],remoteActors:[...(replace?[]:previous?.remoteActors||[]),...request.remoteActors]};
   if(consentStore.compareAndSwap)await consentStore.compareAndSwap(before,next);
   else{if(JSON.stringify(await consentStore.read()??null)!==JSON.stringify(before))fail('COMPUTER_GRANT_CHANGED');await consentStore.write(next);}return status();
  },
  async authorize({tool,path:input,destination}={}){
   const name=TOOLS[tool];if(!name)fail('COMPUTER_TOOL_UNSUPPORTED');
   const context=executionContext();
   const owned=await grant();if(!owned?.capabilities.includes(name))fail('COMPUTER_PERMISSION_REQUIRED');
   if(context?.kind!=='local-owner'&&!owned.remoteActors?.some(a=>['platform','bindingId','chatId','actorId'].every(k=>a[k]===context?.[k])&&a.capabilities.includes(name)))fail('COMPUTER_OWNER_REQUIRED');
   const result=await probe(name,owned.roots.map(r=>r.path));if(result.state!=='granted')fail('COMPUTER_PERMISSION_REQUIRED');
   let selected=null,target=null;
   if(name.startsWith('files.')){
    if(typeof input!=='string'||!path.isAbsolute(input)||input.includes('\0'))fail('COMPUTER_PATH_INVALID');target=path.resolve(input);
    selected=owned.roots.filter(r=>inside(r.path,target)).sort((a,b)=>b.path.length-a.path.length)[0];if(!selected)fail('COMPUTER_PATH_OUTSIDE_GRANT');
    const info=await fs.lstat(selected.path).catch(()=>null);
    if(!info||info.isSymbolicLink()||!info.isDirectory()||info.dev!==selected.device||info.ino!==selected.inode)fail('COMPUTER_ROOT_CHANGED');
    let current=selected.path;for(const segment of path.relative(selected.path,target).split(path.sep).filter(Boolean)){
     current=path.join(current,segment);const part=await fs.lstat(current).catch(e=>{if(e.code==='ENOENT')return null;throw e;});if(part?.isSymbolicLink())fail('COMPUTER_PATH_LINK');
    }
   }
   if(name==='channel.files'&&(!destination||!owned.destinations?.some(d=>JSON.stringify(d)===JSON.stringify(destination))))fail('COMPUTER_DESTINATION_REQUIRED');
   return {capability:name,root:selected?.path||null,path:target,grantId:owned.grantId,hostIdentity:structuredClone(host)};
  },
  async repair({capability}={}){if(!COMPUTER_CAPABILITIES.includes(capability))fail('COMPUTER_REQUEST_INVALID');if(executionContext()?.kind!=='local-owner')fail('COMPUTER_OWNER_REQUIRED');
   const action=typeof systemProbe?.repair==='function'?await systemProbe.repair(capability,{hostIdentity:host}):{action:'open-system-settings',performed:false};return {action,status:(await status()).find(c=>c.name===capability)};
  },
 };
}
