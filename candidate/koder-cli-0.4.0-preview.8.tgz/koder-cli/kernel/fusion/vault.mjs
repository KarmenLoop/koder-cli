// Not shipped with Koder CLI: the desktop app's login vault.
const MESSAGE = "Koder CLI 不包含桌面端的登录保管库";
export function isSealed() { throw new Error(MESSAGE); }
export function openVault() { throw new Error(MESSAGE); }
export function createLoginStore() { throw new Error(MESSAGE); }
