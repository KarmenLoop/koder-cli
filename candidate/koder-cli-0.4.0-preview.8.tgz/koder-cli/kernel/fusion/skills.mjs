// Skills the whole app can turn on: the ones that ship with Koder, and the
// ones a person uploads or asks the model to write. A skill with no project
// and no dialog listed is on everywhere.
import path from "node:path";
import {verifiedMaintenance} from "./skill-maintenance.mjs";
import { ECOSYSTEM_SKILLS } from "./ecosystem.mjs";
import { frameworkText } from "./frameworks.mjs";

// The supported scalar fields do not require evaluating YAML or loading plugins.
function frontFields(text) {
  const result = {};
  const lines = String(text).split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const match = /^(name|description|when):\s*(.*)$/.exec(lines[i]);
    if (!match) continue;
    let value = match[2].trim();
    if (/^[>|][-+]?$/.test(value)) {
      const folded = value.startsWith(">");
      const parts = [];
      while (i + 1 < lines.length && (/^\s/.test(lines[i + 1]) || !lines[i + 1])) parts.push(lines[++i].replace(/^\s+/, ""));
      value = parts.join(folded ? " " : "\n").trim();
    } else if (value.startsWith('"') && value.endsWith('"')) {
      try { value = JSON.parse(value); } catch { value = value.slice(1, -1); }
    } else if (value.startsWith("'") && value.endsWith("'")) value = value.slice(1, -1).replace(/''/g, "'");
    result[match[1]] = value;
  }
  return result;
}

export const BUNDLED_SKILLS = [
  {
    id: "builtin:整理真实材料",
    name: "整理真实材料",
    source: "bundled",
    body: [
      '先核对本轮实际提供的工具，再读取用户指定的材料。成果里的数字和结论必须能追溯到文件、行或单元格，不补造缺失数据。',
      'Koder 提供 studio_do 时：先调用 {"area":"workflows","action":"audit_help"} 获取表格、响应覆盖和引文核对的字段；按用户指定项目、文件和规则执行 workflows/audit，再读取真实异常和核验记录。Word、Excel、PPT、PDF 先用 {"area":"office","action":"help"} 查可用动作，不把二进制文件当文本。',
      '数字员工提供 work_read、work_write 时，用这些工具在自己的任务目录处理文件，并用 work_submit 提交逐文件检查；只有授权的 work_koder_task 才能委托项目执行。不能编造没有出现在本轮工具列表中的调用。',
      '普通文本可使用本轮的 read_file / write_file，保留来源并遵守写入审批。缺少需要的读取、格式转换或核验能力时，明确说明缺项，不用口头完成代替实际文件。',
      '确需用户决定且提供 ask_user 时，给出具体问题和可选答案。需要登录时，使用已提供的 studio_do {"area":"auth","action":"open"} 打开授权界面，或引导用户到设置中的对应平台连接页。密码、密钥和授权码只在专用表单输入，不在对话、文件或工具参数中收集。',
    ].join('\n'),
    when: "表格,报告,材料",
  },
  {
    id: "builtin:加页面",
    name: "加页面",
    source: "bundled",
    when: "加页面,新页面,加一页",
    body: "在旧项目里加页面。先找到相邻页面和路由的写法，新路由接进已有导航。完成标准是从已有页面能进入新页面，再走完新页面自己的动作。不要另起一套布局。",
  },
  {
    id: "builtin:改错位",
    name: "改错位",
    source: "bundled",
    when: "错位,对不齐,布局歪",
    body: "改界面错位。先在浏览器里复现，记下宽度和错位的那一块。只改这一块的布局。完成标准是同一宽度下那一块与周围对齐，主路径仍能走通。",
  },
  {
    id: "builtin:做表单",
    name: "做表单",
    source: "bundled",
    when: "表单,提交表单",
    body: "做表单。先列字段、哪一项必填、提交后发生什么。缺必填时停在原页并指出哪一项。完成标准是合法输入到达成功状态，非法输入留下可理解的提示。",
  },
  {
    id: "builtin:接口页面",
    name: "接口页面",
    source: "bundled",
    when: "接口,接上数据,真实字段",
    body: "把接口数据做成页面。先读接口的真实字段，页面只绑定这些字段。加载中、空列表和请求失败各自有一块界面。完成标准是浏览器里能看到一份真实返回，接口失败时能看到失败状态。",
  },
  {
    id: "builtin:先写测试",
    name: "先写测试",
    source: "bundled",
    when: "先写测试,测试驱动",
    body: "先写测试再改行为。先写一条会失败的检查，运行并保留失败输出，再改实现，直到这条检查通过。原有断言保留。",
  },
  {
    id: "builtin:解释代码",
    name: "解释代码",
    source: "bundled",
    when: "解释这段,为什么这样写,这段代码",
    body: "解释一块代码。从入口读到它调用的下一层。回答先给这条路径做什么，再给文件位置。不改仓库。",
  },
  {
    id: "builtin:改名搬文件",
    name: "改名搬文件",
    source: "bundled",
    when: "改名,重命名,搬动文件",
    body: "改名或搬动文件。先搜索全部引用，改完再搜索旧名字。完成标准是旧名字不再出现在源码里，项目原有检查仍然通过。",
  },
  {
    id: "builtin:命令行",
    name: "命令行",
    source: "bundled",
    when: "命令行,子命令",
    body: "做命令行工具。先定一个子命令、它的参数和成功时打印的一行结果。错误输入打印原因并以非零退出。完成标准是两条命令的退出码和输出都符合这个约定。",
  },
  {
    id: "builtin:发布前",
    name: "发布前核对",
    source: "bundled",
    when: "发布前,上线前,核对发布",
    body: "发布前核对。只读。核对主路径、失败状态、项目原有检查和环境变量是否只写了名字。输出一份未通过的清单。不要再加功能。",
  },
  ...["website", "application", "desktop", "app"].map((id) => ({
    id: `builtin:guide-${id}`,
    name: { website: "网站", application: "应用", desktop: "桌面应用", app: "手机应用" }[id],
    source: "bundled",
    when: `形态:${id}`,
    body: frameworkText(id),
  })),
  ...ECOSYSTEM_SKILLS,
];

const ids = (list) => (Array.isArray(list) ? list.filter((id) => typeof id === "string" && id.length > 0 && id.length <= 80).slice(0, 40) : []);

const paths = (list) => Array.isArray(list) ? list.filter((value) => typeof value === "string" && value.length > 0 && value.length <= 4096).slice(0, 40) : [];

export function skillRecord(input, source = input?.source || "user") {
  const name = String(input?.name || "").trim();
  const body = String(input?.body || "").trim();
  if (!name || !body) throw Object.assign(new Error("技能需要名称和说明"), { code: "BODY" });
  if (name.length > 120 || Buffer.byteLength(body) > 256 * 1024) throw Object.assign(new Error("技能名称或正文超过容量限制"), { code: "SKILL_SIZE" });
  const description = String(input.description || "");
  const when = String(input.when || "");
  const frontmatter = String(input.frontmatter || "");
  if (description.length > 4000 || when.length > 2000 || Buffer.byteLength(frontmatter) > 64 * 1024) throw Object.assign(new Error("技能元数据超过容量限制"), { code: "SKILL_SIZE" });
  const record = {
    id: String(input.id || "").slice(0, 80) || undefined,
    name, body, source,
    enabled: input.enabled !== false,
    when, description, frontmatter,
    projects: ids(input.projects), threads: ids(input.threads), paths: paths(input.paths),
  };
  for (const key of ["repository", "ref", "treeSHA", "sourcePath", "installedPath", "hash", "license", "url", "installedAt"]) {
    if (input[key] !== undefined) record[key] = structuredClone(input[key]);
  }
  if (input.resources !== undefined) {
    if (!Array.isArray(input.resources) || input.resources.length > 128) throw Object.assign(new Error("技能资源清单超过容量限制"), { code: "SKILL_SIZE" });
    record.resources = structuredClone(input.resources);
  }
  return record;
}

export function mergeSkills(saved = []) {
  const own = saved.filter((item) => item?.source!=='internal'&&item?.id && !BUNDLED_SKILLS.some((bundled) => bundled.id === item.id));
  const bundled = BUNDLED_SKILLS.map((item) => {
    const over = saved.find((skill) => skill.id === item.id) || {};
    const active=verifiedMaintenance(over),record=saved.find(s=>s.id==='internal:skill-maintenance-state')?.maintenance?.active?.[item.id];
    const accepted=active&&record?.version===active.version&&record?.contentDigest===active.contentDigest;
    return {
      ...item,
      ...(accepted?{body:active.body,activeMaintenance:active}:{}),
      ...(item.requiredPolicy?{userDisabled:over.enabled===false}:{}),
      enabled: over.enabled === undefined ? item.enabled !== false : over.enabled !== false,
      projects: ids(over.projects),
      threads: ids(over.threads),
      paths: paths(over.paths),
      source: item.source,
    };
  });
  return [...bundled, ...own.map((item) => ({ ...item, source: item.source || "user", projects: ids(item.projects), threads: ids(item.threads), paths: paths(item.paths), enabled: item.enabled !== false }))];
}

export function skillApplies(skill, { cwd = "", threadId = "", paths = [] } = {}) {
  if (skill.enabled === false) return false;
  if(skill.requiredPolicy && !arguments[1]?.personalizationPolicy?.can(skill.requiredPolicy,arguments[1]?.subject))return false;
  const projects = paths.length ? paths : skill.paths || [];
  const threads = skill.threads || [];
  const restrictedProjects = projects.length > 0 || (skill.projects || []).length > 0;
  // A removed/unknown project must not turn a scoped skill into a global one.
  if (!restrictedProjects && !threads.length) return true;
  const here = cwd ? path.resolve(cwd) : "";
  const inProject = projects.some((item) => path.resolve(item) === here);
  const inThread = threads.includes(threadId);
  if (restrictedProjects && threads.length) return inProject || inThread;
  return restrictedProjects ? inProject : inThread;
}

export function parseSkillFile(text, filename = "技能") {
  const raw = String(text ?? "").replace(/^\uFEFF/, "").trim();
  if (!raw) throw Object.assign(new Error("文件是空的"), { code: "EMPTY" });
  let name = filename.replace(/\.(md|txt|skill)$/i, "").slice(0, 120);
  let body = raw;
  let metadata = {};
  const front = /^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/.exec(raw);
  if (front) {
    metadata = { ...frontFields(front[1]), frontmatter: front[1] };
    if (metadata.name) name = metadata.name;
    body = front[2].trim();
  } else if (raw.startsWith("# ")) {
    const [head, ...rest] = raw.split(/\r?\n/);
    name = head.replace(/^#\s*/, "").trim().slice(0, 120) || name;
    body = rest.join("\n").trim();
  }
  return skillRecord({ ...metadata, name, body, source: "user" });
}

export function parseSkillDraft(text) {
  const lines = String(text ?? "").trim().split(/\r?\n/);
  const name = lines.shift()?.replace(/^#\s*/, "").trim();
  const body = lines.join("\n").trim();
  return skillRecord({ name, body, source: "generated" });
}
