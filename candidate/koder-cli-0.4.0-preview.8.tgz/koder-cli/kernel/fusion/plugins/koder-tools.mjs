import { TOOL_PLUGINS } from "../../harness/plugins.mjs";

export const name = "koder-tools";
export const inject = ["tools"];

export function apply(ctx) {
  for (const tool of TOOL_PLUGINS) {
    ctx.tools.register({
      ...tool,
      source: "harness",
      execute(args) {
        return ctx.tools.runBuiltin(tool.name, args);
      },
    });
  }
  ctx.effect(() => () => {});
}
