import { createMcpRegistry } from './mcp-registry.mjs';
import { createMcpInstaller } from './mcp-install.mjs';
import { createMcpOAuth } from './mcp-oauth.mjs';
import { createConnectApps } from './connect-apps.mjs';
export async function createMcpRoutes({dir,lock,kernel,workbenchToken,registry=createMcpRegistry(),installer,oauth}={}) {
  installer ||= createMcpInstaller({dir,registry}); oauth ||= await createMcpOAuth({dir,lock});
  const installed = new Map(), plans = new Map();
  const serverById = async id => {
    const answer = await kernel.call('GET','/api/mcp');
    const item = answer.json?.servers?.find(item=>item.id===id);
    if (!item) throw Object.assign(new Error('没有这个 MCP 服务'),{status:404});
    return item;
  };
  const patch = async (id,body) => {
    const result=await kernel.call('PATCH','/api/mcp/'+id,body);
    if(result.status>=400)throw new Error(result.json?.error||'MCP 配置没有保存');return result.json;
  };
  async function dispatch(method,url,body={}, {signal,internalToken}={}) {
      const req={method,headers:{'x-koder-workbench':internalToken}},readBody=async()=>body;
      const internal=url.pathname==='/api/internal/mcp-headers';
      const authRoute=/^\/api\/mcp\/([a-f0-9-]{36})\/auth(?:\/(start|cancel|logout))?$/.exec(url.pathname);
      const registryRoute=/^\/api\/mcp\/(registry|install-plan|install)$/.exec(url.pathname);
      if (!internal && !authRoute && !registryRoute) return null;
      if(internal && (!workbenchToken||req.method!=='POST'||req.headers['x-koder-workbench']!==workbenchToken))throw Object.assign(new Error('MCP 授权桥凭证无效'),{status:403});
        let result;
        if(internal){
          const body=await readBody(req),entry=await serverById(body.id);
          if(entry.auth?.type!=='oauth'||!entry.url)throw new Error('此 MCP 没有启用 OAuth');
          result={headers:await oauth.headers(entry.id,{forceRefresh:body.forceRefresh===true,rejectedAuthorization:body.rejectedAuthorization,signal,url:entry.url})};
        } else if(authRoute){
          const [,id,action]=authRoute,entry=await serverById(id);
          if(!action && req.method==='GET')result=await oauth.status(id);
          else if(req.method==='POST' && action){
            const body=await readBody(req);
            if(action==='start'){
              if(!['http','streamable-http'].includes(entry.transport))throw new Error('只有远程 MCP 使用浏览器授权');
              await patch(id,{enabled:false,auth:{type:'oauth'}});
              result=await oauth.start({id,url:entry.url,clientId:typeof body.clientId==='string'?body.clientId:undefined,scope:typeof body.scope==='string'?body.scope:'',signal});
            } else if(action==='cancel'){await oauth.cancel(id,{flowId:body.flowId});result=await oauth.status(id);}
            else {await patch(id,{enabled:false});result=await oauth.logout(id);}
          } else throw Object.assign(new Error('没有这项 MCP 授权操作'),{status:405});
        } else if(registryRoute[1]==='registry' && req.method==='GET'){
          result=await registry.search({query:url.searchParams.get('q')||'',cursor:url.searchParams.get('cursor')||'',signal});
        } else if(req.method==='POST' && registryRoute[1]==='install-plan'){
          const body=await readBody(req);result=await installer.plan({name:body.name,version:body.version,packageIndex:body.packageIndex,signal});
          if(plans.size>=128)plans.delete(plans.keys().next().value);plans.set(result.planId,result);
        } else if(req.method==='POST' && registryRoute[1]==='install'){
          const body=await readBody(req);
          if(body.confirmed!==true)throw new Error('请先查看并确认安装来源及版本');
          const plan=plans.get(body.planId);if(!plan)throw new Error('安装计划已过期');
          const env={};for(const field of plan.requiredInputs||[]){const value=body.env?.[field.name];if(field.isRequired && !value)throw new Error('缺少配置：'+field.name);if(value!==undefined){if(typeof value!=='string'||value.length>16384||value.includes('\0'))throw new Error('配置值不合法');env[field.name]=value;}}
          if(!installed.has(body.planId)){
            const job=(async()=>{
              const entry=await installer.install({planId:body.planId,confirmed:true,bin:body.bin,args:body.args,signal});
              signal.throwIfAborted();
              const response=await kernel.call('POST','/api/mcp',{...entry,env,enabled:false,allowAll:false,allowed:[]});
              if(response.status>=400)throw new Error(response.json?.error||'MCP 已下载但没有登记成功');return response.json;
            })();
            installed.set(body.planId,job);job.catch(()=>installed.delete(body.planId));
            if(installed.size>128)installed.delete(installed.keys().next().value);
          }
          result=await installed.get(body.planId);
        } else throw Object.assign(new Error('没有这项 MCP 操作'),{status:405});
        return {status:200,json:result};
  }
  return {
    dispatch,
    async handle(req,res,url,{readBody,send}) {
      if(url.pathname!=='/api/internal/mcp-headers'&&!/^\/api\/mcp\/([a-f0-9-]{36}\/auth(?:\/(start|cancel|logout))?|registry|install-plan|install)$/.test(url.pathname))return false;
      const controller=new AbortController(),cancel=()=>{if(!res.writableEnded)controller.abort();};res.once('close',cancel);
      try {
        const result=await dispatch(req.method,url,await readBody(req),{signal:controller.signal,internalToken:req.headers['x-koder-workbench']});
        if(!result)return false;
        if(!res.destroyed)send(res,result.status,result.json);return true;
      } finally {res.off('close',cancel);}
    },
    connectApps: createConnectApps({ kernel, oauth }),
    logout:id=>oauth.logout(id),
    async close(){const results=await Promise.allSettled([installer.close(),oauth.close()]);const failures=results.filter(r=>r.status==='rejected'||r.value?.cleanupComplete===false);if(failures.length)throw Object.assign(new Error('MCP 授权或安装清理未确认'),{code:'MCP_CLEANUP',cleanupComplete:false});return {closed:true,cleanupComplete:true};},
  };
}
