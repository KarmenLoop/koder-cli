import crypto from 'node:crypto';
const error=code=>Object.assign(new Error(code),{code});
const hostKey=h=>JSON.stringify([h?.uid,h?.executable,h?.signature??null]);
const safeCode=e=>/CERT|TLS|SSL/.test(String(e?.code||''))?'COMPUTER_TLS_ERROR':/PROXY|ENOTFOUND|EAI_AGAIN/.test(String(e?.code||''))?'COMPUTER_NETWORK_ERROR':/^[A-Z0-9_]{1,80}$/.test(e?.code||'')&&e.code.startsWith('COMPUTER_')?e.code:'COMPUTER_DRIVER_UNAVAILABLE';
export function createComputerDriver({capabilities,transport,hostIdentity,timeoutMs=20000}={}) {
 if(!hostIdentity||hostIdentity.uid===undefined||typeof hostIdentity.executable!=='string'||!hostIdentity.executable||typeof hostIdentity.signature!=='string'||!hostIdentity.signature||!Number.isFinite(timeoutMs)||timeoutMs<1||timeoutMs>60000)throw error('COMPUTER_HOST_INVALID');
 const host=structuredClone(hostIdentity),key=hostKey(host),active=new Set(),allowedActions=new Set(['click','type','press','scroll','select','focus']);
 let closed=false,snapshot=null,ticket=0,closePromise=null;
 async function call(method,input){
  if(closed)throw error('COMPUTER_DRIVER_CLOSED');if(typeof transport?.[method]!=='function')throw error('COMPUTER_DRIVER_MISSING');
  const controller=new AbortController();active.add(controller);let timer;
  try{return await new Promise((resolve,reject)=>{
   let settled=false;const finish=(fn,value)=>{if(settled)return;settled=true;clearTimeout(timer);controller.signal.removeEventListener('abort',abort);fn(value);};
   const abort=()=>finish(reject,controller.signal.reason||error('COMPUTER_DRIVER_CLOSED'));controller.signal.addEventListener('abort',abort,{once:true});
   timer=setTimeout(()=>controller.abort(error('COMPUTER_DRIVER_TIMEOUT')),timeoutMs);
   Promise.resolve().then(()=>transport[method]({...input,signal:controller.signal})).then(value=>finish(resolve,value),e=>finish(reject,error(safeCode(e))));
  });}finally{active.delete(controller);clearTimeout(timer);}
 }
 async function describe(){
  const meta=await call('inspect');if(hostKey(meta?.hostIdentity)!==key)throw error('COMPUTER_HOST_CHANGED');
  if(meta.available!==true)throw error('COMPUTER_DRIVER_UNAVAILABLE');
  if(!['desktop','browser'].includes(meta.kind)||typeof meta.generation!=='string'||!meta.generation||!Number.isSafeInteger(meta.revision)||typeof meta.targetId!=='string')throw error('COMPUTER_DRIVER_PROTOCOL');
  return meta;
 }
 const authorize=meta=>capabilities.authorize({tool:meta.kind==='browser'?'browser.act':'desktop.act'});
 async function capture({app=null}={}){
  const selected=++ticket;snapshot=null;
  if(app!==null&&(typeof app!=='string'||app.length>200||/[\x00-\x1f\x7f]/.test(app)))throw error('COMPUTER_TARGET_INVALID');
  const before=await describe();await authorize(before);const raw=await call('capture',{app});const after=await describe();await authorize(after);
  if(closed||ticket!==selected)throw error('COMPUTER_SNAPSHOT_STALE');
  if(hostKey(raw?.hostIdentity)!==key)throw error('COMPUTER_HOST_CHANGED');
  if(raw.generation!==after.generation||raw.revision!==after.revision||raw.targetId!==after.targetId||(app!==null&&raw.targetId!==app))throw error('COMPUTER_SNAPSHOT_STALE');
  if(!Array.isArray(raw.elements)||raw.elements.length>4000||raw.elements.some(e=>typeof e?.id!=='string'||!e.id||e.id.length>200)||new Set(raw.elements.map(e=>e.id)).size!==raw.elements.length)throw error('COMPUTER_DRIVER_PROTOCOL');
  snapshot={snapshotId:crypto.randomUUID(),hostIdentity:host,generation:raw.generation,revision:raw.revision,targetId:raw.targetId,kind:after.kind,
   elements:raw.elements.map(e=>({id:e.id,role:String(e.role||'').slice(0,80),label:String(e.label||'').slice(0,512)})),text:String(raw.text||'').slice(0,16000),capturedAt:Date.now()};
  return structuredClone(snapshot);
 }
 return {
  async inspect(){try{const meta=await describe();return {available:true,kind:meta.kind,hostIdentity:host,generation:meta.generation,targetId:meta.targetId,revision:meta.revision,actions:(meta.actions||[]).filter(a=>allowedActions.has(a))};}catch(e){return {available:false,hostIdentity:host,reasonCode:safeCode(e)};}},
  capture,
  async act({snapshotId,element,action,args={}}={}){
   const before=snapshot;if(!before||snapshotId!==before.snapshotId)throw error('COMPUTER_SNAPSHOT_STALE');
   if(typeof element!=='string'||!before.elements.some(e=>e.id===element))throw error('COMPUTER_ELEMENT_INVALID');
   if(!allowedActions.has(action)||!args||typeof args!=='object'||Array.isArray(args)||Object.keys(args).some(k=>!['text','key','keys','dx','dy','value'].includes(k))||Buffer.byteLength(JSON.stringify(args))>20000)throw error('COMPUTER_ACTION_INVALID');
   const meta=await describe();await authorize(meta);
   if(snapshot!==before||meta.generation!==before.generation||meta.revision!==before.revision||meta.targetId!==before.targetId)throw error('COMPUTER_SNAPSHOT_STALE');
   if(!meta.actions?.includes(action))throw error('COMPUTER_ACTION_UNSUPPORTED');
   snapshot=null;++ticket;
   try{
    const result=await call('act',{generation:before.generation,revision:before.revision,targetId:before.targetId,element,action,args});
    if(result?.ok!==true)throw error('COMPUTER_ACTION_UNKNOWN');
    const after=await capture({app:before.targetId});return {ok:true,before,after};
   }catch(e){const unknown=error('COMPUTER_ACTION_UNKNOWN');unknown.causeCode=safeCode(e);throw unknown;}
  },
  close(){if(closePromise)return closePromise;closed=true;snapshot=null;++ticket;for(const controller of active)controller.abort(error('COMPUTER_DRIVER_CLOSED'));closePromise=Promise.resolve().then(()=>transport?.close?.()).catch(()=>{});return closePromise;},
 };
}
