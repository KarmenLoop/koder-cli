import fs from 'node:fs/promises';
import {constants} from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import {openInside,resolveInside,safeRelative,matchesOpenedPath} from '../harness/paths.mjs';
const fail=code=>{throw Object.assign(new Error(code),{code});};
const fingerprint=s=>`${s.dev}:${s.ino}:${s.size}:${s.mtimeMs}:${s.ctimeMs}`;
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const nofollow=constants.O_NOFOLLOW||0;

export function createAuthorizedFiles({capabilities,fsImpl=fs,processIsAlive=async pid=>{try{process.kill(pid,0);return true;}catch(e){return e.code!=='ESRCH';}}}={}) {
 const f=fsImpl,cursors=new Map();
 async function locate(tool,input){const grant=await capabilities.authorize({tool,path:input});const rel=path.relative(grant.root,grant.path);safeRelative(rel);return {...grant,rel};}
 async function parentFor(located){
  const parent=path.dirname(located.path),opened=await openInside({root:located.root,target:parent},constants.O_RDONLY|(constants.O_DIRECTORY||0));
  return {async check(){await opened.recheck();if(!await matchesOpenedPath(parent,opened.file,{fsImpl:f}))fail('FILE_PARENT_CHANGED');},close:opened.close,parent};
 }
 async function readHeld(located){
  const parent=await parentFor(located);let file;
  try{file=await f.open(located.path,constants.O_RDONLY|nofollow);await parent.check();const info=await file.stat();if(!info.isFile()||info.nlink!==1)fail('FILE_KIND_UNSUPPORTED');if(!await matchesOpenedPath(located.path,file,{fsImpl:f}))fail('FILE_CHANGED');return {file,info,parent,close:async()=>{await file.close();await parent.close();}};}
  catch(e){await file?.close();await parent.close();throw e;}
 }
 async function digestHeld(held,{collect=false,offset=0,maxBytes=65536,signal}={}){
  const sum=crypto.createHash('sha256'),parts=[];let position=0;
  while(true){signal?.throwIfAborted();const buffer=Buffer.alloc(65536),{bytesRead}=await held.file.read(buffer,0,buffer.length,position);if(!bytesRead)break;const bytes=buffer.subarray(0,bytesRead);sum.update(bytes);
   if(collect&&position+bytesRead>offset&&position<offset+maxBytes)parts.push(bytes.subarray(Math.max(0,offset-position),Math.min(bytesRead,offset+maxBytes-position)));position+=bytesRead;
   if(position>1024*1024*1024)fail('FILE_HASH_LIMIT');
  }
  await held.parent.check();if(fingerprint(await held.file.stat())!==fingerprint(held.info))fail('FILE_CHANGED');
  return {sha256:sum.digest('hex'),content:Buffer.concat(parts),size:position};
 }
 async function currentDigest(located){
  try{const held=await readHeld(located);try{return await digestHeld(held);}finally{await held.close();}}catch(e){if(e.code==='ENOENT')return null;throw e;}
 }
 async function removeOwned(file,handle){if(await matchesOpenedPath(file,handle,{fsImpl:f}).catch(()=>false))await f.unlink(file);}
 async function recoverLock(lock,parent){
  let held;try{
   held=await f.open(lock,constants.O_RDONLY|nofollow);const before=await held.stat();
   if(!before.isFile()||before.size<1||before.size>4096||(process.getuid&&before.uid!==process.getuid()))return false;
   const marker=JSON.parse(await held.readFile('utf8'));
   if(marker.version!==1||marker.purpose!=='koder-authorized-write'||marker.host!==os.hostname()||!Number.isSafeInteger(marker.pid)||marker.pid<1||!(/^[a-f0-9-]{36}$/.test(marker.id||'')))return false;
   if(await processIsAlive(marker.pid)!==false)return false;
   await parent.check();if(fingerprint(await held.stat())!==fingerprint(before))return false;
   if(!await matchesOpenedPath(lock,held,{fsImpl:f}))return false;
   await f.unlink(lock);return true;
  }catch{return false;}finally{await held?.close();}
 }
 async function save(input,producer,signal){
  const located=await locate('file.write',input.path),parent=await parentFor(located);
  const lock=path.join(parent.parent,'.koder-file-'+hash(located.path).slice(0,24)+'.lock'),temp=path.join(parent.parent,'.koder-write-'+crypto.randomUUID()+'.tmp');
  let lockHandle,tempHandle,renamed=false;
  try{
   signal?.throwIfAborted();await parent.check();
   try{lockHandle=await f.open(lock,constants.O_WRONLY|constants.O_CREAT|constants.O_EXCL|nofollow,0o600);}catch(e){if(e.code!=='EEXIST')throw e;if(!await recoverLock(lock,parent))fail('FILE_BUSY');try{lockHandle=await f.open(lock,constants.O_WRONLY|constants.O_CREAT|constants.O_EXCL|nofollow,0o600);}catch{fail('FILE_BUSY');}}
   await parent.check();if(!await matchesOpenedPath(lock,lockHandle,{fsImpl:f}))fail('FILE_BUSY');await lockHandle.writeFile(JSON.stringify({version:1,purpose:'koder-authorized-write',host:os.hostname(),pid:process.pid,id:crypto.randomUUID()}));await lockHandle.sync();
   const before=await currentDigest(located);if((before?.sha256??null)!==(input.expectedDigest??null))fail('FILE_VERSION_CONFLICT');
   tempHandle=await f.open(temp,constants.O_WRONLY|constants.O_CREAT|constants.O_EXCL|nofollow,0o600);await parent.check();
   const sum=crypto.createHash('sha256');let bytes=0;
   for await(const chunk of producer()){
    signal?.throwIfAborted();const data=Buffer.from(chunk);bytes+=data.length;if(bytes>1024*1024*1024)fail('FILE_COPY_LIMIT');sum.update(data);
    let offset=0;while(offset<data.length){const result=await tempHandle.write(data,offset,data.length-offset);if(!result.bytesWritten)fail('FILE_WRITE_STALLED');offset+=result.bytesWritten;}
   }
   await tempHandle.sync();await parent.check();await capabilities.authorize({tool:'file.write',path:located.path});
   if(((await currentDigest(located))?.sha256??null)!==(input.expectedDigest??null))fail('FILE_VERSION_CONFLICT');
   signal?.throwIfAborted();await f.rename(temp,located.path);renamed=true;
   await parent.check();if(!await matchesOpenedPath(located.path,tempHandle,{fsImpl:f}))fail('FILE_READBACK_FAILED');
   const expected=sum.digest('hex'),readback=await currentDigest(located);if(readback?.sha256!==expected||readback.size!==bytes)fail('FILE_READBACK_FAILED');
   return {path:located.path,bytes,sha256:expected,status:'saved'};
  }finally{
   try{if(tempHandle&&!renamed)await removeOwned(temp,tempHandle);if(lockHandle)await removeOwned(lock,lockHandle);}
   finally{try{await tempHandle?.close();}finally{try{await lockHandle?.close();}finally{await parent.close();}}}
  }
 }
 const api={
  async materialize({path:input,maxBytes,signal}={}){
   if(!Number.isSafeInteger(maxBytes)||maxBytes<1||maxBytes>50*1024*1024)fail('FILE_SIZE_UNSUPPORTED');const located=await locate('file.read',input),held=await readHeld(located);
   try{if(held.info.size>maxBytes)fail('FILE_SIZE_UNSUPPORTED');const result=await digestHeld(held,{collect:true,maxBytes,signal});await capabilities.authorize({tool:'file.read',path:located.path});return {path:located.path,name:path.basename(located.path),bytes:result.size,sha256:result.sha256,content:result.content};}
   finally{await held.close();}
  },
  async read({path:input,offset=0,maxBytes=65536,signal}={}){
   if(!Number.isSafeInteger(offset)||offset<0||!Number.isInteger(maxBytes)||maxBytes<1||maxBytes>1048576)fail('FILE_READ_INVALID');
   const located=await locate('file.read',input),held=await readHeld(located);
   try{const result=await digestHeld(held,{collect:true,offset,maxBytes,signal});await capabilities.authorize({tool:'file.read',path:located.path});const bytes=result.content.length;
    return {path:located.path,bytes,sha256:result.sha256,status:'read',encoding:'base64',contentBase64:result.content.toString('base64'),text:result.content.toString('utf8'),nextOffset:offset+bytes<result.size?offset+bytes:null,size:result.size};
   }finally{await held.close();}
  },
  write({path:input,content,expectedDigest,signal}={}){if(typeof content!=='string'&&!Buffer.isBuffer(content))fail('FILE_CONTENT_INVALID');const data=Buffer.from(content);if(data.length>1048576)fail('FILE_CONTENT_TOO_LARGE');return save({path:input,expectedDigest},async function*(){yield data;},signal);},
  async copy({from,to,expectedDigest,signal}={}){
   const source=await locate('file.read',from),held=await readHeld(source);
   try{const original=fingerprint(held.info);const receipt=await save({path:to,expectedDigest},async function*(){let offset=0;while(true){signal?.throwIfAborted();const buffer=Buffer.alloc(65536),{bytesRead}=await held.file.read(buffer,0,buffer.length,offset);if(!bytesRead)break;offset+=bytesRead;yield buffer.subarray(0,bytesRead);}await held.parent.check();if(fingerprint(await held.file.stat())!==original)fail('FILE_SOURCE_CHANGED');await capabilities.authorize({tool:'file.read',path:source.path});},signal);return {...receipt,status:'copied'};}
   finally{await held.close();}
  },
  async move(input){
   if(typeof input?.from==='string'&&typeof input?.to==='string'&&path.resolve(input.from)===path.resolve(input.to))fail('FILE_SAME_PATH');
   const source=await locate('file.move',input.from),original=await currentDigest(source),receipt=await api.copy(input);
   await capabilities.authorize({tool:'file.move',path:source.path});if((await currentDigest(source))?.sha256!==original?.sha256)fail('FILE_SOURCE_CHANGED');
   const parent=await parentFor(source);try{await parent.check();await f.unlink(source.path);await parent.check();}finally{await parent.close();}
   return {...receipt,status:'moved'};
  },
  async search({query='',cursor=null,limit=100,signal}={}){
   if(typeof query!=='string'||query.length>1024||!Number.isInteger(limit)||limit<1||limit>500)fail('FILE_SEARCH_INVALID');signal?.throwIfAborted();
   let scan=cursor&&cursors.get(cursor);if(cursor&&!scan)fail('FILE_SEARCH_CURSOR_INVALID');
   if(!scan){const status=await capabilities.status(),roots=status.find(c=>c.name==='files.search'&&c.state==='granted')?.roots||[];if(!roots.length)fail('COMPUTER_PERMISSION_REQUIRED');scan={query,queue:roots.map(root=>({path:root,root})),skipped:[],scanned:0};}
   if(scan.query!==query)fail('FILE_SEARCH_CURSOR_INVALID');if(cursor)cursors.delete(cursor);
   const items=[];let budget=5000;
   while(scan.queue.length&&items.length<limit&&budget-->0){signal?.throwIfAborted();const next=scan.queue.shift();await capabilities.authorize({tool:'file.search',path:next.path});let info;
    try{info=await f.lstat(next.path);if(info.isSymbolicLink())continue;if(info.isDirectory()){const parent=await openInside({root:next.root,target:next.path},constants.O_RDONLY|(constants.O_DIRECTORY||0));try{const children=await f.readdir(next.path,{withFileTypes:true});await parent.recheck();scan.queue.push(...children.filter(c=>!c.isSymbolicLink()&&!['.git','node_modules','.ssh','.aws','.gnupg','.koder-cli'].includes(c.name)).map(c=>({path:path.join(next.path,c.name),root:next.root})));}finally{await parent.close();}continue;}}
    catch(e){if(scan.skipped.length<20)scan.skipped.push({path:next.path,code:e.code||'FILE_ACCESS_DENIED'});continue;}
    scan.scanned++;if(info.isFile()&&path.basename(next.path).toLocaleLowerCase().includes(query.toLocaleLowerCase()))items.push({path:next.path,size:info.size,modifiedAt:info.mtimeMs});
   }
   const nextCursor=scan.queue.length?crypto.randomUUID():null;if(nextCursor){if(cursors.size>=128)cursors.delete(cursors.keys().next().value);cursors.set(nextCursor,scan);}
   return {items,nextCursor,hasMore:Boolean(nextCursor),scanned:scan.scanned,skipped:scan.skipped,contentIndexed:false};
  },
 };
 return api;
}
