import { readFileSync } from "node:fs";
import { newestFirst } from "../public/model-order.mjs";

function model(entry) {
  return {
    protocol: "openai",
    auth: "bearer",
    chatPath: "/chat/completions",
    sendApiKeyHeader: false,
    ...entry,
  };
}

export const MODEL_PRESETS = [
  model({
    id: "zhipu",
    name: "智谱 GLM",
    vendor: "智谱",
    region: "cn",
    baseUrl: "https://open.bigmodel.cn/api/paas/v4",
    model: "glm-5.3",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "OpenAI 兼容。默认用最新的 GLM，可改成你账号里开通的型号。上下文按所选型号的规格裁剪。",
  }),
  model({
    id: "qwen",
    name: "通义千问",
    vendor: "阿里云百炼",
    region: "cn",
    baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",
    model: "qwen-plus",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "百炼兼容模式。若控制台给了业务空间域名，把地址换成那个域名。默认模型 qwen-plus。",
  }),
  model({
    id: "mimo",
    name: "小米 MiMo",
    vendor: "小米",
    region: "cn",
    baseUrl: "https://api.xiaomimimo.com/v1",
    model: "mimo-v2.6-pro",
    contextWindow: 131072,
    maxOutput: 8192,
    sendApiKeyHeader: true,
    detail: "按量接口。同时发送 Authorization: Bearer 和 api-key。Token Plan 需要换成控制台给出的地址。",
  }),
  model({
    id: "kimi",
    name: "Kimi",
    vendor: "月之暗面",
    region: "cn",
    baseUrl: "https://api.moonshot.cn/v1",
    model: "moonshot-v1-128k",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "Moonshot OpenAI 兼容。默认 moonshot-v1-128k，可改成已开通的 Kimi 模型。",
  }),
  model({
    id: "doubao",
    name: "豆包",
    vendor: "火山方舟",
    region: "cn",
    baseUrl: "https://ark.cn-beijing.volces.com/api/v3",
    model: "",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "模型栏要填火山方舟的接入点 ID，形如 ep-。地址是北京地域的 OpenAI 兼容接口。",
  }),
  model({
    id: "hunyuan",
    name: "腾讯混元",
    vendor: "腾讯云",
    region: "cn",
    baseUrl: "https://api.hunyuan.cloud.tencent.com/v1",
    model: "hunyuan-turbos-latest",
    contextWindow: 32768,
    maxOutput: 4096,
    detail: "混元 OpenAI 兼容。默认 hunyuan-turbos-latest。",
  }),
  model({
    id: "stepfun",
    name: "阶跃星辰",
    vendor: "阶跃星辰",
    region: "cn",
    baseUrl: "https://api.stepfun.com/v1",
    model: "step-2-16k",
    contextWindow: 16384,
    maxOutput: 4096,
    detail: "StepFun OpenAI 兼容。默认 step-2-16k。",
  }),
  model({
    id: "yi",
    name: "零一万物",
    vendor: "零一万物",
    region: "cn",
    baseUrl: "https://api.lingyiwanwu.com/v1",
    model: "yi-lightning",
    contextWindow: 16384,
    maxOutput: 4096,
    detail: "零一万物 OpenAI 兼容。默认 yi-lightning。",
  }),
  model({
    id: "baichuan",
    name: "百川",
    vendor: "百川智能",
    region: "cn",
    baseUrl: "https://api.baichuan-ai.com/v1",
    model: "Baichuan4",
    contextWindow: 32768,
    maxOutput: 4096,
    detail: "百川 OpenAI 兼容。默认 Baichuan4。",
  }),
  model({
    id: "spark",
    name: "讯飞星火",
    vendor: "科大讯飞",
    region: "cn",
    baseUrl: "https://spark-api-open.xf-yun.com/v1",
    model: "4.0Ultra",
    contextWindow: 8192,
    maxOutput: 2048,
    detail: "星火 OpenAI 兼容 HTTP 接口。默认 4.0Ultra，以控制台开通的模型名为准。",
  }),
  model({
    id: "qianfan",
    name: "百度千帆",
    vendor: "百度智能云",
    region: "cn",
    baseUrl: "https://qianfan.baidubce.com/v2",
    model: "ernie-4.0-8k",
    contextWindow: 8192,
    maxOutput: 2048,
    detail: "千帆 v2 OpenAI 兼容。默认 ernie-4.0-8k，可改成已开通的模型。",
  }),
  model({
    id: "minimax",
    name: "MiniMax",
    vendor: "MiniMax",
    region: "global",
    baseUrl: "https://api.minimax.io/v1",
    model: "MiniMax-M2.5",
    contextWindow: 204800,
    maxOutput: 8192,
    detail: "国际接口，OpenAI 兼容，Authorization: Bearer。上下文按所选型号的规格裁剪。",
  }),
  model({
    id: "minimax-cn",
    name: "MiniMax 国内",
    vendor: "MiniMax",
    region: "cn",
    baseUrl: "https://api.minimaxi.com/v1",
    model: "MiniMax-M2.5",
    contextWindow: 204800,
    maxOutput: 8192,
    detail: "国内主机。协议与国际 MiniMax 相同。上下文按所选型号的规格裁剪。",
  }),
  model({
    id: "deepseek",
    name: "DeepSeek",
    vendor: "深度求索",
    region: "cn",
    baseUrl: "https://api.deepseek.com/v1",
    model: "deepseek-chat",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "OpenAI 兼容。上下文按所选型号的规格裁剪。",
  }),
  model({
    id: "chatgpt",
    name: "ChatGPT",
    vendor: "OpenAI",
    region: "global",
    baseUrl: "https://api.openai.com/v1",
    model: "gpt-4.1",
    contextWindow: 1047576,
    maxOutput: 32768,
    detail: "OpenAI Chat Completions。上下文按所选型号的规格裁剪。",
  }),
  model({
    id: "claude",
    name: "Claude",
    vendor: "Anthropic",
    region: "global",
    protocol: "anthropic",
    auth: "x-api-key",
    chatPath: "/messages",
    baseUrl: "https://api.anthropic.com/v1",
    model: "claude-sonnet-4-5",
    contextWindow: 200000,
    maxOutput: 8192,
    detail: "Anthropic Messages。请求头使用 x-api-key 和 anthropic-version。上下文按所选型号的规格裁剪。",
  }),
  model({
    id: "gemini",
    name: "Gemini",
    vendor: "Google",
    region: "global",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
    model: "gemini-2.5-pro",
    contextWindow: 1048576,
    maxOutput: 8192,
    detail: "Gemini 的 OpenAI 兼容入口。默认 gemini-2.5-pro。",
  }),
  model({
    id: "grok",
    name: "Grok",
    vendor: "xAI",
    region: "global",
    baseUrl: "https://api.x.ai/v1",
    model: "grok-3",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "xAI OpenAI 兼容。默认 grok-3。",
  }),
  model({
    id: "mistral",
    name: "Mistral",
    vendor: "Mistral",
    region: "global",
    baseUrl: "https://api.mistral.ai/v1",
    model: "mistral-large-latest",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "Mistral OpenAI 兼容。默认 mistral-large-latest。",
  }),
  model({
    id: "groq",
    name: "Groq",
    vendor: "Groq",
    region: "global",
    baseUrl: "https://api.groq.com/openai/v1",
    model: "llama-3.3-70b-versatile",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "Groq OpenAI 兼容。默认 llama-3.3-70b-versatile。",
  }),
  model({
    id: "cerebras",
    name: "Cerebras",
    vendor: "Cerebras",
    region: "global",
    baseUrl: "https://api.cerebras.ai/v1",
    model: "gpt-oss-120b",
    contextWindow: 131072,
    maxOutput: 32768,
    detail: "Cerebras 推理云，OpenAI 兼容，速度快。",
  }),
  model({
    id: "nvidia",
    name: "NVIDIA NIM",
    vendor: "NVIDIA",
    region: "hub",
    baseUrl: "https://integrate.api.nvidia.com/v1",
    model: "deepseek-ai/deepseek-v3.1",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "NVIDIA 托管的开源模型，OpenAI 兼容。",
  }),
  model({
    id: "huggingface",
    name: "Hugging Face",
    vendor: "Hugging Face",
    region: "hub",
    baseUrl: "https://router.huggingface.co/v1",
    model: "openai/gpt-oss-120b",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "Hugging Face 推理路由，聚合多家开源模型，OpenAI 兼容。",
  }),
  model({
    id: "siliconflow",
    name: "硅基流动",
    vendor: "硅基流动",
    region: "hub",
    baseUrl: "https://api.siliconflow.cn/v1",
    model: "deepseek-ai/DeepSeek-V3",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "聚合多家模型的 OpenAI 兼容接口。默认 deepseek-ai/DeepSeek-V3，可改成平台上的其他模型名。",
  }),
  model({
    id: "openrouter",
    name: "OpenRouter",
    vendor: "OpenRouter",
    region: "hub",
    baseUrl: "https://openrouter.ai/api/v1",
    model: "openai/gpt-4.1",
    contextWindow: 1047576,
    maxOutput: 8192,
    detail: "聚合接口。模型名用厂商前缀，例如 openai/gpt-4.1。",
  }),
  model({
    id: "together",
    name: "Together",
    vendor: "Together",
    region: "hub",
    baseUrl: "https://api.together.xyz/v1",
    model: "meta-llama/Llama-3.3-70B-Instruct-Turbo",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "Together OpenAI 兼容。默认 Llama 3.3 70B，可改模型名。",
  }),
  model({
    id: "fireworks",
    name: "Fireworks",
    vendor: "Fireworks",
    region: "hub",
    baseUrl: "https://api.fireworks.ai/inference/v1",
    model: "accounts/fireworks/models/llama-v3p3-70b-instruct",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "Fireworks OpenAI 兼容。模型名以控制台给出的 accounts/fireworks/models/ 路径为准。",
  }),
  model({
    id: "perplexity",
    name: "Perplexity",
    vendor: "Perplexity",
    region: "global",
    baseUrl: "https://api.perplexity.ai",
    model: "sonar",
    contextWindow: 131072,
    maxOutput: 8192,
    detail: "Perplexity chat completions。默认 sonar。",
  }),
  model({
    id: "local",
    name: "本地兼容接口",
    vendor: "本机",
    region: "local",
    auth: "none",
    baseUrl: "http://127.0.0.1:11434/v1",
    model: "本地模型",
    contextWindow: 8192,
    maxOutput: 2048,
    detail: "本机 OpenAI 兼容服务，例如 Ollama 的 11434 或 LM Studio 的 1234。不需要云端密钥。对话里也可以用 local_model 工具直接调用。",
  }),
  model({
    id: "kilo-free",
    name: "Kilo 匿名免费",
    vendor: "Kilo",
    region: "free",
    auth: "none",
    baseUrl: "https://api.kilo.ai/api/gateway",
    model: "",
    contextWindow: 8192,
    maxOutput: 2048,
    detail: "官方文档允许的匿名免费模型。每 IP 每小时 200 次，不是无限量。不使用你已保存的其他密钥，也不会在失败后改走付费模型。",
  }),
  model({
    id: "custom",
    name: "其他兼容接口",
    vendor: "自定义",
    region: "local",
    baseUrl: "https://",
    model: "",
    contextWindow: 8192,
    maxOutput: 4096,
    detail: "任何 OpenAI 或 Anthropic 兼容地址。协议、模型和上下文窗口都可以改。",
  }),
];

export const MODEL_REGIONS = [
  { id: "all", label: "全部" },
  { id: "cn", label: "国内" },
  { id: "global", label: "国际" },
  { id: "hub", label: "聚合" },
  { id: "local", label: "本地" },
];

const LATEST = {
  zhipu: ["glm-5.3", "glm-4.6", "glm-4-plus", "glm-4-flash"],
  qwen: ["qwen3-max", "qwen-plus", "qwen-max", "qwen-turbo", "qwen-long"],
  mimo: ["mimo-v2.6-pro", "mimo-v2.5-pro"],
  kimi: ["kimi-k2", "moonshot-v1-128k", "moonshot-v1-32k"],
  doubao: [],
  hunyuan: ["hunyuan-turbos-latest", "hunyuan-t1-latest"],
  stepfun: ["step-2-16k", "step-1-8k"],
  yi: ["yi-lightning"],
  baichuan: ["Baichuan4", "Baichuan3-Turbo"],
  spark: ["4.0Ultra", "generalv3.5"],
  qianfan: ["ernie-4.0-8k", "ernie-3.5-8k"],
  minimax: ["MiniMax-M2.5", "MiniMax-M2"],
  "minimax-cn": ["MiniMax-M2.5", "MiniMax-M2"],
  deepseek: ["deepseek-chat", "deepseek-reasoner"],
  chatgpt: ["gpt-4.1", "gpt-4.1-mini", "gpt-4o"],
  claude: ["claude-sonnet-4-5", "claude-opus-4-1"],
  gemini: ["gemini-2.5-pro", "gemini-2.5-flash"],
  grok: ["grok-3", "grok-3-mini"],
  mistral: ["mistral-large-latest", "mistral-small-latest"],
  groq: ["llama-3.3-70b-versatile", "llama-3.1-8b-instant"],
  siliconflow: ["deepseek-ai/DeepSeek-V3", "Qwen/Qwen2.5-72B-Instruct"],
  openrouter: ["openai/gpt-4.1", "anthropic/claude-sonnet-4.5", "google/gemini-2.5-pro"],
  together: ["meta-llama/Llama-3.3-70B-Instruct-Turbo"],
  fireworks: ["accounts/fireworks/models/llama-v3p3-70b-instruct"],
  perplexity: ["sonar", "sonar-pro"],
  local: ["本地模型"],
};

// 获取密钥: where each service's API keys are made, checked against the
// vendors' own pages and documentation in October 2026. `notice` is the
// vendor's own announcement, shown above the form; `stopped` services are
// listed but not offered.
const KEY_PAGES = {
  zhipu: { url: "https://bigmodel.cn/usercenter/proj-mgmt/apikeys", steps: ["登录智谱 BigModel 开放平台", "打开 API Keys，点“添加新的 API Key”", "复制密钥"] },
  "kilo-free": { url: "https://kilo.ai/docs/gateway/authentication", steps: ["打开 Kilo 网关文档，确认匿名免费通道的条款和限额", "不需要创建密钥：在 Koder 模型设置里选「Kilo 匿名免费」即可使用", "用量以官方公告为准：每 IP 每小时 200 次，不是无限量"] },
  qwen: { url: "https://bailian.console.aliyun.com/cn-beijing/?tab=model#/api-key", steps: ["登录阿里云百炼，右上角地域选“华北2（北京）”", "在 API Key 页面点“创建 API Key”", "复制以 sk- 开头的密钥"] },
  mimo: { url: "https://platform.xiaomimimo.com/console/", steps: ["用小米账号登录 MiMo 开放平台的控制台", "打开 API Keys，创建按量付费的密钥", "复制以 sk- 开头的密钥"] },
  kimi: { url: "https://platform.kimi.com/console/api-keys", steps: ["登录 Kimi API 开放平台", "在 API Keys 页面新建密钥", "复制密钥"] },
  doubao: { url: "https://ark.volcengine.com/region:cn-beijing/apikey", steps: ["登录火山方舟控制台", "在 API Key 管理里点“创建 API Key”，复制密钥", "在在线推理里创建接入点，把 ep- 开头的接入点 ID 填到模型名"] },
  hunyuan: {
    url: "https://console.cloud.tencent.com/hunyuan/api-key",
    steps: ["用腾讯云主账号登录", "进入“立即接入管理”，点“创建 API KEY”", "复制密钥"],
    notice: "腾讯云公告：混元正在迁移到 TokenHub，原平台不再支持新购模型服务，已经购买的可以继续使用。",
  },
  stepfun: { url: "https://platform.stepfun.com/interface-key", steps: ["登录阶跃星辰开放平台，个人账号要先完成实名认证", "在 账户管理 → 接口密钥 里创建密钥", "复制密钥"] },
  yi: { stopped: true, notice: "零一万物开放平台已在 2026 年 9 月 3 日停止 API 调用，也不再接受新用户注册，这一家现在用不了。", steps: [] },
  baichuan: { url: "https://platform.baichuan-ai.com/console/apikey", steps: ["登录百川开放平台", "在 API Key 管理里创建密钥，马上复制，之后就看不到了", "完成实名认证后，密钥才生效"] },
  spark: { url: "https://console.xfyun.cn/", steps: ["登录讯飞开放平台控制台，创建一个应用", "在应用里选要用的星火版本", "复制“HTTP 服务接口认证信息”里的 APIPassword，不同版本的不一样"] },
  qianfan: { url: "https://console.bce.baidu.com/iam/#/iam/apikey/list", steps: ["登录百度智能云", "在 安全认证 → API Key 里创建，权限选千帆的模型服务", "复制密钥"] },
  minimax: { url: "https://platform.minimax.io/", steps: ["登录 MiniMax 国际开放平台", "打开 API Keys，点 Create new secret key", "复制密钥。国际和国内平台的密钥不能混用"] },
  "minimax-cn": { url: "https://platform.minimaxi.com/", steps: ["登录 MiniMax 开放平台（国内）", "在 接口密钥 里点“创建新的 API Key”", "复制密钥。国内和国际平台的密钥不能混用"] },
  deepseek: { url: "https://platform.deepseek.com/api_keys", steps: ["登录 DeepSeek 开放平台", "先充值，余额为零时调用会失败", "在 API keys 页面创建密钥并复制"] },
  chatgpt: { url: "https://platform.openai.com/api-keys", steps: ["登录 OpenAI Platform，需要先设置付款方式", "在 API keys 页面点 Create new secret key", "复制以 sk- 开头的密钥"] },
  claude: { url: "https://platform.claude.com/settings/keys", steps: ["登录 Claude Console", "在 Settings → API keys 里点 Create key", "复制以 sk-ant- 开头的密钥，它只显示一次"] },
  gemini: { url: "https://aistudio.google.com/apikey", steps: ["用 Google 账号登录 Google AI Studio", "点 Create API key", "复制密钥。2026 年 5 月 28 日以后新建的才是现在能用的类型"] },
  grok: { url: "https://console.x.ai/", steps: ["登录 xAI Console 并充值", "打开 API Keys，点 Create API Key", "复制密钥，它只显示一次"] },
  mistral: { url: "https://console.mistral.ai/api-keys", steps: ["登录 Mistral Studio", "在 API Keys 里点 Create new key", "复制密钥，它只显示一次"] },
  groq: { url: "https://console.groq.com/keys", steps: ["登录 GroqCloud", "点 Create API Key", "复制密钥"] },
  cerebras: { url: "https://cloud.cerebras.ai/", steps: ["登录 Cerebras Cloud", "在左侧打开 API Keys，点 Generate API Key", "复制密钥"] },
  nvidia: { url: "https://build.nvidia.com/settings/api-keys", steps: ["登录 build.nvidia.com", "点 Generate Key，范围选 Public API Endpoints", "复制以 nvapi- 开头的密钥"] },
  huggingface: { url: "https://huggingface.co/settings/tokens", steps: ["登录 Hugging Face", "在 Settings → Access Tokens 里点 New token，要能调用推理服务", "复制令牌"] },
  siliconflow: { url: "https://cloud.siliconflow.cn/account/ak", steps: ["登录硅基流动", "在 API 密钥页面点“新建 API 密钥”", "复制以 sk- 开头的密钥"] },
  openrouter: { url: "https://openrouter.ai/keys", steps: ["登录 OpenRouter", "在 Keys 页面点 Create Key，建议给它设一个额度上限", "复制以 sk-or- 开头的密钥"] },
  together: { url: "https://api.together.ai/settings/projects/~current/api-keys", steps: ["登录 Together AI", "在项目的 API Keys 页面点 Create key", "复制密钥，它只显示一次"] },
  fireworks: { url: "https://app.fireworks.ai/settings/users/api-keys", steps: ["登录 Fireworks", "在 Settings → API Keys 里点 Create API Key", "复制以 fw_ 开头的密钥"] },
  perplexity: {
    url: "https://console.perplexity.ai/settings/api-keys",
    steps: ["登录 Perplexity 的 API 控制台，先建一个项目", "在 API keys 里点 Generate API Key", "复制密钥"],
    notice: "Perplexity 在 2026 年 9 月 27 日停用了 Sonar 系列（这里默认的 sonar），改成了 Agent API，这个接口现在可能用不了。",
  },
  local: { steps: ["先在本机启动兼容 OpenAI 的服务，例如 Ollama", "多数本机服务不检查密钥，密钥栏填任意文字即可，例如 local", "把模型名改成本机实际加载的名字"] },
  custom: { steps: ["填服务方给你的接口地址、协议和模型名", "密钥从服务方的控制台获取"] },
};

// Per-model specs come from the pi-ai catalog (MIT) via
// scripts/sync-model-catalog.mjs; the hand-written lists above only add
// models that catalog does not know.
const synced = JSON.parse(readFileSync(new URL("./catalog-models.json", import.meta.url), "utf8"));
export const CATALOG_SOURCE = synced.source;

// MiniMax-M2 and M2.5 reject max_tokens above this. The synced catalog no longer
// lists them, so a newer model's output limit must not be sent in their place.
const MINIMAX_M2 = { contextWindow: 204800, maxOutput: 196608, reasoning: true };

for (const preset of MODEL_PRESETS) {
  preset.baseContextWindow = preset.contextWindow;
  preset.baseMaxOutput = preset.maxOutput;
  const { url, steps = [], notice, stopped } = KEY_PAGES[preset.id] ?? {};
  preset.key = url ? { url, steps } : { steps };
  if (notice) preset.notice = notice;
  if (stopped) preset.stopped = true;
  const specs = synced.presets[preset.id] || [];
  preset.specs = Object.fromEntries(specs.map((spec) => [spec.id, spec]));
  if (preset.id === "minimax" || preset.id === "minimax-cn") {
    for (const id of ["MiniMax-M2.5", "MiniMax-M2"]) {
      if (!preset.specs[id]) preset.specs[id] = { id, name: id, ...MINIMAX_M2 };
    }
  }
  const known = [...specs.map((spec) => spec.id), ...(LATEST[preset.id] || []), preset.model].filter(Boolean);
  const hub = preset.region === "hub";
  preset.models = [...new Set(hub ? known : newestFirst(known))];
  if (!hub && specs.length) preset.model = newestFirst(specs.map((spec) => spec.id))[0];
  const spec = preset.specs[preset.model];
  if (spec) {
    preset.contextWindow = spec.contextWindow;
    preset.maxOutput = spec.maxOutput;
  }
}

export function presetById(id) {
  return MODEL_PRESETS.find((item) => item.id === id) || null;
}

// USD per million tokens. Vendors are synced before resellers, so the first price seen is the vendor's own.
const PRICES = new Map();
for (const specs of Object.values(synced.presets)) {
  for (const spec of specs) if (spec.cost && !PRICES.has(spec.id)) PRICES.set(spec.id, spec.cost);
}

export function priceOf(model) {
  return PRICES.get(model) ?? null;
}
