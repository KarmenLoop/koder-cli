import path from 'node:path';

// Windows PowerShell -File keeps quotes and backslashes literally, so a JSON
// argument arrives broken and the data lock reports KEYCHAIN. Base64 has neither.
export function encodeHelperArg(value) {
  const text = String(value ?? "");
  if (!text.startsWith("{") && !text.startsWith("[")) return text;
  return Buffer.from(text, "utf8").toString("base64");
}

export function windowsPowerShell(env = process.env) {
  const root = env.SystemRoot || env.WINDIR;
  if (process.platform !== "win32" || !root) return "powershell.exe";
  return path.win32.join(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
}

// A PowerShell helper is started through powershell.exe. A Mac helper is the program itself.
export function helperArgv(helper, extra = [], env = process.env) {
  const list = Array.isArray(helper) ? helper : [helper];
  const [file, ...prefix] = list;
  if (String(file).toLowerCase().endsWith(".ps1")) {
    return [windowsPowerShell(env), ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", file, ...prefix, ...extra.map(encodeHelperArg)]];
  }
  return [file, [...prefix, ...extra]];
}

