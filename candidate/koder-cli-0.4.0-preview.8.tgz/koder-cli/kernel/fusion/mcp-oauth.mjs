// Authorization Code + PKCE for a catalog-approved provider only.
// Endpoints never come from a model, a page, or an uploaded screenshot.
import http from "node:http";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import {loadGammaConnectionConfig} from './gamma-config.mjs';
import {createOAuthRedirect} from './oauth-redirect.mjs';
import {appDigest} from './app-binding.mjs';

export function pkcePair() {
  const state = randomBytes(32).toString("base64url");
  const verifier = randomBytes(32).toString("base64url");
  return { state, verifier, challenge: createHash("sha256").update(verifier).digest("base64url") };
}

export function authorizationUrl({ clientId, authorizationEndpoint, redirectUri, challenge, state, resource, scope = "" }) {
  const authorization = new URL(authorizationEndpoint);
  const audience = new URL(resource);
  if (authorization.protocol !== "https:" || audience.protocol !== "https:") throw new Error("授权地址必须是 HTTPS");
  authorization.search = new URLSearchParams({
    response_type: "code",
    client_id: clientId,
    redirect_uri: redirectUri,
    code_challenge: challenge,
    code_challenge_method: "S256",
    state,
    resource: audience.href,
    ...(scope ? { scope } : {}),
  }).toString();
  return authorization.href;
}

export async function authorizeOAuth({
  clientId,
  authorizationEndpoint,
  tokenEndpoint,
  resource,
  scope = "",
  redirectPort = 0,
  openBrowser,
  fetchImpl = fetch,
  saveTokens,
  timeoutMs = 120_000,
} = {}) {
  const authorization = new URL(authorizationEndpoint);
  const token = new URL(tokenEndpoint);
  const audience = new URL(resource);
  if ([authorization, token, audience].some((url) => url.protocol !== "https:" || url.username || url.password)) {
    throw new Error("授权服务和资源地址必须是 HTTPS");
  }
  if (authorization.origin !== token.origin) throw new Error("授权页和换票地址必须同源");
  if (!clientId || typeof openBrowser !== "function" || typeof saveTokens !== "function") {
    throw new Error("OAuth 需要已审定的客户端、系统浏览器和加密保存");
  }
  const { state, verifier, challenge } = pkcePair();
  let acceptCode;
  let rejectCode;
  const codePromise = new Promise((resolve, reject) => {
    acceptCode = resolve;
    rejectCode = reject;
  });
  codePromise.catch(() => {});
  const server = http.createServer((req, res) => {
    const expectedHost = `127.0.0.1:${server.address().port}`;
    if (req.headers.host !== expectedHost || req.method !== "GET") {
      res.writeHead(400).end();
      return;
    }
    let url; try { url = new URL(req.url, `http://${expectedHost}`); } catch { res.writeHead(400).end(); return; }
    const candidate = url.searchParams.get("state") ?? "";
    const same = Buffer.byteLength(candidate) === Buffer.byteLength(state) && timingSafeEqual(Buffer.from(candidate), Buffer.from(state));
    if (url.pathname !== "/oauth/callback" || !same) {
      res.writeHead(400).end("回调无效");
      return;
    }
    const code = url.searchParams.get("code");
    res.setHeader("content-type", "text/plain; charset=utf-8");
    res.setHeader("cache-control", "no-store");
    if (url.searchParams.has("error") || !code) {
      res.writeHead(400).end("没有完成授权。");
      rejectCode(new Error("用户没有完成授权"));
      return;
    }
    res.end("已经收到授权，可以回到 Koder。");
    acceptCode(code);
  });
  let timer;
  try {
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(redirectPort, "127.0.0.1", resolve);
    });
    const redirectUri = `http://127.0.0.1:${server.address().port}/oauth/callback`;
    timer = setTimeout(() => rejectCode(new Error("授权超时")), timeoutMs);
    await openBrowser(authorizationUrl({
      clientId,
      authorizationEndpoint: authorization.href,
      redirectUri,
      challenge,
      state,
      resource: audience.href,
      scope,
    }));
    const code = await codePromise;
    const response = await fetchImpl(token.href, {
      method: "POST",
      redirect: "error",
      signal: AbortSignal.timeout(30_000),
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        client_id: clientId,
        redirect_uri: redirectUri,
        code_verifier: verifier,
        code,
        resource: audience.href,
      }),
    });
    if (!response.ok) throw new Error(`换票失败：HTTP ${response.status}`);
    const tokens = await response.json();
    if (typeof tokens.access_token !== "string" || !tokens.access_token || String(tokens.token_type).toLowerCase() !== "bearer") {
      throw new Error("授权服务没有返回可用的访问令牌");
    }
    await saveTokens({ ...tokens, issuer: authorization.origin, resource: audience.href, obtainedAt: Date.now() });
    return { authorized: true, expiresIn: tokens.expires_in ?? null, scope: tokens.scope ?? scope };
  } finally {
    clearTimeout(timer);
    await new Promise((resolve) => {
      server.close(resolve);
      server.closeAllConnections?.();
    });
  }
}

// Product OAuth uses the official SDK's discovery, PKCE, registration and
// refresh implementation. Only public state leaves this manager.
export async function createMcpOAuth({ dir, lock, fetchImpl = fetch, now = Date.now, timeoutMs = 120_000, authStore,gammaConfig=loadGammaConnectionConfig(),scope:connectionScope=null,currentScope=()=>connectionScope } = {}) {
  const { auth } = await import('@modelcontextprotocol/sdk/client/auth.js');
  const { createMcpAuthStore } = await import('./mcp-auth-store.mjs');
  const store = authStore || createMcpAuthStore({ dir, lock });
  const flows = new Map(), refreshes = new Map(), blocked = new Set(), starts = new Map(), revisions = new Map();
  let closed = false, cleanupFailure;
  const secure = (input) => {
    const url = new URL(input);
    if (url.protocol !== 'https:' || url.username || url.password) throw new Error('MCP OAuth 端点必须为 HTTPS');
    return url;
  };
  const safeFetch = (signal) => async (input, init = {}) => {
    secure(typeof input === 'string' || input instanceof URL ? input : input.url);
    const deadline = AbortSignal.timeout(30_000);
    const response = await fetchImpl(input, { ...init, redirect: 'error', signal: AbortSignal.any([deadline, ...(init.signal ? [init.signal] : []), ...(signal ? [signal] : [])]) });
    if (response.redirected) throw new Error('MCP OAuth 拒绝重定向');
    return response;
  };
  const cleanupError = () => (cleanupFailure ||= Object.assign(new Error('MCP 授权清理未确认'), {code:'MCP_CLEANUP',status:503,cleanupComplete:false}));
  const authRequired = () => Object.assign(new Error('MCP 需要重新授权'), { code: 'MCP_AUTH_REQUIRED', status: 409 });
  const publicError = error => error?.code === 'MCP_AUTH_REQUIRED' ? authRequired() : Object.assign(new Error('MCP 授权服务未完成请求，请重试或重新授权'), {code:'MCP_AUTH_FAILED',status:502});
  async function clearAborted(id, epoch) {
    try { await store.update(id, (r) => { if (r.authEpoch === epoch) { delete r.tokens; r.authorized = false; } }); }
    catch { throw cleanupError(); }
  }
  function provider(id, flow, context) {
    const guard = (r) => {
      context.signal.throwIfAborted();
      if (r.authEpoch !== context.epoch) throw authRequired();
    };
    const sameScope=async()=>{if(appDigest(await currentScope())!==appDigest(connectionScope))throw authRequired();};
    const read = async () => { await sameScope();const r = await store.get(id); guard(r); return r; };
    const write = async (change) => { await store.update(id, async(r) => {await sameScope();guard(r);change(r);}); context.signal.throwIfAborted(); };
    return {
      get redirectUrl() { return flow?.redirectUri || context.redirectUri; },
      get clientMetadata() { return { client_name: 'Koder', redirect_uris: flow ? [flow.redirectUri] : [], grant_types: ['authorization_code', 'refresh_token'], response_types: ['code'], token_endpoint_auth_method: 'none', ...(flow?.scope ? { scope: flow.scope } : {}) }; },
      state: () => flow?.state,
      clientInformation: async () => (await read()).client,
      saveClientInformation: (client) => write((r) => { r.client = client; r.registeredRedirect = flow?.redirectUri; }),
      tokens: async () => (await read()).tokens,
      saveTokens: (tokens) => write((r) => { r.tokens = { ...tokens, ...(!tokens.refresh_token && r.tokens?.refresh_token ? { refresh_token: r.tokens.refresh_token } : {}) }; r.obtainedAt = now(); r.expiresAt = Number.isFinite(tokens.expires_in) ? now() + tokens.expires_in * 1000 : null; r.authorized = true; }),
      redirectToAuthorization: async (url) => {
        secure(url); context.signal.throwIfAborted();
        if (!flow) throw authRequired();
        flow.authorizationUrl = String(url); flow.status = 'awaiting_authorization';
      },
      saveCodeVerifier: async (value) => { context.signal.throwIfAborted(); if (!flow) throw authRequired(); flow.verifier = value; },
      codeVerifier: async () => { context.signal.throwIfAborted(); if (!flow?.verifier) throw new Error('授权会话已失效'); return flow.verifier; },
      discoveryState: async () => (await read()).discovery,
      saveDiscoveryState: (state) => write((r) => { r.discovery = state; }),
      invalidateCredentials: (scope) => write((r) => { if (scope === 'all' || scope === 'tokens') { delete r.tokens; r.authorized = false; } if (scope === 'all' || scope === 'client') delete r.client; if (scope === 'all' || scope === 'discovery') delete r.discovery; if (flow && (scope === 'all' || scope === 'verifier')) delete flow.verifier; }),
    };
  }
  const publicFlow = (flow) => ({ flowId: flow.flowId, serverId: flow.id, status: flow.status, authorizationUrl: flow.status === 'awaiting_authorization' ? flow.authorizationUrl : undefined, expiresAt: flow.expiresAt, error: flow.error });
  async function cancelCurrent(id) {
    const flow = flows.get(id), refresh = refreshes.get(id);
    refresh?.controller.abort();
    if (flow && !['authorized', 'failed', 'cancelled'].includes(flow.status)) { flow.controller.abort(); flow.reject(new Error('授权已取消')); }
    const results = await Promise.allSettled([flow?.done, refresh?.job]);
    if (cleanupFailure || results.some(r => r.status === 'rejected' && r.reason?.cleanupComplete === false)) throw cleanupError();
  }
  async function cancel(id, {flowId} = {}) {
    // UI disposal may arrive after another view has started a new flow.
    // Only broad lifecycle cancellation invalidates an as-yet unpublished start.
    if (flowId !== undefined && (typeof flowId !== 'string' || flows.get(id)?.flowId !== flowId)) return {stale:true};
    const alreadyBlocked = blocked.has(id); blocked.add(id);
    revisions.set(id, (revisions.get(id) || 0) + 1);
    try {
      const results = await Promise.allSettled([cancelCurrent(id), starts.get(id)]);
      if (cleanupFailure || results.some(r => r.status === 'rejected' && r.reason?.cleanupComplete === false)) throw cleanupError();
      return {cleanupComplete:true};
    } finally { if (!alreadyBlocked) blocked.delete(id); }
  }
  async function startFlow({ id, url, clientId, scope = '', signal } = {}) {
    if (closed || cleanupFailure || blocked.has(id) || starts.has(id)) throw cleanupFailure || authRequired();
    secure(url);
    const gamma=new URL(url).hostname==='mcp.gamma.app';
    if(gamma&&gammaConfig.mcpRegistrationState!=='ready')throw Object.assign(new Error('Gamma MCP 需要服务方登记和公开 HTTPS 回调；API Key 不适用于 MCP'),{status:409,code:'APP_PROVIDER_SETUP_REQUIRED'});
    const revision = revisions.get(id) || 0;
    const checkStart = () => { if (closed || blocked.has(id) || (revisions.get(id) || 0) !== revision) throw authRequired(); signal?.throwIfAborted(); };
    await cancelCurrent(id); checkStart();
    const controller = new AbortController(), state = randomBytes(32).toString('base64url');
    let accept, reject;
    const code = new Promise((yes, no) => { accept = yes; reject = no; }); code.catch(() => {});
    const flow = { id, flowId: randomBytes(16).toString('hex'), state, scope, controller, reject, status: 'starting', expiresAt: now() + timeoutMs };
    const callback = http.createServer(async(req, res) => {
      const expected = `127.0.0.1:${callback.address().port}`;
      if (req.method !== 'GET' || req.headers.host !== expected) { res.writeHead(400).end(); return; }
      let incoming; try { incoming = new URL(req.url, `http://${expected}`); } catch { res.writeHead(400).end(); return; }
      if (flow.callbackConsumed || [...incoming.searchParams.keys()].some(key => incoming.searchParams.getAll(key).length !== 1)) { res.writeHead(400).end('Invalid callback'); return; }
      let acceptedCode;
      try{acceptedCode=await flow.redirectGuard.complete(new URL(req.url,flow.redirectUri).href);}catch{res.writeHead(400).end('Invalid callback');return;}
      flow.callbackConsumed = true;
      res.setHeader('content-type', 'text/plain; charset=utf-8'); res.setHeader('cache-control', 'no-store');
      res.end('授权已收到，请回到 Koder。'); accept(acceptedCode);
    });
    await new Promise((resolve, fail) => { callback.once('error', fail); callback.listen(gamma?gammaConfig.mcpListenPort:0, '127.0.0.1', resolve); });
    try { checkStart(); } catch (error) { await new Promise(resolve => callback.close(resolve)); throw error; }
    flow.redirectUri = gamma?gammaConfig.mcpRedirect:`http://127.0.0.1:${callback.address().port}/oauth/callback`;
    flow.redirectGuard=createOAuthRedirect({redirectUri:flow.redirectUri,scope:connectionScope,current:currentScope,now,timeoutMs});
    flow.redirectGuard.start({state,signal:controller.signal}).done.catch(reject);
    const abort = () => { controller.abort(); reject(new Error('授权已取消')); };
    signal?.addEventListener('abort', abort, { once: true });
    const timer = setTimeout(() => { controller.abort(); reject(new Error('授权超时')); }, timeoutMs);
    flows.set(id, flow);
    let preparedResolve, preparedReject;
    const prepared = new Promise((yes, no) => { preparedResolve = yes; preparedReject = no; });
    flow.done = (async () => {
      try {
        signal?.throwIfAborted();
        await store.update(id, (r) => { if (r.url && r.url !== url) { for (const k of Object.keys(r)) delete r[k]; } controller.signal.throwIfAborted(); r.url = url; r.authEpoch = flow.flowId; if (clientId) r.client = { client_id: clientId }; else if (r.registeredRedirect !== flow.redirectUri) delete r.client; delete r.tokens; r.authorized = false; });
        const p = provider(id, flow, { signal: controller.signal, epoch: flow.flowId });
        const result = await auth(p, { serverUrl: url, scope, fetchFn: safeFetch(controller.signal) });
        if (result === 'REDIRECT') {
          preparedResolve(publicFlow(flow));
          const authorizationCode = await code;
          controller.signal.throwIfAborted(); flow.status = 'exchanging';
          const outcome = await auth(p, { serverUrl: url, authorizationCode, scope, fetchFn: safeFetch(controller.signal) });
          if (outcome !== 'AUTHORIZED') throw new Error('授权未完成');
        }
        controller.signal.throwIfAborted(); flow.status = 'authorized'; preparedResolve(publicFlow(flow));
      } catch (error) {
        flow.status = controller.signal.aborted ? 'cancelled' : 'failed';
        let failure = controller.signal.aborted ? controller.signal.reason : publicError(error);
        try { if (controller.signal.aborted) await clearAborted(id, flow.flowId); }
        catch (cleanup) { failure = cleanup; flow.status = 'failed'; }
        flow.error = failure?.code === 'MCP_CLEANUP' ? 'MCP_CLEANUP' : controller.signal.aborted ? 'MCP_AUTH_CANCELLED' : publicError(error).code;
        // Always settle preparation, including failed cleanup during initial IO.
        preparedReject(failure);
        if (failure?.cleanupComplete === false) throw failure;
      }
      finally { clearTimeout(timer); signal?.removeEventListener('abort', abort);flow.redirectGuard.cancel(); delete flow.verifier; await new Promise((resolve) => { callback.close(resolve); callback.closeAllConnections(); }); }
    })();
    flow.done.catch(() => {});
    return prepared;
  }
  // Cancelling one HTTP caller only cancels its wait. Logout/cancel/close own
  // the shared refresh controller, so another caller cannot lose its token.
  function waitFor(job, signal) {
    if (!signal) return job;
    signal.throwIfAborted();
    return new Promise((resolve, reject) => {
      const abort = () => { cleanup(); reject(signal.reason); };
      const cleanup = () => signal.removeEventListener('abort', abort);
      signal.addEventListener('abort', abort, { once: true });
      job.then(value => { cleanup(); if (signal.aborted) reject(signal.reason); else resolve(value); }, error => { cleanup(); reject(error); });
    });
  }
  async function headers(id, { signal, forceRefresh = false, rejectedAuthorization, url } = {}) {
    if (closed || cleanupFailure || blocked.has(id) || starts.has(id)) throw cleanupFailure || authRequired();
    signal?.throwIfAborted();
    const revision = revisions.get(id) || 0;
    const initial = await store.get(id);
    signal?.throwIfAborted();
    if ((revisions.get(id) || 0) !== revision) throw authRequired();
    // Identity is checked before consulting the shared in-flight refresh.
    if (url && new URL(initial.url).href !== new URL(url).href) throw new Error('MCP OAuth 资源地址不匹配');
    if (closed || cleanupFailure || blocked.has(id) || starts.has(id)) throw cleanupFailure || authRequired();
    if (refreshes.has(id)) return waitFor(refreshes.get(id).job, signal);
    if (!initial.tokens?.access_token) throw authRequired();
    // A delayed 401 may refer to the token another request already rotated.
    // Never rotate the replacement again merely because the old request failed.
    if (forceRefresh && rejectedAuthorization && rejectedAuthorization !== `Bearer ${initial.tokens.access_token}`) forceRefresh = false;
    const controller = new AbortController();
    const lifetime = controller.signal;
    const entry = { controller, job: null };
    const job = (async () => {
      let record = initial;
      const epoch = record.authEpoch || randomBytes(16).toString('hex');
      try {
        if (!record.authEpoch) await store.update(id, (r) => { lifetime.throwIfAborted(); if (!r.tokens?.access_token) throw authRequired(); r.authEpoch ||= epoch; });
        if (forceRefresh || (record.expiresAt && record.expiresAt <= now() + 60_000)) {
          const result = await auth(provider(id, null, { signal: lifetime, epoch, redirectUri: record.registeredRedirect || 'http://127.0.0.1/oauth/callback' }), { serverUrl: record.url, fetchFn: safeFetch(lifetime) });
          if (result !== 'AUTHORIZED') throw authRequired();
          record = await store.get(id);
        }
        lifetime.throwIfAborted();
        if (!record.tokens?.access_token) throw authRequired();
        return { Authorization: `Bearer ${record.tokens.access_token}` };
      } catch (error) { if (lifetime.aborted) { await clearAborted(id, epoch); throw lifetime.reason; } throw publicError(error); }
    })();
    entry.job = job; refreshes.set(id, entry);
    const finish = () => { if (refreshes.get(id) === entry) refreshes.delete(id); };
    job.then(finish, finish);
    return waitFor(job, signal);
  }
  function start(options) {
    const id = options?.id;
    if (starts.has(id)) return Promise.reject(authRequired());
    const job = startFlow(options); starts.set(id, job);
    const finish = () => { if (starts.get(id) === job) starts.delete(id); };
    job.then(finish, finish);
    return job;
  }
  return {
    start, headers, cancel,
    async status(id) { if (cleanupFailure) throw cleanupFailure; const r = await store.get(id); return { serverId: id, authorized: Boolean(r.authorized && r.tokens?.access_token), expiresAt: r.expiresAt ?? null, scope: r.tokens?.scope || '', ...(flows.has(id) ? { flow: publicFlow(flows.get(id)) } : {}) }; },
    async logout(id) { if (blocked.has(id)) throw authRequired(); blocked.add(id); try { await cancel(id); await store.delete(id); flows.delete(id); return { authorized: false }; } finally { blocked.delete(id); } },
    async close() { closed = true; const results = await Promise.allSettled([...new Set([...flows.keys(), ...refreshes.keys(), ...starts.keys()])].map(id => cancel(id))); if (cleanupFailure || results.some(r => r.status === 'rejected')) throw cleanupError(); return {closed:true,cleanupComplete:true}; },
  };
}
