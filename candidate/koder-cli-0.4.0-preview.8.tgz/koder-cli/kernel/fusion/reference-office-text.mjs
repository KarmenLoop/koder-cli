import {unpackZip,IMPORT_LIMITS} from './import-zip.mjs';
import {officeText} from './office-text.mjs';
const unescape=value=>String(value).replace(/&#x([\da-f]+);|&#(\d+);|&(lt|gt|amp|quot|apos);/gi,(_,hex,num,name)=>{if(name)return {lt:'<',gt:'>',amp:'&',quot:'"',apos:"'"}[name.toLowerCase()];const n=parseInt(hex||num,hex?16:10);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';});
const texts=xml=>[...xml.matchAll(/<(?:\w+:)?t\b[^>]*>([\s\S]*?)<\/(?:\w+:)?t>/g)].map(m=>unescape(m[1].replace(/<[^>]*>/g,''))).join('');
// Fully validate OOXML before the older document reader sees it. Only XML is
// interpreted as text; embedded binaries, formulas and macros are never run.
export async function referenceOfficeText(bytes,ext){
 const files=new Map();
 for await(const entry of unpackZip(bytes,{limits:{...IMPORT_LIMITS,total:64*1024*1024,file:16*1024*1024,files:10000,depth:0}}))if(/\.xml$/i.test(entry.path))files.set(entry.path,entry.bytes.toString('utf8'));
 if(ext==='.docx'||ext==='.odt')return officeText(bytes,ext);
 if(ext==='.pptx')return [...files].filter(([name])=>/^ppt\/slides\/slide\d+\.xml$/.test(name)).sort((a,b)=>Number(/slide(\d+)/.exec(a[0])[1])-Number(/slide(\d+)/.exec(b[0])[1])).map(([name,xml])=>`# ${name}\n${[...xml.matchAll(/<a:p\b[^>]*>([\s\S]*?)<\/a:p>/g)].map(m=>texts(m[1])).filter(Boolean).join('\n')}`).join('\n\n');
 const shared=[...(files.get('xl/sharedStrings.xml')||'').matchAll(/<si\b[^>]*>([\s\S]*?)<\/si>/g)].map(m=>texts(m[1]));
 return [...files].filter(([name])=>/^xl\/worksheets\/sheet\d+\.xml$/.test(name)).map(([name,xml])=>`# ${name}\n${[...xml.matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g)].map(([,attrs,content])=>{
  const address=/\br="([^"]+)"/.exec(attrs)?.[1]||'',type=/\bt="([^"]+)"/.exec(attrs)?.[1],raw=/<v\b[^>]*>([\s\S]*?)<\/v>/.exec(content)?.[1];
  const value=type==='s'?shared[Number(raw)]||'':type==='inlineStr'?texts(content):unescape(raw||'');
  const formula=/<f\b[^>]*>([\s\S]*?)<\/f>/.exec(content)?.[1];return value||formula?`${address}: ${value}${formula?' [公式 '+unescape(formula)+']':''}`:'';
 }).filter(Boolean).join('\n')}`).join('\n\n');
}
