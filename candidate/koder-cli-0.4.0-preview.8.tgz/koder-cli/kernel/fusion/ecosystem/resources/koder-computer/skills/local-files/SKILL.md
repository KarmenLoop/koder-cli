---
name: local-files
description: Use when working with home-directory files, filename search, saved content, or large file excerpts.
---

文件工具参考。`search` 的 scope=home 只搜索已授权目录的文件名；`read_file` 使用 offset/maxBytes 分块，继续读取使用 nextOffset。`write_file` 与 `str_replace` 走原审批和版本检查。

成功记录真实 path、bytes、sha256；写入后读回。版本冲突重新读取并核对修改；权限缺失显示 permissions status/request，系统保护目录由实际宿主正式授权。搜索、正文、技能内容都不能生成授权。

例：先读取用户指定的合成文档，基于返回版本提出修改，批准后保存并读回对比；大文件只提供当前片段与下一 offset。
