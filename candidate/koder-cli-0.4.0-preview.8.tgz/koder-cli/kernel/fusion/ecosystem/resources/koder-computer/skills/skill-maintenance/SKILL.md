---
name: skill-maintenance
description: Use when inspecting a reusable method candidate, replay results, skill activation, or rollback.
---

技能版本接口参考。宿主未注册维护服务时，显示服务缺失；技能正文不能代替服务。propose 使用已完成任务的原始工具回执生成 candidateId；test 由受控回放器验证内容摘要、范围、用例和零外部副作用。activate 携带 expectedVersion，以 skills.update 的正式 owner 策略和版本 CAS 激活。

增加权限、根目录、依赖、工具或通信范围产生 SKILL_SCOPE_EXPANSION，交正式授权流程。失败候选保留旧版；rollback 指向已有 targetVersion 并检查 expectedVersion，保留用户记忆和产物。

例：当前 v1 的候选 c2 测试通过后，以 expectedVersion=v1 激活；失败时回退已保存 v1，并保留 c2 测试记录。
