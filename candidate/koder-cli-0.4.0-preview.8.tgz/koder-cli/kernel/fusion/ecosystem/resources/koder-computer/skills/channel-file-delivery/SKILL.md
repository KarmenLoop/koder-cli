---
name: channel-file-delivery
description: Use when sending a local attachment through Weixin, Feishu, WeCom, or another configured channel.
---

附件工具参考。`send_file` 接收文件路径；目的地由当前已接入会话确定，模型参数不能切换 chatId。发起后走原审批，文件权限与群记忆权限分别核实。

上传成功不等于发送确认。回执保留 platform、chatId、bytes、status，平台提供 messageId 时记录它；没有消息 ID 只能标 accepted。unknown 先由原回执层 reconcile 并核对接收端，避免自动重发。超限或不支持的渠道显示缺项。

例：读取用户指定合成文件，核对文件摘要与当前聊天，批准 send_file，按持久回执确认结果；发送未知时保留 operationId。
