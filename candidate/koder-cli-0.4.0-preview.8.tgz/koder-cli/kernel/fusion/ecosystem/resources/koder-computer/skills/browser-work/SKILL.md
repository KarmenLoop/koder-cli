---
name: browser-work
description: Use when inspecting or acting on a browser page or desktop application through the computer driver.
---

电脑工具参考。先调用 `computer_inspect`；COMPUTER_DRIVER_MISSING 表示实际宿主尚未提供驱动。只有可用时调用 `computer_capture`，从返回元素选择目标，并将该次 snapshotId 与元素 ID 交给 `computer_act`。动作走原审批，结果包含真实前后状态。

新截图、页面变化或宿主签名改变后，旧句柄失效，重新观察。驱动超时或结果 unknown 时先核对目标，不重放未知动作。辅助功能、录屏和浏览器权限属于实际宿主，由操作系统确认。

例：读取自有测试窗口，选截图中出现的按钮 ID，批准点击，再读取返回 after 状态判断结果。
