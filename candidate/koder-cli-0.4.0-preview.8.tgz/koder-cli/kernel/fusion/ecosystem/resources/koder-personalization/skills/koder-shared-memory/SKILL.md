---
name: koder-shared-memory
description: Shared conversation memory for a linked account. Preference learning is a separate opt-in.
---

Koder wrote this note for the installed CLI. The user-supplied experimental skill text is not in this package. Its redistribution terms were not verified, so that text is omitted.

Shared conversation memory and preference learning are different switches. For an account that is already linked, group and direct-chat memory follows the memory configuration and is shared across those linked chats. Turning preference learning off does not by itself turn that memory off. Cross-device memory runs only when a connection and identity are configured. Preference learning and self-evolution stay off until you opt in.

This note does not grant access to unrelated files or permission to send messages. This preview was not tested on WeChat, Feishu, or WeCom.

Source: original Koder interface note. Not a copy of the omitted text.
