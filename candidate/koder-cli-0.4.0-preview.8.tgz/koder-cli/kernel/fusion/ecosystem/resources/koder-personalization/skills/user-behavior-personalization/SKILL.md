# Personalization

Koder wrote this note for the installed CLI.

The user-supplied experimental skill text is not in this package. Its redistribution terms were not verified, so the original text is omitted. This file only keeps the interface: behavior personalization stays off until you turn learning on. Accepting the end-user agreement does not turn it on.

Source: original Koder interface note. Not a copy of the omitted text.
