// Not shipped with Koder CLI: the desktop app's login vault.
const MESSAGE = "Koder CLI 不包含桌面端的登录保管库";
export function sealWith() { throw new Error(MESSAGE); }
export function openWith() { throw new Error(MESSAGE); }
export function scrubHelperSaid() { throw new Error(MESSAGE); }
export function keychainPepper() { throw new Error(MESSAGE); }
export function assertFreshDataDirectory() { throw new Error(MESSAGE); }
export function readKeyFile() { throw new Error(MESSAGE); }
export function publishKeyFile() { throw new Error(MESSAGE); }
export function createDataLock() { throw new Error(MESSAGE); }
export function LockError() { throw new Error(MESSAGE); }
export function isLocked() { throw new Error(MESSAGE); }
