// Private files: authenticated encryption, bounded reads, ordered atomic commits.
// Plain legacy input is backed up in encrypted form before the original changes.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { constants } from 'node:fs';
import { isLocked, LockError } from './private-format.mjs';
import { writeFileBytes } from '../loop/json-store.mjs';
import { withPrivateLease } from './private-lease.mjs';
const tails=new Map();
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function ordered(file,work) {
 const run=(tails.get(file)||Promise.resolve()).then(work);const settled=run.then(()=>{},()=>{});tails.set(file,settled);void settled.then(()=>{if(tails.get(file)===settled)tails.delete(file);});return run;
}
export function createPrivateStore({dir,lock,maxBytes=32*1024*1024}) {
 if(!lock?.seal||!lock?.open)throw new LockError('NO_KEY','私有存储需要已解锁的数据锁');
 const root=path.resolve(dir);
 const sealed=bytes=>typeof lock.isLocked==='function'?lock.isLocked(bytes):isLocked(bytes);
 const alive=()=>lock.assertAlive?.();
 const guard=(relative,work)=>ordered(location(relative),()=>{alive();return withPrivateLease(root,relative,work,{assertActive:alive});});
 function location(relative) {
  if(typeof relative!=='string'||!relative||relative.includes('\\')||relative.includes('\0')||path.isAbsolute(relative)||relative.split('/').some(x=>!x||x==='.'||x==='..'))throw new LockError('BAD_PATH','私有存储路径无效');
  if(relative==='keys'||relative.startsWith('keys/'))throw new LockError('BAD_PATH','数据记录不能访问密钥目录');
  return path.join(root,relative);
 }
 async function checked(relative,{create=false}={}) {
  alive();
  const full=location(relative);if(create)await fs.mkdir(root,{recursive:true,mode:0o700});
  const parts=[root,...relative.split('/').slice(0,-1)];let current=parts.shift();
  for(let index=0;index<=parts.length;index++) {
   if(index)current=path.join(current,parts[index-1]);
   let stat;try{stat=await fs.lstat(current);}catch(error){if(error.code!=='ENOENT'||!create)throw error;try{await fs.mkdir(current,{mode:0o700});}catch(mkdirError){if(mkdirError.code!=='EEXIST')throw mkdirError;}stat=await fs.lstat(current);}
   if(!stat.isDirectory()||stat.isSymbolicLink())throw new LockError('BAD_PATH','私有存储目录不能是链接');
  }
  try{const stat=await fs.lstat(full);if(!stat.isFile()||stat.isSymbolicLink())throw new LockError('BAD_PATH','私有存储文件必须是常规文件');}catch(error){if(error.code!=='ENOENT')throw error;}
  return full;
 }
 async function raw(relative) {
  const full=await checked(relative);const handle=await fs.open(full,constants.O_RDONLY|(constants.O_NOFOLLOW||0));
  try{const stat=await handle.stat();if(!stat.isFile()||stat.size>maxBytes+4096)throw new LockError('FILE_LIMIT','私有存储文件超过容量');const chunks=[];let total=0;for(;;){const chunk=Buffer.alloc(Math.min(65536,maxBytes+4097-total));const {bytesRead}=await handle.read(chunk,0,chunk.length,null);if(!bytesRead)break;total+=bytesRead;if(total>maxBytes+4096)throw new LockError('FILE_LIMIT','私有存储文件超过容量');chunks.push(chunk.subarray(0,bytesRead));}return Buffer.concat(chunks,total);}finally{await handle.close();}
 }
 const label=relative=>`private:${relative}`;
 const formatPath=relative=>`private-formats/${hash(Buffer.from(relative))}.json`;
 async function format(relative) {
  let bytes;try{bytes=await raw(formatPath(relative));}catch(error){if(error.code==='ENOENT')return null;throw error;}
  if(!sealed(bytes)||bytes.length>4096)throw new LockError('DAMAGED','私有存储格式记录损坏');
  let value;try{value=JSON.parse(lock.open(bytes,label(formatPath(relative))).toString('utf8'));}catch{throw new LockError('DAMAGED','私有存储格式记录损坏');}
  if(value?.version!==1||value.relative!==relative||!['sealed','migrating'].includes(value.state)||value.state==='migrating'&&!/^[a-f0-9]{64}$/.test(value.legacyHash))throw new LockError('DAMAGED','私有存储格式记录损坏');
  return value;
 }
 async function mark(relative,legacyHash=null) {
  const record={version:1,relative,state:legacyHash?'migrating':'sealed',...(legacyHash?{legacyHash}:{})};
  const target=formatPath(relative),box=lock.seal(JSON.stringify(record),label(target));
  const full=await checked(target,{create:true});alive();await writeFileBytes(full,box);
 }
 async function write(relative,bytes,{legacyHash=null}={}) {
  if(bytes.length>maxBytes)throw new LockError('FILE_LIMIT','私有存储文件超过容量');
  const known=await format(relative);
  if(legacyHash||known?.state!=='sealed')await mark(relative,legacyHash);
  const box=lock.seal(bytes,label(relative));const full=await checked(relative,{create:true});alive();await writeFileBytes(full,box);
  if(legacyHash)await mark(relative);
 }
 async function read(relative,{fallback,legacyLabel,validate}={}) {
  let bytes;try{bytes=await raw(relative);}catch(error){if(error.code==='ENOENT')return fallback;throw error;}
  const known=await format(relative);
  if(sealed(bytes)) {
   let plain;try{plain=lock.open(bytes,label(relative));}catch(error){if(!legacyLabel)throw error;plain=lock.open(bytes,legacyLabel);}
   validate?.(plain);if(known?.state!=='sealed')await mark(relative);return plain;
  }
  if(known&&(known.state!=='migrating'||known.legacyHash!==hash(bytes)))throw new LockError('DAMAGED','已加密记录的文件头损坏，拒绝按旧明文迁移');
  validate?.(bytes); // A corrupt record is not silently replaced or migrated.
  const backup=`migration-backups/${crypto.randomUUID()}.json`;
  const saved=Buffer.from(JSON.stringify({relative,sha256:hash(bytes),createdAt:Date.now(),base64:bytes.toString('base64')}));
  await write(backup,saved);if(!lock.open(await raw(backup),label(backup)).equals(saved))throw new LockError('BACKUP_INVALID','迁移备份验证失败');
  // Do not overwrite a concurrent legacy writer's newer bytes.
  if(!(await raw(relative)).equals(bytes))throw new LockError('MIGRATION_CONFLICT','迁移时文件已被其他进程修改');
  await write(relative,bytes,{legacyHash:hash(bytes)});return bytes;
 }
 return {
  dir:root,
  async drain(){for(;;){const pending=[...tails].filter(([file])=>file.startsWith(root+path.sep)).map(([,tail])=>tail);if(!pending.length)return;await Promise.all(pending);}},
  readBytes(relative,options={}) {return guard(relative,()=>read(relative,options));},
  writeBytes(relative,bytes,options={}) {const snapshot=Buffer.from(bytes);return guard(relative,async()=>{await read(relative,options);await write(relative,snapshot);});},
  readJson(relative,fallback=null,options={}) {return guard(relative,async()=>{const bytes=await read(relative,{...options,fallback:undefined,validate:bytes=>JSON.parse(bytes.toString('utf8'))});return bytes===undefined?structuredClone(fallback):JSON.parse(bytes.toString('utf8'));});},
  writeJson(relative,value,options={}) {let bytes;try{const text=JSON.stringify(value);if(text===undefined)throw new TypeError('JSON value required');bytes=Buffer.from(text+'\n');}catch(error){return Promise.reject(error);}return guard(relative,async()=>{const previous=await read(relative,{...options,validate:old=>JSON.parse(old.toString('utf8'))});if(options.skipUnchanged===true&&previous?.equals(bytes))return;await write(relative,bytes);});},
  updateJson(relative,fallback,change,options={}) {return guard(relative,async()=>{const bytes=await read(relative,{...options,validate:old=>JSON.parse(old.toString('utf8'))});const value=bytes===undefined?structuredClone(fallback):JSON.parse(bytes.toString('utf8'));const result=await change(value);await write(relative,Buffer.from(JSON.stringify(value)+'\n'));return result;});},
  updateBytes(relative,fallback,change,options={}) {return guard(relative,async()=>{const bytes=await read(relative,{...options,fallback});const next=await change(bytes);await write(relative,Buffer.from(next));return next.length;});},
  async list(relative) {const full=location(`${relative}/.directory-check`);try{await checked(`${relative}/.directory-check`);return (await fs.readdir(path.dirname(full),{withFileTypes:true})).filter(item=>item.isFile()).map(item=>item.name);}catch(error){if(error.code==='ENOENT')return [];throw error;}},
  remove(relative) {return guard(relative,async()=>{try{await fs.unlink(await checked(relative));}catch(error){if(error.code!=='ENOENT')throw error;}});},
  async stat(relative) {return fs.stat(await checked(relative));},
 };
}

// Absolute-path adapter for existing product modules. It has the same narrow
// file contract as the runtime storage client, without accepting outside paths.
export function createPrivateFiles(options) {
 const store=createPrivateStore(options),relative=file=>path.relative(store.dir,file).split(path.sep).join('/');
 return {drain:()=>store.drain(),readJson:(file,fallback,opts)=>store.readJson(relative(file),fallback,opts),writeJson:(file,value,opts)=>store.writeJson(relative(file),value,opts),readBytes:(file,fallback=null,opts={})=>store.readBytes(relative(file),{...opts,fallback}),writeBytes:(file,bytes,opts)=>store.writeBytes(relative(file),bytes,opts),list:file=>store.list(relative(file)),remove:file=>store.remove(relative(file)),stat:file=>store.stat(relative(file)),updateJson:(file,fallback,change,opts)=>store.updateJson(relative(file),fallback,change,opts),updateBytes:(file,fallback,change,opts)=>store.updateBytes(relative(file),fallback,change,opts)};
}
