const failure=code=>Object.assign(new Error(code),{code});
// The token is issued only by the existing Core task/node writer. No local
// lease is substituted when the account service is absent or unreachable.
export async function acquireHostLease({transport,input,current,onLost=()=>{}}){
 if(typeof transport!=='function'||!await current())throw failure('HOST_IDENTITY_UNAVAILABLE');
 const claim=await transport('acquire',input);
 if(!claim?.taskId||!Number.isSafeInteger(claim.epoch)||typeof claim.token!=='string')throw failure('HOST_LEASE_INVALID');
 let released=false,lost=null,renewing=null;
 const fail=error=>{lost=error;clearInterval(timer);onLost(error);throw error;};
 async function requireCurrent(){
  if(released||lost)throw lost||failure('HOST_LEASE_RELEASED');
  if(renewing)return renewing;
  renewing=(async()=>{if(!await current())throw failure('HOST_IDENTITY_CHANGED');const result=await transport('check',claim);if(result?.current!==true||!await current())throw failure('HOST_LEASE_STALE');return true;})().catch(fail).finally(()=>{renewing=null;});return renewing;
 }
 const timer=setInterval(()=>{void requireCurrent().catch(()=>{});},30000);timer.unref?.();
 const lease={taskId:claim.taskId,requireCurrent,
  async call(operation,body={}){await requireCurrent();const value=await transport(operation,{...claim,...body});if(!await current())throw failure('HOST_IDENTITY_CHANGED');return value;},
  async release(){if(released)return;released=true;clearInterval(timer);if(renewing)await renewing.catch(()=>{});try{await transport('release',claim);}catch(error){if(!lost&&![401,403,404,409].includes(error.status))throw error;}},
 };
 try{await requireCurrent();return lease;}catch(error){await lease.release().catch(()=>{});throw error;}
}
