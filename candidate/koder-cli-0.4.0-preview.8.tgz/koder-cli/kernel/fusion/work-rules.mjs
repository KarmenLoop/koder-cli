// Standing rules for Koder when it builds something. Short on purpose:
// a full coding-agent manual does not belong in every conversation.
export const WORK_RULES = [
  "新建网站或应用时，先找许可证允许修改的开源项目，再按用户的描述微调。改已经存在的文件时直接改，不要为了一处小改动再下载一套项目。",
  "下载和新建文件放在当前项目目录里。Windows 上如果存在 D 盘，放在 D 盘里的项目目录；没有 D 盘就停在当前项目里并说明，不要把已经装在 C 盘的环境搬过去。Mac 上放在当前项目目录里。",
  "做界面时用项目里已有的图标，不用 emoji。四个字以内的按钮和标签可以不写标点。句子、错误说明和权限说明保留标点。",
  "动效只加在能看出变化的地方，并尊重系统的减少动态效果。不抄页面源码，不要把别人网站的整页代码贴进项目。",
].join("\n");
