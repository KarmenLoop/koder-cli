// Model projection is separate from the original protected application receipt.
import {createHash} from 'node:crypto';
import {estimateTokens} from './tokens.mjs';
export function redactAppValue(value,secrets=[]) {
 const clean=text=>{let out=text;for(const secret of secrets)if(typeof secret==='string'&&secret)out=out.replaceAll(secret,'[redacted]');return out.replace(/\bBearer\s+[A-Za-z0-9._~+/=-]+/gi,'Bearer [redacted]').replace(/\b(?:sk-|xox[baprs]-)[A-Za-z0-9_-]{8,}/g,'[redacted]');};
 const walk=v=>typeof v==='string'?clean(v):Array.isArray(v)?v.map(walk):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,/^(?:access_token|refresh_token|client_secret|password|apiKey|api_key|authorization)$/i.test(k)?'[redacted]':walk(x)])):v;
 return walk(value);
}
export async function shapeAppResult(result,{threadId,callId,budget=1000,artifacts,secrets=[],now=Date.now()}={}) {
 const safe=redactAppValue(result,secrets),source=JSON.stringify(safe),state=safe?.state||'succeeded';let nonText=false;
 const project=value=>{
  if(Array.isArray(value))return value.map(project);
  if(!value||typeof value!=='object')return value;
  if(['image','audio'].includes(value.type)&&typeof value.data==='string'){nonText=true;return {type:value.type,mimeType:value.mimeType,encodedBytes:value.data.length,available:'artifact-only'};}
  if(value.type==='resource_link'&&value.expiresAt&&Date.parse(value.expiresAt)<=now){nonText=true;return {...value,available:false,retrieval:'refetch-required'};}
  return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,project(v)]));
 };
 const projected=project(safe),text=JSON.stringify(projected),cap=Math.max(128,Math.min(8000,Number(budget)||1000));
 if(!nonText&&estimateTokens(text)<=cap)return {modelContent:text,artifactRefs:[],state};
 if(!threadId||!callId||!artifacts?.put)throw Object.assign(new Error('Full application result storage unavailable'),{code:'APP_RESULT_STORAGE_UNAVAILABLE'});
 const stored=await artifacts.put({threadId,callId,text:source});
 const ref={id:stored.id,sha256:createHash('sha256').update(source).digest('hex'),bytes:Buffer.byteLength(source)};
 const envelope={ok:safe?.ok!==false,state,...(safe?.remoteId?{remoteId:String(safe.remoteId).slice(0,160)}:{}),...(safe?.errorCode?{errorCode:String(safe.errorCode).slice(0,80)}:{}),artifact:ref,readWith:'app_result_read',...(nonText?{media:'artifact-only',resources:'expired links require refetch-required'}:{}),preview:''};
 let lo=0,hi=text.length;
 while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(estimateTokens(JSON.stringify({...envelope,preview:text.slice(0,mid)}))<=cap)lo=mid;else hi=mid-1;}
 envelope.preview=text.slice(0,lo);
 const modelContent=JSON.stringify(envelope);
 if(estimateTokens(modelContent)>cap)throw Object.assign(new Error('Application result metadata exceeds available budget'),{code:'APP_RESULT_BUDGET'});
 return {modelContent,artifactRefs:[ref],state};
}
