import crypto from 'node:crypto';

const API='https://api.github.com';
const permissive=new Set(['MIT','Apache-2.0','BSD-2-Clause','BSD-3-Clause','ISC','0BSD','Unlicense']);
const failure=(code)=>Object.assign(new Error(code),{code});
const clean=(value,max=1000)=>String(value||'').replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g,'').slice(0,max);
const repoPattern=/^[A-Za-z0-9][A-Za-z0-9_.-]{0,99}\/[A-Za-z0-9][A-Za-z0-9_.-]{0,99}$/;
const fixedRef=/^[a-f0-9]{40}(?:[a-f0-9]{24})?$/;
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');

function repository(row){
  if(!repoPattern.test(row?.full_name||''))throw failure('GITHUB_INVALID_REPOSITORY');
  return {repository:row.full_name,url:`https://github.com/${row.full_name}`,description:clean(row.description,500),language:clean(row.language,40),stars:Number(row.stargazers_count)||0,archived:row.archived===true,fork:row.fork===true,pushedAt:clean(row.pushed_at,40),licenseHint:clean(row.license?.spdx_id||'UNKNOWN',80),licenseVerified:false};
}

// Anonymous public reads only. No model/user API credentials are forwarded.
// Requests and response bodies share a total deadline; no arbitrary URLs or redirects.
export function createGitHubResearch({fetchImpl=globalThis.fetch,timeoutMs=12000}={}){
  return async function research(args={}, {signal}={}){
    const controller=new AbortController();
    const abort=()=>controller.abort(signal?.reason||failure('GITHUB_CANCELLED'));
    signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
    const timer=setTimeout(()=>controller.abort(failure('GITHUB_TIMEOUT')),timeoutMs);
    const bounded=async promise=>{
      let cancel;const stopped=new Promise((_,reject)=>{cancel=()=>reject(controller.signal.reason);if(controller.signal.aborted)cancel();else controller.signal.addEventListener('abort',cancel,{once:true});});
      try{return await Promise.race([promise,stopped]);}finally{controller.signal.removeEventListener('abort',cancel);}
    };
    async function get(route,{missing=false}={}){
      controller.signal.throwIfAborted();
      const pending=Promise.resolve().then(()=>fetchImpl(API+route,{signal:controller.signal,redirect:'error',headers:{accept:'application/vnd.github+json','x-github-api-version':'2022-11-28','user-agent':'Koder-CLI-Research'}}));
      pending.then(response=>{if(controller.signal.aborted)response.body?.cancel().catch(()=>{});},()=>{});
      const response=await bounded(pending);
      if(!response.ok){response.body?.cancel().catch(()=>{});if(missing&&response.status===404)return null;if(response.status===429||response.status===403&&response.headers.get('x-ratelimit-remaining')==='0')throw failure('GITHUB_RATE_LIMIT: retry after the GitHub limit resets');throw failure(`GITHUB_HTTP_${response.status}`);}
      const reader=response.body?.getReader();if(!reader)throw failure('GITHUB_EMPTY_RESPONSE');
      try{const chunks=[];let size=0;for(;;){const part=await bounded(reader.read());if(part.done)break;size+=part.value.byteLength;if(size>1024*1024)throw failure('GITHUB_RESPONSE_TOO_LARGE');chunks.push(Buffer.from(part.value));}return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
      finally{reader.cancel().catch(()=>{});}
    }
    function fileContent(value){
      if(value?.type!=='file'||value.encoding!=='base64'||typeof value.content!=='string')throw failure('GITHUB_NOT_TEXT_FILE');
      const bytes=Buffer.from(value.content,'base64');if(bytes.length>64000)throw failure('GITHUB_FILE_TOO_LARGE');if(bytes.includes(0))throw failure('GITHUB_NOT_TEXT_FILE');return {text:clean(bytes.toString('utf8'),64000),sha256:hash(bytes),bytes:bytes.length};
    }
    try{
      const evidence={untrusted:true,retrievedAt:new Date().toISOString(),source:'GitHub public API'};
      if(args.action==='search'){
        const query=typeof args.query==='string'?args.query.trim():'';
        if(!query||query.length>240||/[\r\n\x00-\x1f]/.test(query))throw failure('GITHUB_QUERY_INVALID');
        const json=await get('/search/repositories?'+new URLSearchParams({q:query,per_page:'5',sort:'updated'}));
        return {...evidence,query,total:json.total_count||0,incomplete:json.incomplete_results===true,repositories:(json.items||[]).slice(0,5).map(repository),next:'Inspect candidate repositories and their fixed-ref LICENSE before reusing code. Compare fit, maintenance, license and deployment cost; stars are not verification.'};
      }
      if(!repoPattern.test(args.repository||''))throw failure('GITHUB_REPOSITORY_INVALID');
      const root='/repos/'+args.repository;
      if(args.action==='repository'){
        const meta=await get(root),commit=await get(root+'/commits/'+encodeURIComponent(meta.default_branch||'HEAD'));
        if(!fixedRef.test(commit.sha||''))throw failure('GITHUB_FIXED_REF_REQUIRED');
        const license=await get(root+'/license?ref='+commit.sha,{missing:true});
        const spdx=clean(license?.license?.spdx_id||'UNKNOWN',80);
        return {...evidence,...repository(meta),ref:commit.sha,license:license?{status:'retrieved',spdx,preference:permissive.has(spdx)?'permissive-candidate':'review-required',path:clean(license.path,200),url:`https://github.com/${args.repository}/blob/${commit.sha}/${license.path}`,...fileContent({...license,type:license.type||'file'}),notice:'Check the complete license and dependencies; preserve copyright/NOTICE, attribution and any source-disclosure obligations. Metadata is not legal clearance.'}:{status:'unknown',spdx,preference:'review-required',notice:'No verified license. Do not copy or redistribute until permissions are established.'}};
      }
      if(args.action==='file'){
        if(!fixedRef.test(args.ref||''))throw failure('GITHUB_FIXED_REF_REQUIRED');
        const name=args.path;if(typeof name!=='string'||name.length>400||/[\\\x00-\x1f]/.test(name)||name.split('/').some(p=>!p||p==='.'||p==='..'))throw failure('GITHUB_PATH_INVALID');
        const value=await get(root+'/contents/'+name.split('/').map(encodeURIComponent).join('/')+'?ref='+args.ref);
        const content=fileContent(value),offset=args.offset??0;
        if(!Number.isInteger(offset)||offset<0||offset>content.text.length)throw failure('GITHUB_OFFSET_INVALID');
        const limit=8000;return {...evidence,repository:args.repository,ref:args.ref,path:name,url:`https://github.com/${args.repository}/blob/${args.ref}/${name}`,...content,text:content.text.slice(offset,offset+limit),total:content.text.length,nextOffset:offset+limit<content.text.length?offset+limit:null};
      }
      throw failure('GITHUB_ACTION_INVALID');
    }finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
  };
}
