import {skillApplies} from './skills.mjs';
import {verifiedMaintenance} from './skill-maintenance.mjs';
import {readEcosystemSkill} from './ecosystem.mjs';
import {readInstalledResource} from './skill-library.mjs';
import {createResourceReader} from './resource-import.mjs';
import path from 'node:path';

// Imported presets often keep their upstream English titles. Query aliases
// help Chinese users discover them without rewriting licensed source text.
const TOPICS = [
 ['合同','contract'], ['法律','律师','legal','lawyer'], ['招聘','recruit','recruitment'],
 ['入职','onboarding'], ['人力','human resource'], ['小说','novel'], ['写作','writing','writer'],
 ['电商','commerce'], ['采购','sourcing','procurement'], ['选品','product selection'],
 ['抖音','douyin','tiktok'], ['图纸','制图','cad'], ['代码','编程','coding'],
];

export function searchSkills(skills,query='',{offset=0,limit=20,context={}}={}){
 const runs=String(query).slice(-8000).toLowerCase().match(/[a-z0-9_-]+|[\u3400-\u9fff]+/g)||[];
 const queryText=String(query).slice(-8000).toLowerCase();
 const aliases=TOPICS.filter(words=>words.some(word=>/[\u3400-\u9fff]/.test(word)?queryText.includes(word):runs.includes(word)||queryText.includes(' '+word+' '))).flat();
 const terms=[...new Set([...runs,...aliases])],pairs=[...new Set(runs.filter(t=>/^[\u3400-\u9fff]{3,}$/.test(t)).flatMap(t=>Array.from({length:t.length-1},(_,i)=>t.slice(i,i+2))))];
 const rows=skills.filter(s=>skillApplies(s,context)).map(s=>{const name=`${s.name} ${s.when||''}`.toLowerCase(),hay=`${name} ${s.description||''} ${(s.roles||[]).join(' ')}`.toLowerCase();return {s,score:terms.reduce((n,t)=>n+(name.includes(t)?8:hay.includes(t)?3:0),0)+pairs.reduce((n,t)=>n+(name.includes(t)?2:hay.includes(t)?0.5:0),0)};}).filter(x=>!terms.length||x.score).sort((a,b)=>b.score-a.score||a.s.name.localeCompare(b.s.name));
 const start=Math.max(0,Math.floor(Number(offset)||0)),size=Math.max(1,Math.min(30,Math.floor(Number(limit)||20)));
 return {total:rows.length,items:rows.slice(start,start+size).map(({s})=>({id:s.id,name:s.name,description:String(s.description||s.when||'').slice(0,300),source:s.source,roles:s.roles||[],licenseStatus:s.licenseStatus})),nextOffset:start+size<rows.length?start+size:null};
}
export async function readSkillResource(skill,args,{dataDir,storage,personalizationPolicy,subject}={}){
 if(skill.requiredPolicy && (!personalizationPolicy||!await personalizationPolicy.require(skill.requiredPolicy)||!personalizationPolicy.can(skill.requiredPolicy,subject)))throw Object.assign(new Error('PERSONALIZATION_DISABLED'),{code:'PERSONALIZATION_DISABLED',status:403});
 if(skill.source==='internal')throw Object.assign(new Error('SKILL_RESOURCE_INTERNAL'),{code:'SKILL_RESOURCE_INTERNAL'});
 if(skill.enabled===false)throw Object.assign(new Error('技能已停用'),{code:'SKILL_DISABLED',status:403});
 const active=verifiedMaintenance(skill);
 if(active&&(!args.path||args.path==='SKILL.md')){const text=active.body,offset=Math.max(0,Math.floor(Number(args.offset)||0)),limit=Math.max(1,Math.min(12000,Math.floor(Number(args.limit)||12000)));return {id:skill.id,path:'SKILL.md',text:text.slice(offset,offset+limit),content:text.slice(offset,offset+limit),nextOffset:offset+limit<text.length?offset+limit:null,version:active.version};}
 if(skill.source==='archive')return createResourceReader({dataDir,storage}).readSkill(skill,args.path||'SKILL.md',args);
 if(skill.source==='ecosystem')return readEcosystemSkill(skill.id,args.path||'SKILL.md',args);
 if(skill.source==='github')return readInstalledResource(skill,args.path||'SKILL.md',{...args,dir:path.join(dataDir,'skill-library')});
 if(args.path&&args.path!=='SKILL.md')throw Object.assign(new Error('这项技能没有配套文件'),{code:'SKILL_RESOURCE'});
 const text=skill.body||'',offset=Math.max(0,Math.floor(Number(args.offset)||0)),limit=Math.max(1,Math.min(12000,Math.floor(Number(args.limit)||12000)));
 return {id:skill.id,path:'SKILL.md',content:text.slice(offset,offset+limit),nextOffset:offset+limit<text.length?offset+limit:null};
}
