import {isIP} from 'node:net';
export function publicOAuthRedirect(value) {
 try {const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.search&&!u.hash&&!isIP(u.hostname)&&u.hostname.includes('.')&&!/(?:^|\.)(?:localhost|local|internal|invalid)$/.test(u.hostname)?u.href:null;}catch{return null;}
}
export function loadGammaConnectionConfig({env=process.env,profile={}}={}) {
 const value=name=>String(profile[name]??env[name]??'').trim();
 const apiClientId=value('KODER_GAMMA_API_CLIENT_ID');
 let apiRedirect=publicOAuthRedirect(value('KODER_GAMMA_API_REDIRECT_URI'));
 if(apiRedirect&&new URL(apiRedirect).pathname!=='/gamma/callback')apiRedirect=null;
 try{const u=new URL(value('KODER_GAMMA_API_REDIRECT_URI'));if(u.protocol==='http:'&&u.hostname==='127.0.0.1'&&Number(u.port)>0&&u.pathname==='/gamma/callback'&&!u.search&&!u.hash&&!u.username&&!u.password)apiRedirect=u.href;}catch{}
 const mcpRedirect=publicOAuthRedirect(value('KODER_GAMMA_MCP_REDIRECT_URI'));
 const port=name=>{const p=Number(value(name));return Number.isSafeInteger(p)&&p>0&&p<65536?p:null;};
 const mcpListenPort=port('KODER_GAMMA_MCP_CALLBACK_PORT');
 return {apiClientId:/^[\w.-]{8,200}$/.test(apiClientId)?apiClientId:null,apiRedirect,apiListenPort:port('KODER_GAMMA_API_CALLBACK_PORT'),mcpRedirect,mcpListenPort,mcpRegistrationState:mcpRedirect&&mcpListenPort&&value('KODER_GAMMA_MCP_REGISTRATION')==='confirmed'?'ready':'required'};
}
