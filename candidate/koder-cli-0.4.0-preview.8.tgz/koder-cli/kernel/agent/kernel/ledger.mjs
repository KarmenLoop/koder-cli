// A write is recorded before it happens. If the result never lands, the next
// run must re-read the file instead of repeating the write.
import path from "node:path";

function fileIdentity(cwd, filePath) {
  if (typeof cwd !== "string" || typeof filePath !== "string" || !cwd || !filePath || /\0/.test(cwd + filePath)) return null;
  const paths = /^[a-z]:[\\/]|^\\\\/i.test(cwd) ? path.win32 : path.posix;
  if (!paths.isAbsolute(cwd)) return null;
  const base = paths.resolve(cwd);
  const target = paths.resolve(base, filePath.replaceAll("\\", "/"));
  const relative = paths.relative(base, target);
  if (!relative || relative === ".." || relative.startsWith(`..${paths.sep}`) || paths.isAbsolute(relative)) return null;
  return { cwd: base, canonicalPath: target };
}

export function effectStart(thread, call) {
  const seq = (thread.seq || 0) + 1;
  thread.seq = seq;
  const identity = fileIdentity(call?.cwd ?? thread.cwd, call?.path);
  thread.effect = {
    seq,
    callId: String(call?.id || ""),
    path: String(call?.path || ""),
    cwd: identity?.cwd || "",
    canonicalPath: identity?.canonicalPath || "",
    phase: "started",
  };
}

export function effectFinish(thread, outcome) {
  if (!thread.effect) return;
  const seq = (thread.seq || 0) + 1;
  thread.seq = seq;
  // An exception after truncate/write/fsync may follow a real disk change.
  // Only a caller with explicit proof that writing never started may say failed.
  const phase = outcome === true || outcome?.ok === true
    ? "done"
    : outcome?.ok === false && outcome?.notStarted === true ? "failed" : "uncertain";
  thread.effect = { ...thread.effect, seq, phase };
}

export function effectRecover(thread) {
  if (thread.effect?.phase !== "started") return false;
  thread.effect = { ...thread.effect, phase: "uncertain" };
  return true;
}

export function writeBlocked(thread, name) {
  if (thread.effect?.phase !== "uncertain") return "";
  if (name !== "write_file" && name !== "str_replace") return "";
  const path = thread.effect.path || "该文件";
  return `上次对 ${path} 的写入没有留下结果。先读取这个文件核对，不要自动再写一遍。`;
}

export function noteRead(thread, read) {
  if (thread.effect?.phase !== "uncertain") return false;
  // canonicalPath must come from a successful confined read, not its displayed
  // text. Legacy records can use the persisted thread cwd, never process.cwd().
  if (read?.name !== "read_file" || read.ok !== true || typeof read.canonicalPath !== "string") return false;
  const paths = /^[a-z]:[\\/]|^\\\\/i.test(read.cwd || "") ? path.win32 : path.posix;
  if (!paths.isAbsolute(read.canonicalPath)) return false;
  const wanted = fileIdentity(thread.effect.cwd || thread.cwd, thread.effect.path);
  const seen = fileIdentity(read.cwd, read.path);
  const canonical = fileIdentity(read.cwd, read.canonicalPath);
  if (!wanted || !seen || !canonical || wanted.cwd !== seen.cwd || wanted.canonicalPath !== seen.canonicalPath || seen.canonicalPath !== canonical.canonicalPath) return false;
  if (thread.effect.canonicalPath && thread.effect.canonicalPath !== wanted.canonicalPath) return false;
  thread.effect = { ...thread.effect, phase: "checked" };
  return true;
}

export function verifiedByCheck(history, { roundId, checkTools = ["shell", "goal_report", "spec_loop"] } = {}) {
  if (typeof roundId !== "string" || !roundId || !Array.isArray(history)) return false;
  // checkTools is the executor's trusted registry, never model arguments.
  // Legacy text-only receipts intentionally do not authorize delivery.
  const allowed = new Set(checkTools);
  const current = history.filter((item) => item?.roundId === roundId);
  const lastMutation = current.findLastIndex((item) => item.mutates === true);
  // A later failed check supersedes an earlier success from the same round.
  const item = current.slice(lastMutation + 1).findLast((entry) => allowed.has(entry.name));
  return Boolean(item && item.ok === true && item.mutates === false && item.exitCode === 0
    && item.timedOut === false && item.aborted === false
    && typeof item.output === "string" && item.output.split(/\r?\n/).includes("VERIFIED"));
}
