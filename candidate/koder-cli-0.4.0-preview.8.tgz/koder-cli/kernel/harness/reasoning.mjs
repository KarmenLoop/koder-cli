import {claudeThinkingMode,supportedReasoningLevels} from './reasoning-capabilities.mjs';
// Wire settings use the selected model's checked-in compatibility metadata.
export function reasoningFields(provider) {
  const level=provider.reasoningEffort, spec=provider.spec;
  if (level == null || !supportedReasoningLevels(provider).includes(level)) return {};
  const value=spec.efforts?.[level], compat=spec.compat || {}, enabled=level !== 'off';
  if (provider.protocol === 'anthropic') {
    if (claudeThinkingMode(provider.model) === 'adaptive') {
      return enabled ? {thinking:{type:'adaptive'},output_config:{effort:value || level}} : {thinking:{type:'disabled'}};
    }
    const budget={minimal:1024,low:2048,medium:4096,high:8192,xhigh:16384,max:32768}[level] || 4096;
    return enabled ? {thinking:{type:'enabled',budget_tokens:Math.min(budget,Math.max(1024,(provider.maxOutput || 4096)-1024))}} : {thinking:{type:'disabled'}};
  }
  if (provider.id === 'gemini' && level === 'off') return {reasoning_effort:'none'};
  const effort = value != null && compat.supportsReasoningEffort !== false ? {reasoning_effort:value} : {};
  switch (compat.thinkingFormat) {
    case 'zai':
    case 'deepseek': return {thinking:{type:enabled?'enabled':'disabled'},...effort};
    case 'qwen': return {enable_thinking:enabled,...effort};
    case 'together': return {chat_template_kwargs:{thinking:enabled},...effort};
    case 'openrouter': return {reasoning:enabled?{effort:value || level}:{enabled:false}};
    default: return effort;
  }
}
