import fs from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";

const BLOCKED = /(^|\/)\.env($|\.)|(^|\/)credentials\.(json|ya?ml)$|(^|\/)id_rsa$|\.pem$/i;
const CLOSED = new Set([".git", ".ssh"]);

function pathError(message) {
  return Object.assign(new Error(message), { code: "PATH" });
}

export function safeRelative(input) {
  if (typeof input !== "string" || !input.trim()) throw pathError("缺少路径");
  if (input.includes("\0")) throw pathError("路径里不能有空字符");
  const raw = input.trim().replaceAll("\\", "/");
  if (raw.startsWith("/") || /^[a-zA-Z]:/.test(raw)) throw pathError("只接受工作区内的相对路径");
  if (raw.length > 300) throw pathError("路径过长");
  if (raw.split("/").some((part) => part === "")) throw pathError("路径不能有空段");
  const normalized = path.normalize(raw);
  const parts = normalized.split(path.sep);
  if (
    normalized === ".." ||
    normalized.startsWith(`..${path.sep}`) ||
    path.isAbsolute(normalized) ||
    parts.some((part) => part === "..")
  ) {
    throw pathError("路径超出工作区");
  }
  if (parts.some((part) => CLOSED.has(part))) throw pathError("这个路径不打开");
  if (BLOCKED.test(normalized.split(path.sep).join("/"))) throw pathError("这个文件不在可读写范围内");
  return normalized;
}

export async function resolveInside(root, input, { missingParents = false } = {}) {
  const rel = safeRelative(input);
  const base = await fs.realpath(root);
  const parts = rel.split(path.sep).filter((part) => part && part !== ".");
  let current = base;
  for (let index = 0; index < parts.length; index += 1) {
    current = path.join(current, parts[index]);
    if (current !== base && !current.startsWith(`${base}${path.sep}`)) throw pathError("路径超出工作区");
    let info;
    try {
      info = await fs.lstat(current);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      if (index < parts.length - 1 && !missingParents) throw pathError("上级目录不存在");
      const rest = parts.slice(index + 1);
      return { rel, target: rest.length ? path.join(current, ...rest) : current, exists: false, root: base };
    }
    if (info.isSymbolicLink()) throw pathError("不跟随符号链接");
    if (index < parts.length - 1 && !info.isDirectory()) throw pathError("上级不是目录");
    if (index === parts.length - 1 && info.isFile() && info.nlink > 1) throw pathError("不打开硬链接");
  }
  return { rel: rel || ".", target: current, exists: true, root: base };
}

const followFlags = constants.O_NOFOLLOW || 0;
const openDir = (dir) => fs.open(dir, constants.O_RDONLY | (constants.O_DIRECTORY || 0) | followFlags);

function sameIdentity(left, right) {
  return left.dev === right.dev && left.ino === right.ino;
}

async function matchesPathIdentity(target, identity, io) {
  const before = await io.lstat(target, { bigint: true });
  if (before.isSymbolicLink() || !(before.isDirectory() || before.isFile())) return false;
  const current = await io.open(target, constants.O_RDONLY | followFlags | (before.isDirectory() ? constants.O_DIRECTORY || 0 : 0));
  try {
    const info = await current.stat({ bigint: true });
    const after = await io.lstat(target, { bigint: true });
    return !after.isSymbolicLink() && before.isDirectory() === info.isDirectory()
      && before.isFile() === info.isFile() && before.isDirectory() === after.isDirectory()
      && before.isFile() === after.isFile() && sameIdentity(info, identity) && sameIdentity(before, after);
  } finally {
    await current.close().catch(() => {});
  }
}

// Compare handle-derived volume/inode pairs, never path-stat against fstat.
// The path is separately checked for links and replacement around the open.
export async function matchesOpenedPath(target, handle, { fsImpl = fs } = {}) {
  return matchesPathIdentity(target, await handle.stat({ bigint: true }), fsImpl);
}

function escapesWorkspace(relative) {
  if (!relative || relative === ".") return false;
  if (path.isAbsolute(relative)) return true;
  return relative === ".." || relative.startsWith(`..${path.sep}`);
}

async function recheckHeld(held) {
  for (const item of held) {
    const still = await item.handle.stat({ bigint: true });
    if (!still.isDirectory() || !sameIdentity(still, item)) {
      throw pathError("路径在打开时离开了项目目录");
    }
    // Windows path-stat and handle-stat can report different volume IDs for
    // the same directory. Compare handles with handles, retaining both dev
    // and the full 64-bit inode; never drop the device check to accept a path.
    if (!await matchesPathIdentity(item.dir, item, fs)) {
      throw pathError("路径在打开时离开了项目目录");
    }
  }
}

async function holdParents(located) {
  const base = located?.root;
  const target = located?.target;
  if (!base || !target) throw pathError("路径超出工作区");
  const relative = path.relative(base, target);
  if (escapesWorkspace(relative)) throw pathError("路径超出工作区");
  const parts = relative === "" ? [] : relative.split(path.sep);
  const held = [];
  const hold = async (dir) => {
    const handle = await openDir(dir);
    const item = { handle, dir };
    held.push(item);
    const info = await handle.stat({ bigint: true });
    if (!info.isDirectory()) throw pathError("上级不是目录");
    item.dev = info.dev;
    item.ino = info.ino;
  };
  try {
    await hold(base);
    let current = base;
    for (const part of parts.slice(0, -1)) {
      current = path.join(current, part);
      await hold(current);
    }
    return {
      target,
      recheck: () => recheckHeld(held),
      close: () => Promise.all(held.map((item) => item.handle.close().catch(() => {}))),
    };
  } catch (error) {
    await Promise.all(held.map((item) => item.handle.close().catch(() => {})));
    throw error;
  }
}

function bound(opened, parents) {
  return {
    file: opened,
    recheck: () => parents.recheck(),
    close: async () => {
      await opened.close().catch(() => {});
      await parents.close();
    },
  };
}

// Parent directories stay open until the caller finishes the real read or
// write. A later path operation can still be checked against those fds.
export async function openInside(located, flags, mode) {
  const parents = await holdParents(located);
  try {
    const opened = mode === undefined
      ? await fs.open(parents.target, flags | followFlags)
      : await fs.open(parents.target, flags | followFlags, mode);
    try {
      await parents.recheck();
      return bound(opened, parents);
    } catch (error) {
      await opened.close().catch(() => {});
      throw error;
    }
  } catch (error) {
    await parents.close();
    throw error;
  }
}

// Creating the file waits until the parent fds still match. A swap inside the
// first open must not leave an empty file outside the workspace.
export async function openWritable(located, mode = 0o600) {
  const parents = await holdParents(located);
  let opened;
  try {
    try {
      opened = await fs.open(parents.target, constants.O_WRONLY | followFlags);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      await parents.recheck();
      opened = await fs.open(parents.target, constants.O_WRONLY | constants.O_CREAT | followFlags, mode);
    }
    await parents.recheck();
    return bound(opened, parents);
  } catch (error) {
    if (opened) await opened.close().catch(() => {});
    await parents.close();
    throw error;
  }
}

export async function readConfined(root, input, limit = 200_000) {
  const located = await resolveInside(root, input);
  if (!located.exists) throw pathError("文件不存在");
  const opened = await openInside(located, constants.O_RDONLY);
  try {
    const info = await opened.file.stat();
    if (!info.isFile() || info.nlink > 1) throw pathError("不打开这种文件");
    if (info.size > limit) throw pathError("文件太大");
    await opened.recheck();
    return await opened.file.readFile("utf8");
  } finally {
    await opened.close();
  }
}

export async function confineReady(root, input) {
  const rel = safeRelative(input);
  const base = await fs.realpath(root);
  const parts = rel.split(path.sep).filter((part) => part && part !== ".");
  if (!parts.length) throw pathError("不能把目录本身当成文件写");
  let current = base;
  for (let index = 0; index < parts.length - 1; index += 1) {
    current = path.join(current, parts[index]);
    if (current !== base && !current.startsWith(`${base}${path.sep}`)) throw pathError("路径超出工作区");
    let info;
    try {
      info = await fs.lstat(current);
    } catch (error) {
      if (error.code === "ENOENT") return { rel };
      throw error;
    }
    if (info.isSymbolicLink()) throw pathError("不跟随符号链接");
    if (!info.isDirectory()) throw pathError("上级不是目录");
  }
  const target = path.join(current, parts.at(-1));
  let existing;
  try {
    existing = await fs.lstat(target);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  if (existing?.isSymbolicLink()) throw pathError("不跟随符号链接");
  if (existing && !existing.isFile()) throw pathError("不能把目录当成文件写");
  return { rel };
}

export async function writeConfined(root, input, text) {
  const rel = safeRelative(input);
  const base = await fs.realpath(root);
  const parts = rel.split(path.sep).filter((part) => part && part !== ".");
  if (!parts.length) throw pathError("不能把目录本身当成文件写");
  let current = base;
  for (let index = 0; index < parts.length - 1; index += 1) {
    current = path.join(current, parts[index]);
    if (current !== base && !current.startsWith(`${base}${path.sep}`)) throw pathError("路径超出工作区");
    let info;
    try {
      info = await fs.lstat(current);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      await fs.mkdir(current);
      continue;
    }
    if (info.isSymbolicLink()) throw pathError("不跟随符号链接");
    if (!info.isDirectory()) throw pathError("上级不是目录");
  }
  const target = path.join(current, parts.at(-1));
  let existing;
  try {
    existing = await fs.lstat(target);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  if (existing?.isSymbolicLink()) throw pathError("不跟随符号链接");
  if (existing?.isFile() && existing.nlink > 1) throw pathError("不打开硬链接");
  const opened = await openWritable({ root: base, target, rel });
  try {
    await opened.recheck();
    await opened.file.truncate(0);
    await opened.file.writeFile(text, "utf8");
    await opened.file.sync();
  } finally {
    await opened.close();
  }
  return { rel, target, exists: Boolean(existing) };
}

export async function writeConfinedBytes(root, input, bytes) {
  const rel = safeRelative(input);
  const base = await fs.realpath(root);
  const parts = rel.split(path.sep).filter((part) => part && part !== ".");
  if (!parts.length) throw pathError("不能把目录本身当成文件写");
  let current = base;
  for (let index = 0; index < parts.length - 1; index += 1) {
    current = path.join(current, parts[index]);
    let info;
    try {
      info = await fs.lstat(current);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      await fs.mkdir(current);
      continue;
    }
    if (info.isSymbolicLink()) throw pathError("不跟随符号链接");
    if (!info.isDirectory()) throw pathError("上级不是目录");
  }
  const target = path.join(current, parts.at(-1));
  const data = Buffer.from(bytes);
  const opened = await openWritable({ root: base, target, rel });
  try {
    await opened.recheck();
    await opened.file.truncate(0);
    await opened.file.write(data);
    await opened.file.sync();
  } finally {
    await opened.close();
  }
  return { rel, target, bytes: data.length };
}

export function redact(text, secrets) {
  let out = String(text ?? "");
  for (const secret of secrets) {
    if (typeof secret === "string" && secret.length > 4) {
      out = out.split(secret).join("***");
    }
  }
  return out;
}
