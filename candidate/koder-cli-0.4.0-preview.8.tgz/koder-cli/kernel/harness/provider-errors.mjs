// Public model failures cross worker and Office boundaries by code, never by
// copying upstream bodies (which can echo credentials or document contents).
const failures = Object.freeze({
  MODEL_AUTH_FAILED: [401, '模型服务拒绝了 API 凭据，请在 Koder 模型设置中检查密钥。'],
  MODEL_ACCESS_DENIED: [403, '当前 API 没有使用此模型的权限，请检查 Koder 模型设置。'],
  MODEL_RATE_LIMIT: [429, '模型服务请求过多或额度不足，请稍后重试并检查服务商额度。'],
  MODEL_BAD_REQUEST: [400, '模型服务不接受本次参数，请检查所选模型与接口协议。'],
  MODEL_NOT_FOUND: [404, '模型或接口地址不存在，请检查 Koder 模型设置。'],
  MODEL_UNAVAILABLE: [502, '模型服务暂时不可用，请稍后重试。'],
  MODEL_NETWORK: [502, '与模型服务的连接中断，当前任务已保留。请稍后重试。'],
  MODEL_TIMEOUT: [504, '模型请求超时，请稍后重试。'],
  MODEL_INCOMPLETE: [502, '模型输出达到上限，本次内容未完整生成。请缩小修改范围后重试；未执行本轮未完成的工具指令。'],
  MODEL_FILTERED: [502, '模型服务中止了本次输出，请调整请求后重试。'],
  MODEL_CONTEXT_LIMIT: [502, '模型的续答上下文过大，请新建办公 AI 对话并缩小修改范围。'],
  CONTEXT_BUDGET_EXCEEDED: [409, '当前请求和必须保留的记录超过模型上下文预算。内容已保留，请缩小请求、处理待确认事项、减少启用的工具或技能，或选择上下文更大的模型后继续。'],
  MODEL_CONTEXT_EXPIRED: [409, '办公 AI 的模型续答上下文已过期，请新建 AI 对话后继续，已保存的文档不受影响。'],
  MODEL_PROTOCOL: [502, '模型没有返回有效的回复，请检查接口协议。'],
  MODEL_EMPTY_REPLY: [502, '模型返回了空内容，请重试或换一个模型。'],
  MODEL_ERROR: [502, '模型请求未完成，请检查 Koder 模型设置后重试。'],
  NO_MODEL: [409, '请先在 Koder 模型设置中连接并选择模型。'],
  NO_PROVIDER: [409, '请先在 Koder 模型设置中登记 API 凭据。'],
  ABORT_ERR: [499, '本次 AI 请求已取消。'],
  BAD_MESSAGES: [400, '需要有效的消息列表。'],
  BAD_MODEL: [400, '所选型号尚未登记，请在 Koder 模型设置中保存型号。'],
  UNKNOWN_PROVIDER: [404, '所选模型服务尚未登记，请检查 Koder 模型设置。'],
  OFFICE_HOST_AUTH: [403, 'Office 与 Koder 的连接凭证已失效，请重新打开应用。'],
});

export function modelError(code = 'MODEL_ERROR') {
  const safeCode = typeof code === 'string' && Object.hasOwn(failures, code) ? code : 'MODEL_ERROR';
  const [status, message] = failures[safeCode];
  return Object.assign(new Error(message), {code: safeCode, status});
}

export function modelHttpError(status) {
  return modelError(status === 401 ? 'MODEL_AUTH_FAILED' : status === 403 ? 'MODEL_ACCESS_DENIED'
    : status === 429 ? 'MODEL_RATE_LIMIT' : status === 404 ? 'MODEL_NOT_FOUND'
    : status === 408 || status === 504 ? 'MODEL_TIMEOUT'
    : status >= 400 && status < 500 ? 'MODEL_BAD_REQUEST' : 'MODEL_UNAVAILABLE');
}

export function publicModelError(error, signal) {
  if (signal?.aborted || error?.name === 'AbortError' || error?.code === 'ABORT_ERR') return modelError('ABORT_ERR');
  if (error?.name === 'TimeoutError' || error?.code === 'ETIMEDOUT') return modelError('MODEL_TIMEOUT');
  return Object.assign(modelError(error?.code), modelRecoveryHints(error));
}

// Only bounded transport facts may cross worker boundaries, never response
// bodies, headers or arbitrary upstream error properties.
export function modelRecoveryHints(error) {
  return {
    ...(Number.isFinite(error?.retryAfterMs) && error.retryAfterMs >= 0 && error.retryAfterMs <= 3_600_000 ? {retryAfterMs:error.retryAfterMs} : {}),
    ...(error?.streamInterrupted === true ? {streamInterrupted:true} : {}),
  };
}
