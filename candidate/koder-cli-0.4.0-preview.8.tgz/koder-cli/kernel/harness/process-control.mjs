import { spawn } from 'node:child_process';

export function shellInvocation(command, { platform = process.platform, env = process.env } = {}) {
  if (platform === 'win32') {
    return {
      file: env.ComSpec || env.COMSPEC || `${env.SystemRoot || 'C:\\Windows'}\\System32\\cmd.exe`,
      args: ['/d', '/s', '/c', `"${String(command)}"`],
      windowsVerbatimArguments: true,
    };
  }
  return { file: '/bin/sh', args: ['-c', String(command)], windowsVerbatimArguments: false };
}

function commandEnvironment(env) {
  const clean = { PATH: env.PATH || '/usr/bin:/bin', HOME: env.HOME || '', LANG: 'C.UTF-8' };
  if (env.PYTHONDONTWRITEBYTECODE === '1') clean.PYTHONDONTWRITEBYTECODE = '1';
  for (const key of ['SystemRoot', 'WINDIR', 'ComSpec', 'COMSPEC', 'PATHEXT', 'TEMP', 'TMP', 'USERPROFILE']) {
    if (typeof env[key] === 'string') clean[key] = env[key];
  }
  return clean;
}

// Only a process group created by this invocation is signalled. All waits are
// bounded, including escalation when the direct shell exits before its child.
export function runOwnedCommand({ cwd, command, signal, spawnImpl = spawn, platform = process.platform, env = process.env, killImpl = process.kill.bind(process), timeoutMs = 20_000, maxOutput = 24_000, stopGraceMs = 200, cleanupTimeoutMs = 1500 }) {
  return new Promise((resolve) => {
    let child;
    let output = '';
    let done = false;
    let closed = false;
    let code = null;
    let exitSignal = null;
    let reason = null;
    let problem = null;
    let timer;
    let escalation;
    let deadline;
    let poll;
    let treeKilled = false;
    let treeKillStarted = false;
    let outputTruncated = false;
    let treeFailed = false;
    const windows = platform === 'win32';

    const finish = (cleanupComplete) => {
      if (done) return;
      done = true;
      for (const active of [timer, escalation, deadline, poll]) clearTimeout(active);
      signal?.removeEventListener('abort', onAbort);
      const timedOut = reason === 'timeout';
      const aborted = reason === 'abort';
      const truncated = outputTruncated;
      const notes = [];
      if (problem) notes.push(problem);
      if (timedOut) notes.push(`…超过 ${Math.ceil(timeoutMs / 1000)} 秒，已停止`);
      if (aborted) notes.push('…已取消');
      if (truncated) notes.push('…输出已截断');
      if (reason === 'descendants') notes.push('…命令退出后仍有子进程，已清理');
      if (!cleanupComplete) notes.push('…未能确认命令进程树已全部退出');
      const content = [output.trimEnd(), ...notes, `退出码 ${code}`].filter(Boolean).join('\n');
      resolve({ ok: code === 0 && !reason && !problem && cleanupComplete, content, output, exitCode: code, signal: exitSignal, timedOut, aborted, truncated, cleanupComplete, error: problem || undefined });
    };

    const groupAlive = () => {
      if (!child?.pid) return false;
      if (windows) return !treeKilled;
      try { killImpl(-child.pid, 0); return true; }
      catch (error) { return error.code !== 'ESRCH'; }
    };

    const maybeFinish = () => {
      if (done || !closed) return;
      if (!reason) {
        if (!windows && groupAlive()) return stop('descendants');
        return finish(true);
      }
      if (!groupAlive() && !treeFailed) return finish(true);
      clearTimeout(poll);
      poll = setTimeout(maybeFinish, 20);
    };

    const killGroup = (force) => {
      if (!child?.pid || done) return;
      if (windows) {
        if (treeKilled || treeKillStarted || treeFailed || !force) return;
        treeKillStarted = true;
        const file = `${env.SystemRoot || 'C:\\Windows'}\\System32\\taskkill.exe`;
        let killer;
        try {
          killer = spawnImpl(file, ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
        } catch { treeFailed = true; try { child.kill(); } catch {} return; }
        let killerTimer = setTimeout(() => { treeFailed = true; try { killer.kill(); } catch {} }, 1000);
        killer.once('error', () => { treeFailed = true; clearTimeout(killerTimer); try { child.kill(); } catch {} });
        killer.once('close', (result) => {
          clearTimeout(killerTimer);
          treeKilled = result === 0;
          treeFailed ||= result !== 0;
          maybeFinish();
        });
        return;
      }
      try { killImpl(-child.pid, force ? 'SIGKILL' : 'SIGTERM'); }
      catch (error) {
        if (error.code === 'ESRCH') return;
        treeFailed = true;
        try { child.kill(force ? 'SIGKILL' : 'SIGTERM'); } catch {}
      }
    };

    const stop = (why) => {
      if (done || reason) return;
      reason = why;
      clearTimeout(timer);
      killGroup(windows);
      escalation = setTimeout(() => { killGroup(true); maybeFinish(); }, stopGraceMs);
      deadline = setTimeout(() => {
        killGroup(true);
        child?.stdout?.destroy();
        child?.stderr?.destroy();
        finish(closed && !groupAlive() && !treeFailed);
      }, cleanupTimeoutMs);
      maybeFinish();
    };
    const onAbort = () => stop('abort');
    if (signal?.aborted) { reason = 'abort'; finish(true); return; }
    const invocation = shellInvocation(command, { platform, env });
    try {
      child = spawnImpl(invocation.file, invocation.args, {
        cwd, detached: !windows, stdio: ['ignore', 'pipe', 'pipe'],
        env: commandEnvironment(env), windowsHide: true,
        windowsVerbatimArguments: invocation.windowsVerbatimArguments,
      });
    } catch (error) {
      problem = `命令没有启动：${error.message}`;
      finish(true);
      return;
    }
    const take = (chunk) => {
      if (done || reason === 'output') return;
      const text = chunk.toString('utf8');
      const remaining = Math.max(0, maxOutput - output.length);
      output += text.slice(0, remaining);
      if (text.length > remaining) { outputTruncated = true; stop('output'); }
    };
    child.stdout?.on('data', take);
    child.stderr?.on('data', take);
    const pipeError = (error) => { problem ||= `命令输出通道错误：${error.message}`; stop('pipe'); };
    child.stdout?.on('error', pipeError);
    child.stderr?.on('error', pipeError);
    child.on('error', (error) => {
      problem ||= `命令没有启动：${error.message}`;
      if (!child.pid) finish(true); else stop('spawn');
    });
    child.on('close', (status, receivedSignal) => {
      closed = true;
      code = typeof status === 'number' ? status : null;
      exitSignal = receivedSignal || null;
      clearTimeout(timer);
      maybeFinish();
    });
    timer = setTimeout(() => stop('timeout'), timeoutMs);
    signal?.addEventListener('abort', onAbort, { once: true });
    if (signal?.aborted) onAbort();
  });
}
