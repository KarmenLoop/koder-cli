import {createHash} from 'node:crypto';

// Koder's model-boundary projection. Durable messages and execution receipts are
// never edited here. Missing results are uncertainty, never success or a retry.
// Design reference: Pi v1.3.0 transform-messages (MIT); see docs/pi-harness.md.
const UNKNOWN_RESULT = 'TOOL_RESULT_UNCONFIRMED：没有可核对的工具结果，外部操作是否发生未知。继续前先读取当前状态；不要据此宣布成功或自动重试副作用。';

export function prepareToolHistory(messages) {
  const result = [];
  const reserved = new Set(messages.flatMap(message => (message.toolCalls || []).map(call => call.id)));
  const used = new Set();
  const wireId = id => {
    if (typeof id === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(id) && !used.has(id)) {
      used.add(id);
      return id;
    }
    const base = `koder_${createHash('sha256').update(String(id ?? '')).digest('hex').slice(0,40)}`;
    let candidate = base, suffix = 0;
    while (used.has(candidate) || reserved.has(candidate)) candidate = `${base}_${++suffix}`;
    used.add(candidate);
    return candidate;
  };
  let pending = null;
  const close = () => {
    if (!pending) return;
    for (const {call, sourceId, ambiguous} of pending.calls) {
      const actual = !ambiguous && pending.results.get(sourceId);
      result.push(actual ? {...actual, toolCallId: call.id} : {
        role: 'tool', toolCallId: call.id, name: call.name,
        content: UNKNOWN_RESULT, isError: true,
      });
    }
    result.push(...pending.system);
    pending = null;
  };
  for (const message of messages) {
    if (message.role === 'notice') continue;
    if (message.role === 'system' && pending) {
      pending.system.push(message);
      continue;
    }
    if (message.role === 'tool') {
      // Do not bind an old/duplicate receipt to a different turn. Orphans stay
      // in the saved history, but cannot be sent as protocol-level receipts.
      if (pending?.calls.some(item => !item.ambiguous && item.sourceId === message.toolCallId) && !pending.results.has(message.toolCallId)) {
        pending.results.set(message.toolCallId, message);
      }
      continue;
    }
    close();
    if (message.role === 'assistant' && message.toolCalls?.length) {
      const counts = new Map();
      for (const call of message.toolCalls) counts.set(call.id, (counts.get(call.id) || 0) + 1);
      const calls = message.toolCalls.map(call => ({sourceId:call.id, ambiguous:counts.get(call.id) > 1, call:{...call, id:wireId(call.id)}}));
      pending = {calls, results: new Map(), system: []};
      result.push({...message, toolCalls:calls.map(item => item.call)});
    } else result.push(message);
  }
  close();
  return result;
}
