import fs from "node:fs/promises";
import path from "node:path";
import { writeFileJson } from "../loop/json-store.mjs";
import { isSealed, openVault } from "../fusion/vault.mjs";
import { createPrivateStore } from "../fusion/private-store.mjs";

export function defaultSettings() {
  return {
    providerId: null,
    mode: "standard",
    surface: "dev",
    interaction: "agent",
    enabled: {},
    contextRatio: 0.5,
    lastThreadId: null,
    theme: "system",
  };
}

export function stampMessages(thread) {
  const now = Date.now();
  for (const message of thread?.messages || []) {
    if (!message.at) message.at = now;
  }
}

export async function createStore(dir, { lock = null } = {}) {
  if (!dir) return memoryStore();
  await fs.mkdir(path.join(dir, "threads"), { recursive: true });
  return diskStore(dir, lock);
}

function memoryStore() {
  const threads = new Map();
  const bag = { settings: defaultSettings(), providers: [], skills: [] };
  return api({
    threads,
    bag,
    async saveBag() {},
    async saveThread() {},
    async removeThread(id) {
      threads.delete(id);
    },
  });
}

function diskStore(dir, lock) {
  const files=lock?createPrivateStore({dir,lock}):null;
  const readJson=async(file,fallback)=>files?files.readJson(path.relative(dir,file).split(path.sep).join('/'),fallback):fs.readFile(file,'utf8').then(JSON.parse,error=>{if(error.code==='ENOENT')return fallback;throw error;});
  const writeJson=(file,value)=>files?files.writeJson(path.relative(dir,file).split(path.sep).join('/'),value):writeFileJson(file,value);
  const threads = new Map();
  const bag = { settings: defaultSettings(), providers: [], skills: [] };
  const bagPath = path.join(dir, "bag.json");
  const recoveryPath = path.join(dir, "bag-recovery.json");
  let vault = null, durableBag = structuredClone(bag), uncertain = null;
  const recoveryError = (cause, code = "BAG_STATE_UNCERTAIN") => Object.assign(new Error("设置保存状态无法确认；已停止继续保存。请重新打开 Koder 恢复之前的设置，再明确授权。", { cause }), { code, effectsMayHaveCompleted: true });
  async function clearRecovery() {
    if (files) await files.remove("bag-recovery.json");
    else await fs.rm(recoveryPath, { force: true });
    if (process.platform !== "win32") {
      const directory = await fs.open(dir, "r");
      try { await directory.sync(); } finally { await directory.close(); }
    }
  }
  async function restoreRecovery(record) {
    if (record?.version !== 1 || !isSealed(record.before)) throw recoveryError(null, "BAG_RECOVERY_REQUIRED");
    const previous = JSON.parse(vault.open(record.before));
    if (!previous?.settings || typeof previous.settings !== "object" || !Array.isArray(previous.providers) || !Array.isArray(previous.skills)) throw recoveryError(null, "BAG_RECOVERY_REQUIRED");
    await writeJson(bagPath, previous);
    await clearRecovery();
    return previous;
  }
  return api({
    threads,
    bag,
    async load() {
      vault = await openVault(dir, { lock });
      // A pending encrypted before-image takes precedence over bag.json,
      // including a candidate that was renamed before a durability failure.
      try {
        const entry = await fs.lstat(recoveryPath).catch(error => { if (error.code === "ENOENT") return null; throw error; });
        if (entry) {
          if (!entry.isFile() || entry.isSymbolicLink()) throw new Error("Invalid bag recovery file");
          await restoreRecovery(await readJson(recoveryPath, null));
        }
      } catch (error) { throw recoveryError(error, "BAG_RECOVERY_REQUIRED"); }
      const parsed = await readJson(bagPath,null);
      durableBag = parsed ? structuredClone(parsed) : structuredClone(bag);
      if (parsed) {
        bag.settings = { ...defaultSettings(), ...(parsed.settings || {}) };
        bag.providers = (parsed.providers || []).map((item) => ({
          ...item,
          apiKey: isSealed(item.apiKey) ? vault.open(item.apiKey) : item.apiKey,
        }));
        bag.skills = parsed.skills || [];
      }
      const folder = path.join(dir, "threads");
      const names = await fs.readdir(folder).catch(() => []);
      for (const name of names) {
        if (!name.endsWith(".json")) continue;
        const thread = await readJson(path.join(folder, name),null);
        threads.set(thread.id, thread);
      }
    },
    async saveBag() {
      const stored = {
        ...bag,
        providers: bag.providers.map((item) => ({
          ...item,
          apiKey: item.apiKey ? vault.seal(item.apiKey) : "",
        })),
      };
      if (uncertain) throw uncertain;
      const before = structuredClone(durableBag);
      // Always encrypt the full before-image, also for the legacy file vault.
      const recovery = { version: 1, before: vault.seal(JSON.stringify(before)) };
      await writeJson(recoveryPath, recovery);
      let candidateWritten = false;
      try {
        await writeJson(bagPath, stored);
        candidateWritten = true;
        await clearRecovery();
        durableBag = stored;
      } catch (error) {
        if (!candidateWritten && error.committedPath !== bagPath) {
          // The bag itself did not change; a blocked target remains retryable.
          try { await clearRecovery(); } catch (cleanupError) { error.recoveryCleanupError = cleanupError; }
          throw error;
        }
        try {
          await restoreRecovery(recovery);
          durableBag = before;
        } catch (rollbackError) {
          // A failed marker unlink fsync may have removed its directory entry.
          // Re-establish the already encrypted recovery record when possible.
          let markerError = null;
          try { await writeJson(recoveryPath, recovery); } catch (failure) { markerError = failure; }
          uncertain = recoveryError(new AggregateError([error, rollbackError, ...(markerError ? [markerError] : [])], "Bag commit and recovery failed"));
          uncertain.recoveryMarkerConfirmed = !markerError;
          if (markerError) uncertain.message = "设置与恢复记录的保存状态都无法确认；已停止继续保存。请保留数据目录并检查磁盘，恢复确认前不要继续授权。";
          throw uncertain;
        }
        error.rollbackComplete = true;
        throw error;
      }
    },
    async saveThread(thread) {
      const file = path.join(dir, "threads", `${thread.id}.json`);
      const stored = { ...thread };
      delete stored.draft;
      await writeJson(file, stored);
      const indexPath = path.join(dir, "index.json");
      const index = [...threads.values()].map(threadSummary);
      await writeJson(indexPath, index);
    },
    async removeThread(id) {
      threads.delete(id);
      if(files)await files.remove(`threads/${id}.json`);
      else await fs.rm(path.join(dir, "threads", `${id}.json`), { force: true });
    },
  });
}

function api(backend) {
  const threads = backend.threads;
  const bag = backend.bag;
  let bagTail = Promise.resolve();
  const saveGroup = (key, next, merge = false) => {
    const snapshot = structuredClone(next);
    // Every bag writer shares this queue: a provider or skill save must not
    // capture permissions whose earlier save will fail and roll back.
    const job = bagTail.then(async () => {
      const previous = bag[key], value = merge ? { ...previous, ...snapshot } : snapshot;
      bag[key] = value;
      try { await backend.saveBag(); return value; }
      catch (error) { if (bag[key] === value) bag[key] = previous; throw error; }
    });
    bagTail = job.then(() => {}, () => {});
    return job;
  };
  return {
    async load() {
      await backend.load?.();
    },
    listThreads() {
      return [...threads.values()].sort((a, b) => b.updatedAt - a.updatedAt);
    },
    getThread(id) {
      return threads.get(id) || null;
    },
    async saveThread(thread) {
      thread.updatedAt = Date.now();
      stampMessages(thread);
      threads.set(thread.id, thread);
      await backend.saveThread(thread);
    },
    async removeThread(id) {
      await backend.removeThread(id);
    },
    settings() {
      return bag.settings;
    },
    saveSettings(next) {
      return saveGroup("settings", next, true);
    },
    providers() {
      return bag.providers;
    },
    async saveProviders(next) {
      await saveGroup("providers", next);
    },
    skills() {
      return bag.skills;
    },
    async saveSkills(next) {
      await saveGroup("skills", next);
    },
    secrets() {
      return bag.providers.map((item) => item.apiKey).filter(Boolean);
    },
  };
}

export function threadSummary(thread) {
  return {
    id: thread.id,
    title: thread.title,
    status: thread.status,
    updatedAt: thread.updatedAt,
    mode: thread.mode,
    usage: thread.usage || null,
  };
}

export function publicProvider(provider) {
  const key = provider.apiKey || "";
  return {
    id: provider.id,
    name: provider.name,
    protocol: provider.protocol,
    baseUrl: provider.baseUrl,
    model: provider.model,
    contextWindow: provider.contextWindow || null,
    maxOutput: provider.maxOutput || null,
    apiKeySet: Boolean(key),
    apiKeyTail: key ? key.slice(-4) : "",
  };
}

export function publicThread(thread) {
  if (!thread) return null;
  const copy = JSON.parse(JSON.stringify(thread));
  delete copy.draft;
  scrub(copy);
  return { ...copy, draft: thread.draft || "" };
}

function scrub(value) {
  if (!value || typeof value !== "object") return;
  for (const key of Object.keys(value)) {
    if (key === "password" || key === "apiKey" || key === "account") delete value[key];
    else scrub(value[key]);
  }
}
