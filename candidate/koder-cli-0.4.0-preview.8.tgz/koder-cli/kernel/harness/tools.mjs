import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import { constants } from "node:fs";
import { openInside, resolveInside, readConfined, safeRelative, writeConfined } from "./paths.mjs";
import { runOwnedCommand } from "./process-control.mjs";

const pendingWrites = new Map();
const TEXT_LIMIT = 80_000;
const SEARCH_FILES = 2000;
const SEARCH_HITS = 40;

function clip(text) {
  const value = String(text ?? "");
  if (value.length <= TEXT_LIMIT) return value;
  return `${value.slice(0, TEXT_LIMIT)}\n…已截断，原文超过 ${TEXT_LIMIT} 字符`;
}

async function walk(root, visitor) {
  const pending = [root];
  let seen = 0;
  while (pending.length && seen < SEARCH_FILES) {
    const dir = pending.pop();
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name === ".git" || entry.name === "node_modules") continue;
      const full = path.join(dir, entry.name);
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) pending.push(full);
      else if (entry.isFile()) {
        seen += 1;
        if (seen > SEARCH_FILES) break;
        await visitor(full);
      }
    }
  }
}

export function createTools({ root, spawnImpl = spawn, commandOptions = {}, authorizedFiles=null, fileDeliveryEnabled=false, computerDriver=null }) {
  const outside=input=>typeof input==='string'&&path.isAbsolute(input)&&(()=>{const rel=path.relative(root,input);return rel==='..'||rel.startsWith('..'+path.sep)||path.isAbsolute(rel);})();
  async function homeRead(input,{offset=0,maxBytes=65536}={}){if(!authorizedFiles)throw Object.assign(new Error('COMPUTER_PERMISSION_REQUIRED'),{code:'COMPUTER_PERMISSION_REQUIRED'});return authorizedFiles.read({path:input,offset,maxBytes:Math.min(65536,Math.max(1,Number(maxBytes)||65536))});}
  async function homeChange(args,replace=false){
    if(!authorizedFiles)throw Object.assign(new Error('COMPUTER_PERMISSION_REQUIRED'),{code:'COMPUTER_PERMISSION_REQUIRED'});
    let before='',expectedDigest=null;
    try{const receipt=await authorizedFiles.read({path:args.path,maxBytes:200000});if(receipt.size>200000)throw new Error('FILE_EDIT_LIMIT');before=receipt.text;expectedDigest=receipt.sha256;}catch(e){if(e.code!=='ENOENT')throw e;}
    let after=args.content;if(replace){if(typeof args.old!=='string'||!args.old||before.split(args.old).length!==2)throw new Error('FILE_REPLACE_NOT_UNIQUE');after=before.replace(args.old,String(args.new??''));}
    if(typeof after!=='string'||after.length>200000)throw new Error('FILE_CONTENT_TOO_LARGE');
    return {ok:true,pause:{kind:'change',path:args.path,before,after,computerScope:true,expectedDigest}};
  }
  return {
    async run(name, args = {}, signal) {
      try {
        signal?.throwIfAborted();
        if(name==='computer_act'){if(!computerDriver)throw new Error('COMPUTER_DRIVER_MISSING');return {ok:true,pause:{kind:'approval',command:'操作当前电脑目标：'+String(args.action||''),computerAction:structuredClone(args)}};}
        if(name==='send_file'){
          if(!fileDeliveryEnabled)return {ok:false,content:'FILE_CHANNEL_UNSUPPORTED',error:'FILE_CHANNEL_UNSUPPORTED'};
          if(typeof args.path!=='string'||args.path.length>4096||typeof(args.caption||'')!=='string')throw new Error('FILE_INPUT_INVALID');
          const file=path.resolve(root,args.path);return {ok:true,pause:{kind:'approval',command:`发送文件：${file} → 当前聊天`,delivery:{path:file,caption:args.caption||''}}};
        }
        if(name==='read_file'&&outside(args.path)){const receipt=await homeRead(args.path,args);return {ok:true,path:receipt.path,canonicalPath:receipt.path,cwd:root,sourceDigest:receipt.sha256,content:receipt.text+`\n[bytes=${receipt.bytes}; sha256=${receipt.sha256}; nextOffset=${receipt.nextOffset}]`};}
        if(name==='write_file'&&outside(args.path))return await homeChange(args);
        if(name==='str_replace'&&outside(args.path))return await homeChange(args,true);
        if(name==='search'&&args.scope==='home'){if(!authorizedFiles)throw new Error('COMPUTER_PERMISSION_REQUIRED');return {ok:true,content:JSON.stringify(await authorizedFiles.search({query:args.query,cursor:args.cursor||null,limit:args.limit||100,signal}))};}
        if (name === "list_dir") return { ok: true, content: await listDir(root, args.path ?? ".") };
        if (name === "read_file") return await readFile(root, args.path);
        if (name === "search") return { ok: true, content: await search(root, args.query) };
        if (name === "str_replace") return await planReplace(root, args);
        if (name === "write_file") return await planWrite(root, args);
        if (name === "shell") return planShell(args);
        return { ok: false, content: `没有这个工具：${name}` };
      } catch (error) {
        return { ok: false, content: error?.message || "工具没有完成", error: error?.code || "TOOL_FAILED" };
      }
    },
    async applyChange(change, signal) {
      signal?.throwIfAborted();
      if(outside(change.path)){if(!authorizedFiles||!change.computerScope)throw new Error('COMPUTER_CHANGE_NOT_PREPARED');return authorizedFiles.write({path:change.path,content:change.after,expectedDigest:change.expectedDigest,signal});}
      const key = path.resolve(await fs.realpath(root), safeRelative(change.path));
      const job = (pendingWrites.get(key) || Promise.resolve()).catch(() => {}).then(async () => {
        signal?.throwIfAborted();
        const located = await resolveInside(root,change.path,{missingParents:true});
        const current = located.exists ? await readConfined(root,change.path,2_000_000) : "";
        if (typeof change.before !== "string" || current !== change.before || typeof change.existed === "boolean" && located.exists !== change.existed) {
          throw Object.assign(new Error("FILE_CHANGED：文件已被修改，未覆盖现有内容。请重新读取后再修改自己负责的段落。"),{code:"FILE_CHANGED",effectsMayHaveCompleted:false});
        }
        signal?.throwIfAborted();
        await writeConfined(root, change.path, change.after);
      });
      pendingWrites.set(key,job);
      try {await job;} finally {if(pendingWrites.get(key)===job)pendingWrites.delete(key);}

    },
    async runShell(command, signal) {
      return (await runOwnedCommand({ ...commandOptions, cwd: root, command, signal, spawnImpl })).content;
    },
    runCommand(command, options = {}) {
      return runOwnedCommand({ ...commandOptions, ...options, cwd: root, command, spawnImpl });
    },
  };
}

async function listDir(root, input) {
  const located = await resolveInside(root, input || ".");
  if (!located.exists) throw new Error("目录不存在");
  const opened = await openInside(located, constants.O_RDONLY);
  try {
    const stat = await opened.file.stat();
    if (!stat.isDirectory()) throw new Error("这是文件，不是目录");
    const entries = await fs.readdir(located.target, { withFileTypes: true });
    await opened.recheck();
    const lines = entries
      .filter((entry) => entry.name !== ".git" && !entry.isSymbolicLink())
      .slice(0, 200)
      .map((entry) => `${entry.isDirectory() ? "dir" : "file"}\t${entry.name}`);
    return lines.join("\n") || "空目录";
  } finally {
    await opened.close();
  }
}

async function readFile(root, input) {
  const cwd = await fs.realpath(root);
  const located = await resolveInside(cwd, input);
  const content = clip(await readConfined(cwd, located.rel, TEXT_LIMIT));
  return { ok: true, content, path: located.rel, canonicalPath: located.target, cwd };
}

async function search(root, query) {
  const needle = String(query || "").trim();
  if (!needle) throw new Error("缺少搜索原文");
  if (needle.length > 200) throw new Error("搜索原文过长");
  const hits = [];
  await walk(root, async (full) => {
    if (hits.length >= SEARCH_HITS) return;
    const stat = await fs.stat(full);
    if (stat.size > 200_000) return;
    let text = "";
    try {
      text = await fs.readFile(full, "utf8");
    } catch {
      return;
    }
    const lines = text.split("\n");
    const rel = path.relative(root, full);
    for (let index = 0; index < lines.length; index += 1) {
      if (!lines[index].toLowerCase().includes(needle.toLowerCase())) continue;
      hits.push(`${rel}:${index + 1}: ${lines[index].trim().slice(0, 180)}`);
      if (hits.length >= SEARCH_HITS) break;
    }
  });
  return hits.join("\n") || "没有匹配";
}

async function planReplace(root, args) {
  const oldText = typeof args.old === "string" ? args.old : "";
  const newText = typeof args.new === "string" ? args.new : "";
  if (!oldText) return { ok: false, content: "old 不能是空字符串" };
  const located = await resolveInside(root, args.path);
  if (!located.exists) return { ok: false, content: "文件不存在，没有替换" };
  const before = await fs.readFile(located.target, "utf8");
  const count = before.split(oldText).length - 1;
  if (count !== 1) return { ok: false, content: `没有替换。这段原文出现了 ${count} 次，需要恰好 1 次。` };
  return {
    ok: true,
    pause: {
      kind: "change",
      path: located.rel,
      existed: located.exists,
      before,
      after: before.replace(oldText, newText),
    },
  };
}

async function planWrite(root, args) {
  if (typeof args.content !== "string") return { ok: false, content: "content 必须是字符串" };
  if (args.content.length > 200_000) return { ok: false, content: "内容超过 200000 字符，没有提出写入" };
  safeRelative(args.path);
  const located = await resolveInside(root, args.path, { missingParents: true });
  const before = located.exists ? await fs.readFile(located.target, "utf8") : "";
  return {
    ok: true,
    pause: {
      kind: "change",
      path: located.rel,
      existed: located.exists,
      before,
      after: args.content,
    },
  };
}

function planShell(args) {
  const command = typeof args.command === "string" ? args.command.trim() : "";
  if (!command) return { ok: false, content: "命令是空的" };
  if (command.length > 4000) return { ok: false, content: "命令超过 4000 字符" };
  return { ok: true, pause: { kind: "approval", command } };
}

