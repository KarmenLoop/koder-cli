function lcsTable(a, b) {
  const rows = a.length + 1;
  const cols = b.length + 1;
  const table = Array.from({ length: rows }, () => new Uint16Array(cols));
  for (let i = a.length - 1; i >= 0; i -= 1) {
    for (let j = b.length - 1; j >= 0; j -= 1) {
      table[i][j] = a[i] === b[j]
        ? table[i + 1][j + 1] + 1
        : Math.max(table[i + 1][j], table[i][j + 1]);
    }
  }
  return table;
}

export function unifiedDiff(before, after) {
  const a = String(before ?? "").split("\n");
  const b = String(after ?? "").split("\n");
  if (a.length * b.length > 250000) {
    return [{
      type: "note",
      text: `改动较大，接受前不会写入。原文 ${a.length} 行，新文 ${b.length} 行。`,
    }];
  }
  const table = lcsTable(a, b);
  const lines = [];
  let i = 0;
  let j = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) {
      lines.push({ type: "same", text: a[i] });
      i += 1;
      j += 1;
    } else if (table[i + 1][j] >= table[i][j + 1]) {
      lines.push({ type: "del", text: a[i] });
      i += 1;
    } else {
      lines.push({ type: "add", text: b[j] });
      j += 1;
    }
  }
  while (i < a.length) {
    lines.push({ type: "del", text: a[i] });
    i += 1;
  }
  while (j < b.length) {
    lines.push({ type: "add", text: b[j] });
    j += 1;
  }
  return collapse(lines);
}

function collapse(lines) {
  const out = [];
  let same = [];
  const flush = (keep) => {
    if (same.length === 0) return;
    if (keep === "all" || same.length <= 4) out.push(...same);
    else {
      out.push(same[0]);
      out.push({ type: "note", text: `… ${same.length - 2} 行未改 …` });
      out.push(same[same.length - 1]);
    }
    same = [];
  };
  for (const line of lines) {
    if (line.type === "same") same.push(line);
    else {
      flush("edge");
      out.push(line);
    }
  }
  flush("edge");
  return out.slice(0, 400);
}
