export const TOOL_PLUGINS = [
  {
    id:'tools.send-file',name:'send_file',mutates:true,modes:['standard','code','execute'],
    description:'把已授权的本地文件发送到当前聊天。结果未知时先核对，不重复发送；没有当前渠道或 owner 授权时会拒绝。',
    parameters:{type:'object',properties:{path:{type:'string'},caption:{type:'string'}},required:['path'],additionalProperties:false},
  },
  {
    id: "tools.list",
    name: "list_dir",
    mutates: false,
    modes: ["standard", "code", "plan", "execute", "report", "enhance"],
    description: "列出工作区内某一层目录。path 用相对路径，根目录用 .",
    parameters: {
      type: "object",
      properties: { path: { type: "string" } },
      required: ["path"],
      additionalProperties: false,
    },
  },
  {
    id: "tools.read",
    name: "read_file",
    mutates: false,
    modes: ["standard", "code", "plan", "execute", "report", "enhance"],
    description: "读取工作区文本；主目录的绝对路径需要本机 owner 已授予的电脑权限。长文件用 offset 分块。",
    parameters: {
      type: "object",
      properties: { path: { type: "string" }, offset: {type:'integer',minimum:0}, maxBytes:{type:'integer',minimum:1,maximum:65536} },
      required: ["path"],
      additionalProperties: false,
    },
  },
  {
    id: "tools.search",
    name: "search",
    mutates: false,
    modes: ["standard", "code", "plan", "execute", "report", "enhance"],
    description: "默认在工作区搜索原文。scope=home 时按已授权主目录检索文件名及元信息，使用 nextCursor 分页。",
    parameters: {
      type: "object",
      properties: { query: { type: "string" },scope:{type:'string',enum:['workspace','home']},cursor:{type:'string'},limit:{type:'integer',minimum:1,maximum:500} },
      required: ["query"],
      additionalProperties: false,
    },
  },
  {
    id: "tools.replace",
    name: "str_replace",
    mutates: true,
    modes: ["standard", "code", "minimal", "execute"],
    description: "把文件中唯一一段 old 换成 new。不会直接落盘，要等用户接受。",
    parameters: {
      type: "object",
      properties: {
        path: { type: "string" },
        old: { type: "string" },
        new: { type: "string" },
        check: { type: "string", description: "接受修改后想跟着跑的检查命令。只有已经设为总是允许的命令会在写入后运行。危险命令不会自动跑。" },
      },
      required: ["path", "old", "new"],
      additionalProperties: false,
    },
  },
  {
    id: "tools.write",
    name: "write_file",
    mutates: true,
    modes: ["standard", "code", "execute"],
    description: "提出一个文件的完整新内容。不会直接落盘，要等用户接受。",
    parameters: {
      type: "object",
      properties: {
        path: { type: "string" },
        content: { type: "string" },
        check: { type: "string", description: "接受修改后想跟着跑的检查命令。只有已经设为总是允许的命令会在写入后运行。危险命令不会自动跑。" },
      },
      required: ["path", "content"],
      additionalProperties: false,
    },
  },
  {
    id: "tools.shell",
    name: "shell",
    mutates: true,
    modes: ["standard", "code", "minimal", "execute"],
    description: "提出一条在工作区目录执行的 shell 命令。用户点允许后才会运行。",
    parameters: {
      type: "object",
      properties: { command: { type: "string" } },
      required: ["command"],
      additionalProperties: false,
    },
  },
];

export const HARNESS_PLUGINS = [
  { id: "model.provider", kind: "model", title: "模型", detail: "OpenAI 兼容或 Anthropic 兼容接口，密钥留在本机。" },
  { id: "tools.core", kind: "tool", title: "工具", detail: "读文件、搜索、提出修改、提出命令。" },
  { id: "skill.prompt", kind: "skill", title: "技能", detail: "一段可开关的工作说明，会进入下一轮系统提示。" },
  { id: "session.log", kind: "session", title: "会话", detail: "消息、工具结果和排队按实际顺序保存。" },
  { id: "loop.agent", kind: "loop", title: "循环", detail: "模型请求、工具、等待确认，直到本轮结束或被取消。" },
  { id: "ui.desktop", kind: "ui", title: "界面", detail: "开发界面与工作界面共用同一条会话。" },
];

export const MODES = {
  standard: "标准：读取、搜索、改文件和命令都可以用。",
  code: "代码：先说明计划，再使用全部编码工具。",
  minimal: "极简：只保留精确替换和 shell。",
  plan: "计划：只读文件和搜索，先写出可执行的计划，不改文件。",
  execute: "执行：按已经定好的计划动手，使用全部编码工具。",
  report: "报告：只读并整理成报告，不改文件。",
  enhance: "增强提示词：只改写用户的提示，输出增强后的提示，不执行。",
};

export function selectTools({ mode = "standard", interaction = "agent", enabled = {}, catalog = TOOL_PLUGINS } = {}) {
  return catalog.filter((tool) => {
    if (!tool.modes.includes(mode)) return false;
    if (enabled[tool.id] === false) return false;
    if (interaction === "ask" && tool.mutates) return false;
    return true;
  });
}

export function toolSchema(tool) {
  return {
    name: tool.name,
    description: tool.description,
    parameters: tool.parameters,
  };
}
