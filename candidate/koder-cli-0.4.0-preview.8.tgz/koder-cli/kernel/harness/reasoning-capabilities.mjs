// The catalog contains SDK-level controls, not always literal HTTP values.
// Keep native-provider protocol restrictions shared by the UI and wire mapper.
export function claudeThinkingMode(model) {
  if (/^claude-(?:fable-5(?:-1)?|mythos-(?:5(?:-1)?|preview)|opus-(?:4-[678]|5(?:-5)?)|sonnet-(?:4-6|5(?:-5)?)|haiku-5-5)(?:-\d{8})?$/.test(model || '')) return 'adaptive';
  if (/^claude-(?:haiku-4-5|(?:opus|sonnet)-4(?:-[15])?|3-7-sonnet)(?:-\d{8})?$/.test(model || '')) return 'budget';
  return null;
}

export function supportedReasoningLevels(provider) {
  const levels = provider.spec?.levels || [];
  if (provider.protocol === 'anthropic') {
    const mode = claudeThinkingMode(provider.model);
    if (!mode) return [];
    if (mode === 'budget') return levels.filter(level => ['off','minimal','low','medium','high','xhigh','max'].includes(level));
    const cannotDisable = /^claude-(?:fable-|mythos-|opus-5-5|sonnet-5-5)/.test(provider.model);
    const supportsXhigh = !/^claude-(?:(?:opus|sonnet)-4-6|mythos-preview)/.test(provider.model);
    return levels.filter(level => ['off','low','medium','high','xhigh','max'].includes(level)
      && (level !== 'off' || !cannotDisable) && (level !== 'xhigh' || supportsXhigh));
  }
  if (provider.id === 'gemini') {
    const canDisable = /^gemini-2\.5-/.test(provider.model) && !/^gemini-2\.5-pro(?:-|$)/.test(provider.model);
    return levels.filter(level => ['off','minimal','low','medium','high'].includes(level) && (level !== 'off' || canDisable));
  }
  return levels;
}
