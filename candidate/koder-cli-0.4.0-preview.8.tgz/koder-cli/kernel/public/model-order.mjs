// Orders model ids newest first by the version embedded in them:
// "MiniMax-M3" before "MiniMax-M2.7", "glm-5.3" before "glm-5.3-flash".
// Numbers of 1000 and up are dates or sizes, not versions.
function versionOf(id) {
  const run = /\d+(?:[.-]\d+)*/.exec(String(id))?.[0] ?? "";
  return run.split(/[.-]/).filter(Boolean).map(Number).filter((n) => n < 1000);
}

export function compareModelIds(a, b) {
  const left = versionOf(a);
  const right = versionOf(b);
  if (!left.length !== !right.length) return left.length ? -1 : 1;
  for (let i = 0; i < Math.max(left.length, right.length); i += 1) {
    const difference = (right[i] ?? 0) - (left[i] ?? 0);
    if (difference) return difference;
  }
  return a.length - b.length || a.localeCompare(b);
}

export function newestFirst(ids) {
  return [...ids].sort(compareModelIds);
}
