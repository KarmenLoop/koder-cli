import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import {resolveMemoryLocation} from "./shared-memory/location.mjs";
import { normalizeLang } from "./i18n.mjs";

export function cliHome(env = process.env) {
  return path.resolve(env.KODER_CLI_HOME || path.join(os.homedir(), ".koder-cli"));
}

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return null;
  }
}

export function loadConfig(env = process.env) {
  const value = readJson(path.join(cliHome(env), "config.json"));
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

export function saveConfig(patch, env = process.env) {
  const home = cliHome(env);
  fs.mkdirSync(home, { recursive: true, mode: 0o700 });
  const next = { ...loadConfig(env), ...patch };
  const file = path.join(home, "config.json");
  const temp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(temp, `${JSON.stringify(next, null, 2)}\n`, { mode: 0o600 });
  fs.renameSync(temp, file);
  return next;
}

// --lang beats KODER_LANG beats the saved choice; Chinese is the default.
export function resolveLang({ flag, env = process.env, config = loadConfig(env) } = {}) {
  return normalizeLang(flag) || normalizeLang(env.KODER_LANG) || normalizeLang(config.lang) || "zh";
}

// Credentials and installation identity remain at cliHome. Existing non-Windows
// installations retain their root until an explicit verified migration.
export function memoryHome(env=process.env,{platform=process.platform,probe}={}) {
  const home=cliHome(env),config=loadConfig(env);
  const configured=config.memoryLocation || (env.KODER_MEMORY_ROOT?{root:env.KODER_MEMORY_ROOT}:null);
  if(!configured && platform!=="win32")return home;
  if(!configured && ["memory","shared-memory"].some(name=>fs.existsSync(path.join(home,name))))return home;
  const userKey=crypto.createHash("sha256").update(String(os.userInfo().uid)+":"+os.userInfo().username).digest("hex").slice(0,24);
  const result=resolveMemoryLocation({platform,configured,userKey,probe});
  if(result.state!=="ready")throw Object.assign(new Error(result.reasonCode),{code:result.reasonCode});
  if(!configured)saveConfig({memoryLocation:result},env);
  return result.root;
}
