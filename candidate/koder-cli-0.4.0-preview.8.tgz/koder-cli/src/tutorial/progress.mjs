// Lessons 1–16 keep their IDs; revision 2 replaces the old graduation with new chapters.
export const TUTORIAL_REVISION = 2;
export const NEW_LESSON = 17;
export function tutorialUpdated(saved) {
  return Boolean(saved?.done && (saved.revision || 1) < TUTORIAL_REVISION);
}
export function resumeLesson(saved) {
  return tutorialUpdated(saved) ? NEW_LESSON : saved?.done ? null : saved?.lesson || null;
}
