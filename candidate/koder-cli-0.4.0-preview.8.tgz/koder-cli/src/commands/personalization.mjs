import {openPersonalization} from '../personalization.mjs';
const features={learning:'learning','daily-state':'dailyState',evolution:'evolution',proactive:'proactive'};
export async function runPersonalization(ctx,parts=ctx.positionals){
 const [action='personalization',sub='status',...args]=parts;
 const runtime=await openPersonalization(ctx,{force:true});
 const out=value=>ctx.stdout.write(JSON.stringify(value,null,ctx.opts.json?0:2)+'\n');
 try{
  if(features[action]){if(!['on','off','status'].includes(sub))throw new Error('Use on|off|status');if(sub!=='status'){const s=await runtime.policy.status();await runtime.policy.configure({[features[action]]:sub==='on'},{expectedRevision:s.revision});}out(await runtime.status());return 0;}
  if(action==='personalization'){out(await runtime.status());return 0;}
  if(action==='reflection'){if(sub==='run')out(await runtime.reflection?.catchUp()||{state:'waiting-account-host'});else out((await runtime.status()).reflection);return 0;}
  if(action==='profile'){
   if(sub==='remember')out(await runtime.remember(args.join(' ')));
   else if(sub==='identity')out(await runtime.remember(args.join(' '),{category:'explicit-background'}));
   else if(sub==='forget')out(await runtime.forget(args));
   else if(sub==='show'||sub==='status')out({profile:await runtime.profile.status(),rules:await runtime.profile.query(),documents:await runtime.profile.render()});
   else throw new Error('Use profile show|remember|forget');return 0;
  }
  if(action==='soul'){
   if(sub==='show')out(await runtime.soul.read());else if(sub==='preview')out(await runtime.soul.preview(args.join(' ')));
   else if(sub==='save')out(await runtime.soul.save(args.join(' '),{expectedVersion:(await runtime.soul.read()).version}));else if(sub==='rollback')out(await runtime.soul.rollback(Number(args[0])));else throw new Error('Use soul show|preview|save|rollback');return 0;
  }
  throw new Error('PERSONALIZATION_COMMAND_INVALID');
 }finally{await runtime.close();}
}
export const PERSONALIZATION_ACTIONS=['learning','daily-state','evolution','proactive','personalization','profile','soul','reflection'];
