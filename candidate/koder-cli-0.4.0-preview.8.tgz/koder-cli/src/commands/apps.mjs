import {flags as channelFlags,run as runChannel} from './gateway.mjs';
import {platformId} from '../gateway/registry.mjs';
import {KoderError} from '../errors.mjs';
import {readHidden} from './model.mjs';
import {openApps,appRequest,printApps} from '../apps.mjs';
import {appNotice} from '../consent-copy.mjs';

export const flags={...channelFlags,'key-env':{type:'string'},'api-key':{type:'bool'},oauth:{type:'bool'},mcp:{type:'bool'}};
export async function run(ctx) {
  const [action='list',id]=ctx.positionals;
  const legacy=platformId(action)||action==='connect'&&platformId(id);
  if(legacy)return runChannel({...ctx,command:'connect',positionals:[legacy]});
  if(!['list','status','connect','disconnect'].includes(action))throw new KoderError('apps.usage');
  let key;
  if(action==='connect') {
    ctx.stderr.write(appNotice(ctx.lang)+'\n');
    if(!id)throw new KoderError('apps.usage');
    if(ctx.opts.mcp&&(ctx.opts.keyEnv||ctx.opts.apiKey)||ctx.opts.oauth&&(ctx.opts.keyEnv||ctx.opts.apiKey))throw new KoderError('apps.authModeConflict');
    if(ctx.opts.keyEnv){key=ctx.env[ctx.opts.keyEnv];if(!key)throw new KoderError('apps.missingEnv',{name:ctx.opts.keyEnv});}
    else if(!ctx.stdin.isTTY||!ctx.stdout.isTTY)throw new KoderError('apps.authRequired');
    else if(id==='gamma'&&(!ctx.opts.oauth&&!ctx.opts.mcp||ctx.opts.apiKey))key=ctx.io.promptSecret?await ctx.io.promptSecret('Gamma API Key: '):await readHidden(ctx,'Gamma API Key: ');
    if(key!==undefined&&!String(key).trim())return 1;
  }
  const host=await openApps(ctx);
  try {
    let result;
    if(['list','status'].includes(action))result=await appRequest(host,'GET','/api/apps');
    else if(action==='connect')result=await appRequest(host,'POST',key?'/api/apps/key':id==='gamma'&&!ctx.opts.mcp?'/api/apps/login':'/api/apps/connect',{app:id==='gamma'&&ctx.opts.mcp?'gamma-mcp':id,key,mode:ctx.opts.mcp?'mcp':'api'},{timeout:120000});
    else {
      if(!id)throw new KoderError('apps.usage');
      result=await appRequest(host,'DELETE',id==='gamma'&&!ctx.opts.mcp?'/api/apps':'/api/apps/connect',{app:id==='gamma'&&ctx.opts.mcp?'gamma-mcp':id});
    }
    printApps(ctx,result);return 0;
  } finally {const receipt=await host.release();if(!receipt.cleanupComplete)ctx.stderr.write(ctx.t('apps.cleanupPending')+'\n');}
}
