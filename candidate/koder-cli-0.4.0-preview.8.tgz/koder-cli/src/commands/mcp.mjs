import fs from 'node:fs';
import {KoderError} from '../errors.mjs';
import {openApps,appRequest,appPort,printApps,authorizeMcp} from '../apps.mjs';
import {appNotice} from '../consent-copy.mjs';
export const flags={command:{type:'string'},arg:{type:'string',multiple:true},url:{type:'string'},cwd:{type:'string'},enable:{type:'bool'},'env-ref':{type:'string',multiple:true},'header-env':{type:'string',multiple:true},'bearer-env':{type:'string'},'client-id':{type:'string'},scope:{type:'string'},params:{type:'string'}};
function refs(ctx,values=[]) {
  const result={};
  for(const value of values){const match=/^([A-Za-z_][A-Za-z0-9_-]*)=([A-Za-z_][A-Za-z0-9_]*)$/.exec(value);if(!match)throw new KoderError('apps.reference');const [,key,variable]=match;if(!ctx.env[variable])throw new KoderError('apps.missingEnv',{name:variable});result[key]=ctx.env[variable];}
  return result;
}
function importConfig(file) {
  if(!file)throw new KoderError('apps.mcpUsage');
  const fd=fs.openSync(file,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));let value;
  try{const stat=fs.fstatSync(fd);if(!stat.isFile()||stat.size>1_000_000)throw new KoderError('apps.importLimit');const bytes=Buffer.alloc(1_000_001),n=fs.readSync(fd,bytes,0,bytes.length,0);if(n>1_000_000)throw new KoderError('apps.importLimit');value=JSON.parse(bytes.subarray(0,n).toString('utf8'));}finally{fs.closeSync(fd);}
  if(!value?.mcpServers||typeof value.mcpServers!=='object'||Array.isArray(value.mcpServers)||Object.keys(value.mcpServers).length>100)throw new KoderError('apps.importFormat');
  return Object.entries(value.mcpServers).map(([name,entry])=>{
    if(!entry||typeof entry!=='object'||Array.isArray(entry))throw new KoderError('apps.importFormat');
    const known=new Set(['command','args','url','cwd','env','headers','transport','type']);
    return {input:{name,serverName:name,transport:entry.url?'streamable-http':'stdio',command:entry.command,args:entry.args,url:entry.url,cwd:entry.cwd,env:entry.env,headers:entry.headers,enabled:false},ignored:Object.keys(entry).filter(key=>!known.has(key))};
  });
}
export async function run(ctx) {
  const [action='list',id]=ctx.positionals;
  if(['add','import','login','enable','test'].includes(action))ctx.stderr.write(appNotice(ctx.lang)+'\n');
  if(!['list','add','import','login','tools','test','enable','disable','remove','resources','prompts','read','prompt'].includes(action))throw new KoderError('apps.mcpUsage');
  if(!['list'].includes(action)&&!id)throw new KoderError('apps.mcpUsage');
  if(action==='login'&&(!ctx.stdin.isTTY||!ctx.stdout.isTTY))throw new KoderError('apps.authRequired');
  let promptArguments;
  if(ctx.opts.params!==undefined){
    try{if(action!=='prompt'||Buffer.byteLength(ctx.opts.params)>16384)throw Error();promptArguments=JSON.parse(ctx.opts.params);if(!promptArguments||Array.isArray(promptArguments)||typeof promptArguments!=='object'||Object.values(promptArguments).some(value=>typeof value!=='string'))throw Error();}
    catch{throw new KoderError('apps.promptParams');}
  }
  const imports=action==='import'?importConfig(id):null;
  let input;
  if(action==='add') {
    const headers=refs(ctx,ctx.opts.headerEnv),env=refs(ctx,ctx.opts.envRef);
    if(ctx.opts.bearerEnv){const secret=ctx.env[ctx.opts.bearerEnv];if(!secret)throw new KoderError('apps.missingEnv',{name:ctx.opts.bearerEnv});headers.Authorization='Bearer '+secret;}
    input={name:id,serverName:id,transport:ctx.opts.url?'streamable-http':'stdio',url:ctx.opts.url,command:ctx.opts.command,args:ctx.opts.arg||[],cwd:ctx.opts.cwd||'',headers,env,enabled:ctx.opts.enable===true};
    if(!input.url&&!input.command)throw new KoderError('apps.mcpUsage');
  }
  const host=await openApps(ctx);
  try {
    const request=(method,route,body)=>appRequest(host,method,route,body);
    const listed=await request('GET','/api/mcp');
    let result;
    if(action==='list')result=listed;
    else if(action==='add')result=await request('POST','/api/mcp',input);
    else if(action==='import') {
      result={servers:[],diagnostics:[]};
      for(const row of imports){if(listed.servers.some(x=>x.name===row.input.name)){result.diagnostics.push({name:row.input.name,code:'EXISTS'});continue;}const created=await request('POST','/api/mcp',row.input);result.servers.push(created.server);if(row.ignored.length)result.diagnostics.push({name:row.input.name,code:'IGNORED_FIELDS',fields:row.ignored});}
    } else {
      const server=listed.servers.find(x=>x.id===id||x.serverName===id||x.name===id);
      if(!server)throw new KoderError('apps.noServer',{name:id});
      const route='/api/mcp/'+server.id;
      if(action==='remove')result=await request('DELETE',route,{});
      else if(['enable','disable'].includes(action))result=await request('PATCH',route,{enabled:action==='enable'});
      else if(action==='tools')result={tools:server.tools,connectionState:server.connectionState};
      else if(['resources','prompts','read','prompt'].includes(action)){
        const method={resources:'resources/list',prompts:'prompts/list',read:'resources/read',prompt:'prompts/get'}[action],value=ctx.positionals[2];
        if(['read','prompt'].includes(action)&&!value)throw new KoderError('apps.mcpUsage');
        result=await appPort(host).protocol({serverId:server.id,method,params:action==='read'?{uri:value}:action==='prompt'?{name:value,...(promptArguments?{arguments:promptArguments}:{})}:value?{cursor:value}:{}});
      }
      else if(action==='login')result=await authorizeMcp(ctx,host,server,{clientId:ctx.opts.clientId,scope:ctx.opts.scope});
      else {
        try {const probe=(await request('PATCH',route,{enabled:true})).server;result={state:probe.status,tools:probe.tools,capabilities:probe.capabilities,errorCode:probe.errorCode};}
        finally {if(!server.enabled)await request('PATCH',route,{enabled:false});}
        printApps(ctx,result);return result.state==='connected'?0:1;
      }
    }
    printApps(ctx,result);return result.ok===false?1:0;
  } finally {const receipt=await host.release();if(!receipt.cleanupComplete)ctx.stderr.write(ctx.t('apps.cleanupPending')+'\n');}
}
