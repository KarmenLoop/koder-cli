import {openMemoryAccount} from '../shared-memory/account.mjs';
export const flags={server:{type:'string'}};
export async function run(ctx) {
 const action=ctx.positionals[0]||'status';
 if(ctx.positionals.length>1||!['login','logout','status'].includes(action))throw new Error('koder account login|logout|status [--server https://your-server]');
 const account=openMemoryAccount(ctx);
 try {
  const result=await account[action]();
  ctx.stdout.write(JSON.stringify(result,null,ctx.opts.json?0:2)+'\n');
  if(action==='login'&&result.credentials.mode==='process-only')ctx.stderr.write(ctx.lang==='en'?'Protected storage unavailable. This login lasts for this process only.\n':'系统保护存储不可用，本次登录仅在当前进程有效。\n');
  return 0;
 } finally {account.dispose();}
}
