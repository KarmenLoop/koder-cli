import {runPersonalization,PERSONALIZATION_ACTIONS} from './personalization.mjs';
import crypto from 'node:crypto';
import {createMemory} from '../memory.mjs';
import {KoderError} from '../errors.mjs';
import {openSharedMemoryRuntime} from '../shared-memory/runtime.mjs';

export async function run(ctx) {
  const [action='show',...args]=ctx.positionals;
  if(PERSONALIZATION_ACTIONS.includes(action))return runPersonalization(ctx);
  let key;
  try { key=ctx.findProvider()?.record?.apiKey; } catch {}
  const memory=createMemory({workspace:ctx.workspace(),env:ctx.env,name:ctx.opts.session||'default',secrets:[key].filter(Boolean)});
  const out=line=>ctx.stdout.write(`${line}\n`);
  const shared=openSharedMemoryRuntime(ctx,{secrets:[key].filter(Boolean)});
  try {
  if(action==='status'||action==='sync'){out(JSON.stringify(action==='sync'?await shared.syncOnce():await shared.status(),null,ctx.opts.json?0:2));return 0;}
  if(action==='add'){
    const text=args.join(' ').trim();
    if(!text||text.length>4096)throw new Error('记忆内容应为 1–4096 个字符。');
    const id=crypto.randomUUID();
    memory.transact(data=>{if(data.notes.length>=32)throw new Error('最多保存 32 条明确记忆，请先删除过期条目。');return memory.write({...data,notes:[...data.notes,{id,text,at:Date.now()}]});});
    await shared.addNote(text,id);
    out(`${ctx.lang==='en'?'Memory saved':'记忆已保存'}: ${id}`);return 0;
  }
  if(action==='remove'){
    const id=args[0];
    memory.transact(data=>{if(!data.notes.some(n=>n.id===id))throw new Error('找不到这条记忆。');return memory.write({...data,notes:data.notes.filter(n=>n.id!==id)});});
    await shared.removeNote(id);
    out(ctx.lang==='en'?'Memory removed.':'记忆已移除。');return 0;
  }
  if(action==='clear'){
    memory.transact(data=>memory.reset(data));out(ctx.lang==='en'?'Started a new conversation. Explicit notes retained.':'已开始新会话，明确保存的记忆仍保留。');return 0;
  }
  if(action==='forget'){const result=await shared.forget();memory.transact(data=>memory.forget(data));out(ctx.opts.json?JSON.stringify(result):ctx.lang==='en'?'Shared memory forgotten for this space. Offline devices retire older history after synchronization.':'已忘记此共享空间的记忆。离线设备会在下次同步后停止使用旧记忆。');return 0;}
  let data=memory.read();
  const sharedStatus=await shared.status();
  if((data.sharedMemory&&data.sharedMemory.spaceId!==sharedStatus.spaceId)||(data.sharedMemory?.memoryEpoch??1)<sharedStatus.memoryEpoch)data={...data,conversation:null,notes:[],interrupted:false};
  if(action==='search'){
    const query=args.join(' ').trim();if(!query)throw new Error('请提供要检索的内容。');
    const matches=[...data.notes.map(note=>({role:'note',content:note.text,id:note.id})),...(data.conversation?.messages||[])].map((m,index)=>({...m,index:index+1})).filter(m=>m.content.toLowerCase().includes(query.toLowerCase()));
    const facts=await shared.query({text:query});
    out(ctx.opts.json?JSON.stringify({local:matches,shared:facts}):[...matches.map(m=>`[${m.index} ${m.role}] ${m.content}`),...facts.map(f=>`[${f.origin.platform}/${f.origin.chatId} ${f.kind}] ${f.payload.text}`)].join('\n')||(ctx.lang==='en'?'No matches.':'没有匹配记录。'));return 0;
  }
  if(action==='show'){
    const result={session:memory.identity.name,workspace:memory.identity.workspace,file:memory.file,conversationId:data.conversation?.id||null,messages:data.conversation?.messages.length||0,interrupted:data.interrupted,notes:data.notes,shared:await shared.status()};
    out(ctx.opts.json?JSON.stringify(result):`${ctx.lang==='en'?'Session':'会话'}: ${result.session}\n${ctx.lang==='en'?'Saved messages':'已保存消息'}: ${result.messages}\n${ctx.lang==='en'?'Notes':'明确记忆'}: ${result.notes.length}\n${result.notes.map(n=>`${n.id} ${n.text}`).join('\n')}\n${result.file}`);return 0;
  }
  throw new KoderError('err.unknownCommand',{name:`memory ${action}`});
  } finally {shared.close();}
}
