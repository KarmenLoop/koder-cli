import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { accepted, notice, writeAcceptance } from "../eula.mjs";
import {consentGuide} from '../consent-copy.mjs';

const file = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "EULA.md");

export async function run(ctx) {
  const action = ctx.positionals[0];
  if (action === "accept") {
    const record = writeAcceptance(ctx.env);
    ctx.stdout.write(`${record.id} accepted\n${record.sha256}\n已接受软件使用许可。喜好学习、同步、电脑和发消息权限均未因此开启。\nSoftware license accepted. Preference learning, synchronization, computer access and messaging were not enabled.\n官网 / Website: https://karmenloop.com\n邮箱 / Email: info@karmenloop.com\n团队 / Team: KARMENLOOP 官方团队 / KARMENLOOP Official Team，中国上海 / Shanghai, China\n安装目录另有 ACCEPTANCE.md 与 LEGAL-NOTICE.md。koder eula 显示 EULA.md 与授权说明。\nThe install folder also contains ACCEPTANCE.md and LEGAL-NOTICE.md. koder eula shows EULA.md and the consent guide.\n拒绝后续版本 / Decline a later version: 协议校验变化后不要运行 koder eula accept；安装时输入 decline、直接回车或按 Ctrl+C。 / When the checksum changes, do not run koder eula accept; during installation type decline, press Enter, or press Ctrl+C.\n`);
    return 0;
  }
  const current = accepted(ctx.env);
  const status = current ? (ctx.lang === 'en' ? 'The current software license is accepted. Optional features keep their separate settings.' : '当前使用许可已接受；各项可选功能仍按你分别设置的状态运行。') : notice(ctx.lang);
  ctx.stdout.write(`${fs.readFileSync(file, "utf8")}\n${consentGuide(ctx.lang)}\n\n${status}\n`);
  return current ? 0 : 2;
}
