import {StringDecoder} from 'node:string_decoder';
// Line input with a queue: a line typed while Koder is busy is kept for the
// next ordinary prompt, while approvals ask with { fresh: true } and only
// accept an answer typed after the question appeared.
export function createPrompter(rl, output, initial = {}) {
  const queue = [...(initial.queue || [])];
  const waiters = [];
  let closed = false,tail='',tailBytes=Buffer.alloc(0),frozen=null;
  const decoder=new StringDecoder('utf8');
  const track=chunk=>{
    const bytes=Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk);
    tailBytes=Buffer.concat([tailBytes,bytes]);const lastByte=Math.max(tailBytes.lastIndexOf(10),tailBytes.lastIndexOf(13));if(lastByte>=0)tailBytes=tailBytes.subarray(lastByte+1);
    tail+=decoder.write(bytes);const last=Math.max(tail.lastIndexOf('\n'),tail.lastIndexOf('\r'));if(last>=0)tail=tail.slice(last+1);
  };
  if(!rl.terminal){if(initial.pendingBytes)track(Buffer.from(initial.pendingBytes,'base64'));else if(initial.draft)track(initial.draft);if(initial.rawBytes)track(Buffer.from(initial.rawBytes,'base64'));} 
  if(!rl.terminal)rl.input.on('data',track);
  const snapshot=()=>({queue:[...queue],history:[...(rl.history||[])],draft:rl.terminal?rl.line||'':tail,...(!rl.terminal?{pendingBytes:tailBytes.toString('base64')}:{})});
  rl.on("line", (line) => {
    const waiter = waiters.shift();
    if (waiter) waiter(line);
    else queue.push(line);
  });
  rl.on("close", () => {
    closed = true;
    while (waiters.length) waiters.shift()(null);
  });
  return {
    rl,
    wake() { while(waiters.length) waiters.shift()(null); },
    snapshot,
    freeze() {
      if(frozen)return frozen;
      rl.pause();rl.input.pause();
      frozen=snapshot();
      // Detach readline before draining already-buffered raw bytes, retaining
      // split UTF-8 characters. Paused native intake leaves later bytes unread.
      if(!rl.terminal)rl.input.off('data',track);
      rl.close();
      const raw=[];while(rl.input.readableLength){const chunk=rl.input.read(rl.input.readableLength);if(chunk===null)break;raw.push(Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk));}
      rl.input.pause();
      if(raw.length)frozen.rawBytes=Buffer.concat(raw).toString('base64');
      return frozen;
    },
    get closed() {
      return closed;
    },
    ask(prompt, { fresh = false } = {}) {
      if (fresh) queue.length = 0;
      if (queue.length) {
        const line = queue.shift();
        output.write(`${prompt}${line}\n`);
        return Promise.resolve(line);
      }
      if (closed) return Promise.resolve(null);
      rl.setPrompt(prompt);
      rl.prompt();
      return new Promise((resolve) => waiters.push(resolve));
    },
    close() {
      if(!rl.terminal)rl.input.off('data',track);rl.close();
    },
  };
}

// For tests and scripted runs: answers come from a function of the prompt.
export function scriptedPrompter(answer) {
  const asked = [];
  return {
    asked,
    closed: false,
    async ask(prompt) {
      asked.push(prompt);
      const value = typeof answer === "function" ? answer(prompt, asked.length - 1) : answer.shift();
      return value === undefined ? null : value;
    },
    close() {},
  };
}
