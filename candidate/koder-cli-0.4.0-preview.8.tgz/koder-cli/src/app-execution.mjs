// The existing Harness approval object is the authority. The app bridge is
// merely transport; neither model arguments nor saved receipts grant approval.
import {importKernel} from './agent.mjs';
const fail=code=>{throw Object.assign(new Error(code),{code});};
export async function openAppExecution(ctx,{thread,save,current,apps}) {
 const {effectStart,effectFinish,effectRecover}=await importKernel('agent/kernel/ledger.mjs',ctx.env);
 const {appDigest,appTask}=await importKernel('fusion/app-binding.mjs',ctx.env);
 const prepared=new Map();
 const fingerprint=bound=>appDigest({name:bound.name,arguments:bound.arguments,connection:bound.connection.id});
 const check=async()=>{await ctx.io.assertGatewayOwner?.();const state=await current();if(!state||state.threadId!==thread.id)fail('APP_SCOPE_CHANGED');return state;};
 async function recover() {
  await check();const record=await apps.loadEffects(thread.id);
  thread.appEffects=structuredClone(record.rows);
  for(const row of Object.values(thread.appEffects)){const projection={effect:row.effect};effectRecover(projection);row.effect=projection.effect;}
  return record;
 }
 return {
  recover,
  async prepare(args,{call,signal}) {
   const state=await check(),task=appTask({...state,callId:call.id});
   const bound=await apps.prepare({...args,task},{signal});
   await check();
   const record=await recover();
   if(Object.values(record.rows).some(row=>['started','uncertain'].includes(row.effect?.phase)&&fingerprint(row.bound)===fingerprint(bound)))fail('APP_PRIOR_RESULT_UNKNOWN');
   prepared.set(call.id,{digest:appDigest(bound),task:appDigest(task)});return bound;
  },
  async execute(actualThread,approval,signal) {
   const state=await check(),bound=approval?.appCall,call=thread.inflight?.calls[thread.inflight.index];
   if(actualThread!==thread||thread.approvals?.find(a=>a.id===approval?.id)!==approval||approval.status!=='approved'||thread.pause?.approvalId!==approval.id||call?.name!=='app_call'||call.id!==approval.toolCallId||!bound||prepared.get(call.id)?.digest!==appDigest(bound)||prepared.get(call.id)?.task!==appDigest(appTask({...state,callId:call.id})))fail('APP_APPROVAL_STALE');
   if(thread.interaction==='ask'||!['standard','code','execute'].includes(thread.mode||'standard'))fail('APP_MODE_DENIED');
   signal?.throwIfAborted();await apps.validate(bound,{signal});
   const record=await recover();
   if(record.rows[call.id]||Object.values(record.rows).some(row=>['started','uncertain'].includes(row.effect?.phase)&&fingerprint(row.bound)===fingerprint(bound)))fail('APP_PRIOR_RESULT_UNKNOWN');
   const projection={seq:thread.seq||0,cwd:thread.cwd||ctx.cwd};effectStart(projection,{id:call.id,path:bound.name});
   const row={bound:structuredClone(bound),effect:{...projection.effect,kind:'application'},at:Date.now()};
   // This minimal encrypted record is required even when chat memory is off.
   const checkpoint=await apps.saveEffects(thread.id,{[call.id]:row},record.revision);
   thread.appEffects=checkpoint.rows;thread.seq=projection.seq;await save();
   await check();signal?.throwIfAborted();
   let result;
   try{result=await apps.call(bound,{signal});}
   catch(error){result={ok:false,state:error.notStarted?'failed':'unknown',notStarted:error.notStarted===true,content:[],cleanupComplete:error.notStarted===true,errorCode:error.code||'APP_RESULT_UNKNOWN'};}
   effectFinish(projection,result.state==='succeeded'?{ok:true}:result.notStarted?{ok:false,notStarted:true}:{ok:false});
   row.effect={...projection.effect,kind:'application'};row.result=result;
   thread.appEffects[call.id]=row;thread.seq=projection.seq;await save();
   // A late result is retained under this task; it is not fed to a new owner.
   await check();prepared.delete(call.id);return result;
  },
 };
}
