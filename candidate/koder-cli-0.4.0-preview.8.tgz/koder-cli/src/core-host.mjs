import {importKernel} from './agent.mjs';
const key=i=>i&&JSON.stringify([i.server,i.tenantId,i.accountId,i.deviceId,i.generation,i.space?.spaceId]);
export function createCoreGatewayOwner(ctx,account,onLost){
 return {async acquireGateway(binding,{current=()=>true}={}){
  const identity=await account.currentIdentity(),client=await account.client?.();
  if(!identity?.space?.spaceId||typeof client?.runtimeHost!=='function')throw Object.assign(new Error('GATEWAY_OWNER_LEASE_UNAVAILABLE'),{code:'GATEWAY_OWNER_LEASE_UNAVAILABLE'});
  const expected=key(identity),{acquireHostLease}=await importKernel('fusion/host-maintenance.mjs',ctx.env);
  return acquireHostLease({transport:(operation,input)=>client.runtimeHost(operation,input),input:{purpose:'gateway',spaceId:identity.space.spaceId,key:binding.bindingId,platform:binding.platform},current:async()=>current()&&key(await account.currentIdentity())===expected&&current(),onLost:error=>{if(current())onLost(binding.platform,error);}});
 }};
}
