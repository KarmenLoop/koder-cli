import {importKernel} from './agent.mjs';
import {openMemoryAccount} from './shared-memory/account.mjs';
import {KoderError} from './errors.mjs';

export async function openApps(ctx) {
  const account=ctx.io.memoryAccount||openMemoryAccount(ctx),identity=await account.currentIdentity();
  const {resolveAppProfile,connectionScope}=await importKernel('fusion/app-profile.mjs',ctx.env);
  const scope=connectionScope({identity,env:ctx.env});
  const {openAppHost}=await importKernel('fusion/app-host.mjs',ctx.env);
  const currentScope=()=>account.isCurrentKnown(identity)&&(!identity?.expiresAt||Date.parse(identity.expiresAt)>Date.now())?scope:{...scope,sessionGeneration:'revoked'};
  return openAppHost({...ctx.io.appHostOptions,profile:resolveAppProfile({env:ctx.env,scope}),scope,currentScope,env:ctx.env});
}
export async function appRequest(host,method,route,body,options) {
  const result=await host.kernel.call(method,route,body,options);
  if(result.status>=400)throw Object.assign(new KoderError('apps.failed',{code:result.json?.code||'APP_REQUEST_FAILED',message:result.json?.error||'Application operation failed'},1),{code:result.json?.code||'APP_REQUEST_FAILED',status:result.status,notStarted:[400,401,403,409].includes(result.status)});
  return result.json;
}
export function appPort(host) {
 const request=(operation,body={},options)=>appRequest(host,'POST','/internal/shared-apps/'+operation,{...body,bridgeToken:host.bridgeToken},options);
 return {
  scope:host.scope,
  async list(args={},options={}){const found=await request('tools',{},options),query=String(args.query||'').toLowerCase(),offset=Math.max(0,Math.floor(Number(args.offset)||0));const rows=found.tools.filter(t=>!query||(t.name+' '+t.description).toLowerCase().includes(query));return {scope:found.scope,tools:rows.slice(offset,offset+25),total:rows.length,nextOffset:offset+25<rows.length?offset+25:null};},
  prepare:(args,options)=>request('prepare',args,options),validate:(bound,options)=>request('validate',bound,options),call:(bound,options)=>request('call',bound,options),
  protocol:(args,options)=>request('request',args,options),
  putArtifact:(args,options)=>request('artifacts',{...args,action:'put'},options),readArtifact:(args,options)=>request('artifacts',{...args,action:'read'},options),
  loadEffects:threadId=>request('effects',{action:'load',threadId}),
  saveEffects:(threadId,rows,expectedRevision)=>request('effects',{action:'save',threadId,rows,expectedRevision}),
 };
}
export async function authorizeMcp(ctx,host,server,{clientId,scope,signal,timeoutMs=120000}={}) {
  const route='/api/mcp/'+server.id+'/auth';
  const controller=new AbortController(),abort=()=>controller.abort();
  const combined=AbortSignal.any([controller.signal,AbortSignal.timeout(timeoutMs),...(signal?[signal]:[])]);
  process.once('SIGINT',abort);
  let flow;
  try {
    flow=await appRequest(host,'POST',route+'/start',{clientId,scope},{signal:combined});
    const {openAuthorization}=await importKernel('fusion/connect-apps.mjs',ctx.env);
    if(flow.authorizationUrl)await (ctx.io.openAuthorization||openAuthorization)(flow.authorizationUrl);
    for(;;) {
      combined.throwIfAborted();
      const state=await appRequest(host,'GET',route,undefined,{signal:combined});
      if(state.authorized)return appRequest(host,'PATCH','/api/mcp/'+server.id,{enabled:true},{signal:combined});
      if(['failed','cancelled'].includes(state.flow?.status))throw new KoderError('apps.failed',{code:state.flow.error||'MCP_AUTH_REQUIRED',message:ctx.t('apps.authRequired')});
      await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{combined.removeEventListener('abort',stop);resolve();},250);const stop=()=>{clearTimeout(timer);reject(combined.reason);};combined.addEventListener('abort',stop,{once:true});});
    }
  }catch(error){if(flow?.flowId)await appRequest(host,'POST',route+'/cancel',{flowId:flow.flowId}).catch(()=>{});throw error;}
  finally{process.off('SIGINT',abort);}
}
export function printApps(ctx,result) {
  if(ctx.opts.json){ctx.stdout.write(JSON.stringify(result)+'\n');return;}
  const rows=result.apps||result.servers;
  if(rows)for(const row of rows)ctx.stdout.write([`${row.id}  ${row.name||row.serverName||''}  ${row.state||row.connectionState||row.status||'not-configured'}`,row.authState?'auth='+row.authState:'',row.workspaceLabel?'workspace='+row.workspaceLabel:'',row.verifiedAt?'verified='+row.verifiedAt:'',row.errorCode?'diagnostic='+row.errorCode:''].filter(Boolean).join('  ')+'\n');
  else ctx.stdout.write(JSON.stringify(result,null,2)+'\n');
  if(!ctx.opts.json&&result.apps)ctx.stdout.write(ctx.t('apps.next')+'\n');
}
