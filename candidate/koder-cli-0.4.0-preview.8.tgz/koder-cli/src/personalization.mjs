import path from 'node:path';
import crypto from 'node:crypto';
import readline from 'node:readline/promises';
import {cliHome,memoryHome,loadConfig,saveConfig} from './config.mjs';
import {openSharedMemoryRuntime} from './shared-memory/runtime.mjs';
import {openMemoryCredentials} from './shared-memory/credentials.mjs';
import {importKernel} from './agent.mjs';
import {createPersonalizationLock} from './personalization-lock.mjs';
import {createModelFetch,withModelEndpoint} from './model-http.mjs';
import {personalizationConsent} from './consent-copy.mjs';
const failure=code=>Object.assign(new Error(code),{code});
export async function openPersonalization(ctx,{force=false,sharedRuntime=null,memoryHandle=null,skillRecords}={}) {
 if(ctx.io.personalization)return ctx.io.personalization;
 if(!force&&!loadConfig(ctx.env).personalizationInitialized)return null;
 const shared=sharedRuntime||openSharedMemoryRuntime(ctx),ownsShared=!sharedRuntime;
 let lock=ctx.io.personalizationLock,ownsLock=false;
 try{
 const handle=memoryHandle||await shared.prepare({sync:false});
 const s=handle.identity,subject={server:s?.server||'local',tenantId:s?.tenantId||'local',accountId:s?.accountId||'local:'+handle.deviceId,spaceId:handle.space.spaceId,subjectId:s?.accountId||'local:'+handle.deviceId,deviceId:handle.deviceId,generation:s?.generation||'local',memoryEpoch:handle.epoch};
 let closed=false;
 const current=()=>closed||shared.isCurrentKnown?.(handle)===false?null:subject;
 if(!lock){
  const credentials=ctx.io.personalizationCredentials||openMemoryCredentials({dir:cliHome(ctx.env),namespace:'personalization'});
  const {withPrivateLease}=await importKernel('fusion/private-lease.mjs',ctx.env);
  lock=await createPersonalizationLock({credentials,scope:JSON.stringify([subject.server,subject.tenantId,subject.accountId,subject.spaceId,subject.subjectId]),withLease:work=>withPrivateLease(cliHome(ctx.env),'personalization-native-key',work)});ownsLock=true;
 }
 const {createPersonalizationStorage}=await importKernel('fusion/personalization-storage.mjs',ctx.env);
 const storage=createPersonalizationStorage({dir:path.join(memoryHome(ctx.env),'personalization'),lock,identity:current,sourcePlatform:ctx.command==='acp'?'acp':'terminal'});
 const owner={async confirm(request){
  if(ctx.io.personalizationOwner?.confirm)return ctx.io.personalizationOwner.confirm(request);
  if(!['setup','memory'].includes(ctx.command)||!ctx.stdin.isTTY||!ctx.stdout.isTTY||ctx.opts.yes)return false;
  const explanation=personalizationConsent(request,ctx.lang,path.join(memoryHome(ctx.env),'personalization'));
  ctx.stderr.write(explanation.text+'\n');
  const label=ctx.lang==='en'?`Type ${explanation.token} to confirm, or press Enter to cancel: `:`输入 ${explanation.token} 确认，直接回车取消：`;
  const content=request.patch||{operation:request.operation,evidence:request.evidence,digest:request.digest};ctx.stderr.write(JSON.stringify(content,null,2)+'\n');
  if(ctx.io.prompter)return await ctx.io.prompter.ask(label,{fresh:true})===explanation.token;
  const rl=readline.createInterface({input:ctx.stdin,output:ctx.stdout,terminal:true,historySize:0});try{return await rl.question(label)===explanation.token;}finally{rl.close();}
 }};
 let ports=storage;
 if(s){const {createAccountPersonalizationStores}=await importKernel('fusion/account-personalization.mjs',ctx.env);const invoke=async(method,args)=>{if(!await shared.isCurrent(handle))throw failure('PERSONALIZATION_SUBJECT_CHANGED');const value=await handle.client[method](handle.space.spaceId,...args);if(!await shared.isCurrent(handle))throw failure('PERSONALIZATION_SUBJECT_CHANGED');return value;};ports=createAccountPersonalizationStores({subject:current,local:storage,transport:{read:options=>invoke('memoryPersonalization',[options]),write:(kind,input,options)=>invoke('memoryPersonalizationWrite',[kind,input,options])}});}
 const {createPersonalizationPolicy}=await importKernel('fusion/personalization-policy.mjs',ctx.env),policy=createPersonalizationPolicy({identity:current,store:ports.policyStore,owner});
 const {openUserProfile}=await importKernel('fusion/user-profile.mjs',ctx.env);
 let reflectionHost=null,proactiveHost=null,automation=null;
 const source={verify:async(e,receipt)=>(await reflectionHost?.source.verify(e,receipt))||(ctx.io.personalizationSource?.verify?ctx.io.personalizationSource.verify(e,receipt,{subject:current()}):storage.verifyOwnerEdit(e,receipt)),authorizeEdit:input=>storage.authorizeOwnerAction(input),verifyCommand:(receipt)=>ctx.io.personalizationSource?.verifyCommand?.(receipt,{subject:current()})};
 const profile=openUserProfile({subject:current,policy,source,versions:ports.versions});
 const {openAssistantSoul}=await importKernel('fusion/assistant-soul.mjs',ctx.env),soul=openAssistantSoul({subject:current,policy,store:ports.soulStore,owner});
 const {createPersonalizationContext}=await importKernel('fusion/personalization-context.mjs',ctx.env),context=createPersonalizationContext({subject:current,policy,profile,soul,proactive:{matchReply:input=>(ctx.io.proactiveService||proactiveHost?.service)?.matchReply(input)},skillRecords});
 const {directory:storageDirectory}=await storage.repair();if(force&&!loadConfig(ctx.env).personalizationInitialized)saveConfig({personalizationInitialized:true},ctx.env);
 async function valid(){return !closed&&await shared.isCurrent(handle)&&handle.store.status().memoryEpoch===handle.epoch;}
 if(s&&typeof handle.client?.runtimeHost==='function'){
  const {createAutomations}=await importKernel('fusion/studio/automations.mjs',ctx.env),{createReflectionHost}=await importKernel('fusion/reflection-host.mjs',ctx.env);
  automation=createAutomations({dir:path.join(storageDirectory,'schedules'),lock,paused:()=>closed,execute:async item=>{if(item.action.type==='reminder')return ctx.command==='chat'?proactiveHost.remind(item.action.questionId):{state:'waiting-destination'};if(item.action.type!=='reflection')throw failure('PERSONALIZATION_AUTOMATION_REQUIRED');return reflectionHost.reflection.catchUp();}});
  const configured=()=>ctx.io.providerOverride||ctx.requireProvider().record;
  const model={get contextWindow(){try{return configured().contextWindow||8192;}catch{return 8192;}},get maxOutput(){return 1024;},async complete(options){
   if(ctx.io.providerOverride)return ctx.io.providerOverride.complete(options);
   const record=ctx.requireProvider().record,{createProvider}=await importKernel('harness/providers.mjs',ctx.env);
   return createProvider({provider:{...record,maxOutput:options.maxOutput},fetchImpl:withModelEndpoint(createModelFetch(ctx.io.fetchImpl||globalThis.fetch,{env:ctx.env}),record)}).complete(options);
  }};
  reflectionHost=createReflectionHost({subject,policy,profile,automation,model,transport:(op,input)=>handle.client.runtimeHost(op,input),current:valid});
  const {createProactiveHost}=await importKernel('fusion/proactive-host.mjs',ctx.env);
  const channel={async send({text,effectKey}){if(!await valid())throw failure('PERSONALIZATION_SUBJECT_CHANGED');await new Promise((resolve,reject)=>ctx.stdout.write(`\n══ Koder · ${effectKey} ══\n${text}\n════════════════════\n`,error=>error?reject(error):resolve()));return {state:'sent',messageId:effectKey};}};
  proactiveHost=createProactiveHost({subject,policy,profile,language:ctx.lang,automation,channel,current:valid,transport:(op,input)=>handle.client.runtimeHost(op,input)});
 }
 return {policy,profile,soul,storage,subject,
  reflection:reflectionHost?.reflection,
  proactive:proactiveHost?.service,
  async startMaintenance({greet=false}={}){if(!reflectionHost)return;await reflectionHost.reflection.ensureSchedule();if(ctx.command==='chat'){await proactiveHost.restoreReminders();if(greet)await proactiveHost.checkIn();}automation.start();return reflectionHost.reflection.catchUp();},
  async context(args){if(!await valid())return {text:'',scope:null};const result=await context.context(args);return await valid()?result:{text:'',scope:null};},
  async status(){return {policy:await policy.status(),storage:await storage.status(),soulVersion:(await soul.read()).version,reflection:reflectionHost?.reflection.status()||{state:'waiting-account-host'},sharing:'linked-account-channels-private-and-associated-groups',cost:'selected model API or installed local model; daily budget applies'};},
  async remember(text,{category='explicit-preference'}={}){
   if(!await policy.require(category==='daily-state'?'dailyState':'learning'))throw failure('PERSONALIZATION_DISABLED');
   if(typeof text!=='string'||!text.trim()||text.length>1000)throw failure('PROFILE_INPUT_LIMIT');
   const {zonedDay}=await importKernel('fusion/personalization-time.mjs',ctx.env),snapshot=await policy.status(),id=crypto.randomUUID();
   const evidence={eventId:id,conversationId:'owner-memory-command',messageId:id,taskId:null,date:zonedDay(Date.now(),snapshot.timezone),subjectId:subject.subjectId,category,scope:'account',text:text.trim(),sourceRef:'owner-command:'+id};
   const receipt=await storage.authorizeEdit(evidence,owner);return profile.apply([evidence],{expectedVersion:(await profile.status()).version,receipt});
  },
  async forget(ids){const id=crypto.randomUUID(),evidence={eventId:id,subjectId:subject.subjectId,category:'owner-edit',operation:'forget',ids,text:'Forget selected preferences'};const receipt=await storage.authorizeEdit(evidence,owner);return profile.forget(ids,{expectedVersion:(await profile.status()).version,receipt});},
  async close(){if(closed)return;closed=true;automation?.stop();await proactiveHost?.close();await reflectionHost?.close();if(ownsShared)shared.close();if(ownsLock)lock.release();},
 };
 }catch(error){if(ownsShared)shared.close();if(ownsLock)lock.release();throw error;}
}
