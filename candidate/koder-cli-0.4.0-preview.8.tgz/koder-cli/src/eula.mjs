import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { cliHome } from "./config.mjs";

export const AGREEMENT_ID = "Koder-EULA-1.0";
export const AGREEMENT_VERSION = "1.0";

const file = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "EULA.md");

export function agreementSha256() {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

export function acceptancePath(env = process.env) {
  return path.join(cliHome(env), "eula-acceptance.json");
}

export function accepted(env = process.env) {
  try {
    const data = JSON.parse(fs.readFileSync(acceptancePath(env), "utf8"));
    return data.id === AGREEMENT_ID && data.version === AGREEMENT_VERSION && data.sha256 === agreementSha256();
  } catch {
    return false;
  }
}

export function writeAcceptance(env = process.env, at = new Date().toISOString()) {
  const home = cliHome(env);
  fs.mkdirSync(home, { recursive: true, mode: 0o700 });
  const record = { id: AGREEMENT_ID, version: AGREEMENT_VERSION, sha256: agreementSha256(), acceptedAt: at, preview: true };
  fs.writeFileSync(path.join(home, "eula-acceptance.json"), `${JSON.stringify(record, null, 2)}\n`, { mode: 0o600 });
  return record;
}

export function notice() {
  const sha = agreementSha256();
  return [
    `这是预览安装包。使用前请接受 ${AGREEMENT_ID}。`,
    `This is a preview build. Accept ${AGREEMENT_ID} before you use it.`,
    "官网 / Website: https://karmenloop.com",
    "邮箱 / Email: info@karmenloop.com",
    "团队 / Team: KARMENLOOP 官方团队 / KARMENLOOP Official Team，中国上海 / Shanghai, China",
    "全文 / Full text: koder eula 显示 EULA.md 与授权说明。安装目录另有 ACCEPTANCE.md 与 LEGAL-NOTICE.md。 / koder eula shows EULA.md and the consent guide. ACCEPTANCE.md and LEGAL-NOTICE.md are separate files in the install folder.",
    "接受：koder eula accept",
    "Agree: koder eula accept",
    "拒绝 / Decline: 不要运行接受命令。安装时输入 decline、直接回车或按 Ctrl+C 取消。 / Do not run the accept command. During installation, type decline, press Enter with no text, or press Ctrl+C.",
    "基础本地使用免费。接受协议不会开启喜好学习、同步、电脑或发消息权限。",
    "Basic local use is free. Acceptance does not enable preference learning, sync, computer access, or messaging.",
    `SHA-256 ${sha}`,
  ].join("\n");
}
