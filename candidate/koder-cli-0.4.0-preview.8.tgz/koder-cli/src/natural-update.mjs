// Only a direct, short local request enters this path. Quoted/piped material,
// model tool output, channel messages and project-edit requests never do.
export function updateIntent(input){
  if(typeof input!=='string'||input.length>140||/[\r\n`"“”'‘’]/.test(input))return null;
  const text=input.trim().replace(/[。！!]+$/,'').trim().toLowerCase();
  const prefix='(?:(?:请|帮我|帮忙|麻烦|现在|直接|给我|进行)\\s*)*';
  const object='(?:(?:这个|我的|当前|我们的)\\s*)?(?:koder(?:\\s*cli)?|cli|命令行(?:工具)?|你自己|自己)';
  if(new RegExp('^'+prefix+'(?:更新|升级)(?:一下)?\\s*(?:'+object+')?\\s*(?:到最新(?:版|版本))?(?:一下|吧)?$','i').test(text))return 'update';
  if(/^(?:please\s+)?(?:help me\s+)?(?:update|upgrade)(?:\s+(?:koder(?:\s+cli)?|this cli|yourself))?(?:\s+to (?:the )?latest(?: version)?)?$/.test(text))return 'update';
  if(new RegExp('^'+prefix+'(?:检查|查看|看看)\\s*(?:'+object+'\\s*)?(?:更新|有没有新版本|是否有新版本|最新版本)$','i').test(text)||/^(?:please )?check (?:koder )?(?:for )?updates$/.test(text))return 'check';
  return null;
}

export async function runNaturalUpdate(ctx,text){
  const intent=updateIntent(text);if(!intent)return null;
  const {run}=await import('./commands/update.mjs');
  const check=intent==='check'||ctx.command==='ask'||['plan','report','enhance'].includes(ctx.opts.mode);
  return run({...ctx,command:'update',opts:{...ctx.opts,check}});
}
