import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {compareVersions,installedVersion} from './update-release.mjs';
import {installInfo} from './commands/update.mjs';
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');

// This file only announces a verified installation. It carries no conversation,
// credentials, approvals, or execution authority. Resolve paths from install.json.
export async function publishActivation(installed) {
  const target=path.join(installed.home,'update-activation.json');
  const value={protocol:1,id:crypto.randomUUID(),version:installed.version,entrySha256:hash(await fs.readFile(installed.entry)),at:new Date().toISOString()};
  const temp=`${target}.${process.pid}.${value.id}.tmp`;
  try {await fs.writeFile(temp,JSON.stringify(value)+'\n',{flag:'wx',mode:0o600});await fs.rename(temp,target);}
  finally {await fs.rm(temp,{force:true});}
  return {...installed,activationId:value.id};
}

export function createRestartController({env=process.env,version,blockedVersion=null}={}) {
  const listeners=new Set();let pending=null,timer=null,checking=false,closed=false;
  const controller={
    resume:null,
    get pending(){return pending;},
    request(target){
      if(closed || compareVersions(target.version,version)<=0)return;
      if(pending && compareVersions(target.version,pending.version)<=0)return;
      pending=target;for(const listener of listeners)listener();
    },
    watch(listener){
      listeners.add(listener);
      if(!timer){timer=setInterval(check,750);timer.unref();void check();}
      if(pending)listener();
      return ()=>{listeners.delete(listener);if(!listeners.size){clearInterval(timer);timer=null;}};
    },
    cancel(){pending=null;controller.close();},
    close(){closed=true;listeners.clear();clearInterval(timer);timer=null;},
  };
  async function check(){
    if(checking || closed || pending)return;checking=true;
    try {
      const info=installInfo(env),stat=await fs.stat(path.join(info?.home || '', 'update-activation.json'));
      if(stat.size>4096)return;
      const activation=JSON.parse(await fs.readFile(path.join(info.home,'update-activation.json'),'utf8'));
      if(activation.protocol!==1 || activation.version!==info.version || activation.version===blockedVersion || compareVersions(activation.version,version)<=0)return;
      const installed=await installedVersion(info,process.platform);
      if(installed && hash(await fs.readFile(installed.entry))===activation.entrySha256)controller.request({...installed,activationId:activation.id});
    }catch{/* Missing/incomplete metadata leaves the current worker running. */}
    finally{checking=false;}
  }
  return controller;
}
