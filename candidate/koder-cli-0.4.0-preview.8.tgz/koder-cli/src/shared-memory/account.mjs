import crypto from 'node:crypto';
import readline from 'node:readline';
import {Writable} from 'node:stream';
import {cliHome,loadConfig,saveConfig} from '../config.mjs';
import {createKarmenClient} from './vendor/index.js';
import {openMemoryCredentials} from './credentials.mjs';
import {accountNotice} from '../consent-copy.mjs';

const fail=code=>{throw Object.assign(new Error(code),{code});};
const present=value=>typeof value==='string'&&value.length>0&&value.length<8192&&!/[\r\n]/.test(value);
async function prompt(ctx,label,secret=false) {
 if(secret&&ctx.io.promptSecret)return ctx.io.promptSecret(label);
 if(!secret&&ctx.io.promptText)return ctx.io.promptText(label);
 const shared=ctx.io.prompter;
 if(!ctx.stdin?.isTTY||!ctx.stdout?.isTTY)fail('MEMORY_INTERACTIVE_LOGIN_REQUIRED');
 if(shared?.rl) {
  if(!secret)return shared.ask(label,{fresh:true});
  const rl=shared.rl,original=rl.output,mute=new Writable({write(_b,_e,next){next();}});
  ctx.stderr.write(label);rl.output=mute;let value;
  try {value=await shared.ask('',{fresh:true});return value;}
  finally {rl.output=original;if(Array.isArray(rl.history))rl.history=rl.history.filter(line=>line!==value);ctx.stderr.write('\n');}
 }
 const output=secret?new Writable({write(_b,_e,next){next();}}):ctx.stdout;
 const rl=readline.createInterface({input:ctx.stdin,output,terminal:true,historySize:0});
 if(secret)ctx.stderr.write(label);
 try{return await new Promise(resolve=>{rl.question(secret?'':label,resolve);rl.once('close',()=>resolve(null));});}
 finally{rl.close();if(secret)ctx.stderr.write('\n');}
}
export function openMemoryAccount(ctx) {
 const credentials=ctx.io.memoryCredentials||openMemoryCredentials({dir:cliHome(ctx.env)});
 const configuration=()=>loadConfig(ctx.env).sharedMemory||ctx.config?.sharedMemory||{};
 const server=()=>ctx.opts?.server||configuration().server||null;
 let activeClient=null,activeGeneration=null;
 const clientFor=(baseUrl,identity=null)=>createKarmenClient({baseUrl,timeoutMs:20000,allowLoopbackHttp:ctx.io.allowLoopbackHttp===true,
  fetch:ctx.io.memoryFetch,getAccessToken:()=>identity?.token,getWorkspaceId:()=>identity?.workspaceId});
 async function currentIdentity() {
  const config=configuration();if(!server()||config.signedOut===true)return null;
  const value=await credentials.read();if(!value)return null;
  if(value.server!==server()||!present(value.token)||!present(value.accountId)||!present(value.tenantId)||!present(value.deviceId)||!present(value.generation))return null;
  if(config.generation&&config.generation!==value.generation)return null;
  if(!value.space||value.space.accountId!==value.accountId||value.space.tenantId!==value.tenantId)return null;
  if(!Number.isFinite(Date.parse(value.expiresAt))||Date.parse(value.expiresAt)<=Date.now())return null;
  return structuredClone(value);
 }
 return {
  currentIdentity,
  isCurrentKnown(identity){const c=configuration();return identity?Boolean(!c.signedOut&&c.generation===identity.generation&&server()===identity.server):c.signedOut===true||!c.generation;},
  async login(input={}) {
   const baseUrl=server();if(!baseUrl)fail('MEMORY_NOT_CONFIGURED');
   ctx.stderr.write(accountNotice(baseUrl,ctx.lang)+'\n');
   const anonymous=clientFor(baseUrl);let sessionClient;
   try {
    const meta=await anonymous.capabilities();
    if(meta?.memory?.enabled!==true||meta.memory.protocol!=='memory-events-v1'||meta.memory.authProtocol!=='karmen-account-v1')fail('MEMORY_SERVICE_UNAVAILABLE');
    const email=input.email??await prompt(ctx,ctx.lang==='en'?'Email: ':'邮箱: ');
    const password=input.password??await prompt(ctx,ctx.lang==='en'?'Password: ':'密码: ',true);
    if(!present(email)||!present(password))fail('MEMORY_LOGIN_CANCELLED');
    const grant=await anonymous.login({email,password});
    if(!present(grant.access_token)||!present(grant.device_id)||!present(grant.session_id))fail('MEMORY_ACCOUNT_INVALID');
    sessionClient=clientFor(baseUrl,{token:grant.access_token});
    const profile=await sessionClient.me();
    if(!present(profile.user_id)||!present(profile.tenant_id)||!present(profile.workspace_id)||profile.device_id!==grant.device_id)fail('MEMORY_ACCOUNT_INVALID');
    sessionClient.dispose();sessionClient=clientFor(baseUrl,{token:grant.access_token,workspaceId:profile.workspace_id});
    const spaces=await sessionClient.memorySpaces();
    const defaults=spaces.items?.filter(s=>s.default===true&&s.accountId===profile.user_id&&s.tenantId===profile.tenant_id);
    if(defaults?.length!==1||!present(defaults[0].spaceId))fail('MEMORY_SPACE_INVALID');
    const identity={server:baseUrl,token:grant.access_token,sessionId:grant.session_id,deviceId:grant.device_id,
     accountId:profile.user_id,tenantId:profile.tenant_id,workspaceId:profile.workspace_id,expiresAt:grant.expires_at,
     space:defaults[0],generation:crypto.randomUUID()};
    if(!Number.isFinite(Date.parse(identity.expiresAt))||Date.parse(identity.expiresAt)<=Date.now())fail('MEMORY_ACCOUNT_INVALID');
    await credentials.write(identity);
    saveConfig({sharedMemory:{...configuration(),server:baseUrl,generation:identity.generation,signedOut:false}},ctx.env);
    activeClient?.dispose();activeClient=null;activeGeneration=null;
    return {state:'connecting',accountId:identity.accountId,tenantId:identity.tenantId,spaceId:identity.space.spaceId,credentials:credentials.availability()};
   } finally {anonymous.dispose();sessionClient?.dispose();}
  },
  async logout() {
   let identity;try{identity=await currentIdentity();}catch{}
   // Invalidate every local process first, even when the OS store/server is unavailable.
   saveConfig({sharedMemory:{...configuration(),signedOut:true,generation:null}},ctx.env);
   activeClient?.dispose();activeClient=null;activeGeneration=null;
   let protectedStoreCleared=true;try{await credentials.clear();}catch{protectedStoreCleared=false;}
   let remoteRevoked=false;
   if(identity){const client=clientFor(identity.server,identity);try{await client.revokeSession(identity.sessionId);remoteRevoked=true;}catch{}finally{client.dispose();}}
   return {state:'waiting-account',remoteRevoked,protectedStoreCleared};
  },
  async client() {
   const identity=await currentIdentity();if(!identity)return null;
   if(activeGeneration!==identity.generation){activeClient?.dispose();activeClient=clientFor(identity.server,identity);activeGeneration=identity.generation;}
   return activeClient;
  },
  async status(){const identity=await currentIdentity();return {state:identity?'connecting':server()?'waiting-account':'local-only',configured:Boolean(server()),accountId:identity?.accountId||null,spaceId:identity?.space.spaceId||null,credentials:credentials.availability()};},
  dispose(){activeClient?.dispose();activeClient=null;},
 };
}
