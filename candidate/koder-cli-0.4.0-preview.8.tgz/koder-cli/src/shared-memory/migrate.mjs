import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const uuid=value=>{const h=hash(value);return `${h.slice(0,8)}-${h.slice(8,12)}-4${h.slice(13,16)}-a${h.slice(17,20)}-${h.slice(20,32)}`;};
const skip=reasonCode=>({imported:0,skipped:1,receiptId:null,reasonCode});
export async function migrateVerifiedSession({snapshot,sourceProof,space,store}) {
 const proof=sourceProof||{},identity=proof.identity;
 if(!identity||typeof identity.workspace!=='string'||!Array.isArray(identity.scope)||typeof identity.name!=='string'||!proof.home||!proof.deviceId)return skip('UNKNOWN_SOURCE');
 let actual;try{actual=fs.realpathSync(identity.workspace);}catch{return skip('UNKNOWN_SOURCE');}
 if(actual!==identity.workspace||hash(identity)!==snapshot?.key||snapshot.identity?.digest!==snapshot.key||snapshot.version!==1)return skip('UNKNOWN_SOURCE');
 const state=store.status();
 if(state.spaceId!==space.spaceId||(proof.accountId??null)!==(state.accountId??null)||(proof.tenantId??null)!==(state.tenantId??null))return skip('ACCOUNT_MISMATCH');
 if(proof.accountId&&!identity.scope.some((value,index)=>identity.scope[index-1]==='account'&&value===JSON.stringify([proof.server,proof.tenantId,proof.accountId])))return skip('UNKNOWN_SOURCE');
 if((snapshot.sharedMemory?.memoryEpoch??1)<state.memoryEpoch)return skip('RETIRED_EPOCH');
 if(snapshot.sharedMemory)return skip(snapshot.sharedMemory.spaceId===space.spaceId?'ALREADY_MANAGED':'ACCOUNT_MISMATCH');
 const source=proof.origin||{platform:'terminal',bindingId:null,chatId:snapshot.conversation?.id||'legacy-notes',actorId:proof.accountId||proof.deviceId};
 const origin=Object.fromEntries(['platform','bindingId','chatId','actorId'].map(key=>[key,source[key]]));
 if(identity.scope[0]==='gateway'&&!proof.origin)return skip('UNKNOWN_SOURCE');
 const receiptId=hash([space.spaceId,snapshot.key,hash(snapshot)]),dir=path.join(proof.home,'shared-memory-migrations',hash([space.spaceId,space.accountId??null,space.tenantId??null]));
 fs.mkdirSync(dir,{recursive:true,mode:0o700});if(fs.lstatSync(dir).isSymbolicLink())throw new Error('MEMORY_STORAGE_INVALID');
 const file=path.join(dir,receiptId+'.json');
 if(fs.existsSync(file))return {imported:0,skipped:0,receiptId,reasonCode:'ALREADY_IMPORTED'};
 const records=[...(snapshot.conversation?.messages||[]).filter(m=>['user','assistant','notice'].includes(m.role)).map(m=>({id:m.id,kind:'message',payload:{role:m.role,text:m.content},at:m.at})),...(snapshot.notes||[]).map(n=>({id:n.id,kind:'note',payload:{noteId:n.id,text:n.text},at:n.at}))];
 let imported=0;
 for(const record of records){
  const parts=[];let part='',size=0;
  for(const char of record.payload.text||''){const bytes=Buffer.byteLength(JSON.stringify(char))-2;if(size+bytes>12000){parts.push(part);part='';size=0;}part+=char;size+=bytes;}if(part)parts.push(part);
  for(let index=0;index<parts.length;index++){
   const eventId=uuid([space.spaceId,snapshot.key,record.kind,record.id,index]);
   await store.append({schemaVersion:1,eventId,spaceId:space.spaceId,originDeviceId:proof.deviceId,origin:{...origin,messageId:'legacy:'+record.id},
    conversationId:snapshot.conversation?.id||'legacy-notes',taskId:null,kind:record.kind,payload:{...record.payload,text:parts[index]},
    createdAt:Number.isSafeInteger(record.at)?record.at:Math.max(0,Number(snapshot.updatedAt)||0),supersedes:null,memoryEpoch:1});imported++;
  }
 }
 const temp=file+'.'+crypto.randomUUID();try{fs.writeFileSync(temp,JSON.stringify({receiptId,sourceKey:snapshot.key,sourceDigest:hash(snapshot),spaceId:space.spaceId,imported}),{flag:'wx',mode:0o600});const fd=fs.openSync(temp,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}try{fs.linkSync(temp,file);}catch(e){if(e.code!=='EEXIST')throw e;}}finally{fs.rmSync(temp,{force:true});}
 return {imported,skipped:0,receiptId,reasonCode:null};
}
