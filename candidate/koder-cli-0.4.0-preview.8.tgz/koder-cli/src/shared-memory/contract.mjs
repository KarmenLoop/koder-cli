import crypto from 'node:crypto';
import {types} from 'node:util';

export const MAX_EVENT_BYTES=32768;
export const MAX_BATCH_EVENTS=64;
export const MAX_BATCH_BYTES=524288;
export const memoryError=code=>Object.assign(new Error(code),{code});
const requireValue=(ok,code='MEMORY_EVENT_INVALID')=>{if(!ok)throw memoryError(code);};
const uuid=value=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
export const memoryId=value=>typeof value==='string'&&value.length>0&&value.length<=200&&!/[\x00-\x1f\x7f]/.test(value);
export function safeMemorySnapshot(value) {
 let count=0;
 function copy(item,depth) {
  requireValue(++count<=4096&&depth<=8);
  if(item===null||typeof item==='boolean')return item;
  if(typeof item==='number'){requireValue(Number.isFinite(item));return item;}
  if(typeof item==='string'){requireValue(Buffer.byteLength(item)<=MAX_BATCH_BYTES,'MEMORY_EVENT_TOO_LARGE');return item;}
  requireValue(item&&typeof item==='object'&&!types.isProxy(item));
  const proto=Object.getPrototypeOf(item);requireValue(Array.isArray(item)?proto===Array.prototype:proto===Object.prototype||proto===null);
  const descriptors=Object.getOwnPropertyDescriptors(item),out=Array.isArray(item)?[]:Object.create(null);
  if(Array.isArray(item)) {
   requireValue(item.length<=4096&&Reflect.ownKeys(descriptors).length===item.length+1);
   for(let i=0;i<item.length;i++)requireValue(Object.hasOwn(descriptors,String(i)));
  }
  for(const key of Reflect.ownKeys(descriptors)) {
   if(Array.isArray(item)&&key==='length')continue;
   const d=descriptors[key];requireValue(typeof key==='string'&&key!=='__proto__'&&key!=='constructor'&&key!=='prototype'&&d.enumerable&&Object.hasOwn(d,'value'));
   out[key]=copy(d.value,depth+1);
  }
  return out;
 }
 return copy(value,0);
}
export const canonicalMemoryJson=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
const fields=(value,required,optional=[])=>requireValue(value&&!Array.isArray(value)&&required.every(key=>Object.hasOwn(value,key))&&Object.keys(value).every(key=>required.includes(key)||optional.includes(key)));
function redact(text,secrets) {
 for(const secret of secrets)if(typeof secret==='string'&&secret.length>=4)text=text.split(secret).join('[redacted]');
 return text.replace(/\b(?:sk-|ghp_|xox[baprs]-)[A-Za-z0-9_-]{12,}\b/g,'[redacted]')
  .replace(/(\bauthorization\s*:\s*)[^\r\n]+/gi,'$1[redacted]')
  .replace(/(["'](?:api[_ -]?key|password|authorization|access[_ -]?token|refresh[_ -]?token)["']\s*:\s*)(["'])(?:\\.|(?!\2)[^\r\n])*?\2/gi,'$1"[redacted]"')
  .replace(/(\b(?:api[_ -]?key|password|access[_ -]?token|refresh[_ -]?token)\s*[=:]\s*)[^\s,;]+/gi,'$1[redacted]');
}
export function createMemoryEvent(input,{secrets=[],verifyDigest=false}={}) {
 const e=safeMemorySnapshot(input);
 fields(e,['schemaVersion','eventId','spaceId','originDeviceId','origin','conversationId','taskId','kind','payload','createdAt','supersedes'],['contentDigest','serverSeq','memoryEpoch']);
 requireValue(e.schemaVersion===1&&uuid(e.eventId)&&memoryId(e.spaceId)&&memoryId(e.originDeviceId)&&memoryId(e.conversationId));
 requireValue(e.taskId===null||memoryId(e.taskId));requireValue(e.supersedes===null||uuid(e.supersedes));
 requireValue(Number.isSafeInteger(e.createdAt)&&e.createdAt>=0);
 requireValue(e.memoryEpoch===undefined||(Number.isSafeInteger(e.memoryEpoch)&&e.memoryEpoch>=1));
 fields(e.origin,['platform','bindingId','chatId','actorId','messageId']);
 requireValue(['platform','chatId','actorId','messageId'].every(key=>memoryId(e.origin[key]))&&(e.origin.bindingId===null||memoryId(e.origin.bindingId)));
 if(e.kind==='message') {
  fields(e.payload,['role','text']);requireValue(['user','assistant','notice'].includes(e.payload.role)&&typeof e.payload.text==='string');
 } else if(e.kind==='note') {
  fields(e.payload,['noteId','text']);requireValue(memoryId(e.payload.noteId)&&typeof e.payload.text==='string');
 } else if(e.kind==='task-fact') {
  fields(e.payload,['text','state'],['resultRef']);requireValue(typeof e.payload.text==='string'&&['planned','running','waiting','completed','failed','cancelled'].includes(e.payload.state));
  if(e.payload.resultRef!==undefined)requireValue(memoryId(e.payload.resultRef));
 } else if(e.kind==='tombstone') {
  fields(e.payload,['eventIds'],['noteIds','scope','expectedEpoch']);requireValue(Array.isArray(e.payload.eventIds)&&e.payload.eventIds.length<=64&&e.payload.eventIds.every(uuid));
  requireValue(e.payload.scope===undefined||e.payload.scope==='space');
  if(e.payload.scope==='space')requireValue(e.payload.eventIds.length===0&&!(e.payload.noteIds?.length)&&Number.isSafeInteger(e.payload.expectedEpoch)&&e.payload.expectedEpoch>=1&&e.payload.expectedEpoch===(e.memoryEpoch??1));
  else requireValue(e.payload.expectedEpoch===undefined);
  if(e.payload.noteIds!==undefined)requireValue(Array.isArray(e.payload.noteIds)&&e.payload.noteIds.length<=64&&e.payload.noteIds.every(memoryId));
 } else throw memoryError('MEMORY_EVENT_INVALID');
 if(typeof e.payload.text==='string')e.payload.text=redact(e.payload.text,secrets);
 const originalDigest=e.contentDigest;delete e.contentDigest;delete e.serverSeq;
 const contentDigest=crypto.createHash('sha256').update(canonicalMemoryJson(e)).digest('hex');
 requireValue(!verifyDigest||originalDigest===contentDigest,'MEMORY_DIGEST_INVALID');
 const result={...e,contentDigest};requireValue(Buffer.byteLength(canonicalMemoryJson(result))<=MAX_EVENT_BYTES,'MEMORY_EVENT_TOO_LARGE');
 return result;
}
