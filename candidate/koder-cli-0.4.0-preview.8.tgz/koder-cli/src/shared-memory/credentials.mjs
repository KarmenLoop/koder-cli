// Compatibility export; ciphertext and credential namespaces are unchanged.
import {importKernel} from '../agent.mjs';
const {openMemoryCredentials}=await importKernel('fusion/native-credentials.mjs');
export {openMemoryCredentials};
