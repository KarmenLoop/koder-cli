import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {canonicalMemoryJson,createMemoryEvent,memoryError,memoryId,MAX_BATCH_EVENTS,MAX_BATCH_BYTES,safeMemorySnapshot} from './contract.mjs';

const fail=code=>{throw memoryError(code);};
function directory(dir) {
 try{fs.mkdirSync(dir,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}
 const stat=fs.lstatSync(dir);if(!stat.isDirectory()||stat.isSymbolicLink())fail('MEMORY_STORAGE_INVALID');
}
function readRecord(file,codec) {
 let fd;
 try {
  fd=fs.openSync(file,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0)|(fs.constants.O_NONBLOCK||0));
  const stat=fs.fstatSync(fd);if(!stat.isFile()||stat.size>MAX_BATCH_BYTES+32768+8192)fail('MEMORY_STORAGE_INVALID');
  const bytes=fs.readFileSync(fd);return JSON.parse((codec?codec.decode(bytes,file):bytes).toString('utf8'));
 } catch(e){if(e.code?.startsWith('MEMORY_'))throw e;throw memoryError('MEMORY_STORAGE_INVALID');}
 finally{if(fd!==undefined)fs.closeSync(fd);}
}
function publish(dir,name,value,codec) {
 directory(dir);const target=path.join(dir,name+'.json'),temp=path.join(dir,'.tmp-'+crypto.randomUUID());let fd;
 const plain=canonicalMemoryJson(value)+'\n',data=codec?codec.encode(Buffer.from(plain),target):plain;
 try {
  fd=fs.openSync(temp,'wx',0o600);fs.writeFileSync(fd,data);fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;
  try{fs.linkSync(temp,target);}catch(e){if(e.code!=='EEXIST')throw e;if(canonicalMemoryJson(readRecord(target,codec))!==plain.trimEnd())fail('MEMORY_EVENT_CONFLICT');}
  if(process.platform!=='win32'){const d=fs.openSync(dir,'r');try{fs.fsyncSync(d);}finally{fs.closeSync(d);}}
 } finally {if(fd!==undefined)fs.closeSync(fd);fs.rmSync(temp,{force:true});}
}
export function openSharedMemory({home,space,secrets=[],codec=null}={}) {
 if(typeof home!=='string'||!memoryId(space?.spaceId))fail('MEMORY_SPACE_INVALID');
 if(codec&&(typeof codec.encode!=='function'||typeof codec.decode!=='function'))fail('MEMORY_STORAGE_INVALID');
 const fixed=structuredClone(space),key=crypto.createHash('sha256').update(canonicalMemoryJson([fixed.spaceId,fixed.tenantId??null,fixed.accountId??null])).digest('hex');
 fs.mkdirSync(home,{recursive:true,mode:0o700});directory(home);
 let root=path.resolve(home);for(const part of ['shared-memory','v1',key]){root=path.join(root,part);directory(root);}
 const dirs=Object.fromEntries(['events','acks','pages'].map(name=>{const dir=path.join(root,name);directory(dir);return [name,dir];}));
 let closed=false;
 const check=()=>{if(closed)fail('MEMORY_CLOSED');directory(root);};
 const records=name=>fs.readdirSync(dirs[name]).filter(file=>/^[0-9a-f-]+\.json$/.test(file)).map(file=>readRecord(path.join(dirs[name],file),codec));
 function state() {
  check();const events=new Map(),acks=new Map();const initialEpoch=Number.isSafeInteger(fixed.memoryEpoch)&&fixed.memoryEpoch>=1?fixed.memoryEpoch:1;
  let cursor=null,cursorSeq=0,lastPullAt=null,lastAckAt=null,hasMore=true,memoryEpoch=initialEpoch,serverEpoch=initialEpoch;
  function add(input,seq=null) {
   const event=createMemoryEvent(input,{verifyDigest:true});if(event.spaceId!==fixed.spaceId)fail('MEMORY_SPACE_MISMATCH');
   const old=events.get(event.eventId);if(old&&old.contentDigest!==event.contentDigest)fail('MEMORY_EVENT_CONFLICT');
   if(old?.serverSeq&&seq&&old.serverSeq!==seq)fail('MEMORY_EVENT_CONFLICT');
   events.set(event.eventId,{...event,...((seq||old?.serverSeq)?{serverSeq:seq||old.serverSeq}:{})});
   if(event.kind==='tombstone'&&event.payload.scope==='space'){memoryEpoch=Math.max(memoryEpoch,event.payload.expectedEpoch+1);if(seq)serverEpoch=Math.max(serverEpoch,event.payload.expectedEpoch+1);}
  }
  for(const e of records('events'))add(e);
  for(const page of records('pages')) {
   if(!Array.isArray(page.events)||!Number.isSafeInteger(page.throughSeq)||!Number.isSafeInteger(page.at)||typeof page.nextCursor!=='string'||typeof page.hasMore!=='boolean')fail('MEMORY_STORAGE_INVALID');
   for(const event of page.events){if(!Number.isSafeInteger(event.serverSeq)||event.serverSeq<1)fail('MEMORY_STORAGE_INVALID');add(event,event.serverSeq);}
   if(page.memoryEpoch!==undefined){if(!Number.isSafeInteger(page.memoryEpoch)||page.memoryEpoch<1)fail('MEMORY_STORAGE_INVALID');memoryEpoch=Math.max(memoryEpoch,page.memoryEpoch);serverEpoch=Math.max(serverEpoch,page.memoryEpoch);}
   if(page.throughSeq>cursorSeq||(page.throughSeq===cursorSeq&&(page.at>=(lastPullAt||0)))){cursor=page.nextCursor;cursorSeq=page.throughSeq;lastPullAt=page.at;hasMore=page.hasMore;}
  }
  for(const record of records('acks')) {
   if(!Array.isArray(record.acks)||!Number.isSafeInteger(record.at))fail('MEMORY_STORAGE_INVALID');
   for(const ack of record.acks) {
    if(!events.has(ack.eventId)||!Number.isSafeInteger(ack.serverSeq)||ack.serverSeq<1)fail('MEMORY_STORAGE_INVALID');
    if((acks.has(ack.eventId)&&acks.get(ack.eventId)!==ack.serverSeq)||(events.get(ack.eventId).serverSeq&&events.get(ack.eventId).serverSeq!==ack.serverSeq))fail('MEMORY_EVENT_CONFLICT');acks.set(ack.eventId,ack.serverSeq);
    const e=events.get(ack.eventId);if(e.kind==='tombstone'&&e.payload.scope==='space')serverEpoch=Math.max(serverEpoch,e.payload.expectedEpoch+1);
   }
   lastAckAt=Math.max(lastAckAt||0,record.at);
  }
  return {events,acks,cursor,cursorSeq,lastPullAt,lastAckAt,hasMore,memoryEpoch,serverEpoch};
 }
 const pendingOf=s=>[...s.events.values()].filter(e=>!e.serverSeq&&!s.acks.has(e.eventId)&&((e.kind==='tombstone'&&e.payload.scope==='space')?e.payload.expectedEpoch>=s.serverEpoch:(e.memoryEpoch??1)===s.memoryEpoch)).sort((a,b)=>(a.memoryEpoch??1)-(b.memoryEpoch??1)||a.createdAt-b.createdAt||a.eventId.localeCompare(b.eventId));
 return {
  async append(input) {
   check();const event=createMemoryEvent(input,{secrets});if(event.spaceId!==fixed.spaceId)fail('MEMORY_SPACE_MISMATCH');
   const snapshot=state(),current=snapshot.events.get(event.eventId);if(current&&current.contentDigest!==event.contentDigest)fail('MEMORY_EVENT_CONFLICT');
   if(!current&&((event.memoryEpoch??1)>snapshot.memoryEpoch||(event.kind==='tombstone'&&event.payload.scope==='space'&&event.payload.expectedEpoch!==snapshot.memoryEpoch)))fail('MEMORY_EPOCH_CHANGED');
   if(!current)publish(dirs.events,event.eventId,event,codec);return structuredClone(current||event);
  },
  async pending(limit=64) {
   if(!Number.isInteger(limit)||limit<1||limit>64)fail('MEMORY_LIMIT_INVALID');
   return pendingOf(state()).slice(0,limit);
  },
  async ack(input) {
   check();const acks=safeMemorySnapshot(input);if(!Array.isArray(acks)||acks.length>64)fail('MEMORY_ACK_INVALID');const s=state();
   for(const a of acks)if(!s.events.has(a.eventId)||!Number.isSafeInteger(a.serverSeq)||a.serverSeq<1||typeof a.duplicate!=='boolean'||(s.acks.has(a.eventId)&&s.acks.get(a.eventId)!==a.serverSeq)||(s.events.get(a.eventId)?.serverSeq&&s.events.get(a.eventId).serverSeq!==a.serverSeq))fail('MEMORY_ACK_INVALID');
   if(acks.length)publish(dirs.acks,crypto.randomUUID(),{acks:acks.map(({eventId,serverSeq})=>({eventId,serverSeq})),at:Date.now()},codec);
  },
  async applyPage(input) {
   check();const page=safeMemorySnapshot(input);
   if(page?.memoryEpoch!==undefined&&(!Number.isSafeInteger(page.memoryEpoch)||page.memoryEpoch<1))fail('MEMORY_PAGE_INVALID');
   if(!page||!Array.isArray(page.events)||page.events.length>MAX_BATCH_EVENTS||Buffer.byteLength(canonicalMemoryJson(page))>MAX_BATCH_BYTES||typeof page.nextCursor!=='string'||!page.nextCursor||page.nextCursor.length>8192||typeof page.hasMore!=='boolean'||(!page.events.length&&page.hasMore))fail('MEMORY_PAGE_INVALID');
   const s=state(),seen=new Set();let last=0;
   const events=page.events.map(input=>{
    const e=createMemoryEvent(input,{verifyDigest:true});const seq=input.serverSeq;
    if(e.spaceId!==fixed.spaceId)fail('MEMORY_SPACE_MISMATCH');
    if(!Number.isSafeInteger(seq)||seq<1||seen.has(e.eventId)||(last&&seq!==last+1)||(!last&&seq>s.cursorSeq+1))fail('MEMORY_CURSOR_GAP');
    const old=s.events.get(e.eventId);if(old&&old.contentDigest!==e.contentDigest)fail('MEMORY_EVENT_CONFLICT');
    if(old?.serverSeq&&old.serverSeq!==seq)fail('MEMORY_EVENT_CONFLICT');
    seen.add(e.eventId);last=seq;return {...e,serverSeq:seq};
   });
   publish(dirs.pages,crypto.randomUUID(),{events,nextCursor:page.nextCursor,hasMore:page.hasMore,memoryEpoch:page.memoryEpoch??1,throughSeq:events.at(-1)?.serverSeq??s.cursorSeq,at:Math.max(Date.now(),(s.lastPullAt||0)+1)},codec);
  },
  async query({text='',taskId=null,limit=20,maxBytes=24576}={}) {
   if(typeof text!=='string'||text.length>32000||!Number.isInteger(limit)||limit<1||limit>100||!Number.isInteger(maxBytes)||maxBytes<2||maxBytes>1048576)fail('MEMORY_QUERY_INVALID');
   const {events,memoryEpoch}=state(),deleted=new Set(),deletedNotes=new Set(),superseded=new Set(),noteCounts=new Map();
   for(const e of events.values())if(e.kind==='tombstone'){for(const id of e.payload.eventIds)deleted.add(id);for(const id of e.payload.noteIds||[])deletedNotes.add(id);}
   for(const e of events.values())if(!deleted.has(e.eventId)&&e.supersedes)superseded.add(e.supersedes);
   const visible=[...events.values()].filter(e=>(e.memoryEpoch??1)===memoryEpoch&&e.kind!=='tombstone'&&!deleted.has(e.eventId)&&!deletedNotes.has(e.payload.noteId)&&!superseded.has(e.eventId));
   for(const e of visible)if(e.kind==='note')noteCounts.set(e.payload.noteId,(noteCounts.get(e.payload.noteId)||0)+1);
   const lowered=text.toLocaleLowerCase(),tokens=lowered.match(/[\p{L}\p{N}_-]+/gu)||[];
   for(const phrase of lowered.match(/\p{Script=Han}{2,}/gu)||[]){const chars=[...phrase];for(let i=0;i<chars.length-1;i++)tokens.push(chars[i]+chars[i+1]);}
   const terms=[...new Set(tokens)].slice(0,64);
   const ranked=visible.map(e=>({e,score:(taskId&&e.taskId===taskId?1000:0)+terms.reduce((n,term)=>n+(e.payload.text?.toLocaleLowerCase().includes(term)?1:0),0)})).filter(r=>!terms.length||r.score>0).sort((a,b)=>b.score-a.score||(b.e.serverSeq||0)-(a.e.serverSeq||0)||b.e.createdAt-a.e.createdAt||a.e.eventId.localeCompare(b.e.eventId));
   const result=[];
   for(const {e} of ranked) {
    let next={...e,...(e.kind==='note'?{conflict:noteCounts.get(e.payload.noteId)>1}:{})};
    if(Buffer.byteLength(JSON.stringify([...result,next]))>maxBytes&&typeof next.payload.text==='string') {
     next={...next,payload:{...next.payload,text:''},excerpted:true};
     const room=maxBytes-Buffer.byteLength(JSON.stringify([...result,next]));
     if(room<=0)continue;
     let excerpt=Buffer.from(e.payload.text).subarray(0,room).toString('utf8');next.payload.text=excerpt;
     while(Buffer.byteLength(JSON.stringify([...result,next]))>maxBytes&&excerpt.length){excerpt=excerpt.slice(0,-1);next.payload.text=excerpt;}
    }
    if(Buffer.byteLength(JSON.stringify([...result,next]))<=maxBytes)result.push(next);
    if(result.length>=limit)break;
   }
   return structuredClone(result);
  },
  status() {
   const s=state(),pending=pendingOf(s).length;
   return {state:!fixed.accountId?'local-only':pending?'offline-pending':s.lastPullAt&&!s.hasMore?'synced':'connecting',spaceId:fixed.spaceId,accountId:fixed.accountId??null,tenantId:fixed.tenantId??null,memoryEpoch:s.memoryEpoch,serverEpoch:s.serverEpoch,pending,cursor:s.cursor,cursorSeq:s.cursorSeq,lastAckAt:s.lastAckAt,lastPullAt:s.lastPullAt,errorCode:null};
  },
  close(){closed=true;},
 };
}
