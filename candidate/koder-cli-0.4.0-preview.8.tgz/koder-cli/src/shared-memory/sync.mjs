export {createMemorySync} from './vendor/memory-sync.js';
