import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
const error=code=>Object.assign(new Error(code),{code});
const digest=data=>crypto.createHash('sha256').update(data).digest('hex');
// Pin every existing ancestor before creating a child. Windows ACL verification
// is supplied by the native host; POSIX chmod is never an ACL receipt.
function inspectRoot(root,{create=true}={}) {
 const absolute=path.resolve(root),parsed=path.parse(absolute);let current=parsed.root;
 const pins=[];
 for(const name of absolute.slice(parsed.root.length).split(path.sep).filter(Boolean)){
  current=path.join(current,name);
  try{fs.lstatSync(current);}catch(e){if(e.code!=='ENOENT'||!create)throw e;fs.mkdirSync(current,{mode:0o700});}
  const stat=fs.lstatSync(current);if(!stat.isDirectory()||stat.isSymbolicLink())throw error('MEMORY_ROOT_UNSAFE');
  pins.push({file:current,dev:stat.dev,ino:stat.ino});
 }
 for(const p of pins){const s=fs.lstatSync(p.file);if(s.isSymbolicLink()||s.dev!==p.dev||s.ino!==p.ino)throw error('MEMORY_ROOT_CHANGED');}
 const stat=fs.lstatSync(absolute);
 return {root:absolute,objectId:`${stat.dev}:${stat.ino}`,volumeId:String(stat.dev),private:process.platform!=='win32'&&(stat.mode&0o077)===0,pins};
}
export function nativeMemoryProbe() {return {
 volume(root){try{if(process.platform!=='win32'){while(!fs.existsSync(root)&&path.dirname(root)!==root)root=path.dirname(root);}const s=fs.statSync(root);let writable=true;try{fs.accessSync(root,fs.constants.W_OK);}catch{writable=false;}return {exists:true,writable,volumeId:String(s.dev)};}catch(e){if(e.code==='ENOENT')return {exists:false};return {exists:true,writable:false};}},
 root(root){const value=inspectRoot(root);const file=path.join(value.root,'.memory-probe-'+crypto.randomUUID());let fd;try{fd=fs.openSync(file,'wx',0o600);fs.writeSync(fd,'koder-memory');fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;if(fs.readFileSync(file,'utf8')!=='koder-memory')throw error('MEMORY_WRITE_VERIFY_FAILED');return value;}finally{if(fd!==undefined)fs.closeSync(fd);fs.rmSync(file,{force:true});}},
};}
export function resolveMemoryLocation({platform=process.platform,configured,userKey,probe=nativeMemoryProbe()}={}) {
 let root=typeof configured==='string'?configured:configured?.root;
 if(!root){
  if(platform==='win32'){
   if(typeof userKey!=='string'||!/^[-a-zA-Z0-9_]{1,80}$/.test(userKey))return {state:'restricted',reasonCode:'MEMORY_USER_UNKNOWN'};
   const d=probe.volume('D:\\');root=path.win32.join(d.exists?'D:\\':'C:\\','Koder','Memory',userKey);
  }else root=path.join(os.homedir(),'.koder-cli');
 }
 const result={root,state:'restricted'};
 try{
  const volume=probe.volume(platform==='win32'?path.win32.parse(root).root:path.resolve(root));
  if(!volume.exists)return {...result,reasonCode:'MEMORY_VOLUME_MISSING'};
  if(!volume.writable)return {...result,reasonCode:'MEMORY_VOLUME_UNWRITABLE'};
  const actual=probe.root(root),volumeId=actual.volumeId||volume.volumeId;
  if((configured?.volumeId&&configured.volumeId!==volumeId)||(configured?.objectId&&configured.objectId!==actual.objectId))return {...result,reasonCode:'MEMORY_ROOT_CHANGED'};
  if(!actual.private)return {...result,volumeId,objectId:actual.objectId,reasonCode:'MEMORY_ACCESS_ISOLATION_UNVERIFIED'};
  return {root:actual.root,volumeId,objectId:actual.objectId,state:'ready',reasonCode:null};
 }catch(e){return {...result,reasonCode:['MEMORY_ROOT_CHANGED','MEMORY_ROOT_UNSAFE'].includes(e.code)?e.code:'MEMORY_ROOT_UNAVAILABLE'};}
}
const memoryDirs=['memory','shared-memory','memory-channel-cache','shared-memory-cache','personalization'];
function inventory(root){
 const files=[];let bytes=0;
 const visit=(dir)=>{for(const ent of fs.readdirSync(dir,{withFileTypes:true})){
  const file=path.join(dir,ent.name),rel=path.relative(root,file),s=fs.lstatSync(file);
  if(s.isSymbolicLink()||(!s.isDirectory()&&!s.isFile()))throw error('MEMORY_ROOT_UNSAFE');
  if(s.isDirectory())visit(file);else {
   if(/\.(lock|reaper)(\.|$)/.test(ent.name))throw error('MEMORY_WRITER_NOT_PAUSED');
   bytes+=s.size;if(bytes>512*1024*1024||files.length>=32768)throw error('MEMORY_MIGRATION_LIMIT');
   files.push({path:rel,bytes:s.size,sha256:digest(fs.readFileSync(file))});
  }
 }};
 for(const name of memoryDirs){const dir=path.join(root,name);if(fs.existsSync(dir)){const s=fs.lstatSync(dir);if(!s.isDirectory()||s.isSymbolicLink())throw error('MEMORY_ROOT_UNSAFE');visit(dir);}}
 return files.sort((a,b)=>a.path.localeCompare(b.path));
}
export async function migrateMemoryLocation({from,to,store,settings,owner,signal}={}) {
 if(typeof owner?.exclusive!=='function'||typeof store?.pause!=='function'||typeof settings?.compareAndSwap!=='function')throw error('MEMORY_OWNER_UNAVAILABLE');
 const source=path.resolve(typeof from==='string'?from:from.root),destination=path.resolve(typeof to==='string'?to:to.root);
 if(source===destination||source.startsWith(destination+path.sep)||destination.startsWith(source+path.sep))throw error('MEMORY_MIGRATION_OVERLAP');
 return owner.exclusive(async()=>{
  const check=()=>{if(signal?.aborted)throw error('MEMORY_MIGRATION_CANCELLED');};check();
  const original=await settings.read();if(original.root!==source)throw error('MEMORY_LOCATION_CONFLICT');
  const sourcePin=inspectRoot(source,{create:false});if(from?.objectId&&from.objectId!==sourcePin.objectId)throw error('MEMORY_ROOT_CHANGED');
  if(fs.existsSync(destination)&&fs.readdirSync(destination).length)throw error('MEMORY_DESTINATION_NOT_EMPTY');
  const targetPin=inspectRoot(destination);const lease=await store.pause();let changed=null,resumed=false;
  try{
   const files=inventory(source);for(const row of files){check();const data=fs.readFileSync(path.join(source,row.path));if(digest(data)!==row.sha256)throw error('MEMORY_SOURCE_CHANGED');const out=path.join(destination,row.path);inspectRoot(path.dirname(out));fs.writeFileSync(out,data,{flag:'wx',mode:0o600});const fd=fs.openSync(out,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
   if(JSON.stringify(inventory(source))!==JSON.stringify(files)||JSON.stringify(inventory(destination))!==JSON.stringify(files))throw error('MEMORY_MIGRATION_VERIFY_FAILED');
   if(inspectRoot(source).objectId!==sourcePin.objectId||inspectRoot(destination).objectId!==targetPin.objectId)throw error('MEMORY_ROOT_CHANGED');
   check();changed=await settings.compareAndSwap(original,{...original,root:destination,volumeId:targetPin.volumeId,objectId:targetPin.objectId,revision:original.revision+1});
   await lease.verify(destination);check();await lease.resume(destination);resumed=true;
   return {root:destination,manifestDigest:digest(JSON.stringify(files)),state:'ready',files:files.length};
  }catch(e){
   // resume is a transactional host operation: on rejection it must retain the
   // paused state. The same exclusive owner covers settings and writer handoff.
   if(!resumed){if(changed)await settings.compareAndSwap(changed,original);await lease.resume(source);}throw e;
  }
 });
}
