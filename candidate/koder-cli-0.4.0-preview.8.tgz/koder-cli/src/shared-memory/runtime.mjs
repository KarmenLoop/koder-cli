import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {cliHome,memoryHome} from '../config.mjs';
import {openSharedMemory} from './store.mjs';
import {openMemoryAccount} from './account.mjs';
import {createMemorySync} from './sync.mjs';
import {redactMemory} from '../memory.mjs';
import {migrateVerifiedSession} from './migrate.mjs';

const uuid=value=>{const h=crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');return `${h.slice(0,8)}-${h.slice(8,12)}-4${h.slice(13,16)}-a${h.slice(17,20)}-${h.slice(20,32)}`;};
const failure=code=>Object.assign(new Error(code),{code});
function directory(dir){fs.mkdirSync(dir,{recursive:true,mode:0o700});const s=fs.lstatSync(dir);if(!s.isDirectory()||s.isSymbolicLink())throw failure('MEMORY_STORAGE_INVALID');return dir;}
function readRecord(file){let fd;try{fd=fs.openSync(file,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));const s=fs.fstatSync(fd);if(!s.isFile()||s.size>131072)throw failure('MEMORY_STORAGE_INVALID');return JSON.parse(fs.readFileSync(fd,'utf8'));}catch(e){if(e.code==='ENOENT')return null;throw failure('MEMORY_STORAGE_INVALID');}finally{if(fd!==undefined)fs.closeSync(fd);}}
function record(dir,id,value){directory(dir);const file=path.join(dir,id+'.json'),temp=file+'.'+crypto.randomUUID();try{fs.writeFileSync(temp,JSON.stringify(value),{flag:'wx',mode:0o600});const fd=fs.openSync(temp,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}try{fs.linkSync(temp,file);}catch(e){if(e.code!=='EEXIST')throw e;}return readRecord(file);}finally{fs.rmSync(temp,{force:true});}}
function localIdentity(home) {
 fs.mkdirSync(home,{recursive:true,mode:0o700});const file=path.join(home,'memory-installation.json');
 if(!fs.existsSync(file)){
  const temp=file+'.'+crypto.randomUUID();try{
   fs.writeFileSync(temp,JSON.stringify({deviceId:crypto.randomUUID(),spaceId:crypto.randomUUID()}),{flag:'wx',mode:0o600});
   try{fs.linkSync(temp,file);}catch(e){if(e.code!=='EEXIST')throw e;}
  }finally{fs.rmSync(temp,{force:true});}
 }
 const fd=fs.openSync(file,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));let value;
 try{const stat=fs.fstatSync(fd);if(!stat.isFile()||stat.size>4096)throw failure('MEMORY_STORAGE_INVALID');value=JSON.parse(fs.readFileSync(fd,'utf8'));}finally{fs.closeSync(fd);}
 if(![value.deviceId,value.spaceId].every(v=>typeof v==='string'&&/^[0-9a-f-]{36}$/.test(v)))throw failure('MEMORY_STORAGE_INVALID');return value;
}
export function openSharedMemoryRuntime(ctx,{secrets=[]}={}) {
 const home=cliHome(ctx.env),memoryRoot=memoryHome(ctx.env),local=localIdentity(home),account=ctx.io.memoryAccount||openMemoryAccount(ctx);
 let current=null,closed=false;
 const identityKey=i=>i?JSON.stringify([i.server,i.tenantId,i.accountId,i.space.spaceId,i.generation]):'local';
 async function refresh() {
  if(closed)throw failure('MEMORY_CLOSED');
  const identity=await account.currentIdentity(),key=identityKey(identity);
  if(current?.key===key)return current;
  current?.sync.stop();
  const space=identity?identity.space:{spaceId:local.spaceId,accountId:null,tenantId:null};
  const store=openSharedMemory({home:memoryRoot,space,secrets:[...secrets,identity?.token].filter(Boolean)});
  const client=identity?await account.client():null;
  const root=directory(path.join(memoryRoot,'memory-channel-cache',crypto.createHash('sha256').update(JSON.stringify([space.spaceId,space.tenantId,space.accountId])).digest('hex')));
  current={key,identity,store,deviceId:identity?.deviceId||local.deviceId,space,client,root};
  current.sync=createMemorySync({store,client,currentIdentity:()=>account.currentIdentity()});
  return current;
 }
 async function guard(handle){return !closed&&identityKey(await account.currentIdentity())===handle.key;}
 const baseOrigin=(h,conversationId)=>({platform:ctx.command==='acp'?'acp':'terminal',bindingId:null,chatId:conversationId,actorId:h.identity?.accountId||local.deviceId,messageId:conversationId});
 const bindingKey=source=>uuid([source.platform,source.bindingId,source.chatId]);
 const pendingDrafts=h=>fs.readdirSync(directory(path.join(h.root,'inbox'))).filter(n=>n.endsWith('.json')&&!fs.existsSync(path.join(h.root,'done',n))).map(n=>({id:n.slice(0,-5),value:readRecord(path.join(h.root,'inbox',n))}));
 async function resolveOrigin(h,origin) {
  if(!origin||!h.identity)return origin;
  const id=bindingKey(origin),dir=directory(path.join(h.root,'bindings'));
  if(readRecord(path.join(h.root,'revoked',id+'.json')))throw failure('MEMORY_BINDING_REVOKED');
  let saved=readRecord(path.join(dir,id+'.json'));
  const signal=AbortSignal.timeout(5000);
  try{
   if(!saved){
    const result=await h.client.memoryBind(h.space.spaceId,{kind:'channel',platform:origin.platform,installationId:local.deviceId+':'+origin.bindingId,chatId:origin.chatId,visibility:origin.visibility||'account'},{signal});
    if(!await guard(h))throw failure('MEMORY_ACCOUNT_CHANGED');
    if(typeof result.bindingId!=='string'||result.spaceId!==h.space.spaceId)throw failure('MEMORY_BINDING_INVALID');
    saved=record(dir,id,{bindingId:result.bindingId,spaceId:h.space.spaceId});
   }else await h.client.memoryQuery(h.space.spaceId,{text:'',limit:1,maxBytes:2,bindingId:saved.bindingId,signal});
  }catch(e){
   if([401,403,404].includes(e.status)){record(path.join(h.root,'revoked'),id,{at:Date.now()});throw failure('MEMORY_BINDING_REVOKED');}
   if(!saved)throw failure('MEMORY_BINDING_PENDING');
   // A previously verified binding may use its local cache while offline.
  }
  return {...origin,bindingId:saved.bindingId};
 }
 async function commitDraft(h,id,draft,origin) {
  if(!await guard(h))return;
  if(draft.epoch<h.store.status().memoryEpoch){record(path.join(h.root,'done'),id,{retired:true});return;}
  const source=Object.fromEntries(['platform','bindingId','chatId','actorId','messageId'].map(k=>[k,origin[k]]));
  const eventId=uuid([draft.deviceId,source.platform,source.bindingId,source.chatId,source.messageId,draft.message.role,draft.part]);
  await h.store.append({schemaVersion:1,eventId,spaceId:h.space.spaceId,originDeviceId:draft.deviceId,origin:source,
   conversationId:draft.conversationId,taskId:draft.taskId,kind:draft.message.kind==='task-fact'?'task-fact':'message',payload:draft.message.kind==='task-fact'?{text:draft.message.content,state:'waiting',resultRef:draft.message.resultRef}:{role:draft.message.role,text:draft.message.content},createdAt:draft.message.at,supersedes:null,memoryEpoch:draft.epoch});
  record(path.join(h.root,'done'),id,{eventId});
 }
 async function prepare({sync=true,origin=null}={}) {
  const h=await refresh();
  if(sync&&h.client){const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),5000);try{await h.sync.syncOnce({signal:abort.signal});}finally{clearTimeout(timer);}}
  const handle={...h,epoch:h.store.status().memoryEpoch,origin,unboundOrigin:origin};
  try{
   handle.origin=await resolveOrigin(h,origin);
   const resolvedBindings=new Map();if(origin)resolvedBindings.set(bindingKey(origin),handle.origin);
   const drainDeadline=Date.now()+5000;
   for(const {id,value} of pendingDrafts(h).slice(0,64)){
    if(value.epoch<h.store.status().memoryEpoch){record(path.join(h.root,'done'),id,{retired:true});continue;}
    const key=bindingKey(value.source);if(origin&&key!==bindingKey(origin))continue;
    if(!resolvedBindings.has(key)){
      if(Date.now()>=drainDeadline||resolvedBindings.size>=2)continue;
      try{resolvedBindings.set(key,await resolveOrigin(h,value.source));}catch{continue;}
    }
    const resolved={...resolvedBindings.get(key),messageId:value.source.messageId,actorId:value.source.actorId};
    await commitDraft(h,id,value,resolved);
   }
  }catch(e){handle.sharedDisabled=true;handle.errorCode=e.code;}
  return handle;
 }
 async function appendMessage(h,message,{conversationId,taskId=null,origin=h.origin}={}) {
  if(!await guard(h))return null;
  if(!['user','assistant','notice'].includes(message.role)||!message.content)return null;
  const source=origin||baseOrigin(h,conversationId),messageId=origin&&message.role==='user'&&source.messageId?source.messageId:message.id;
  const eventId=uuid([h.deviceId,source.platform,source.bindingId,source.chatId,messageId,message.role]);
  // Keep large originals in the existing conversation; split facts into bounded immutable records.
  const text=String(message.content),parts=[];let part='',size=0;
  for(const char of text){const length=Buffer.byteLength(JSON.stringify(char))-2;if(size+length>12000){parts.push(part);part='';size=0;}part+=char;size+=length;}if(part)parts.push(part);
  for(let i=0;i<parts.length;i++){
   if(h.unboundOrigin){
    const draftSource={...h.unboundOrigin,messageId:String(messageId)},id=uuid([h.deviceId,draftSource.platform,draftSource.bindingId,draftSource.chatId,messageId,message.role,i]);
    const draft=record(path.join(h.root,'inbox'),id,redactMemory({source:draftSource,deviceId:h.deviceId,conversationId,taskId,epoch:h.epoch,part:i,message:{id:message.id,role:message.role,content:parts[i],at:Number(message.at)||Date.now(),...(message.kind==='task-fact'?{kind:'task-fact',resultRef:message.resultRef}:{})}},[...secrets,h.identity?.token].filter(Boolean)));
    if(!h.sharedDisabled&&!fs.existsSync(path.join(h.root,'done',id+'.json')))await commitDraft(h,id,draft,{...source,messageId:String(messageId)});
   } else await h.store.append({schemaVersion:1,eventId:i?uuid([eventId,i]):eventId,spaceId:h.space.spaceId,
    originDeviceId:h.deviceId,origin:{...source,messageId:String(messageId)},conversationId,taskId,kind:message.kind==='task-fact'?'task-fact':'message',
    payload:message.kind==='task-fact'?{text:parts[i],state:'waiting',resultRef:message.resultRef}:{role:message.role,text:parts[i]},createdAt:Number(message.at)||Date.now(),supersedes:null,memoryEpoch:h.epoch});
  }
  return eventId;
 }
 async function flush(handle,{timeoutMs=5000}={}) {
  if(!await guard(handle))return {state:'waiting-account',errorCode:'MEMORY_ACCOUNT_CHANGED'};
  if(handle.sharedDisabled)return {state:'offline-pending',errorCode:handle.errorCode};
  if(handle.store.status().memoryEpoch!==handle.epoch)return {state:'conflict',errorCode:'MEMORY_EPOCH_CHANGED'};
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.max(1,Math.min(5000,timeoutMs)));
  try{return await handle.sync.syncOnce({signal:controller.signal});}finally{clearTimeout(timer);}
 }
 return {
  prepare,flush,
  isCurrent:guard,
  isCurrentKnown(handle){return !closed&&handle.store.status().memoryEpoch===handle.epoch&&(!account.isCurrentKnown||account.isCurrentKnown(handle.identity));},
  async migrate(handle,snapshot,identity){if(handle.sharedDisabled||!await guard(handle))return {imported:0,reasonCode:'UNKNOWN_SOURCE'};return migrateVerifiedSession({snapshot,space:handle.space,store:handle.store,sourceProof:{identity,home,deviceId:handle.deviceId,accountId:handle.identity?.accountId??null,tenantId:handle.identity?.tenantId??null,server:handle.identity?.server,origin:handle.origin}});},
  async retrieve(handle,{text='',taskId=null,limit=8,maxBytes=12288}={}) {
   if(handle.sharedDisabled||!await guard(handle))return [];
   let rows=await handle.store.query({text,taskId,limit,maxBytes});
   if(!rows.length&&/继续|刚才|之前|进展|continue|resume|earlier/i.test(text))rows=await handle.store.query({text:'',taskId,limit,maxBytes});
   return rows;
  },
  appendMessage,
  async publishTurn(handle,{messages,conversationId,taskId=null,origin=handle.origin}={}) {
   for(const message of messages){
    if(message.role==='tool'&&typeof message.content==='string'&&message.id){
     const name=/^[a-z_]{1,80}$/.test(message.name||'')?message.name:'tool';
     const result=crypto.createHash('sha256').update(message.content).digest('hex');
     await appendMessage(handle,{id:message.id,role:'notice',kind:'task-fact',resultRef:message.id,content:`工具 ${name} 已返回记录；结果 sha256=${result}。此记录不证明整个任务完成。`,at:message.at},{conversationId,taskId:taskId||conversationId,origin});
    }else await appendMessage(handle,message,{conversationId,taskId,origin});
   }
   return flush(handle);
  },
  async query(options={}){const h=await prepare();return h.store.query(options);},
  async syncOnce(options){const h=await prepare({sync:false}),result=await h.sync.syncOnce(options),drafts=pendingDrafts(h).filter(({value})=>value.epoch>=h.store.status().memoryEpoch).length;return {...result,pendingDrafts:drafts,...(drafts?{state:'offline-pending'}:{})};},
  async status(){const h=await refresh(),drafts=pendingDrafts(h).filter(({value})=>value.epoch>=h.store.status().memoryEpoch).length;return {...h.sync.status(),pendingDrafts:drafts,...(drafts?{state:'offline-pending'}:{})};},
  async addNote(text,id=crypto.randomUUID()) {
   const h=await prepare({sync:false});await h.store.append({schemaVersion:1,eventId:id,spaceId:h.space.spaceId,originDeviceId:h.deviceId,
    origin:baseOrigin(h,'memory-notes'),conversationId:'memory-notes',taskId:null,kind:'note',payload:{noteId:id,text},createdAt:Date.now(),supersedes:null,memoryEpoch:h.epoch});return id;
  },
  async removeNote(noteId) {
   const h=await prepare({sync:false});await h.store.append({schemaVersion:1,eventId:crypto.randomUUID(),spaceId:h.space.spaceId,originDeviceId:h.deviceId,
    origin:baseOrigin(h,'memory-notes'),conversationId:'memory-notes',taskId:null,kind:'tombstone',payload:{eventIds:[],noteIds:[noteId]},createdAt:Date.now(),supersedes:null,memoryEpoch:h.epoch});
  },
  async forget() {
   const h=await prepare();await h.store.append({schemaVersion:1,eventId:crypto.randomUUID(),spaceId:h.space.spaceId,originDeviceId:h.deviceId,
    origin:baseOrigin(h,'memory-forget'),conversationId:'memory-forget',taskId:null,kind:'tombstone',payload:{scope:'space',eventIds:[],expectedEpoch:h.epoch},createdAt:Date.now(),supersedes:null,memoryEpoch:h.epoch});
   return {scope:'space',...h.store.status()};
  },
  close(){closed=true;current?.sync.stop();account.dispose?.();},
 };
}
