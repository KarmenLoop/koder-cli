import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawn,execFile } from 'node:child_process';
import { accepted, agreementSha256 } from './eula.mjs';
import {promisify} from 'node:util';
import { KoderError } from './errors.mjs';

export const UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/KarmenLoop/koder-cli/main/updates/koder-cli-latest.json';
const RELEASE_BASE = 'https://github.com/KarmenLoop/koder-cli/releases/download/cli-';
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const validHash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const fail = key => new KoderError(key, {}, 1);

function versionParts(value) {
  if (typeof value !== 'string' || value.length > 100) throw fail('update.badManifest');
  const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(value);
  if (!match) throw fail('update.badManifest');
  const pre = match[4]?.split('.') || [];
  if (pre.some(x => /^0\d+$/.test(x))) throw fail('update.badManifest');
  return { core: match.slice(1, 4).map(BigInt), pre };
}

export function compareVersions(a, b) {
  a = versionParts(a); b = versionParts(b);
  for (let i = 0; i < 3; i++) if (a.core[i] !== b.core[i]) return a.core[i] > b.core[i] ? 1 : -1;
  if (!a.pre.length || !b.pre.length) return a.pre.length === b.pre.length ? 0 : a.pre.length ? -1 : 1;
  for (let i = 0; i < Math.max(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === y) continue;
    if (x === undefined || y === undefined) return x === undefined ? -1 : 1;
    const nx = /^\d+$/.test(x), ny = /^\d+$/.test(y);
    if (nx && ny) return BigInt(x) > BigInt(y) ? 1 : -1;
    if (nx !== ny) return nx ? -1 : 1;
    return x > y ? 1 : -1;
  }
  return 0;
}

function officialBase(base) {
  if (!base) return true;
  return base === 'https://karmenloop.com/install' ||
    base === UPDATE_MANIFEST_URL.slice(0, UPDATE_MANIFEST_URL.lastIndexOf('/')) ||
    /^https:\/\/github\.com\/KarmenLoop\/koder-cli\/releases\/download\/cli-[0-9A-Za-z.-]+$/.test(base);
}

async function download(url, fetchImpl, limit) {
  for (let attempt = 0; attempt < 2; attempt++) {
    let reader;
    try {
      const response = await fetchImpl(url, { signal: AbortSignal.timeout(15_000), headers: { accept: 'application/octet-stream', 'user-agent': 'Koder-CLI-Updater' } });
      if (!response.ok) {
        await response.body?.cancel();
        if (attempt === 0 && (response.status === 429 || response.status >= 500)) continue;
        throw fail('update.networkFailed');
      }
      if (Number(response.headers.get('content-length')) > limit) {
        await response.body?.cancel();
        throw fail('update.badManifest');
      }
      reader = response.body?.getReader();
      if (!reader) throw fail('update.networkFailed');
      const chunks = []; let size = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > limit) throw fail('update.badManifest');
        chunks.push(Buffer.from(value));
      }
      return Buffer.concat(chunks);
    } catch (error) {
      if (error instanceof KoderError) throw error;
      if (attempt === 1) throw fail('update.networkFailed');
    } finally {
      await reader?.cancel().catch(() => {});
    }
  }
}

function validateManifest(manifest) {
  versionParts(manifest?.version);
  if (manifest.file !== `koder-cli-${manifest.version}.tgz` || !validHash(manifest.sha256) ||
      !Number.isSafeInteger(manifest.size) || manifest.size < 1 || manifest.size > 100_000_000 ||
      typeof manifest.preview !== 'boolean' || Boolean(versionParts(manifest.version).pre.length) !== manifest.preview ||
      typeof manifest.agreement?.id !== 'string' || typeof manifest.agreement.version !== 'string' || !validHash(manifest.agreement.sha256)) throw fail('update.badManifest');
  for (const ext of ['sh', 'ps1']) {
    if (manifest.installers?.[ext]?.file !== `koder-cli.${ext}` || !validHash(manifest.installers[ext].sha256)) throw fail('update.badManifest');
  }
  return manifest;
}


export async function installedVersion(info,platform){
 if(!info?.home||!info.version)return null;
 try{
  versionParts(info.version);
  const root=platform==='win32'?path.join(info.home,'versions',info.version):path.join(info.home,'current');
  const pkg=JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8'));
  return pkg.version===info.version?{home:info.home,version:pkg.version,entry:await fs.realpath(path.join(root,'bin/koder.mjs'))}:null;
 }catch{return null;}
}

async function verifyInstalled(ctx,version,platform){
 let installed;
 try{
  const {installInfo}=await import('./commands/update.mjs');
  installed=await installedVersion(installInfo(ctx.env,platform),platform);
  if(installed?.version!==version)throw new Error('version mismatch');
  const {stdout}=await promisify(execFile)(process.execPath,[installed.entry,'--version'],{env:ctx.env,timeout:10000,maxBuffer:8192,windowsHide:true});
  if(stdout.trim()!==`koder ${version}`&&stdout.trim()!==version)throw new Error('entry version mismatch');
 }catch{throw fail('update.verifyFailed');}
 ctx.stdout.write(`${ctx.t('update.verified',{version})}\n`);
 return installed;
}

export async function updateFromGitHub(ctx, info, platform) {
  const explicit = String(ctx.env.KODER_INSTALL_BASE || '').replace(/\/+$/, '');
  const saved = String(info?.base || '').replace(/\/+$/, '');
  const mirror = explicit || (officialBase(saved) ? '' : saved);
  if (mirror) {
    let url;
    try { url = new URL(mirror); } catch { throw fail('update.badManifest'); }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw fail('update.badManifest');
  }
  const fetchImpl = ctx.io.fetchImpl || globalThis.fetch;
  ctx.stdout.write(`${ctx.t('update.checking')}\n`);
  const raw = await download(mirror ? `${mirror}/koder-cli-latest.json` : UPDATE_MANIFEST_URL, fetchImpl, 64 * 1024);
  let manifest;
  try { manifest = validateManifest(JSON.parse(raw.toString('utf8'))); }
  catch { throw fail('update.badManifest'); }
  const current = (await installedVersion(info,platform))?.version || ctx.version;
  if (compareVersions(manifest.version, current) <= 0) {
    ctx.stdout.write(`${ctx.t('update.current', { version: current })}\n`);
    return 0;
  }
  ctx.stdout.write(`${ctx.t(manifest.preview ? 'update.availablePreview' : 'update.available', { current, version: manifest.version })}\n`);
  if (ctx.opts.check) return 0;
  // Existing agreement consent is reusable only for the same exact text.
  if (manifest.agreement.id !== 'Koder-EULA-1.0' || manifest.agreement.version !== '1.0' || manifest.agreement.sha256 !== agreementSha256()) throw fail('update.agreementChanged');
  const base = mirror || `${RELEASE_BASE}${manifest.version}`;
  const ext = platform === 'win32' ? 'ps1' : 'sh';
  const installer = manifest.installers[ext];
  const bytes = await download(`${base}/${installer.file}`, fetchImpl, 1024 * 1024);
  if (digest(bytes) !== installer.sha256) throw fail('update.badChecksum');
  const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'koder-update-'));
  try {
    const file = path.join(temporary, installer.file);
    await fs.writeFile(file, bytes, { mode: 0o600, flag: 'wx' });
    const env = { ...ctx.env, KODER_INSTALL_BASE: base, KODER_NO_ONBOARD: '1',
      KODER_EXPECTED_VERSION: manifest.version, KODER_EXPECTED_PACKAGE_SHA256: manifest.sha256 };
    if (info?.home) env.KODER_CLI_HOME = info.home;
    if (ctx.env.KODER_EULA_ACCEPT !== '0' && accepted(ctx.env)) env.KODER_EULA_ACCEPT = '1';
    ctx.stdout.write(`${ctx.t('update.running', { url: base })}\n`);
    const child = platform === 'win32'
      ? spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', file], { stdio: 'inherit', env })
      : spawn('bash', [file, '--no-onboard', '--no-modify-path'], { stdio: 'inherit', env });
    const code=await new Promise(resolve => child.once('error', () => resolve(1)).once('close', code => resolve(code ?? 1)));
    if(code===0){
      const installed=await verifyInstalled(ctx,manifest.version,platform);
      const {publishActivation}=await import('./update-lifecycle.mjs');
      const target=await publishActivation(installed);
      ctx.io.restart?.request(target);
    }
    return code;
  } finally {
    await fs.rm(temporary, { recursive: true, force: true });
  }
}
