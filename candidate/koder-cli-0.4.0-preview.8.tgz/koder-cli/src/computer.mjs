import fs from 'node:fs';
import os from 'node:os';
import {cliHome} from './config.mjs';
import {openMemoryCredentials} from './shared-memory/credentials.mjs';
import {importKernel} from './agent.mjs';
import {computerConsent} from './consent-copy.mjs';

export function computerHostIdentity(){const file=fs.realpathSync(process.execPath),s=fs.statSync(file);return {uid:os.userInfo().uid,executable:file,signature:`file:${s.dev}:${s.ino}:${s.size}:${s.mtimeMs}`,signatureType:'file-identity',responsibleApplication:'unverified'};}
export async function openComputerCapabilities(ctx) {
 const {createComputerCapabilities}=await importKernel('fusion/computer-capabilities.mjs',ctx.env);
 const host=ctx.io.computerHost||computerHostIdentity();
 const credentials=openMemoryCredentials({dir:cliHome(ctx.env),namespace:'computer-grants'});
 let storageError=null;
 const consentStore=ctx.io.computerConsentStore||{
  async read(){try{const grant=await credentials.read();storageError=null;return grant;}catch(e){storageError=e.code;return null;}},
  write:grant=>credentials.write(grant),
  async authorizeOwner(request){
   if(ctx.command!=='permissions'||ctx.opts.json||!ctx.stdin.isTTY||!ctx.stdout.isTTY)return false;
   const prompt=ctx.io.prompter;if(!prompt)return false;
   ctx.stderr.write(computerConsent(request,ctx.lang)+'\n');
   return (await prompt.ask(ctx.lang==='en'?'Type GRANT to authorize this computer scope: ':'输入 GRANT 授权此电脑范围: ',{fresh:true}))==='GRANT';
  },
 };
 const probe=ctx.io.computerProbe|| (async(name,{roots})=>{
  if(name==='network')return {state:typeof globalThis.fetch==='function'?'granted':'missing',hostIdentity:host,reasonCode:'NETWORK_RUNTIME_AVAILABLE'};
  if(name==='channel.files')return {state:ctx.io.fileTransportReady?.()===true?'granted':'unknown',hostIdentity:host,reasonCode:'CHANNEL_ADAPTER_CURRENT'};
  if(name.startsWith('files.')){
   if(!roots.length)return {state:'unknown',hostIdentity:host,reasonCode:'ROOT_NOT_SELECTED'};
   try{for(const root of roots)fs.accessSync(root,name==='files.write'?fs.constants.W_OK:fs.constants.R_OK);return {state:'granted',hostIdentity:host,reasonCode:'ROOT_ENTRY_ACCESS_CONFIRMED'};}catch{return {state:'restricted',hostIdentity:host,reasonCode:'OS_FILE_ACCESS_DENIED'};}
  }
  return {state:'unknown',hostIdentity:host,reasonCode:'NATIVE_HOST_NOT_VERIFIED'};
 });
 const capabilities=createComputerCapabilities({hostIdentity:host,systemProbe:probe,consentStore,executionContext:()=>ctx.io.computerExecutionContext||{kind:ctx.command==='gateway'||ctx.command==='connect'?'channel':'local-owner'}});
 return {capabilities,metadata:()=>({hostIdentity:host,storage:ctx.io.computerConsentStore?{mode:'injected-test'}:{...credentials.availability(),errorCode:storageError}})};
}
export function lazyAuthorizedFiles(ctx){
 let files;
 const open=async()=>{if(!files){const runtime=await openComputerCapabilities(ctx),{createAuthorizedFiles}=await importKernel('fusion/authorized-files.mjs',ctx.env);files=createAuthorizedFiles({capabilities:runtime.capabilities});}return files;};
 return Object.fromEntries(['search','read','write','copy','move','materialize'].map(name=>[name,async input=>(await open())[name](input)]));
}
