import {openMemoryAccount} from '../shared-memory/account.mjs';
import {createCoreGatewayOwner} from '../core-host.mjs';
import crypto from "node:crypto";
import path from "node:path";
import fs from "node:fs";
import { importKernel } from "../agent.mjs";
import { KoderError } from "../errors.mjs";
import { createSession } from "../session.mjs";
import { unreachable } from "../turn.mjs";
import { createMemory } from "../memory.mjs";
import { isApproved, loadGateway, platformPolicy, requestPairing,gatewayBindingId } from "./store.mjs";

// Chat platforms carry the same approvals as the terminal: nothing is written
// or run until the same person answers yes in the same chat.
const YES = /^(y|yes|ok|okay|是|是的|允许|同意|确认|好|好的|可以|执行|接受|accept|allow|approve|go)$/i;

export function splitText(text, max = 4000) {
  const value = String(text || "");
  if (value.length <= max) return [value];
  const chunks = [];
  let rest = value;
  while (rest.length > max) {
    let cut = rest.lastIndexOf("\n", max);
    if (cut < max * 0.5) cut = max;
    chunks.push(rest.slice(0, cut));
    rest = rest.slice(cut).replace(/^\n/, "");
  }
  if (rest) chunks.push(rest);
  return chunks;
}

function diffPreview(rows, limit = 30) {
  const changed = rows.filter((row) => row.type === "add" || row.type === "del");
  const lines = changed.slice(0, limit).map((row) => `${row.type === "add" ? "+" : "-"} ${row.text}`);
  if (changed.length > limit) lines.push(`… +${changed.length - limit}`);
  return lines.join("\n");
}

export function createGateway(ctx, { config = loadGateway(ctx.env), log = () => {}, sessionFactory = createSession, onState = () => {} } = {}) {
  const t = (key, vars) => ctx.t(key, vars);
  const account=ctx.io.memoryAccount||openMemoryAccount(ctx),ownerLeases=new Map(),accountManaged=new Set();
  const ingressRevisions=new Map();
  const ownerRequests=new Set();
  const chats = new Map();
  const adapters = new Map();
  const status = {};
  let diff = null;
  let closed = false;
  let inflight = 0;
  const seen = new Set(ctx.io.resume?.gateway?.seen || []);
  const continuations=new Map((ctx.io.resume?.gateway?.sessions||[]).map(row=>[row.key,row]));
  const gatewayOwner=ctx.io.gatewayOwner||createCoreGatewayOwner(ctx,account,(platform,error)=>{
    void detach(new Set([platform]),'waiting-owner-lease',error.code||'HOST_LEASE_STALE').catch(()=>{});
  });

  function ownerFor(platform){
    const revision=ingressRevisions.get(platform)||0;
    const pending=[...ownerRequests].find(row=>row.platform===platform&&row.revision===revision);if(pending)return pending.promise;
    const request={platform,revision,promise:null},bindingId=gatewayBindingId(config.platforms[platform]);
    const current=()=>!closed&&(ingressRevisions.get(platform)||0)===revision&&gatewayBindingId(config.platforms[platform])===bindingId;
    const requireBinding=()=>{if(!current())throw Object.assign(new Error('GATEWAY_BINDING_CHANGED'),{code:'GATEWAY_BINDING_CHANGED'});};
    request.promise=(async()=>{
    requireBinding();
    const identity=await account.currentIdentity();
    requireBinding();
    if(!identity){if(accountManaged.has(platform))throw Object.assign(new Error('GATEWAY_ACCOUNT_CHANGED'),{code:'GATEWAY_ACCOUNT_CHANGED'});return null;}
    accountManaged.add(platform);const key=JSON.stringify([identity.server,identity.tenantId,identity.accountId,identity.deviceId,identity.generation,identity.space?.spaceId,bindingId]);
    let active=ownerLeases.get(platform);
    if(active&&active.key!==key){ownerLeases.delete(platform);await active.handle.release();active=null;}
    if(!active){
      // This port must be supplied by the original Core owner. Memory is never its authority.
      if(typeof gatewayOwner?.acquireGateway!=='function')throw Object.assign(new Error('GATEWAY_OWNER_LEASE_UNAVAILABLE'),{code:'GATEWAY_OWNER_LEASE_UNAVAILABLE'});
      requireBinding();
      const handle=await gatewayOwner.acquireGateway({platform,bindingId,accountId:identity.accountId,tenantId:identity.tenantId,deviceId:identity.deviceId,generation:identity.generation},{current});
      if(!handle||typeof handle.requireCurrent!=='function'||typeof handle.release!=='function')throw Object.assign(new Error('GATEWAY_OWNER_LEASE_UNAVAILABLE'),{code:'GATEWAY_OWNER_LEASE_UNAVAILABLE'});
      if(!current()){await handle.release();requireBinding();}
      active={key,handle};ownerLeases.set(platform,active);
    }
    await active.handle.requireCurrent();requireBinding();return active.handle;
    })().finally(()=>ownerRequests.delete(request));
    ownerRequests.add(request);return request.promise;
  }
  function admit(message) {
    if (!config.platforms[message.platform] || config.platforms[message.platform].enabled === false) return { ok: false };
    const policy = platformPolicy(config.platforms[message.platform]);
    if (message.isGroup) {
      if (policy.groupPolicy === "disabled" || !message.mentioned) return { ok: false };
      if (policy.groupPolicy === "allowlist" && !policy.groupAllowFrom.includes(message.chatId)) return { ok: false };
      return { ok: true };
    }
    if (policy.dmPolicy === "disabled") return { ok: false };
    if (policy.dmPolicy === "open") return { ok: true };
    if (policy.allowFrom.includes(message.userId) || isApproved(message.platform, message.userId, ctx.env)) return { ok: true };
    if (policy.dmPolicy === "pairing") {
      const entry = requestPairing({ platform: message.platform, userId: message.userId, userName: message.userName }, ctx.env);
      log(`pairing ${message.platform} ${message.userId} ${entry.code}`);
      return { ok: false, reply: t("gw.pairing", { code: entry.code }) };
    }
    return { ok: false, reply: t("gw.notAllowed") };
  }

  function continuationKey(message){return JSON.stringify([sessionScope(message),ownerLeases.get(message.platform)?.key||null,path.resolve(config.workspace||ctx.workspace()),ctx.opts.engine||ctx.config.engine||'koder',ctx.opts.provider||null]);}
  function chatFor(message) {
    const key = `${message.platform}:${message.chatId}`;
    let entry = chats.get(key);
    if (!entry) {
      entry = { key, session: null, busy: false, queue: Promise.resolve(), pending: null, moa: config.moa, generation: 0, resetting: false };
      const saved=continuations.get(continuationKey(message));
      if(saved)entry.moa=saved.moa;
      entry.continuationKey=continuationKey(message);
      chats.set(key, entry);
    }
    return entry;
  }

  async function deliver(message, text) {
    const adapter = adapters.get(message.platform);
    const chunks = splitText(text, adapter?.maxLength || 4000).filter((chunk) => chunk.trim());
    if (message.replyChunks) return message.replyChunks(chunks);
    for (const chunk of chunks) await message.reply(chunk);
  }

  async function askInChat(entry, message, pause) {
    if (entry.retired) return { cancel: true };
    try{await ownerFor(message.platform);}catch{return {cancel:true};}
    if (pause.kind === "secret") {
      await message.reply(t("turn.secret", { service: pause.service }));
      return { cancel: true };
    }
    let prompt;
    if (pause.kind === "change") {
      diff ??= (await importKernel("harness/diff.mjs", ctx.env)).unifiedDiff;
      prompt = t("gw.askChange", { path: pause.path, diff: diffPreview(diff(pause.before, pause.after)) });
    } else if (pause.kind === "approval") {
      prompt = t("gw.askCommand", { command: pause.command });
    } else {
      prompt = `${t("turn.choice", { question: pause.question })}\n${pause.options.map((option, i) => `${i + 1}. ${option}`).join("\n")}\n${t("gw.askChoice")}`;
    }
    // Register before sending: the peer can answer before the transport ACK.
    const waiting = new Promise((resolve) => {
      const timer = setTimeout(() => {
        entry.pending = null;
        resolve(null);
      }, config.approvalTimeoutSec * 1000);
      entry.pending = {
        userId: message.userId,
        resolve(text, responder) {
          clearTimeout(timer);
          entry.pending = null;
          if (responder) {
            message.reply = responder.reply;
            message.replyChunks = responder.replyChunks;
            message.deliveryReplyContext={messageId:responder.messageId,actorId:responder.userId};
          }
          resolve(text);
        },
      };
    });
    try { await deliver(message, prompt); }
    catch (error) { entry.pending?.resolve(null); throw error; }
    const answer = await waiting;
    try{await ownerFor(message.platform);}catch{return {cancel:true};}
    if (answer == null) {
      if (entry.retired || entry.resetting) return { cancel: true };
      await message.reply(t("gw.timeout"));
      return { cancel: true };
    }
    if (pause.kind === "choice") {
      const index = Number(answer.trim()) - 1;
      return Number.isInteger(index) && index >= 0 && index < pause.options.length ? { index } : { cancel: true };
    }
    return { accept: YES.test(answer.trim()) };
  }

  function sessionScope(message) {
    const credentials = config.platforms[message.platform] || {};
    const binding = gatewayBindingId(credentials);
    return ["gateway", message.platform, binding, message.chatId, message.userId];
  }

  async function sessionFor(entry, message) {
    const key=continuationKey(message);
    if (entry.session && entry.sessionOwner === message.userId && entry.continuationKey===key) return entry.session;
    await entry.session?.close?.();
    const saved=continuations.get(key);continuations.delete(key);
    if(saved)entry.moa=saved.moa;
    entry.continuationKey=key;
    if (config.workspace) fs.mkdirSync(config.workspace, { recursive: true });
    entry.sessionOwner = message.userId;
    entry.session = null;
    const sessionCtx=Object.create(ctx);sessionCtx.io={...ctx.io,resume:saved?{conversation:saved.conversation}:undefined,assertGatewayOwner:()=>ownerFor(message.platform),computerExecutionContext:{kind:'channel',platform:message.platform,bindingId:gatewayBindingId(config.platforms[message.platform]),chatId:message.chatId,actorId:message.userId},fileTransportReady:()=>!closed&&!entry.retired&&adapters.get(message.platform)?.capabilities?.().files?.send===true};
    entry.session = await sessionFactory(sessionCtx, { workspace: config.workspace, interaction: config.interaction, quiet: true, moa: entry.moa, memoryScope: sessionScope(message), memoryName: "default" });
    entry.sessionOwner = message.userId;
    return entry.session;
  }

  async function runTurn(entry, message, text, generation) {
    if (closed || entry.retired || generation !== entry.generation) return;
    entry.busy = true;
    try {
      await ownerFor(message.platform);
      await sessionFor(entry, message);
      // Join any ingress ownership check begun while session initialization was
      // pending. An admitted reset publishes its barrier before this turn runs.
      await ownerFor(message.platform);
      if (entry.retired || entry.resetting || generation !== entry.generation) { await entry.session.cancel(); return; }
      const scope=sessionScope(message);
      const outcome = await entry.session.turn(text, { silent: true, inbound:{platform:message.platform,bindingId:scope[2],chatId:message.chatId,threadId:entry.session.thread?.id||entry.key,actorId:message.userId,messageId:String(message.messageId||''),text,replyTo:typeof (message.replyToMessageId||message.replyTo)==='string'?(message.replyToMessageId||message.replyTo):null}, memoryOrigin:{platform:message.platform,bindingId:scope[2],chatId:message.chatId,actorId:message.userId,messageId:String(message.messageId||crypto.randomUUID()),visibility:message.isGroup?'group-members':'account'},fileDelivery:{adapter:adapters.get(message.platform),isCurrent:()=>!closed&&!entry.retired&&!entry.resetting&&generation===entry.generation,requestContext:()=>({platform:message.platform,bindingId:scope[2],chatId:message.chatId,actorId:message.deliveryReplyContext?.actorId||message.userId,messageId:message.deliveryReplyContext?.messageId||message.messageId,isGroup:Boolean(message.isGroup)})}, decide: (pause) => askInChat(entry, message, pause) });
      if (entry.retired || entry.resetting || generation !== entry.generation) return;
      await ownerFor(message.platform);
      let reply = outcome.text;
      if(outcome.replyConsumed)return;
      if(outcome.attachments?.some(r=>r.status==='unknown'))reply=ctx.lang==='en'?'The attachment result is unconfirmed. Automatic resend is stopped; check the receiving chat first.':'附件发送结果尚未确认，已停止自动重发，请先核对接收端。';
      if (unreachable(outcome.thread)) reply = t("model.missing");
      else if (outcome.cancelled) reply = t(outcome.reason || "turn.cancelled");
      await deliver(message, reply || t("gw.done"));
    } catch (error) {
      const detail = error instanceof KoderError ? t(error.key, error.vars) : error?.message || String(error);
      log(`turn ${entry.key}: ${detail}`);
      await message.reply(t("gw.error", { message: detail })).catch(() => {});
    } finally {
      entry.busy = false;
    }
  }

  async function acceptMessage(message) {
    if (closed || !message.platform || !message.chatId || !message.userId) return;
    const ingress=ingressRevisions.get(message.platform)||0;
    try{await ownerFor(message.platform);}catch(error){hub.status(message.platform,'waiting-owner-lease',error.code||'GATEWAY_OWNER_LEASE_UNAVAILABLE');if(adapters.has(message.platform))void Promise.resolve().then(()=>detach(new Set([message.platform]))).catch(()=>{});return {accepted:false,reasonCode:error.code};}
    if(closed||(ingressRevisions.get(message.platform)||0)!==ingress)return;
    const text = String(message.text || "").trim();
    if (!text) return;
    status[message.platform] = { ...(status[message.platform] || {}), lastEventAt: Date.now() };
    const verdict = admit(message);
    if (!verdict.ok) {
      if (verdict.reply) await message.reply(verdict.reply).catch(() => {});
      return;
    }
    const messageKey = message.messageId ? JSON.stringify([message.platform,gatewayBindingId(config.platforms[message.platform]),message.chatId,message.userId,String(message.messageId)]) : null;
    if (messageKey && seen.has(messageKey)) return;
    if (messageKey) { seen.add(messageKey); if(seen.size>4096)seen.delete(seen.values().next().value); }
    const entry = chatFor(message);
    const wantsNew = /^\/(new|reset)$|^新会话$/i.test(text);
    if (entry.pending && (!wantsNew || entry.pending.userId !== message.userId)) {
      if (entry.pending.userId === message.userId) entry.pending.resolve(text, message);
      return;
    }
    if (wantsNew) {
      continuations.delete(continuationKey(message));
      if (entry.busy && entry.sessionOwner !== message.userId) return;
      entry.generation += 1;
      entry.resetting = true;
      entry.pending?.resolve(null, message);
      const activeSession = entry.session;
      const cancellation = entry.busy ? Promise.resolve().then(() => activeSession?.cancel()).then(() => null, error => error) : Promise.resolve(null);
      // Publish the reset barrier before yielding to cancellation: later input
      // must never run against the old history while cancel is settling.
      entry.queue = entry.queue.then(async () => {
        if (entry.retired) return;
        try {
          const error = await cancellation;
          if (error) throw error;
          if (entry.session && entry.sessionOwner === message.userId) await entry.session.reset();
          else if (ctx.opts.memory !== false) {
            if (config.workspace) fs.mkdirSync(config.workspace, { recursive: true });
            const memory = createMemory({ workspace: config.workspace || ctx.workspace(), env: ctx.env, scope: sessionScope(message) });
            memory.transact(data => memory.reset(data));
          }
          entry.session = null;
          await message.reply(t("gw.reset"));
        } catch (error) { await message.reply(t("gw.error", { message: error.message })).catch(() => {}); }
        finally { entry.resetting = false; }
      });
      return entry.queue;
    }
    if (/^\/(stop|cancel)$|^停止$/i.test(text)) {
      if (entry.busy) await entry.session?.cancel();
      await message.reply(t("gw.stopped"));
      return;
    }
    if (/^\/moa$/i.test(text)) {
      continuations.delete(continuationKey(message));
      entry.moa = !entry.moa;
      entry.session = null;
      await message.reply(t(entry.moa ? "gw.moaOn" : "gw.moaOff"));
      return;
    }
    if (/^\/(help|start)$|^帮助$/i.test(text)) {
      await message.reply(t("gw.help"));
      return;
    }
    if (entry.busy) await message.reply(t("gw.queued")).catch(() => {});
    const generation = entry.generation;
    entry.queue = entry.queue.then(() => runTurn(entry, message, text, generation));
    return entry.queue;
  }

  async function receive(message) {
    if(closed)return {accepted:false,reasonCode:'GATEWAY_RESTARTING'};
    inflight++;
    try{return await acceptMessage(message);}finally{inflight--;}
  }

  const hub = {
    receive,
    status(platform, state, detail = "") {
      status[platform] = { ...(status[platform] || {}), state, detail, at: Date.now() };
      onState({ ...status });
    },
  };

  function detach(ids,state='disconnected',detail='') {
    for(const id of ids)ingressRevisions.set(id,(ingressRevisions.get(id)||0)+1);
    const previous = [], retired = [], owners=[];
    for (const id of ids) {
      const owner=ownerLeases.get(id);if(owner){ownerLeases.delete(id);owners.push(owner.handle);}
      const adapter = adapters.get(id);
      if (adapter) previous.push(adapter);
      adapters.delete(id);
    }
    // Revoke every chat before the first asynchronous cancellation.
    for (const [key, entry] of chats) {
      if (!ids.has(key.split(":")[0])) continue;
      entry.retired = true;
      entry.pending?.resolve(null);
      chats.delete(key);
      retired.push(entry);
    }
    for (const id of ids) hub.status(id,state,detail);
    const pending=[...ownerRequests].filter(row=>ids.has(row.platform));
    return Promise.all([...retired.map(async (entry) => entry.busy ? entry.session?.cancel() : entry.session?.close?.()), ...previous.map(async (adapter) => adapter.stop?.()),...owners.map(handle=>handle.release()),...pending.map(row=>row.promise.catch(()=>{}))]);
  }

  return {
    receive,
    hub,
    status,
    chats,
    quiesceIfIdle() { if(closed || inflight || ownerRequests.size) return false; closed=true; return true; },
    exportRestartState() {
      if(inflight||ownerRequests.size)throw new Error('UPDATE_TASK_STILL_RUNNING');
      const sessions=new Map(continuations);
      for(const entry of chats.values())if(!entry.retired&&entry.continuationKey){
        const conversation=entry.session?(ctx.opts.memory===false||entry.session.engine?entry.session.exportConversation?.()||null:null):sessions.get(entry.continuationKey)?.conversation||null;
        sessions.set(entry.continuationKey,{key:entry.continuationKey,moa:entry.moa,conversation});
      }
      return {seen:[...seen],sessions:[...sessions.values()]};
    },
    async start(list) {
      await Promise.all(list.map(async (adapter) => {
        if (closed) return;
        const revision=ingressRevisions.get(adapter.id)||0;
        const current=()=>!closed&&(ingressRevisions.get(adapter.id)||0)===revision;
        try{await ownerFor(adapter.id);}catch(error){if(current())hub.status(adapter.id,'waiting-owner-lease',error.code||'GATEWAY_OWNER_LEASE_UNAVAILABLE');return;}
        if(!current())return;
        adapters.set(adapter.id, adapter);
        hub.status(adapter.id, "connecting");
        try {
          await adapter.start({ receive: (message) => adapters.get(adapter.id) === adapter ? receive(message) : undefined, status: (state, detail) => { if (adapters.get(adapter.id) === adapter) hub.status(adapter.id, state, detail); }, log: (line) => log(`${adapter.id}: ${line}`) });
          if (closed || adapters.get(adapter.id) !== adapter) await adapter.stop?.();
        } catch (error) {
          if (!closed && adapters.get(adapter.id) === adapter) hub.status(adapter.id, "error", error?.message || String(error));
          log(`${adapter.id}: ${error?.message || error}`);
        }
      }));
    },
    async remove(id) {
      await detach(new Set(Array.isArray(id) ? id : [id]));
    },
    async stop() {
      closed = true;
      const ids = new Set([...adapters.keys(),...ownerLeases.keys(),...[...ownerRequests].map(row=>row.platform), ...Array.from(chats.keys(), (key) => key.split(":")[0])]);
      await detach(ids);
      await Promise.allSettled([...ownerLeases.values()].map(owner=>owner.handle.release()));ownerLeases.clear();
    },
  };
}
