import {importKernel} from '../agent.mjs';
const fail=code=>{throw Object.assign(new Error(code),{code});};
const transitions={prepared:['uploading'],uploading:['uploading','uploaded'],uploaded:['uploaded','sending'],sending:['unknown','acknowledged','uploaded'],unknown:['acknowledged'],acknowledged:[]};
const sameDestination=(a,b)=>a.platform===b.platform&&a.bindingId===b.bindingId&&a.chatId===b.chatId;
export async function openFileReceipts(ctx,{thread,save,assertCurrent}={}){
 if(!thread?.id||typeof save!=='function'||typeof assertCurrent!=='function')fail('FILE_RECEIPTS_UNAVAILABLE');
 const {effectStart,effectFinish,effectRecover}=await importKernel('agent/kernel/ledger.mjs',ctx.env);
 const rows=structuredClone(thread.deliveryEffects||{}),tails=new Map();thread.deliveryEffects=rows;
 const check=()=>{if(assertCurrent()!==true||thread.deliveryEffects!==rows)fail('FILE_RECEIPT_SCOPE_CHANGED');};
 const valid=(id,value)=>value?.operationId===id&&value.context?.taskId===thread.id&&Number.isSafeInteger(value.revision)&&value.revision>0&&Object.hasOwn(transitions,value.phase);
 for(const [id,value] of Object.entries(rows))if(!valid(id,value))fail('FILE_RECEIPTS_DAMAGED');
 if(Object.keys(rows).length>128)fail('FILE_RECEIPTS_DAMAGED');
 let recovered=false;
 for(const [id,value] of Object.entries(rows))if(value.phase==='sending'){
  const projection={seq:thread.seq||0,effect:value.effect};effectRecover(projection);
  rows[id]={...value,phase:'unknown',revision:value.revision+1,effect:projection.effect};thread.seq=projection.seq;recovered=true;
 }
 if(recovered){check();await save();check();}
 return {
  async get(id){check();return Object.hasOwn(rows,id)?structuredClone(rows[id]):null;},
  async put(id,value,{expectedRevision}={}){
   check();const previous=Object.hasOwn(rows,id)?rows[id]:null;
   if(!valid(id,value)||(previous?.revision||0)!==expectedRevision||value.revision!==expectedRevision+1)fail('FILE_RECEIPT_CONFLICT');
   if(previous?!transitions[previous.phase].includes(value.phase):value.phase!=='prepared')fail('FILE_RECEIPT_TRANSITION_INVALID');
   if(!previous){
    if(Object.keys(rows).length>=128)fail('FILE_RECEIPT_CAPACITY');
    if(Object.values(rows).some(r=>['unknown','sending'].includes(r.phase)&&r.sha256===value.sha256&&r.bytes===value.bytes&&sameDestination(r.context,value.context)))fail('FILE_PRIOR_RESULT_UNKNOWN');
   }
   const projection={seq:thread.seq||0,cwd:thread.cwd||ctx.cwd||'',effect:previous?.effect};
   if(!previous)effectStart(projection,{id,path:value.path,cwd:projection.cwd});
   if(value.phase==='unknown')effectFinish(projection,{ok:false});
   if(value.phase==='acknowledged')effectFinish(projection,{ok:true});
   const next={...structuredClone(value),effect:{...projection.effect,kind:'channel-file',destination:value.context.chatId}};
   Object.defineProperty(rows,id,{value:next,writable:true,configurable:true,enumerable:true});thread.seq=projection.seq;
   await save();check();
  },
  exclusive(id,work){check();const job=(tails.get(id)||Promise.resolve()).catch(()=>{}).then(()=>{check();return work();});tails.set(id,job);return job;},
 };
}
