async function request(fetchImpl, url, { method = "GET", headers = {}, body, signal, timeoutMs = 20_000, parseJson=JSON.parse } = {}, binaryUpload=false) {
  const controller = new AbortController();
  const failure=code=>Object.assign(new Error(code),{code,name:code==='ABORT_ERR'?'AbortError':'Error'});
  const timer = setTimeout(() => controller.abort(failure('GATEWAY_TIMEOUT')), timeoutMs);
  const abort = () => controller.abort(failure('ABORT_ERR'));
  signal?.addEventListener("abort", abort, { once: true });
  if (signal?.aborted) controller.abort();
  const bounded=value=>new Promise((resolve,reject)=>{
    const cancel=()=>{controller.signal.removeEventListener('abort',cancel);reject(controller.signal.reason||failure('ABORT_ERR'));};
    if(controller.signal.aborted){Promise.resolve(value).catch(()=>{});cancel();return;}
    controller.signal.addEventListener('abort',cancel,{once:true});Promise.resolve(value).then(v=>{controller.signal.removeEventListener('abort',cancel);resolve(v);},e=>{controller.signal.removeEventListener('abort',cancel);reject(e);});
  });
  try {
    const multipart=typeof FormData!=='undefined'&&body instanceof FormData;
    const pending=Promise.resolve().then(()=>{if(controller.signal.aborted)throw controller.signal.reason;return fetchImpl(url, {
      method,
      headers: { ...(body !== undefined&&!multipart&&!binaryUpload ? { "content-type": "application/json; charset=utf-8" } : {}), ...headers },
      body: body === undefined ? undefined : multipart||binaryUpload||typeof body === "string" ? body : JSON.stringify(body),
      signal: controller.signal,
      redirect:'error',
    });});
    pending.then(response=>{if(controller.signal.aborted)response.body?.cancel().catch(()=>{});},()=>{});
    const response = await bounded(pending);
    if(binaryUpload){response.body?.cancel().catch(()=>{});if(!response.ok)throw Object.assign(failure('GATEWAY_UPLOAD_HTTP_ERROR'),{status:response.status});return {status:response.status,headers:response.headers};}
    const chunks=[];let size=0;
    if(response.body){const reader=response.body.getReader();try{while(true){const next=await bounded(reader.read());if(next.done)break;size+=next.value.byteLength;if(size>8*1024*1024)throw failure('GATEWAY_RESPONSE_TOO_LARGE');chunks.push(Buffer.from(next.value));}}finally{reader.cancel().catch(()=>{});}}
    const text = Buffer.concat(chunks).toString('utf8');
    let json = null;
    try {
      json = text ? parseJson(text) : {};
    } catch {
      json = null;
    }
    if (!response.ok) {
      const retry=response.headers.get('retry-after');
      const retryAfterMs=retry===null?0:/^\d+(?:\.\d+)?$/.test(retry)?Number(retry)*1000:Math.max(0,Date.parse(retry)-Date.now())||0;
      throw Object.assign(new Error(`HTTP ${response.status}`), { code:'GATEWAY_HTTP_ERROR',status: response.status, json,retryAfterMs });
    }
    if (json === null) throw failure('GATEWAY_INVALID_RESPONSE');
    return json;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", abort);
  }
}

export function transientConnectionError(error){
  if([408,429,500,502,503,504].includes(error?.status))return true;
  if(['GATEWAY_TIMEOUT','GATEWAY_INVALID_RESPONSE','ECONNRESET','ECONNREFUSED','ETIMEDOUT','EAI_AGAIN','ENETUNREACH','EHOSTUNREACH','UND_ERR_CONNECT_TIMEOUT','UND_ERR_SOCKET'].includes(error?.code||error?.cause?.code))return true;
  return error?.name==='TypeError'&&/fetch failed|network/i.test(error.message||'')&&!/CERT|TLS|SSL/.test(error.cause?.code||'');
}

export async function requestJson(fetchImpl,url,options={}){
  // Opt in only at authentication/discovery/read calls. Message sends, uploads
  // and arbitrary POST requests are never automatically replayed.
  if(!options.retry)return request(fetchImpl,url,options);
  const deadline=Date.now()+(options.timeoutMs??20000),delays=(options.retryDelays||[350,1000]).slice(0,2);
  for(let attempt=0;;attempt++){
    options.signal?.throwIfAborted();
    const remaining=deadline-Date.now();if(remaining<=0)throw Object.assign(new Error('GATEWAY_TIMEOUT'),{code:'GATEWAY_TIMEOUT'});
    try{return await request(fetchImpl,url,{...options,timeoutMs:Math.min(remaining,options.attemptTimeoutMs??8000)});}
    catch(error){
      options.signal?.throwIfAborted();
      if(attempt>=delays.length||!transientConnectionError(error))throw error;
      const delay=Math.max(delays[attempt],error.retryAfterMs||0);
      if(delay>=deadline-Date.now())throw error;
      await sleep(delay,options.signal);
    }
  }
}
export function uploadBinary(fetchImpl,url,options){return request(fetchImpl,url,options,true);}

export function sleep(ms, signal) {
  return new Promise((resolve) => {
    const done = () => { signal?.removeEventListener("abort", abort); resolve(); };
    const abort = () => {
      clearTimeout(timer);
      done();
    };
    const timer = setTimeout(done, ms);
    signal?.addEventListener("abort", abort, { once: true });
    if (signal?.aborted) abort();
  });
}
