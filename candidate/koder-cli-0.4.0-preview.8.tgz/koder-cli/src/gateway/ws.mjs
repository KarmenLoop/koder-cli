// A single owned connection attempt, including endpoint discovery and handshake.
// Late callbacks cannot publish or send through a replacement connection.
const BACKOFF=[1000,2000,5000,10000,30000,60000];
export function createSocket({url,binary=false,onOpen,onMessage,onClose,onError,log=()=>{},WebSocketImpl=globalThis.WebSocket,backoff=BACKOFF,connectTimeoutMs=15000}){
  let socket=null,stopped=true,attempt=0,timer=null,deadline=null,stable=null,connected=false,generation=0,controller=null;
  const owns=g=>!stopped&&generation===g;
  const report=error=>{log(error.message);onError?.(error);};
  const clear=()=>{clearTimeout(deadline);clearTimeout(stable);};
  function schedule(){
    if(stopped||timer)return;
    const delay=backoff[Math.min(attempt++,backoff.length-1)]??1000;
    timer=setTimeout(()=>{timer=null;connect();},delay);
  }
  function disconnect(g,error){
    if(!owns(g))return;
    generation++;clear();controller?.abort();
    const previous=socket;socket=null;connected=false;
    try{previous?.close();}catch{}
    onClose?.(api);
    if(error)report(error);
    if(error?.retryable===false){stopped=true;return;}
    schedule();
  }
  async function connect(){
    if(stopped)return;
    const g=++generation;controller=new AbortController();const signal=controller.signal;
    deadline=setTimeout(()=>disconnect(g,Object.assign(new Error('WebSocket endpoint/handshake timed out; reconnecting'),{code:'GATEWAY_TIMEOUT'})),connectTimeoutMs);
    try{
      const target=await url({signal});if(!owns(g))return;
      if(!WebSocketImpl)throw Object.assign(new Error('WebSocket unavailable; use Node.js 22 or newer'),{retryable:false});
      const ws=new WebSocketImpl(target);socket=ws;if(binary)ws.binaryType='arraybuffer';
      const view={
        send:data=>owns(g)&&socket===ws?api.send(data):false,
        reconnect:()=>disconnect(g),
        stop(){if(owns(g))api.stop();},
        markReady(){if(owns(g))attempt=0;},
        get connected(){return owns(g)&&socket===ws&&connected;},
      };
      ws.addEventListener('open',()=>{
        if(!owns(g)||socket!==ws)return;
        clearTimeout(deadline);connected=true;stable=setTimeout(()=>{if(owns(g))attempt=0;},30000);stable.unref?.();
        Promise.resolve().then(()=>owns(g)&&onOpen?.(view)).catch(error=>disconnect(g,error));
      });
      ws.addEventListener('message',event=>{
        if(!owns(g)||socket!==ws)return;
        Promise.resolve().then(()=>{
          if(!owns(g))return;
          const data=binary?new Uint8Array(event.data):typeof event.data==='string'?event.data:Buffer.from(event.data).toString('utf8');
          return onMessage?.(data,view);
        }).catch(error=>{if(owns(g))report(error);});
      });
      ws.addEventListener('close',()=>disconnect(g));
      ws.addEventListener('error',()=>disconnect(g,new Error('WebSocket connection failed; reconnecting (check network/proxy if it persists)')));
    }catch(error){
      if([400,401,403,404].includes(error.status))error.retryable=false;
      disconnect(g,error);
    }
  }
  const api={
    start(){if(!stopped)return;stopped=false;connect();},
    send(data){if(socket?.readyState!==1||stopped)return false;try{socket.send(typeof data==='string'||data instanceof Uint8Array?data:JSON.stringify(data));return true;}catch{disconnect(generation,new Error('WebSocket send failed; delivery may be unknown'));return false;}},
    reconnect(){disconnect(generation);},
    markReady(){attempt=0;},
    stop(){stopped=true;generation++;clearTimeout(timer);timer=null;clear();controller?.abort();connected=false;const previous=socket;socket=null;try{previous?.close();}catch{}},
    get connected(){return connected;},
  };
  return api;
}
