import crypto from 'node:crypto';
import path from 'node:path';
const fail=code=>{throw Object.assign(new Error(code),{code});};
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const notSubmitted=new WeakSet();
export function messageNotSubmitted(code){const error=Object.assign(new Error(code),{code});notSubmitted.add(error);return error;}
export const FILE_CAPABILITY={upload:true,send:true,maxBytes:20*1024*1024,mimeTypes:['*/*'],caption:false,limitsSource:'koder-policy'};
export function checkAttachment(file){if(!Buffer.isBuffer(file?.content)||file.content.length!==file.bytes||file.bytes<1||file.bytes>FILE_CAPABILITY.maxBytes)fail('FILE_SIZE_UNSUPPORTED');if(typeof file.name!=='string'||file.name!==path.basename(file.name)||/[\x00-\x1f\x7f]/.test(file.name)||Buffer.byteLength(file.name)>255)fail('FILE_NAME_INVALID');}
const destination=context=>({platform:context.platform,bindingId:context.bindingId,chatId:context.chatId});
const safeReceipt=value=>Object.fromEntries(['platform','chatId','messageId','requestId','bytes','status'].filter(k=>value[k]!==undefined).map(k=>[k,value[k]]));
const publicResult=record=>record.phase==='acknowledged'?{...record.receipt,operationId:record.operationId}:{operationId:record.operationId,platform:record.context.platform,chatId:record.context.chatId,bytes:record.bytes,status:'unknown',errorCode:'FILE_DELIVERY_UNKNOWN'};
export function createFileDelivery({adapters,capabilities,receiptStore,files}={}) {
 if(!['get','put','exclusive'].every(name=>typeof receiptStore?.[name]==='function'))fail('FILE_RECEIPTS_UNAVAILABLE');
 const adapterFor=id=>adapters instanceof Map?adapters.get(id):adapters?.[id];
 const validReceipt=(value,record)=>value&&value.platform===record.context.platform&&value.chatId===record.context.chatId&&value.bytes===record.bytes&&
  (value.status==='accepted'||(value.status==='sent'&&typeof value.messageId==='string'&&value.messageId.length>0));
 async function check(context){if(typeof context?.isCurrent!=='function'||await context.isCurrent()!==true)fail('FILE_REQUEST_CHANGED');await capabilities.authorize({tool:'channel.sendFile',destination:destination(context)});if(await context.isCurrent()!==true)fail('FILE_REQUEST_CHANGED');}
 async function reconcileRecord(record){
  if(record.phase==='acknowledged')return publicResult(record);
  const adapter=adapterFor(record.context.platform);
  await capabilities.authorize({tool:'channel.sendFile',destination:destination(record.context)});
  if(record.phase==='unknown'&&typeof adapter?.reconcileFile==='function'){
   const result=await adapter.reconcileFile({operationId:record.operationId,requestContext:record.context,uploaded:record.uploaded});
   if(validReceipt(result,record)){const next={...record,phase:'acknowledged',receipt:safeReceipt(result),revision:record.revision+1};await receiptStore.put(record.operationId,next,{expectedRevision:record.revision});return publicResult(next);}
  }
  return publicResult(record);
 }
 return {
  async send({requestContext,file,caption='',idempotencyKey,signal}={}){
   await check(requestContext);signal?.throwIfAborted();
   const adapter=adapterFor(requestContext.platform),cap=adapter?.capabilities?.().files;
   if(!cap?.upload||!cap.send||typeof adapter.uploadFile!=='function'||typeof adapter.sendFile!=='function')fail('FILE_CHANNEL_UNSUPPORTED');
   if(requestContext.isGroup&&cap.groups===false)fail('FILE_GROUP_UNSUPPORTED');
   if(typeof file?.path!=='string'||!path.isAbsolute(file.path)||typeof caption!=='string'||caption.length>2000)fail('FILE_INPUT_INVALID');
   if(caption&&cap.caption!==true)fail('FILE_CAPTION_UNSUPPORTED');
   if(file.destination&&hash(file.destination)!==hash(destination(requestContext)))fail('FILE_DESTINATION_CHANGED');
   const material=await files.materialize({path:file.path,maxBytes:cap.maxBytes,signal});
   if(!Buffer.isBuffer(material.content)||material.content.length!==material.bytes||material.bytes<1||material.bytes>cap.maxBytes)fail('FILE_SIZE_UNSUPPORTED');
   const mime=file.mime||'application/octet-stream';if(!cap.mimeTypes?.includes('*/*')&&!cap.mimeTypes?.includes(mime))fail('FILE_TYPE_UNSUPPORTED');
   const name=material.name||path.basename(file.path);if(name!==path.basename(name)||/[\x00-\x1f\x7f]/.test(name)||Buffer.byteLength(name)>255)fail('FILE_NAME_INVALID');
   const context=Object.fromEntries(['platform','bindingId','chatId','taskId','callId'].map(k=>[k,requestContext[k]]));
   if(Object.values(context).some(v=>typeof v!=='string'||!v||v.length>200||/[\x00-\x1f\x7f]/.test(v)))fail('FILE_REQUEST_INVALID');
   const operationId=idempotencyKey||hash([context.taskId,context.callId]);if(typeof operationId!=='string'||!operationId||operationId.length>200||/[\x00-\x1f\x7f]/.test(operationId))fail('FILE_OPERATION_INVALID');
   const intentDigest=hash([context,file.path,name,mime,material.sha256,material.bytes,caption]);
   return receiptStore.exclusive(operationId,async()=>{
    await check(requestContext);let record=await receiptStore.get(operationId);
    if(record&&record.intentDigest!==intentDigest)fail('FILE_OPERATION_CONFLICT');
    if(record?.phase==='acknowledged'||record?.phase==='unknown'||record?.phase==='sending'){
     if(record.phase==='sending'){const next={...record,phase:'unknown',revision:record.revision+1};await receiptStore.put(operationId,next,{expectedRevision:record.revision});record=next;}
     return reconcileRecord(record);
    }
    const save=async patch=>{const next={...(record||{}),...patch,revision:(record?.revision||0)+1};await receiptStore.put(operationId,next,{expectedRevision:record?.revision||0});record=next;};
    if(!record)await save({operationId,intentDigest,context,path:material.path||file.path,bytes:material.bytes,sha256:material.sha256,name,mime,phase:'prepared',uploadAttempts:0});
    const attachment={...material,name,mime};
    if(record.phase!=='uploaded'){
     if(record.uploadAttempts>=3)fail('FILE_UPLOAD_RETRY_LIMIT');
     await save({phase:'uploading',uploadAttempts:record.uploadAttempts+1});await check(requestContext);signal?.throwIfAborted();
     let uploaded;try{uploaded=await adapter.uploadFile({requestContext,file:attachment,idempotencyKey:operationId,signal});}catch{fail('FILE_UPLOAD_FAILED');}
     await check(requestContext);await save({phase:'uploaded',uploaded});
    }
    await check(requestContext);signal?.throwIfAborted();await save({phase:'sending'});
    try{
     const receipt=await adapter.sendFile({requestContext,file:attachment,uploaded:record.uploaded,caption,idempotencyKey:operationId,signal});
     if(!validReceipt(receipt,record))throw new Error('invalid receipt');
     await check(requestContext);await save({phase:'acknowledged',receipt:safeReceipt(receipt)});return publicResult(record);
    }catch(error){if(notSubmitted.has(error)){await save({phase:'uploaded'});throw error;}await save({phase:'unknown'});return publicResult(record);}
   });
  },
  async reconcile(operationId){return receiptStore.exclusive(operationId,async()=>{const record=await receiptStore.get(operationId);if(!record)fail('FILE_OPERATION_NOT_FOUND');return reconcileRecord(record);});},
 };
}
