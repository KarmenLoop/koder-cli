import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { createSocket } from "../ws.mjs";
import {FILE_CAPABILITY,checkAttachment,messageNotSubmitted} from '../file-delivery.mjs';
export { wecomQrLogin as qrLogin } from "../onboarding.mjs";

// WeCom AI bot over the openws long connection, protocol as in Hermes Agent's
// plugins/platforms/wecom (MIT): aibot_subscribe → ping every 30 s →
// aibot_msg_callback in, aibot_respond_msg (same req_id) or aibot_send_msg out.
export const meta = {
  id: "wecom",
  name: { zh: "企业微信", en: "WeCom" },
  console: "https://work.weixin.qq.com/wework_admin/frame#/aiHelper/create",
  qr: true,
  steps: {
    zh: "在企业微信管理后台 →「应用管理」→「智能机器人」创建机器人，连接方式选择「长连接（API 模式）」，复制 Bot ID 和 Secret。",
    en: "In the WeCom admin console go to App Management → AI Bot, create a bot with the long-connection (API) mode and copy the Bot ID and Secret.",
  },
  fields: [
    { key: "botId", label: { zh: "Bot ID", en: "Bot ID" } },
    { key: "secret", secret: true, label: { zh: "Secret", en: "Secret" } },
  ],
};

const PING_MS = 30_000;
const REQUEST_MS = 15_000;

function deviceId(dataDir) {
  if (!dataDir) return crypto.randomUUID();
  const file = path.join(dataDir, "device.json");
  try {
    return JSON.parse(fs.readFileSync(file, "utf8")).deviceId;
  } catch {
    const id = crypto.randomUUID();
    fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(file, JSON.stringify({ deviceId: id }), { mode: 0o600 });
    return id;
  }
}

function connection(creds, { WebSocketImpl, dataDir, onFrame, onStatus, log }) {
  const pending = new Map();
  let pingTimer = null;
  const device = deviceId(dataDir);
  const reqId = (prefix) => `${prefix}_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
  const request = (ws, cmd, id, body) => new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error(`${cmd} timeout`));
    }, REQUEST_MS);
    pending.set(id, { reject(error) { clearTimeout(timer); reject(error); }, resolve(frame) {
      clearTimeout(timer);
      resolve(frame);
    } });
    if (!ws.send({ cmd, headers: { req_id: id }, body })) {
      clearTimeout(timer);
      pending.delete(id);
      reject(new Error("socket closed"));
    }
  });
  const socket = createSocket({
    WebSocketImpl,
    url: async () => creds.wsUrl || "wss://openws.work.weixin.qq.com",
    log,
    async onOpen(ws) {
      try {
        const answer = await request(ws, "aibot_subscribe", reqId("subscribe"), { bot_id: creds.botId, secret: creds.secret, device_id: device });
        if (answer.errcode && answer.errcode !== 0) throw Object.assign(new Error(`WeCom subscribe rejected (errcode=${answer.errcode}); check Bot ID/Secret and bot availability`),{retryable:[-1,45009].includes(answer.errcode)});
        if (!ws.connected) return;
        ws.markReady();
        onStatus("connected", creds.botId);
        clearInterval(pingTimer);
        pingTimer = setInterval(() => ws.send({ cmd: "ping", headers: { req_id: reqId("ping") }, body: {} }), PING_MS);
        pingTimer.unref?.();
      } catch (error) {
        if(error.retryable===false){ws.stop();onStatus("error",error.message);}
        else {if(ws.connected)ws.reconnect();onStatus("connecting",error.message);}
      }
    },
    onClose() {
      clearInterval(pingTimer);
      for (const entry of pending.values()) entry.reject(new Error("WeCom socket disconnected"));
      pending.clear();
      onStatus("connecting", "reconnecting");
    },
    onError(error) { onStatus(error.retryable===false?"error":"connecting", error.message); },
    onMessage(data) {
      const frame = JSON.parse(data);
      const id = frame.headers?.req_id;
      const cmd = frame.cmd || "";
      if (id && pending.has(id) && cmd !== "aibot_msg_callback" && cmd !== "aibot_callback" && cmd !== "aibot_event_callback") {
        pending.get(id).resolve(frame);
        pending.delete(id);
        return;
      }
      onFrame(frame);
    },
  });
  return {
    socket,
    reqId,
    request: (cmd, id, body) => request(socket, cmd, id, body),
    stop() {
      clearInterval(pingTimer);
      for (const entry of pending.values()) entry.reject(new Error("WeCom connection stopped"));
      pending.clear();
      socket.stop();
    },
  };
}

export async function verify(creds, { WebSocketImpl, timeoutMs = 45_000 } = {}) {
  return new Promise((resolve, reject) => {
    let conn;
    const timer = setTimeout(() => {
      conn?.stop();
      reject(new Error("subscribe timeout"));
    }, timeoutMs);
    conn = connection(creds, {
      WebSocketImpl,
      onFrame() {},
      log() {},
      onStatus(state, detail) {
        if (state === "connected" || state === "error") {
          clearTimeout(timer);
          conn.stop();
          if (state === "connected") resolve({ detail: `Bot ${creds.botId}` });
          else reject(new Error(detail));
        }
      },
    });
    conn.socket.start();
  });
}

export function create(creds, { WebSocketImpl, dataDir } = {}) {
  let conn = null;
  const lastReq = new Map();
  const groups = new Set();
  const seen = new Set();

  const markdown = (content) => ({ msgtype: "markdown", markdown: { content: content.slice(0, 4000) } });

  // Group chats only accept replies tied to an inbound req_id; each req_id answers once.
  async function send(chatId, text, origin = lastReq.get(chatId), repeated = false) {
    const latest = origin;
    if (latest?.id && (!latest.used || repeated)) {
      latest.used = true;
      const answer = await conn.request("aibot_respond_msg", latest.id, markdown(text));
      if (!answer.errcode) return answer;
    }
    if (groups.has(chatId)) throw new Error("wecom: group reply needs a fresh message");
    const answer = await conn.request("aibot_send_msg", conn.reqId("send"), { chatid: chatId, ...markdown(text) });
    if (answer.errcode) throw new Error(`aibot_send_msg: ${answer.errmsg || answer.errcode}`);
    return answer;
  }

  function handle(hub, frame) {
    if (frame.cmd !== "aibot_msg_callback" && frame.cmd !== "aibot_callback") return;
    const body = frame.body || {};
    const sender = String(body.from?.userid || "").trim();
    const chatId = String(body.chatid || sender).trim();
    if (!chatId) return;
    const messageId = String(body.msgid || "");
    if (messageId && seen.has(messageId)) return;
    if (messageId) { seen.add(messageId); if (seen.size > 1000) seen.delete(seen.values().next().value); }
    const isGroup = String(body.chattype || "").toLowerCase() === "group";
    if (isGroup) groups.add(chatId);
    const origin = { id: frame.headers?.req_id, used: false, messageId,actorId:sender };
    lastReq.set(chatId, origin);
    let text = body.msgtype === "mixed"
      ? (body.mixed?.msg_item || []).filter((item) => item.msgtype === "text").map((item) => item.text?.content || "").join("\n")
      : body.text?.content || body.voice?.content || "";
    if (isGroup) text = text.replace(/^@\S+\s*/, "");
    Promise.resolve(hub.receive({ platform: "wecom", chatId, userId: sender, userName: sender, text: text.trim(), isGroup, mentioned: true, messageId, reply: (value) => send(chatId, value, origin), async replyChunks(chunks) {
      // Hermes sends ordered chunks against the same callback request. Keep
      // the legacy single-reply API while supporting the gateway's batches.
      for (const chunk of chunks) await send(chatId, chunk, origin, true);
    } })).catch((error) => hub.log?.(`receive: ${error.message}`));
  }

  return {
    id: "wecom",
    maxLength: 3800,
    capabilities:()=>({files:{...structuredClone(FILE_CAPABILITY),groupRequiresFreshReply:true}}),
    async uploadFile({file,signal}){
      checkAttachment(file);if(!conn)throw new Error('WECOM_CONNECTION_REQUIRED');signal?.throwIfAborted();
      const size=512*1024,total=Math.ceil(file.bytes/size);
      const init=await conn.request('aibot_upload_media_init',conn.reqId('file-init'),{type:'file',filename:file.name,total_size:file.bytes,total_chunks:total,md5:crypto.createHash('md5').update(file.content).digest('hex')});
      const uploadId=init.body?.upload_id;if(init.errcode||!uploadId)throw new Error('WECOM_UPLOAD_INIT_FAILED');
      for(let index=0;index<total;index++){
        signal?.throwIfAborted();const result=await conn.request('aibot_upload_media_chunk',conn.reqId('file-chunk'),{upload_id:uploadId,chunk_index:index,base64_data:file.content.subarray(index*size,(index+1)*size).toString('base64')});
        if(result.errcode)throw new Error('WECOM_UPLOAD_CHUNK_FAILED');
      }
      signal?.throwIfAborted();const result=await conn.request('aibot_upload_media_finish',conn.reqId('file-finish'),{upload_id:uploadId});
      if(result.errcode||!result.body?.media_id)throw new Error('WECOM_UPLOAD_FINISH_FAILED');return {mediaId:result.body.media_id};
    },
    async sendFile({requestContext,file,uploaded,signal}){
      checkAttachment(file);signal?.throwIfAborted();if(!conn||!uploaded?.mediaId)throw messageNotSubmitted('WECOM_FILE_NOT_READY');
      const body={msgtype:'file',file:{media_id:uploaded.mediaId}},origin=lastReq.get(requestContext.chatId);
      let command='aibot_send_msg',requestId=conn.reqId('file-send');
      if(groups.has(requestContext.chatId)||requestContext.isGroup){
        if(!origin?.id||origin.used||origin.messageId!==requestContext.messageId||origin.actorId!==requestContext.actorId)throw messageNotSubmitted('WECOM_GROUP_REPLY_EXPIRED');
        origin.used=true;requestContext.replyConsumed=true;command='aibot_respond_msg';requestId=origin.id;
      }else body.chatid=requestContext.chatId;
      const answer=await conn.request(command,requestId,body);if(answer.errcode)throw new Error('WECOM_FILE_SEND_REJECTED');
      const value=answer.body?.msgid||answer.body?.message_id,messageId=typeof value==='string'?value:null;
      return {platform:'wecom',chatId:requestContext.chatId,messageId,requestId,bytes:file.bytes,status:messageId?'sent':'accepted'};
    },
    async start(hub) {
      conn = connection(creds, { WebSocketImpl, dataDir, log: (line) => hub.log?.(line), onStatus: hub.status, onFrame: (frame) => handle(hub, frame) });
      conn.socket.start();
    },
    stop() {
      conn?.stop();
    },
    send,
  };
}
