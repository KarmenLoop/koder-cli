// Compatibility export; KPM1 and the original AAD remain unchanged.
import {importKernel} from './agent.mjs';
const {createPersonalizationLock}=await importKernel('fusion/protected-lock.mjs');
export {createPersonalizationLock};
