import { importKernel } from './agent.mjs';
import { diagnosticFetch } from './turn.mjs';
import { modelEndpoint, transportOptions, withModelEndpoint } from './model-http.mjs';

export function connectionHint(failure, lang = 'zh') {
  const en=lang==='en';
  const status=failure?.status;
  if((status===401||status===403)&&/^api\.kimi\.(?:com|ai)(?::|$)/.test(failure?.host||''))return en?'Check the Kimi Code membership key, model entitlement and context tier; a Moonshot API key is a separate product.':'请核对 Kimi Code 会员密钥、型号权限和上下文档位；Moonshot 按量 API 是另一项产品。';
  if(status===401)return en?'Check API key.':'请检查 API 密钥。';
  if(status===403)return en?'Check model permissions and region.':'请检查模型权限和服务地区。';
  if(status===404)return en?'Check base URL, endpoint and model name.':'请检查接口地址、路径和模型名。';
  if(status===429)return en?'Rate limit or exhausted quota; check provider quota.':'请求限流或额度不足，请检查服务商额度。';
  if(status===400 || status===422)return en?'Check protocol, model and supported request parameters.':'请检查协议、模型和参数支持情况。';
  if(status>=500)return en?'Provider unavailable after bounded retries.':'服务商暂时不可用，已完成有限重试。';
  if(failure?.error==='API_TLS_ERROR')return en?'Check certificate chain, trusted CA and proxy.':'请检查证书链、受信任 CA 和代理。';
  if(failure?.error==='API_DNS_ERROR')return en?'Check DNS and API hostname.':'请检查 DNS 和 API 域名。';
  if(failure?.error==='API_INVALID_RESPONSE')return en?'Endpoint returned HTML; check API path and proxy.':'接口返回网页，请检查 API 路径和代理。';
  if(/TIMEOUT/.test(failure?.error || ''))return en?'Response stalled or exceeded its deadline; check provider and network.':'响应等待超时或中途停滞，请检查服务商和网络。';
  if(failure?.error==='API_TOOL_CALL_UNVERIFIED')return en?'This model did not complete the required tool round trip. Text chat alone does not establish task support.':'该模型未完成工具调用与续答验证；仅能文字回复不能证明任务能力。';
  if(failure?.error==='API_MODEL_PROTOCOL')return en?'The response did not match the selected API protocol. Check the endpoint and protocol; no incomplete tool call was executed.':'响应格式不符合所选 API 协议，请核对接口路径和协议；未执行不完整的工具指令。';
  if(failure?.error==='MODEL_INCOMPLETE')return en?'The output budget ended before a complete reply. Check model context/output settings; private reasoning also uses this budget.':'回复在完整生成前耗尽输出额度。请核对模型上下文与输出设置；接口的内部推理也占用输出额度。';
  if(failure?.error==='MODEL_EMPTY_REPLY')return en?'The API returned no visible reply or complete tool call. Check the model output budget and protocol; no hidden reasoning is shown.':'接口没有返回可见回复或完整工具调用。请检查模型输出额度与协议；内部推理不会作为回复显示。';
  if(failure?.error==='MODEL_FILTERED')return en?'The provider filtered this reply. Check its content policy or try a different task.':'服务商过滤了本次回复，请检查其内容规则或更换任务内容。';
  return en?'Check network, API URL and proxy; run koder model test.':'请检查网络、API 地址和代理；可运行 koder model test。';
}
export async function checkModel(ctx, record) {
  const diagnostic=diagnosticFetch(ctx.io.fetchImpl || globalThis.fetch,{env:ctx.env});
  const {createProvider}=await importKernel('harness/providers.mjs',ctx.env);
  const provider=createProvider({provider:{...record,id:'cli-check',maxOutput:Math.min(record.maxOutput || 4096,record.spec?.compat?.requiresReasoning?16384:4096)},fetchImpl:withModelEndpoint(diagnostic.fetch,record)});
  const started=Date.now();
  try {
    const messages=[{role:'user',content:ctx.opts.tools?'Call koder_connection_probe with nonce "koder-check"; after its result, reply ready.':'Reply with the single word ready.'}];
    const tools=ctx.opts.tools?[{name:'koder_connection_probe',description:'A harmless local connection test. Returns a fixed nonce; no file or network access.',parameters:{type:'object',properties:{nonce:{type:'string',enum:['koder-check']}},required:['nonce'],additionalProperties:false}}]:[];
    const first=await provider.complete({messages,tools});
    if(ctx.opts.tools){
      const call=first.toolCalls?.[0];
      if(first.toolCalls?.length!==1||call.name!=='koder_connection_probe'||call.arguments?.nonce!=='koder-check')throw Object.assign(new Error('Tool calling was not demonstrated'),{code:'API_TOOL_CALL_UNVERIFIED'});
      messages.push({role:'assistant',content:first.text,toolCalls:first.toolCalls,providerBlocks:first.providerBlocks,providerReasoning:first.providerReasoning},{role:'tool',toolCallId:call.id,content:'{"nonce":"koder-check","ok":true}'});
      const final=await provider.complete({messages,tools});if(!final.text?.trim()||final.toolCalls?.length)throw Object.assign(new Error('Tool result continuation failed'),{code:'API_TOOL_CALL_UNVERIFIED'});
    }
    return {ok:true,tools:!!ctx.opts.tools,host:new URL(modelEndpoint(record)).host,elapsedMs:Date.now()-started};
  }catch(error){
    const code=error?.code;
    const semantic=code==='MODEL_PROTOCOL'?'API_MODEL_PROTOCOL':['API_TOOL_CALL_UNVERIFIED','MODEL_INCOMPLETE','MODEL_EMPTY_REPLY','MODEL_FILTERED'].includes(code)?code:null;
    const last=diagnostic.state.last;
    // A successful HTTP status is transport evidence, not the parser failure.
    const failure=semantic?{error:semantic}:last?.error||last?.status>=400?last:{error:'API_MODEL_RESPONSE'};
    return {ok:false,host:new URL(modelEndpoint(record)).host,elapsedMs:Date.now()-started,failure};
  }
}
export async function printModelCheck(ctx, record) {
  const result=await checkModel(ctx,record);
  if(result.ok)ctx.stdout.write(`${result.tools?(ctx.lang==='en'?'API connected (tool call and continuation verified)':'API 已连接（已验证工具调用与续答）'):(ctx.lang==='en'?'API connected (text reply only; run koder model test --tools for task support)':'API 已连接（仅文字回复；任务能力请运行 koder model test --tools）')} · ${result.host} · ${result.elapsedMs} ms\n`);
  else {
    const detail=result.failure.status?`HTTP ${result.failure.status}`:result.failure.error;
    ctx.stderr.write(`${ctx.lang==='en'?'API check failed':'API 连接检测失败'} (${detail} · ${result.host}) ${connectionHint(result.failure,ctx.lang)}\n`);
  }
  return result.ok?0:2;
}
export function transportSummary(env, lang) {
  const config=transportOptions(env);
  return `${lang==='en'?'API transport':'API 连接策略'}: ${lang==='en'?'retries':'最多重试'} ${config.retries}; ${lang==='en'?'headers/idle/total':'响应头/空闲/总超时'} ${config.connectTimeoutMs}/${config.idleTimeoutMs}/${config.timeoutMs} ms`;
}
