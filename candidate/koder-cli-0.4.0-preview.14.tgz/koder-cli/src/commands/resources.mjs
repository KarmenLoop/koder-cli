import path from 'node:path';
import {openResourceLibrary} from '../resource-library.mjs';
export const flags={ 'model-access':{type:'bool'}, confirm:{type:'string'}, out:{type:'string'}, limit:{type:'number'}, offset:{type:'number'} };
export async function run(ctx){
 const [action='status',...args]=ctx.positionals,en=ctx.lang==='en';
 if(!['status','list','import','search','read','export','allow-model','disable','remove'].includes(action)||['import','search','read','export','allow-model','disable','remove'].includes(action)&&!args.length){ctx.stdout.write('koder resources status | import <zip> [--model-access] | search <query> | read <id> | export <id> --out <file> | allow-model <collection-id> --confirm MODEL | disable <collection-id> | remove <collection-id>\n');return 2;}
 if(action==='allow-model'&&ctx.opts.confirm!=='MODEL'){ctx.stdout.write(en?'Add --confirm MODEL to allow this local collection to be searched and its excerpts sent to your configured model.\n':'加上 --confirm MODEL，才允许检索这个本机合集并把选中的片段发给你配置的模型。\n');return 2;}
 const lib=await openResourceLibrary({env:ctx.env,credentials:ctx.io.resourceCredentials}),controller=new AbortController();
 const cancel=()=>controller.abort();process.once('SIGINT',cancel);
 try{let result;
  if(action==='status'||action==='list')result=await lib.status();
  else if(action==='import'){
   result=[];for(const file of args){ctx.stderr.write((en?'Checking local collection: ':'正在检查本机合集：')+path.basename(file)+'\n');const m=await lib.importFile(path.resolve(ctx.cwd,file),{modelAccess:ctx.opts.modelAccess===true,signal:controller.signal,onProgress:p=>ctx.stderr.write((en?'Checked entries: ':'已检查条目：')+p.entries+'\n')});result.push({id:m.id,name:m.name,files:m.files.length,skills:m.skillCount,skipped:m.skipped.length,modelAccess:m.modelAccess,duplicate:m.duplicate===true});}
  }else if(action==='search')result=await lib.search(args.join(' '),ctx.opts);
  else if(action==='read')result=await lib.read(args[0],{...ctx.opts,signal:controller.signal});
  else if(action==='export'){if(!ctx.opts.out)throw Error('RESOURCE_EXPORT_OUT_REQUIRED');result=await lib.export(args[0],path.resolve(ctx.cwd,ctx.opts.out));}
  else if(action==='remove'){await lib.remove(args[0]);result={removedFromCatalog:true,originalArchivesUnchanged:true,encryptedObjectsRetained:true};}
  else{await lib.access(args[0],action==='allow-model');result={id:args[0],modelAccess:action==='allow-model'};}
  ctx.stdout.write(JSON.stringify(result,null,2)+'\n');return 0;
 }finally{process.removeListener('SIGINT',cancel);await lib.close();}
}
