import { tutorialUpdated } from "../tutorial/progress.mjs";
import { featureNotice } from "../consent-copy.mjs";
import { spawn, spawnSync } from "node:child_process";
import readline from "node:readline/promises";
import { askLine } from "../ask.mjs";
import { saveConfig } from "../config.mjs";
import { KoderError } from "../errors.mjs";
import { PLATFORMS, loadPlatform } from "../gateway/registry.mjs";
import { loadGateway, loadState, pidAlive } from "../gateway/store.mjs";
import { createT } from "../i18n.mjs";
import { activeModelName, saveModel } from "../models.mjs";
import { isEnvName } from "../provider.mjs";
import { detectShell, isWindowsShell, shellName } from "../platform.mjs";
import { HERMES_ENGINE } from "../session.mjs";
import { detectTheme, setTheme, theme } from "../theme.mjs";
import { createScreen, notice, prompt, select } from "../tui.mjs";
import { useAscii } from "./banner.mjs";
import { SNIPPETS, snippetFor } from "./editor.mjs";
import { which } from "./engine.mjs";
import { limitsForPreset } from "../provider-catalog.mjs";
import { presetRecord, presets } from "./model.mjs";

const FIRST = ["deepseek", "kimi", "qwen", "zhipu", "doubao", "minimax-cn", "mimo", "mimo-token-plan", "chatgpt", "claude", "gemini", "openrouter", "siliconflow", "local", "kilo-free", "custom"];
const KEY_NAMES = { chatgpt: "OPENAI_API_KEY", claude: "ANTHROPIC_API_KEY", kimi: "MOONSHOT_API_KEY", qwen: "DASHSCOPE_API_KEY", gemini: "GEMINI_API_KEY" };

const COPY = {
  zh: {
    title: "Koder 设置",
    footer: "↑↓ 选择 · 回车确定 · 鼠标点一下也行 · Esc 返回",
    inputFooter: "回车保存 · Esc 返回 · Ctrl+U 清空重输",
    mainFooter: "↑↓ 选择 · 回车确定 · 鼠标点一下也行 · 数字直达 · Esc 退出",
    anyKey: "按任意键或点一下返回",
    search: "筛选",
    searchHint: "直接打字就能筛选，比如输入 deep；Esc 清空",
    empty: "没有匹配的项，按 Esc 清空筛选",
    intro: (shell) => `你在用 ${shell}。每一项改完都自动保存，随时可以回来改。`,
    items: {
      lang: ["语言 Language", "整个 Koder 的界面语言，切过去马上生效。Switch Koder between Chinese and English."],
      model: ["模型", "Koder 的大脑。选服务商 → 选型号 → 粘贴密钥，三步就好。手上没有密钥？选「本地兼容接口」用本机的 Ollama，或者「Kilo 匿名免费」。"],
      theme: ["配色", "官网同款的深色和浅色两套。终端是白底就选浅色，不然字会淡得像没睡醒。"],
      glyphs: ["开屏样式", "Windows 老控制台会把方块字画成两格宽，开屏就乱成一团，这时选「纯字符」。Windows Terminal、macOS 和 Linux 选彩色折光体。"],
      anim: ["开屏动画", "进门时那 0.2 秒的旋转定格。嫌晃眼就关掉，什么功能都不受影响。"],
      engine: ["引擎", "真正干活的智能体。默认是内置的 Koder 内核，开箱即用；接口由 Koder 直接适配；备用引擎默认关闭。"],
      gateway: ["聊天软件", "在飞书、企业微信、微信、钉钉、Telegram、Slack、Discord、WhatsApp 里给 Koder 派活。选一个平台，照提示把凭据粘进来就行。"],
      editor: ["编辑器", "给 Zed、Neovim、Emacs 生成接入配置，一键复制到剪贴板，再粘进编辑器的配置文件。"],
      learn: ["互动教程", (shell) => `30 课，按 ${shell} 的写法来讲，在练习场里边学边动手，不花一分钱。`],
      doctor: ["体检", "检查 Node.js、Git、模型、颜色和启动速度。哪里不对劲，先来这里看看。"],
      context: ["上下文与输出", "设置当前模型实际支持的上下文窗口和每次输出上限，保留现有密钥。"],
      personalization: ["记忆与灵魂", "分别选择习惯学习、当天状态、自我进化与主动服务；可跳过，也可编辑助理风格。"],
      permissions: ["电脑执行权限", "查看真实权限，按能力或完整工作模式授权。需要单独确认，--yes 不会授权。"],
      apps: ["应用与 MCP", "连接 Gamma 等应用，导入、启用和诊断 MCP；与各 Agent 共用本机连接。"],
      consent: ["使用许可与授权说明", "查看许可、数据范围、API费用、群私聊共享及关闭/撤销方式。接受协议不会代开其他功能。"],
      celebrate: ["节日与生日彩蛋", "六秒动画随时跳过，生日、音乐、语言地区分别选择。"],
      privacy: ["完整隐私条款", "离线查看 CLI 条款与官网原始消费者声明。"],
      feedback: ["反馈与联系", "官方邮箱和空白模板，不自动发送任何内容。"],
      done: ["完成", "所有设置都已经保存好了。之后在终端里输入 koder 就能开始干活。"],
    },
    zh: "中文", en: "English",
    noModel: "还没配置，先选这里",
    auto: (now) => `自动（现在是${now}）`, dark: "深色", light: "浅色",
    blocks: "彩色折光体", ascii: "纯字符",
    on: "开", off: "关",
    koder: "Koder 内核（内置）",
    gwNone: "还没配置", gwCount: (n, names) => `已保存 ${n} 个：${names}`,
    editors: "Zed · Neovim · Emacs",
    learnDone: "已毕业", learnUpdated: "新增隐私与彩蛋课程", learnAt: (n) => `学到第 ${n} 课`, learnNew: "还没开始",
    langTitle: "选择语言 · Language",
    themeTitle: "选择配色",
    themeAuto: "自动", themeAutoHint: "按终端背景自动判断，判断不了就用深色。",
    themeDarkHint: "官网深色：舞台 #12141c，正文 #ededeb，强调蓝 #7ca6ff。",
    themeLightHint: "官网浅色：舞台 #e4e1d8，正文 #1d1c1a，强调蓝 #2455d3。适合白底终端。",
    glyphTitle: "选择开屏样式",
    glyphAuto: "自动", glyphAutoHint: "Windows 老控制台用纯字符，其他终端用彩色折光体。",
    glyphBlocksHint: "半格方块拼出来的彩色折光体，需要终端把方块字画成一格宽。",
    glyphAsciiHint: "只用 + - | 和字母符号，任何终端都不会乱，代价是没那么好看。",
    animTitle: "开屏动画",
    animOnHint: "进门转一下再定格，约 0.2 秒。", animOffHint: "直接显示定格画面。",
    modelTitle: "选择模型服务商",
    modelHeader: "国内用户一般选 DeepSeek、Kimi、通义千问、智谱；有海外账号可以选 ChatGPT、Claude、Gemini。",
    region: { cn: "国内", global: "海外", hub: "聚合平台", local: "本机/自定义", free: "免费" },
    pickModel: "选择型号", recommended: "推荐", typeModel: "自己输入型号…",
    modelName: "型号", modelNameHint: "填服务方文档里写的型号名。",
    localHint: "先在本机启动 Ollama（ollama.com 下载）或 LM Studio，再填它加载的模型名，比如 qwen3:8b。",
    required: "这一项不能空着。",
    baseUrl: "接口地址", baseUrlHint: "服务方给你的 OpenAI 或 Anthropic 兼容地址，例如 https://api.example.com/v1", badUrl: "地址要以 http:// 或 https:// 开头。",
    protocolTitle: "接口协议", openai: "OpenAI 兼容", anthropic: "Anthropic 兼容",
    keyTitle: "API 密钥",
    keySteps: "怎么拿到密钥：",
    keyPaste: "粘贴密钥（推荐，最简单）", keyPasteHint: "密钥明文保存在本机配置，屏幕只显示末四位且不进命令历史；希望配置不含密钥请选择环境变量。",
    keyEnv: "从环境变量读取", keyEnvHint: "适合服务器和 CI：配置里只记变量名，密钥放在系统环境变量里。",
    keyOpen: "打开网页去拿密钥", keyOpenHint: "用默认浏览器打开服务方的密钥页面，拿到以后回来选「粘贴密钥」。",
    back: "返回",
    keyLabel: "密钥", keyShort: "这串太短了，不像一把完整的密钥，再检查一下？",
    paste: { windows: "粘贴：Windows Terminal 里按 Ctrl+V；老式控制台窗口点鼠标右键。", mac: "粘贴：按 ⌘V。", linux: "粘贴：按 Ctrl+Shift+V，或者鼠标中键。" },
    envLabel: "变量名", badEnv: "变量名只能用字母、数字和下划线，并且不能以数字开头。",
    envHow: {
      powershell: (n) => `设置这个变量：永久保存用 setx ${n} "你的密钥"（之后新开的窗口才生效）；只在当前窗口用 $env:${n} = "你的密钥"`,
      cmd: (n) => `设置这个变量：永久保存用 setx ${n} "你的密钥"（之后新开的窗口才生效）；只在当前窗口用 set "${n}=你的密钥"`,
      mac: (n) => `设置这个变量：echo 'export ${n}=你的密钥' >> ~/.zshrc，然后重新打开终端`,
      linux: (n) => `设置这个变量：echo 'export ${n}=你的密钥' >> ~/.bashrc，然后重新打开终端`,
    },
    envMissing: (n) => `注意：当前窗口里还读不到 ${n}。按上面的方法设置好，重新打开终端再用。`,
    openFailed: (url) => `没能自动打开浏览器，请手动复制这个地址：${url}`,
    opened: "已经在浏览器里打开了。拿到密钥以后回来选「粘贴密钥」。",
    savedTitle: "模型已保存",
    saved: (name, model) => `${name} · ${model}`,
    savedKey: (tail) => `密钥明文保存在本机配置（屏幕仅显示末四位 ${tail}）。`,
    savedEnv: (n) => `密钥从环境变量 ${n} 读取。`,
    savedLocal: "本机模型不需要密钥。记得先把 Ollama 或 LM Studio 打开。",
    noKernel: "找不到 Koder 内核，模型预设读不出来。可以运行 koder doctor 看看原因。",
    engineTitle: "选择引擎",
    engineKoderHint: "内置的 Node 版 Koder 内核，不用另装任何东西。",
    engineHermesHint: "Nous Research 的 Python 版 Hermes，通过 ACP 接入，批准请求仍然由 Koder 来问你。",
    current: "正在用", installed: "已安装", notInstalled: "还没安装",
    hermesWindows: "Hermes 的安装脚本需要 bash，在 Windows 上请到 WSL（适用于 Linux 的 Windows 子系统）里安装 Koder 和 Hermes。内置的 Koder 内核在 Windows 上可以直接用。",
    installNow: "现在安装 Hermes", installHint: "会下载 Hermes 官方安装脚本（固定到核对过的版本）并运行，需要联网。",
    gwTitle: "接入聊天软件", gwOn: "已连接", gwPaused: "已暂停", gwOff: "未配置",
    gwStart: "在后台启动机器人", gwStartHint: "接好平台以后，让机器人在后台收消息；关掉终端也不会停。",
    editorTitle: "编辑器配置",
    copy: "复制到剪贴板", copyHint: "复制以后打开上面写的配置文件，粘贴进去保存。",
    copied: (file) => `已复制。打开 ${file}，粘贴进去保存就好。`,
    copyFailed: "没找到剪贴板工具（Linux 需要 wl-copy、xclip 或 xsel）。可以退出后运行 koder editor 手动复制。",
    pressEnter: "按回车回到设置 › ",
    bye: "设置已保存。输入 koder 开始对话，koder setup 随时回来改。",
    nonInteractive: "koder setup 需要在终端窗口里打开。也可以直接用命令：koder lang en、koder theme light、koder model set --preset deepseek --key-env DEEPSEEK_API_KEY",
  },
  en: {
    title: "Koder setup",
    footer: "↑↓ move · Enter select · click works too · Esc back",
    inputFooter: "Enter saves · Esc back · Ctrl+U clears",
    mainFooter: "↑↓ move · Enter select · click works too · digits jump · Esc quit",
    anyKey: "Press any key or click to go back",
    search: "Filter",
    searchHint: "Type to filter, e.g. deep; Esc clears",
    empty: "Nothing matches; Esc clears the filter",
    intro: (shell) => `You're on ${shell}. Every change is saved right away; come back any time.`,
    items: {
      lang: ["Language 语言", "The language of all of Koder; takes effect at once. 切换中文或英文。"],
      model: ["Model", "Koder's brain. Provider, then model, then paste your key. No key? Pick the local endpoint for Ollama on this machine, or Kilo's anonymous free tier."],
      theme: ["Colours", "The website's dark and light palettes. White terminal background? Pick light, or the text will look half asleep."],
      glyphs: ["Banner style", "The classic Windows console draws block characters two columns wide and the banner falls apart; pick plain characters there. Windows Terminal, macOS and Linux get the colour refractor."],
      anim: ["Banner animation", "The 0.2-second spin when Koder starts. Turn it off if it bothers you; nothing else changes."],
      engine: ["Engine", "The agent doing the work: the built-in Koder kernel by default, with direct model API adapters; the fallback engine starts disabled."],
      gateway: ["Chat apps", "Send Koder tasks from Feishu, WeCom, WeChat, DingTalk, Telegram, Slack, Discord or WhatsApp. Pick one and paste its credentials."],
      editor: ["Editors", "Generate the Zed, Neovim or Emacs config, copy it in one go, paste it into the editor's settings."],
      learn: ["Tutorial", (shell) => `23 lessons written for ${shell}, hands-on in a practice project, free of charge.`],
      doctor: ["Check-up", "Checks Node.js, Git, the model, colours and startup time. Start here when something feels off."],
      context: ["Context and output", "Set the active model context window and output limit, keeping its saved credentials."],
      personalization: ["Memory and soul", "Choose learning, daily state, evolution and proactive service independently; optional."],
      permissions: ["Computer execution scope", "Inspect capabilities and authorize custom or full work mode with separate consent."],
      apps: ["Applications and MCP", "Connect applications, import and verify MCP, and share local connections with agents."],
      consent: ["License and consent guide", "Review data scope, API cost, group sharing and how to disable or revoke. License acceptance enables no optional features."],
      celebrate: ["Holidays and birthdays", "Six-second effects are skippable. Birthday, music, language, and region are separate choices."],
      privacy: ["Full privacy terms", "Read CLI terms and the complete official consumer originals offline."],
      feedback: ["Feedback and contact", "Official email and a blank template. Nothing is sent automatically."],
      done: ["Done", "Everything is saved. Type koder in a terminal to get to work."],
    },
    zh: "中文", en: "English",
    noModel: "not set yet, start here",
    auto: (now) => `auto (${now} now)`, dark: "dark", light: "light",
    blocks: "colour refractor", ascii: "plain characters",
    on: "on", off: "off",
    koder: "Koder kernel (built in)",
    gwNone: "none yet", gwCount: (n, names) => `${n} saved: ${names}`,
    editors: "Zed · Neovim · Emacs",
    learnDone: "graduated", learnUpdated: "new plan, privacy, and celebration lessons", learnAt: (n) => `at lesson ${n}`, learnNew: "not started",
    langTitle: "Language · 语言",
    themeTitle: "Colours",
    themeAuto: "auto", themeAutoHint: "Follows the terminal background; dark when unsure.",
    themeDarkHint: "Website dark: stage #12141c, text #ededeb, accent #7ca6ff.",
    themeLightHint: "Website light: stage #e4e1d8, text #1d1c1a, accent #2455d3. For white terminals.",
    glyphTitle: "Banner style",
    glyphAuto: "auto", glyphAutoHint: "Plain characters in the classic Windows console, the colour refractor elsewhere.",
    glyphBlocksHint: "A refractor drawn with half blocks; the terminal must draw them one column wide.",
    glyphAsciiHint: "Only + - | and letters. Never breaks, less pretty.",
    animTitle: "Banner animation",
    animOnHint: "A short spin before it settles, about 0.2 s.", animOffHint: "Show the settled frame straight away.",
    modelTitle: "Model provider",
    modelHeader: "In China most people pick DeepSeek, Kimi, Qwen or Zhipu; with overseas accounts, ChatGPT, Claude or Gemini.",
    region: { cn: "China", global: "global", hub: "hub", local: "local/custom", free: "free" },
    pickModel: "Model", recommended: "recommended", typeModel: "Type another model…",
    modelName: "Model", modelNameHint: "The model name from the provider's docs.",
    localHint: "Start Ollama (ollama.com) or LM Studio first, then enter the model it serves, e.g. qwen3:8b.",
    required: "This can't be empty.",
    baseUrl: "Endpoint", baseUrlHint: "The OpenAI- or Anthropic-compatible URL from your provider, e.g. https://api.example.com/v1", badUrl: "It must start with http:// or https://.",
    protocolTitle: "Protocol", openai: "OpenAI compatible", anthropic: "Anthropic compatible",
    keyTitle: "API key",
    keySteps: "Getting a key (provider's steps):",
    keyPaste: "Paste the key (easiest)", keyPasteHint: "Stored in plaintext in local configuration; the screen masks it and it skips shell history. Use an environment variable to keep the key out of configuration.",
    keyEnv: "Read it from an environment variable", keyEnvHint: "For servers and CI: only the variable name is saved.",
    keyOpen: "Open the key page in a browser", keyOpenHint: "Opens the provider's key page; come back and paste the key.",
    back: "Back",
    keyLabel: "Key", keyShort: "That's too short to be a whole key. Check it again?",
    paste: { windows: "Paste: Ctrl+V in Windows Terminal; right-click in the classic console.", mac: "Paste: ⌘V.", linux: "Paste: Ctrl+Shift+V or the middle mouse button." },
    envLabel: "Variable", badEnv: "Letters, digits and underscores only, not starting with a digit.",
    envHow: {
      powershell: (n) => `Set it: setx ${n} "your-key" to keep it (new windows only), or $env:${n} = "your-key" for this window`,
      cmd: (n) => `Set it: setx ${n} "your-key" to keep it (new windows only), or set "${n}=your-key" for this window`,
      mac: (n) => `Set it: echo 'export ${n}=your-key' >> ~/.zshrc, then open a new terminal`,
      linux: (n) => `Set it: echo 'export ${n}=your-key' >> ~/.bashrc, then open a new terminal`,
    },
    envMissing: (n) => `Note: this window can't see ${n} yet. Set it as above and open a new terminal.`,
    openFailed: (url) => `Couldn't open a browser; copy this address: ${url}`,
    opened: "Opened in your browser. Come back and choose Paste the key.",
    savedTitle: "Model saved",
    saved: (name, model) => `${name} · ${model}`,
    savedKey: (tail) => `The key is stored locally in plaintext (display ends in ${tail}).`,
    savedEnv: (n) => `The key is read from ${n}.`,
    savedLocal: "Local models need no key. Make sure Ollama or LM Studio is running.",
    noKernel: "The Koder kernel wasn't found, so presets can't be read. Run koder doctor for details.",
    engineTitle: "Engine",
    engineKoderHint: "The built-in Node Koder kernel. Nothing else to install.",
    engineHermesHint: "Nous Research's Python Hermes over ACP; approvals still go through Koder.",
    current: "in use", installed: "installed", notInstalled: "not installed",
    hermesWindows: "The Hermes installer needs bash. On Windows, install Koder and Hermes inside WSL. The built-in Koder kernel works on Windows as is.",
    installNow: "Install Hermes now", installHint: "Downloads and runs the official Hermes installer pinned to the checked version; needs the internet.",
    gwTitle: "Chat apps", gwOn: "connected", gwPaused: "paused", gwOff: "not connected",
    gwStart: "Start the bots in the background", gwStartHint: "Once a platform is connected, keep receiving messages even after the terminal closes.",
    editorTitle: "Editor config",
    copy: "Copy to clipboard", copyHint: "Then open the file shown above, paste and save.",
    copied: (file) => `Copied. Open ${file}, paste and save.`,
    copyFailed: "No clipboard tool found (Linux needs wl-copy, xclip or xsel). Quit and run koder editor to copy by hand.",
    pressEnter: "Press Enter to return to setup › ",
    bye: "Settings saved. Type koder to start; koder setup brings you back here.",
    nonInteractive: "koder setup needs a terminal window. Or use commands: koder lang en, koder theme light, koder model set --preset deepseek --key-env DEEPSEEK_API_KEY",
  },
};

const copyFor = (ctx) => COPY[ctx.lang === "en" ? "en" : "zh"];
const pick = (value, ...args) => (typeof value === "function" ? value(...args) : value);
const family = (shell) => (isWindowsShell(shell) ? "windows" : shell);

export function openUrl(ctx, url) {
  if (ctx.io.openUrl) return ctx.io.openUrl(url);
  if (!/^https:\/\/[^\s"'<>|&^]+$/.test(url)) return false;
  const platform = ctx.io.platform || process.platform;
  const [command, args] = platform === "win32" ? ["explorer.exe", [url]] : platform === "darwin" ? ["open", [url]] : ["xdg-open", [url]];
  try {
    const child = spawn(command, args, { detached: true, stdio: "ignore", windowsHide: true });
    child.on("error", () => {});
    child.unref();
    return true;
  } catch {
    return false;
  }
}

export function copyText(ctx, text) {
  if (ctx.io.clipboard) return ctx.io.clipboard(text);
  const platform = ctx.io.platform || process.platform;
  const tools = platform === "win32" ? [["clip", []]] : platform === "darwin" ? [["pbcopy", []]] : [["wl-copy", []], ["xclip", ["-selection", "clipboard"]], ["xsel", ["--clipboard", "--input"]]];
  for (const [command, args] of tools) {
    const result = spawnSync(command, args, { input: text, stdio: ["pipe", "ignore", "ignore"], windowsHide: true });
    if (result.status === 0) return command;
  }
  return null;
}

function modelValue(ctx, c) {
  try {
    const found = ctx.findProvider();
    if (found) return { value: c.saved(found.record.name, found.record.model), tone: "ok" };
  } catch (error) {
    return { value: error instanceof KoderError ? ctx.t(error.key, error.vars) : error.message, tone: "warn" };
  }
  return { value: c.noModel, tone: "warn" };
}

async function menuItems(ctx, c, shell) {
  const config = ctx.config;
  const gateway = loadGateway(ctx.env);
  const connected = [];
  for (const id of PLATFORMS) if (gateway.platforms?.[id]) connected.push((await loadPlatform(id)).meta.name[ctx.lang === "en" ? "en" : "zh"]);
  const tutorial = config.tutorial || {};
  const values = {
    lang: { value: ctx.lang === "en" ? c.en : c.zh },
    model: modelValue(ctx, c),
    theme: { value: config.theme === "dark" ? c.dark : config.theme === "light" ? c.light : c.auto(theme().name === "light" ? c.light : c.dark) },
    glyphs: { value: config.glyphs === "ascii" ? c.ascii : config.glyphs === "blocks" ? c.blocks : c.auto(useAscii(ctx) ? c.ascii : c.blocks) },
    anim: { value: config.anim === false ? c.off : c.on },
    engine: { value: (!config.engine || config.engine === "koder" || (config.engine === "hermes" && !config.fallbackEngineEnabled)) ? c.koder : config.engine },
    gateway: { value: connected.length ? c.gwCount(connected.length, connected.join("、")) : c.gwNone, tone: connected.length ? "ok" : undefined },
    editor: { value: c.editors },
    learn: { value: tutorialUpdated(tutorial) ? c.learnUpdated : tutorial.done ? c.learnDone : tutorial.lesson > 1 ? c.learnAt(tutorial.lesson) : c.learnNew },
    doctor: { value: "" },
    context: { value: (() => { try { const r=ctx.findProvider()?.record; return r ? `${r.contextWindow} / ${r.maxOutput} tokens` : c.noModel; } catch { return c.noModel; } })() },
    done: { value: "" },
  };
  return Object.entries(c.items).map(([id, [label, hint]]) => ({ id, label, hint: pick(hint, shellName(shell, ctx.lang)), ...values[id] }));
}

async function waitEnter(ctx, c) {
  const rl = readline.createInterface({ input: ctx.stdin, output: ctx.stdout, terminal: true });
  try {
    await askLine(rl, `\n${c.pressEnter}`);
  } finally {
    rl.close();
  }
}

// Leaves the full screen, runs another koder command in the normal terminal, then comes back.
async function outside(ctx, screen, c, argv) {
  await screen.suspend(async () => {
    ctx.stdout.write("\n");
    try {
      await ctx.dispatch(argv, { prompter: null });
    } catch (error) {
      ctx.stdout.write(`${error instanceof KoderError ? ctx.t(error.key, error.vars) : error.message}\n`);
    }
    await waitEnter(ctx, c);
  });
}

async function chooseLang(ctx, screen, c) {
  const picked = await select(screen, { title: c.langTitle, items: [{ label: "中文", id: "zh" }, { label: "English", id: "en" }], index: ctx.lang === "en" ? 1 : 0, footer: c.footer });
  if (!picked || picked.quit) return picked;
  ctx.lang = picked.item.id;
  ctx.t = createT(ctx.lang);
  ctx.config.lang = ctx.lang;
  saveConfig({ lang: ctx.lang }, ctx.env);
  return null;
}

async function chooseTheme(ctx, screen, c) {
  const items = [{ label: c.themeAuto, id: "auto", hint: c.themeAutoHint }, { label: c.dark, id: "dark", hint: c.themeDarkHint }, { label: c.light, id: "light", hint: c.themeLightHint }];
  const picked = await select(screen, { title: c.themeTitle, items, index: Math.max(0, items.findIndex((item) => item.id === (ctx.config.theme || "auto"))), footer: c.footer });
  if (!picked || picked.quit) return picked;
  ctx.config.theme = picked.item.id;
  saveConfig({ theme: picked.item.id }, ctx.env);
  setTheme(detectTheme({ env: ctx.env, config: ctx.config }));
  return null;
}

async function chooseGlyphs(ctx, screen, c) {
  const items = [{ label: c.glyphAuto, id: "auto", hint: c.glyphAutoHint }, { label: c.blocks, id: "blocks", hint: c.glyphBlocksHint }, { label: c.ascii, id: "ascii", hint: c.glyphAsciiHint }];
  const picked = await select(screen, { title: c.glyphTitle, items, index: Math.max(0, items.findIndex((item) => item.id === (ctx.config.glyphs || "auto"))), footer: c.footer });
  if (!picked || picked.quit) return picked;
  ctx.config.glyphs = picked.item.id;
  saveConfig({ glyphs: picked.item.id }, ctx.env);
  screen.ascii = useAscii(ctx);
  return null;
}

async function chooseAnim(ctx, screen, c) {
  const items = [{ label: c.on, id: true, hint: c.animOnHint }, { label: c.off, id: false, hint: c.animOffHint }];
  const picked = await select(screen, { title: c.animTitle, items, index: ctx.config.anim === false ? 1 : 0, footer: c.footer });
  if (!picked || picked.quit) return picked;
  ctx.config.anim = picked.item.id;
  saveConfig({ anim: picked.item.id }, ctx.env);
  return null;
}

async function chooseModel(ctx, screen, c, shell) {
  let list;
  try {
    list = await presets(ctx);
  } catch {
    return notice(screen, { title: c.modelTitle, lines: [{ text: c.noKernel, tone: "warn" }], footer: c.anyKey }).then(() => null);
  }
  const ordered = [...FIRST.map((id) => list.find((item) => item.id === id)).filter(Boolean), ...list.filter((item) => !FIRST.includes(item.id))];
  const items = ordered.map((preset) => ({ label: preset.name, value: `${c.region[preset.region] || preset.region} · ${preset.vendor}`, hint: preset.detail, keywords: preset.id, preset }));
  const picked = await select(screen, { title: c.modelTitle, items, header: [c.modelHeader, ctx.lang==='en'?'Koder connects directly. Account access is unverified until model test --tools succeeds.':'默认由 Koder 直接连接；账号权限与任务能力需通过 model test --tools 验证。'], filter: true, footer: c.footer });
  if (!picked || picked.quit) return picked;
  const preset = picked.item.preset;
  const title = `${c.modelTitle} · ${preset.name}`;
  const raw = presetRecord(preset);
  const models = (preset.models || []).filter((id) => id && id !== "本地模型");
  if (models.length > 1) {
    const choice = await select(screen, { title: `${title} · ${c.pickModel}`, items: [...models.map((id) => ({ label: id, value: id === preset.model ? c.recommended : "" })), { label: c.typeModel, custom: true }], footer: c.footer });
    if (!choice || choice.quit) return choice;
    raw.model = choice.item.custom ? await prompt(screen, { title, label: c.modelName, header: [c.modelNameHint], footer: c.inputFooter, validate: (v) => (v ? "" : c.required) }) : choice.item.label;
  } else if (!models.length || preset.id === "local") {
    raw.model = await prompt(screen, { title, label: c.modelName, initial: preset.id === "local" ? "qwen3:8b" : models[0] || "", header: [preset.id === "local" ? c.localHint : c.modelNameHint], footer: c.inputFooter, validate: (v) => (v ? "" : c.required) });
  }
  if (raw.model == null) return null;
  if (raw.model !== preset.model) Object.assign(raw, limitsForPreset(preset, raw.model));
  if (preset.id === "custom") {
    raw.name = raw.model;
    raw.baseUrl = await prompt(screen, { title, label: c.baseUrl, initial: "https://", header: [c.baseUrlHint], footer: c.inputFooter, validate: (v) => (/^https?:\/\/[^/\s]+/i.test(v) ? "" : c.badUrl) });
    if (raw.baseUrl == null) return null;
    const protocol = await select(screen, { title: `${title} · ${c.protocolTitle}`, items: [{ label: c.openai, id: "openai" }, { label: c.anthropic, id: "anthropic" }, { label: "OpenAI Responses", id: "responses" }], footer: c.footer });
    if (!protocol || protocol.quit) return protocol;
    raw.protocol = protocol.item.id;
    raw.auth = protocol.item.id === "anthropic" ? "x-api-key" : "bearer";
  }
  if (preset.id === "mimo-token-plan") {
    raw.baseUrl = await prompt(screen, { title, label: c.baseUrl, initial: raw.baseUrl, header: [ctx.lang === "en" ? "Use the Token Plan Base URL shown in your console; the default is the China cluster." : "填写套餐控制台显示的 Base URL；默认中国集群，其他地区可在这里修改。"], footer: c.inputFooter, validate: v => /^https:\/\/token-plan-(?:cn|sgp|ams)\.xiaomimimo\.com\/v1\/?$/.test(v) ? "" : c.badUrl });
    if (raw.baseUrl == null) return null;
  }
  const lines = [{ text: c.saved(raw.name, raw.model), tone: "ok", bold: true }];
  if (raw.auth !== "none") {
    const steps = [...(preset.key?.steps || []).map((step, i) => `${i + 1}. ${step}`), ...(preset.key?.url ? [preset.key.url] : [])];
    for (;;) {
      const options = [
        { label: c.keyPaste, id: "paste", hint: c.keyPasteHint },
        { label: c.keyEnv, id: "env", hint: c.keyEnvHint },
        ...(preset.key?.url ? [{ label: c.keyOpen, id: "open", value: preset.key.url, hint: c.keyOpenHint }] : []),
        { label: c.back, id: "back" },
      ];
      const how = await select(screen, { title: `${title} · ${c.keyTitle}`, header: steps.length ? [c.keySteps, ...steps] : [], items: options, footer: c.footer });
      if (!how || how.quit || how.item.id === "back") return how?.quit ? how : null;
      if (how.item.id === "open") {
        const ok = openUrl(ctx, preset.key.url);
        await notice(screen, { title: c.keyOpen, lines: [ok ? c.opened : c.openFailed(preset.key.url)], footer: c.anyKey });
        continue;
      }
      if (how.item.id === "paste") {
        const key = await prompt(screen, { title: `${title} · ${c.keyTitle}`, label: c.keyLabel, secret: true, header: [c.paste[family(shell)], c.keyPasteHint], footer: c.inputFooter, validate: (v) => (v.length >= 8 ? "" : c.keyShort) });
        if (key == null) continue;
        raw.apiKey = key;
        lines.push(c.savedKey(key.slice(-4)));
      } else {
        const guess = KEY_NAMES[preset.id] || `${preset.id.replace(/[^a-z0-9]/gi, "_").toUpperCase()}_API_KEY`;
        const name = await prompt(screen, { title: `${title} · ${c.keyTitle}`, label: c.envLabel, initial: guess, header: [c.envHow[shell](guess)], footer: c.inputFooter, validate: (v) => (isEnvName(v) || v.length >= 8 ? "" : c.badEnv) });
        if (name == null) continue;
        if (isEnvName(name)) {
          raw.keyEnv = name;
          delete raw.apiKey;
          lines.push(c.savedEnv(name), c.envHow[shell](name));
          if (!ctx.env[name]) lines.push({ text: c.envMissing(name), tone: "warn" });
        } else {
          raw.apiKey = name;
          delete raw.keyEnv;
          lines.push(c.savedKey(name.slice(-4)));
        }
      }
      break;
    }
  } else lines.push(c.savedLocal);
  saveModel(activeModelName(ctx.env), raw, ctx.env);
  ctx._record = undefined;
  await notice(screen, { title: c.savedTitle, lines, footer: c.anyKey });
  return null;
}

async function chooseContext(ctx, screen, c) {
  const found=ctx.findProvider();
  if(!found) return notice(screen,{title:c.modelTitle,lines:[c.noModel],footer:c.anyKey});
  const en=ctx.lang==='en',record=found.record;
  const title=en?'Context and output':'上下文与输出';
  const contextWindow=await prompt(screen,{title,label:'contextWindow (tokens)',initial:String(record.contextWindow),header:[en?'Use the actual limit for this model and endpoint.':'请填写当前型号与接口实际支持的窗口；输出上限也占用这个窗口。'],footer:c.inputFooter,validate:v=>Number.isSafeInteger(Number(v))&&Number(v)>=2048&&Number(v)<=16777216?'':(en?'Enter an integer between 2048 and 16777216':'请输入 2048 至 16777216 之间的整数')});
  if(contextWindow==null)return null;
  const maxOutput=await prompt(screen,{title,label:'maxOutput (tokens)',initial:String(Math.min(record.maxOutput,Math.floor(Number(contextWindow)/4))),header:[en?'This is an output ceiling, not additional input context.':'这是每次输出的上限，并非额外输入空间。较小的输出预留能留出更多历史容量。'],footer:c.inputFooter,validate:v=>Number.isSafeInteger(Number(v))&&Number(v)>=256&&Number(v)<Number(contextWindow)?'':(en?'Output must be at least 256 and below the window':'输出至少 256，且必须小于上下文窗口')});
  if(maxOutput==null)return null;
  screen.stop();
  let code;
  try { code=await ctx.dispatch(['model','context','--context-window',contextWindow,'--max-output',maxOutput],{noStdin:true}); }
  finally { screen.start(); }
  ctx._record=undefined;
  return notice(screen,{title,lines:[code===0?(en?'Context limits saved.':'上下文配置已保存。'):(en?'Context limits were not saved; check the command error.':'上下文未保存，请检查命令错误。')],footer:c.anyKey});
}

async function choosePersonalization(ctx,screen,c,shell){
 const {openPersonalization}=await import('../personalization.mjs');let runtime,status;
 try{runtime=await openPersonalization(ctx,{force:true});status=await runtime.status();}catch(error){return notice(screen,{title:ctx.lang==='en'?'Memory unavailable':'记忆存储暂不可用',lines:[error.code||error.message],footer:c.anyKey});}finally{runtime?.close();}
 const en=ctx.lang==='en',labels=en?[['learning','Preference learning'],['daily-state','Daily state'],['evolution','Skill evolution'],['proactive','Proactive service']]:[['learning','喜好习惯学习'],['daily-state','当天状态'],['evolution','自我进化'],['proactive','主动服务']];
 const items=labels.map(([id,label])=>({id,label,value:status.policy[id==='daily-state'?'dailyState':id]?c.on:c.off}));items.push({id:'soul',label:en?'Edit assistant soul':'编辑助理灵魂'},{id:'status',label:en?'Directory and shared memory status':'目录与共享范围'},{id:'back',label:c.back});
 const choice=await select(screen,{title:en?'Memory and soul':'记忆与灵魂',header:[status.storage.directory,en?'Optional. Daily reflection uses the configured API/local model (default 4 calls/day). Associated group members can use linked private memory.':'功能均可跳过。每日反思使用已配置API或本地模型，默认最多4次调用；关联群成员可用关联私聊记忆。'],items,footer:c.footer});if(!choice||choice.quit||choice.item.id==='back')return;
 if(choice.item.id==='status')return outside(ctx,screen,c,['memory','personalization','status']);
 if(choice.item.id==='soul'){
  const name=await prompt(screen,{title:en?'Assistant soul':'助理灵魂',label:en?'Assistant name':'助理名字',initial:'',footer:c.inputFooter,validate:v=>v.length<=80?'':'最多80字'});if(name===null)return;
  const styles=['concise','formal','friendly','analytical','coaching','creative'],style=await select(screen,{title:en?'Communication style':'表达风格',items:styles.map((id,i)=>({id,label:en?id:['简洁直接','正式稳重','温暖友好','分析严谨','引导启发','富有创意'][i]})),footer:c.footer});if(!style||style.quit)return;
  return outside(ctx,screen,c,['memory','soul','save',JSON.stringify({name,style:style.item.id})]);
 }
 const state=await select(screen,{title:choice.item.label,header:featureNotice(choice.item.id==='daily-state'?'dailyState':choice.item.id,ctx.lang).split('\n'),items:[{id:'on',label:c.on},{id:'off',label:c.off},{id:'back',label:c.back}],footer:c.footer});if(state&&!state.quit&&state.item.id!=='back')return outside(ctx,screen,c,['memory',choice.item.id,state.item.id]);
}
async function choosePermissions(ctx,screen,c){
 const en=ctx.lang==='en';
 const choice=await select(screen,{title:en?'Computer scope':'电脑执行权限',header:[en?'Grant only the required scope. OS permissions remain separate.':'按需授权；Koder范围与操作系统权限分别管理。'],items:[
  {id:'status',label:en?'Inspect actual capabilities':'查看真实能力'},
  {id:'home',label:en?'Authorize home file work':'授权主目录文件工作',hint:en?'Read, write, search and network; review roots before GRANT.':'读取、写入、搜索与联网；输入 GRANT 前核对目录。'},
  {id:'full',label:en?'Authorize full work mode':'授权完整工作模式',hint:en?'Visible disk roots and capability categories, within actual OS permissions.':'全部可见磁盘根与能力类别；仍受真实系统权限约束。'},
  {id:'revoke',label:en?'Revoke Koder computer grants':'撤销 Koder 电脑授权',hint:en?'Blocks future calls; does not undo completed writes or OS permissions.':'阻止后续调用，不追回已执行操作；系统权限在系统设置中撤销。'},
  {id:'back',label:c.back}],footer:c.footer});
 if(!choice||choice.quit||choice.item.id==='back')return;
 const commands={full:['permissions','request','--mode','full'],home:['permissions','request','--home'],revoke:['permissions','revoke'],status:['permissions','status']};
 return outside(ctx,screen,c,commands[choice.item.id]);
}

async function chooseEngine(ctx, screen, c, shell) {
  const current = ctx.config.engine==='hermes'&&!ctx.config.fallbackEngineEnabled?'koder':ctx.config.engine||'koder';
  const hermes = { ...HERMES_ENGINE, ...(ctx.config.engines?.hermes || {}) };
  const found = Boolean(which(hermes.command, ctx.env));
  const items = [
    { label: c.koder, id: "koder", value: current === "koder" ? c.current : "", hint: c.engineKoderHint, tone: current === "koder" ? "ok" : undefined },
    { label: "Hermes", id: "hermes", disabled: !ctx.config.fallbackEngineEnabled, value: ctx.config.fallbackEngineEnabled?(current === "hermes" ? c.current : found ? c.installed : c.notInstalled):(ctx.lang==='en'?'Disabled fallback':'备用 · 未启用'), hint: ctx.lang==='en'?'Koder adapts the configured API directly. The fallback is disabled by default.':'Koder 直接适配所配置的接口。备用引擎默认关闭，不会自动切换。', tone: 'text3' },
    ...Object.keys(ctx.config.engines || {}).filter((id) => id !== "hermes").map((id) => ({ label: id, id, value: current === id ? c.current : "" })),
  ];
  const picked = await select(screen, { title: c.engineTitle, items, index: Math.max(0, items.findIndex((item) => item.id === current)), footer: c.footer });
  if (!picked || picked.quit) return picked;
  if (picked.item.id === "hermes" && !found) {
    if (isWindowsShell(shell)) return notice(screen, { title: "Hermes", lines: [c.hermesWindows], footer: c.anyKey }).then(() => null);
    const next = await select(screen, { title: "Hermes", items: [{ label: c.installNow, id: "install", hint: c.installHint }, { label: c.back, id: "back" }], footer: c.footer });
    if (!next || next.quit || next.item.id === "back") return next?.quit ? next : null;
    await outside(ctx, screen, c, ["engine", "install", "hermes"]);
    const { loadConfig } = await import("../config.mjs");
    Object.assign(ctx.config, loadConfig(ctx.env));
    if (!ctx.config.engines?.hermes) return null;
  }
  ctx.config.engine = picked.item.id;
  saveConfig({ engine: picked.item.id }, ctx.env);
  return null;
}

async function chooseGateway(ctx, screen, c) {
  for (;;) {
    const config = loadGateway(ctx.env);
    const state = loadState(ctx.env);
    const running = state && pidAlive(state.pid);
    const lang = ctx.lang === "en" ? "en" : "zh";
    const items = [];
    for (const id of PLATFORMS) {
      const { meta } = await loadPlatform(id);
      const entry = config.platforms?.[id];
      const live = running ? state.platforms?.[id] : null;
      const connected = live?.state === "connected" && entry?.enabled !== false;
      const value = !entry ? c.gwOff : entry.enabled === false ? c.gwPaused : connected ? c.gwOn : live?.detail || ctx.t("gw.configured");
      items.push({ label: meta.name[lang], id, value, tone: connected ? "ok" : undefined, hint: meta.steps[lang] });
    }
    items.push({ label: c.gwStart, id: "start", hint: c.gwStartHint }, { label: c.back, id: "back" });
    const picked = await select(screen, { title: c.gwTitle, items, footer: c.footer });
    if (!picked || picked.quit || picked.item.id === "back") return picked?.quit ? picked : null;
    if (picked.item.id === "start") { await outside(ctx, screen, c, ["gateway", "start", "--background"]); continue; }
    const id = picked.item.id;
    const { meta } = await loadPlatform(id);
    let options = [];
    if (meta.qr) {
      const methods = [
        { label: lang === "zh" ? "扫码连接（推荐）" : "Connect by QR code (recommended)", id: "qr", hint: lang === "zh" ? "用手机确认，机器人凭据会自动保存到本机。" : "Confirm on your phone. Bot credentials are saved on this computer." },
        { label: lang === "zh" ? "手动填写机器人凭据" : "Enter bot credentials manually", id: "manual", hint: meta.steps[lang] },
        ...(config.platforms[id] ? [{ label: lang === "zh" ? "连接已保存的机器人" : "Connect the saved bot", id: "saved" }] : []),
        { label: c.back, id: "back" },
      ];
      const method = await select(screen, { title: `${c.gwTitle} · ${meta.name[lang]}`, items: methods, footer: c.footer });
      if (!method || method.quit || method.item.id === "back") continue;
      options = method.item.id === "manual" ? ["--manual"] : method.item.id === "qr" ? ["--qr"] : [];
    }
    await outside(ctx, screen, c, ["gateway", "connect", id, ...options]);
  }
}

async function chooseEditor(ctx, screen, c, shell) {
  for (;;) {
    const names = { zed: "Zed", nvim: "Neovim（CodeCompanion）", emacs: "Emacs（agent-shell）" };
    const items = Object.keys(SNIPPETS).map((id) => ({ label: ctx.lang === "en" ? names[id].replace("（", " (").replace("）", ")") : names[id], id, value: snippetFor(id, { lang: ctx.lang, shell }).file }));
    items.push({ label: c.back, id: "back" });
    const picked = await select(screen, { title: c.editorTitle, items, footer: c.footer });
    if (!picked || picked.quit || picked.item.id === "back") return picked?.quit ? picked : null;
    const snippet = snippetFor(picked.item.id, { lang: ctx.lang, shell });
    const action = await select(screen, { title: `${c.editorTitle} · ${picked.item.label}`, header: [snippet.file, snippet.note, "", ...snippet.code.split("\n")], items: [{ label: c.copy, id: "copy", hint: c.copyHint }, { label: c.back, id: "back" }], footer: c.footer });
    if (action?.quit) return action;
    if (action?.item.id === "copy") {
      const tool = copyText(ctx, snippet.code);
      await notice(screen, { title: c.editorTitle, lines: [tool ? { text: c.copied(snippet.file), tone: "ok" } : { text: c.copyFailed, tone: "warn" }], footer: c.anyKey });
    }
  }
}

async function chooseApps(ctx,screen,c) {
  const en=ctx.lang==='en';
  const picked=await select(screen,{title:en?'Applications and MCP':'应用与 MCP',header:[en?'Connections share submitted data with third parties. Review authorization, fees and local MCP programs before enabling.':'连接会向第三方提交所选数据；启用前核对服务授权、费用及本地MCP程序。'],items:[{id:'list',label:en?'Connections and diagnostics':'连接与诊断',hint:'koder apps'},{id:'gamma',label:'Gamma',hint:en?'API key or OAuth setup':'API Key 或 OAuth 配置'},{id:'mcp',label:'MCP',hint:'koder mcp list / import / enable / test'}],footer:c.footer});
  if(picked?.item)await outside(ctx,screen,c,picked.item.id==='gamma'?['apps','connect','gamma']:picked.item.id==='mcp'?['mcp','list']:['apps']);
}

export async function run(ctx) {
  if(ctx.positionals[0]==='apps'){const {run}=await import('./apps.mjs');return run({...ctx,positionals:ctx.positionals.slice(1)});}
  if(ctx.positionals[0]==='memory'){const {runPersonalization}=await import('./personalization.mjs');return runPersonalization(ctx,['personalization','status']);}
  const c0 = copyFor(ctx);
  if (!ctx.stdin.isTTY || !ctx.stdout.isTTY) {
    ctx.stdout.write(`${c0.nonInteractive}\n`);
    return 0;
  }
  const shell = detectShell({ env: ctx.env, platform: ctx.io.platform || process.platform });
  const screen = createScreen({ input: ctx.stdin, output: ctx.stdout, depth: ctx.depth, ascii: useAscii(ctx) });
  const handlers = { lang: chooseLang, theme: chooseTheme, glyphs: chooseGlyphs, anim: chooseAnim, model: chooseModel, context: chooseContext, personalization: choosePersonalization, permissions: choosePermissions, apps: chooseApps, engine: chooseEngine, gateway: chooseGateway, editor: chooseEditor };
  let index = null;
  screen.start();
  try {
    for (;;) {
      const c = copyFor(ctx);
      Object.assign(screen, { searchLabel: c.search, searchHint: c.searchHint, emptyLabel: c.empty });
      const items = await menuItems(ctx, c, shell);
      index ??= items[1].tone === "warn" ? 1 : 0;
      const picked = await select(screen, { title: `${c.title} · KODER CLI v${ctx.version}`, header: [c.intro(shellName(shell, ctx.lang))], items, index, footer: c.mainFooter });
      if (!picked || picked.quit || picked.item.id === "done") break;
      index = picked.index;
      const id = picked.item.id;
      let result = null;
      if (handlers[id]) result = await handlers[id](ctx, screen, c, shell);
      else if (id === "learn") await outside(ctx, screen, c, ["learn"]);
      else if (id === "doctor") await outside(ctx, screen, c, ["doctor"]);
      else if (id === "consent") await outside(ctx, screen, c, ["eula"]);
      else if (["celebrate","privacy","feedback"].includes(id)) await outside(ctx,screen,c,[id]);
      if (result?.quit) break;
    }
  } finally {
    screen.stop();
  }
  ctx.config.setupDone = true;
  saveConfig({ setupDone: true }, ctx.env);
  ctx.stdout.write(`${copyFor(ctx).bye}\n`);
  return 0;
}
