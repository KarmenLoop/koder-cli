// Existing lesson IDs stay stable. Revision 3 adds optional consumer chapters
// before graduation; graduates of revision 1 still start at the consent intake.
export const TUTORIAL_REVISION = 3;
export const NEW_LESSON = 23;
export function tutorialUpdated(saved) {
  return Boolean(saved?.done && (saved.revision || 1) < TUTORIAL_REVISION);
}
export function resumeLesson(saved) {
  return tutorialUpdated(saved) ? (saved.revision||1)<2?17:NEW_LESSON : saved?.done ? null : saved?.lesson || null;
}
