const L=(zh,en)=>({zh,en});
export const CONSUMER_LESSONS=[
 {id:'subscription-routes',title:L('套餐不串门：阿里与火山的正确入口','Keep the right door open: Alibaba and Volcano plans'),beats:[
  {say:L('套餐密钥不是万能门卡。阿里云 Token Plan、Coding Plan 和按量付费是独立通道；火山 Coding Plan 也有单独的地址。Koder 把它们分开列出，不会偷偷换到另一条计费路线。','A subscription key is not an all-access pass. Alibaba Token Plan, Coding Plan, and metered APIs are separate routes. Volcano Coding Plan has its own endpoint too. Koder lists them separately and never quietly changes the billing route.')},
  {code:'koder model presets\nkoder model models aliyun-token-plan\nkoder model models aliyun-coding-plan\nkoder model models volcano-coding-plan\nkoder model models kimi-code'},
  {tip:L('设置里先选对应套餐，再选型号，最后输入该套餐的密钥。型号、地区和当前席位必须由你的控制台确认；这里的列表不是赠送额度。','In setup, choose the exact plan, then a model, then that plan’s key. Your console decides model access, region, and seat availability. A listing is not free credit.')},
  {joke:L('门牌号写对，比对着 401 多喊几声“开门”管用。','The right address works better than asking a 401 to open up.')},
 ]},
 {id:'mimo-tool-check',title:L('小米体检：能聊天，还要会交工具作业','MiMo checkup: a reply is only the first step'),beats:[
  {say:L('MiMo 的按量付费与 Token Plan 也不能混用密钥。已经配置好模型后，先检查文字，再明确选择工具续答测试。下面命令会真实请求你的 API，可能产生费用；教程只展示，不替你执行。','MiMo metered and Token Plan credentials are separate too. Once configured, check text, then explicitly choose a tool round trip. The commands below make real requests to your API and may cost money. This lesson displays them without running them.')},
  {code:'koder model show\nkoder model test\nkoder model test --tools'},
  {tip:L('旧会话说“你好”只该开启当前问候，不该把几百条历史里的旧任务重新开工。想开始新话题可用 /new；想继续旧任务，请说清楚继续哪一项。原始历史不会因为一次问候被删除。','A hello in an old session should be a hello, not a restart of a task buried in hundreds of messages. Use /new for a new topic, or name the task you want to resume. A greeting does not erase saved history.')},
 ]},
 {id:'privacy-paper-trail',title:L('隐私文件带在包里，断网也能看','Privacy paperwork, even with the Wi-Fi off'),beats:[
  {say:L('隐私不该是一条打不开的链接。CLI 的完整条款、简明声明，以及官网消费者原始全文，都随包提供。CLI 配置文件和桌面加密密钥库不同，说明会分别讲清。','Privacy should be more than a link that will not load. Full CLI terms, a plain-language statement, and the complete official consumer originals ship with the package. CLI configuration files and the desktop encrypted key store are explained separately.')},
  {code:'koder privacy consumer\nkoder privacy statement\nkoder privacy desktop\nkoder privacy agreement\nkoder privacy sources'},
  {tip:L('这几条只读取本机文件，不需要 API Key。接受许可不会顺手开启学习、同步、音乐、IP 查询或电脑权限。','These commands read local files and need no API key. Accepting the license does not turn on learning, sync, music, IP lookup, or computer grants.')},
 ]},
 {id:'feedback-desk',title:L('找得到人：反馈不是把密钥打包寄来','A real feedback address, without the secrets'),beats:[
  {say:L('对话里明确说“我要反馈”或“怎么联系官方”，Koder 会给你邮箱和空白模板。它不会自动发送，也不会把聊天历史、API Key 或私人路径塞进附件。','Say “I want to give feedback” or “How do I contact support?” and Koder provides an email address and blank template. It does not send the email or attach chat history, keys, or private paths.')},
  {code:'koder feedback'},
  {joke:L('可以吐槽，欢迎复现步骤。密钥就免礼了，我们真不收。','Complaints are welcome. Reproduction steps are even better. Please keep the keys.')},
 ]},
 {id:'celebration-corner',title:L('六秒钟的快乐，随时可以散场','Six seconds of fun, with an exit right there'),beats:[
  {say:L('代码雨、礼花、烟花、圣诞树、南瓜灯、国庆灯笼、跨年与生日，都在彩蛋菜单里。动画约六秒，任意键立即跳过；不支持动画的终端只显示文字。普通命令、JSON 和脚本输出不会被刷屏。','Code rain, confetti, fireworks, a Christmas tree, Halloween pumpkins, National Day lanterns, New Year, and birthdays live in one optional menu. Effects last about six seconds; any key skips. Terminals without animation support get text. Ordinary commands, JSON, and scripts stay clean.')},
  {code:'koder celebrate\nkoder celebrate fireworks\nkoder celebrate auto notice\nkoder celebrate auto off'},
  {tip:L('默认在已收录节日显示一次祝福，选择 auto on 才自动播放动画。地区日历和农历节日按本机日期识别；自己的纪念日可添加，之后每年自动出现。','By default, a supported holiday gets one greeting. Choose auto on for automatic effects. Regional and lunar holidays follow the local date; add your own annual occasion when it is not on the calendar.')},
  {code:'koder celebrate custom --date 03-14 --name "Our day"'},
 ]},
 {id:'birthday-choice',title:L('记住一小格生日，不建立人生档案','Remember a birthday, not a dossier'),beats:[
  {say:L('你可以在对话里明确说“记住我的生日是三月十四日”，或使用下面的数字日期。只保存月日，不索要出生年份或年龄。普通提及会先给你选择，他人生日不会变成你的生日。教程不会替你保存示例日期。','You can explicitly ask Koder to remember your birthday, or use a month and day below. It does not ask for a birth year or age. A casual mention offers a choice; someone else’s birthday never becomes yours. The tutorial does not save the example date.')},
  {code:'koder celebrate birthday --date 03-14\nkoder celebrate birthday forget'},
  {tip:L('生日设置不会自动进入模型或同步。你在普通消息里主动输入的内容，仍按所选模型的正常对话规则处理。','Birthday settings are not automatically included in model requests or sync. Information you type in an ordinary message still follows that model conversation’s normal data rules.')},
 ]},
 {id:'music-and-locale',title:L('生日歌先问一句，语言由你做主','A birthday song, and a language you choose'),beats:[
  {say:L('音乐和 IP 辅助地区默认关闭，分别确认。开启音乐后，生日使用对话时最多自动打开一个浏览器页；本地旋律无需登录。浏览器不让自动播放时，点播放即可。关闭页面不会影响工作。','Music and IP country lookup are off by default and confirmed separately. Enabled birthday music opens at most one automatic browser tab when you use chat that day. The local melody needs no sign-in. If autoplay is blocked, press Play. Closing the page does not affect work.')},
  {code:'koder celebrate music on\nkoder celebrate music off\nkoder celebrate locale --language en\nkoder celebrate locale --language auto\nkoder celebrate locale --ip'},
  {tip:L('手动语言优先，其次是你主动开启的本地常用语言计数，IP 只作弱提示。IP 查询会让 ipapi.co 看到公网地址；选外部音乐平台会把访问数据交给该平台。每一步都能回车跳过。','Your chosen language comes first, then explicitly enabled local language counts. IP is only a weak hint. Country lookup exposes your public address to ipapi.co; an external music service receives its own visit data. Enter skips each choice.')},
  {joke:L('蛋糕可以多切一块。权限按需给就好。','A second slice of cake is fine. Permissions can stay small.')},
 ]},
];
