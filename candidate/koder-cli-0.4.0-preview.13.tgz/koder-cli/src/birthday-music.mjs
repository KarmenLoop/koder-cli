import crypto from 'node:crypto';
import {execFile} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {writePrivate,claimPrivate} from './private-state.mjs';
import {localDate,OCCASIONS} from './occasions.mjs';

export function musicSearch(language='zh',service='local') {
 if(service==='qq')return 'https://y.qq.com/n/ryqq/search?w='+encodeURIComponent(language==='zh'?'生日快乐歌':'Happy Birthday song');
 if(service==='youtube')return 'https://music.youtube.com/search?q='+encodeURIComponent(language==='zh'?'生日快乐歌':'Happy Birthday song');
 return null;
}
export function birthdayPage(language='zh') {
 const en=language==='en',wish=OCCASIONS.find(o=>o.id==='birthday').blessing[en?'en':'zh'];
 const css='*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#101622;color:#f3f0ea;font:18px/1.7 system-ui}main{max-width:680px;padding:48px}h1{font-size:clamp(40px,8vw,72px);line-height:1.1;color:#ffd479}p{white-space:pre-line}button,a{display:inline-block;padding:12px 18px;margin:8px 8px 0 0;border:1px solid #7ca6ff;border-radius:14px;background:#1e304b;color:#fff;text-decoration:none;font:inherit}small{display:block;color:#b0bbcb;margin-top:24px}.star{display:inline-block;color:#ffd479;animation:float 6s cubic-bezier(.77,0,.175,1) 1}@keyframes float{50%{transform:translateY(-12px) rotate(8deg)}}@media(prefers-reduced-motion:reduce){.star{animation:none}}';
 const script=`const button=document.querySelector('button'),status=document.querySelector('#status');let audio,busy=false,attempt=0,ending;const melody=[[67,.25],[67,.25],[69,.5],[67,.5],[72,.5],[71,1],[67,.25],[67,.25],[69,.5],[67,.5],[74,.5],[72,1],[67,.25],[67,.25],[79,.5],[76,.5],[72,.5],[71,.5],[69,1],[77,.25],[77,.25],[76,.5],[72,.5],[74,.5],[72,1]];async function play(){if(busy)return;const own=++attempt;try{audio??=new(window.AudioContext||window.webkitAudioContext)();await audio.resume();if(own!==attempt)return;if(audio.state!=='running'){status.textContent=${JSON.stringify(en?'Your browser needs a click before music can play.':'浏览器需要你点一下，音乐才会开始。')};return;}busy=true;button.disabled=true;let t=audio.currentTime+.1;for(const[n,d]of melody){const o=audio.createOscillator(),g=audio.createGain();o.type='triangle';o.frequency.value=440*Math.pow(2,(n-69)/12);o.connect(g);g.connect(audio.destination);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.12,t+.02);g.gain.exponentialRampToValueAtTime(.001,t+d*.52);o.start(t);o.stop(t+d*.55);t+=d*.58;}status.textContent=${JSON.stringify(en?'Happy Birthday — a locally generated instrumental melody.':'生日快乐——正在播放本机生成的生日旋律。')};clearTimeout(ending);ending=setTimeout(()=>{busy=false;button.disabled=false},Math.max(0,(t-audio.currentTime)*1000));}catch{status.textContent=${JSON.stringify(en?'Audio is unavailable here. The music-service links below still work.':'当前浏览器无法播放本地音频，可以使用下面的音乐平台链接。')}}}button.addEventListener('click',play);document.querySelector('#stop').addEventListener('click',()=>{attempt++;clearTimeout(ending);audio?.close();audio=null;busy=false;button.disabled=false;status.textContent=${JSON.stringify(en?'Music stopped.':'音乐已停止。')}});void play();`;
 const hash=s=>crypto.createHash('sha256').update(s).digest('base64');
 const csp=`default-src 'none'; style-src 'sha256-${hash(css)}'; script-src 'sha256-${hash(script)}'; connect-src 'none'; base-uri 'none'; form-action 'none'`;
 const escape=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 return '<!doctype html><html lang="'+(en?'en':'zh-CN')+'"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="'+escape(csp)+'"><title>'+(en?'Happy birthday · KARMEN LOOP':'生日快乐 · KARMEN LOOP')+'</title><style>'+css+'</style><main><span class="star">✦ ✧ ✦</span><h1>'+(en?'Happy birthday.':'生日快乐。')+'</h1><p>'+escape(wish)+'</p><button type="button">'+(en?'Play birthday music':'播放生日快乐音乐')+'</button><button type="button" id="stop">'+(en?'Stop':'停止')+'</button><p id="status">'+(en?'If autoplay is blocked, press Play.':'如自动播放被拦截，请点播放。')+'</p><a rel="noreferrer noopener" target="_blank" href="'+escape(musicSearch(language,en?'youtube':'qq'))+'">'+(en?'Find a song on YouTube Music':'在 QQ 音乐查找生日歌')+'</a><small>'+(en?'The melody is generated on this computer. Opening a music service shares your network address with that service. You can close this tab at any time.':'旋律在本机生成。点击音乐平台链接后，该平台会收到你的网络地址。随时关闭页面即可。')+'</small></main><script>'+script+'</script></html>';
}
function browser(url) {
 const command=process.platform==='darwin'?'open':process.platform==='win32'?'rundll32.exe':'xdg-open';
 const args=process.platform==='win32'?['url.dll,FileProtocolHandler',url]:[url];
 return new Promise(resolve=>execFile(command,args,{timeout:5000,windowsHide:true},error=>resolve(!error)));
}
export async function birthdayMusic(ctx,{date=new Date(),preferences={},manual=false}={}) {
 if(!preferences.musicEnabled)return {state:'disabled'};
 if(!manual&&!claimPrivate('music-birthday-'+localDate(date),ctx.env))return {state:'already-offered'};
 const language=preferences.resolvedLanguage||ctx.lang;
 const local=pathToFileURL(writePrivate('birthday.html',birthdayPage(language),ctx.env)).href;
 const url=musicSearch(language,preferences.musicService)||local;
 const opened=await (ctx.io.openBrowser||browser)(url);
 return {state:opened===false?'browser-unavailable':'browser-open-requested',playback:'browser-controlled',local:!musicSearch(language,preferences.musicService)};
}
