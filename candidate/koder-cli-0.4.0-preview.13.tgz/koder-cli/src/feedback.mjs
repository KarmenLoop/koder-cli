import os from 'node:os';
import {OFFICIAL,aboutText} from './official.mjs';
export function wantsFeedback(text) {
 const s=String(text).trim().slice(0,1200);if(!s||/^(?:请)?(?:帮我)?(?:添加|实现|开发|写)|\b(?:implement|build|add (?:a |the )?(?:feedback|support))\b/i.test(s))return false;
 return /(?:我要|我想|如何|怎么|哪里|向你们|官方).{0,12}(?:反馈|投诉|报错|联系)|(?:反馈|投诉|联系官方)(?:一下|渠道|入口|邮箱|邮件|问题)?[。？！!?\s]*$|\b(?:I (?:want|need|would like) to (?:report|give feedback|contact support)|how (?:do|can) I (?:report|contact)|report (?:a |this )?bug|contact (?:your )?support|feedback (?:email|address))\b/i.test(s);
}
export function wantsInternalSource(text) {
 const s=String(text).trim();return s.length<240&&/(?:Koder|KARMEN\s*LOOP|你们(?:的)?内核|你的内核)/i.test(s)&&/(?:源码|源代码|内部提示词|系统提示词|api\s*key|private source|kernel source|system prompt)/i.test(s)&&/(?:展示|给我|打印|泄露|输出|发给|show|give|print|reveal|dump)/i.test(s);
}
export function feedbackText(ctx) {
 const en=ctx.lang==='en';return [
  en?`Send feedback to ${OFFICIAL.email}. Nothing is sent automatically.`:`反馈邮箱：${OFFICIAL.email}。Koder 不会自动发送邮件。`,
  en?'Subject: Koder feedback':'邮件主题：Koder 使用反馈',
  `Koder: ${ctx.version}`,
  `${en?'System':'系统'}: ${os.platform()} ${os.arch()}`,
  en?'What happened:\nWhat you expected:\nSteps to reproduce:':'遇到的情况：\n希望的结果：\n复现步骤：',
  en?'Before sending, remove API keys, passwords, chat history, personal file paths, and other private content. Attach only the redacted error lines you choose.':'发送前请移除 API Key、密码、聊天历史、个人路径及其他私人内容，只附上你选定且已脱敏的错误行。',
 ].join('\n');
}
export function publicIntroduction(ctx) {return aboutText(ctx.lang)+'\n'+(ctx.lang==='en'?'This overview describes public capabilities. Private implementation and credentials are not included.':'这里只介绍公开能力，不展示内部实现或凭据。');}
