const occasion=(id,zh,en,effect,zhWish,enWish)=>({id,zh,en,effect,blessing:{zh:zhWish+'\n—— KARMEN LOOP 团队',en:enWish+'\n— The KARMEN LOOP team'}});
export const OCCASIONS=[
 occasion('new-year','元旦','New Year','new-year','新年快乐！愿新的一年有好消息，也有按自己节奏生活的底气。','Happy New Year. May the year ahead bring good news and more time for what matters to you.'),
 occasion('spring-festival','春节','Lunar New Year','fireworks','新春快乐！愿饭桌有热气，身边有牵挂，日子越过越有盼头。','Happy Lunar New Year. Wishing you a warm table, good company, and a year full of possibilities.'),
 occasion('lantern','元宵节','Lantern Festival','national','元宵快乐！愿灯火照见归途，也照亮想去的地方。','Happy Lantern Festival. May the lights lead you home and brighten the road ahead.'),
 occasion('dragon-boat','端午节','Dragon Boat Festival','confetti','端午安康！忙里记得吃口粽子，也给自己留一点慢下来的时间。','Wishing you a peaceful Dragon Boat Festival, a good meal, and a well-earned pause.'),
 occasion('mid-autumn','中秋节','Mid-Autumn Festival','fireworks','中秋快乐！愿抬头有月，身边有人，远方的牵挂也能好好抵达。','Happy Mid-Autumn Festival. Here is to good company, a bright moon, and feeling close even across the miles.'),
 occasion('national-day','国庆节','National Day holiday','national','国庆假期快乐！愿风景值得奔赴，休息不必内疚，好心情准时抵达。','Enjoy the National Day holiday. Wishing you a change of scenery, a proper rest, and a little room to wander.'),
 occasion('halloween','万圣节','Halloween','halloween','万圣节快乐！今晚只许糖分超标，不许快乐欠费。','Happy Halloween. May your treats be plentiful and your surprises the good kind.'),
 occasion('christmas','圣诞节','Christmas','christmas','圣诞快乐！愿冬天有热饮，平常日子也有闪闪发光的小惊喜。','Merry Christmas. Wishing you warm company, small delights, and a little extra sparkle this winter.'),
 occasion('new-year-eve','跨年夜','New Year’s Eve','new-year','这一年辛苦了。把值得珍藏的带上，其余留给昨晚；新的一年，我们继续一起出发。','You made it through another year. Keep the good memories, leave a little weight behind, and step into the next one with us.'),
 occasion('thanksgiving','感恩节','Thanksgiving','confetti','感恩节快乐！愿你被善意记得，也有时间和重要的人好好吃顿饭。','Happy Thanksgiving. Wishing you a seat at a welcoming table and time with the people who matter.'),
 occasion('labour-day','劳动节','Labour Day','confetti','劳动节快乐！今天让待办清单喘口气，你也一样。','Enjoy Labour Day. Let the to-do list wait a little. You have earned a breather.'),
 occasion('birthday','生日','Birthday','birthday','生日快乐！愿新的一岁有热爱可奔赴，有好事在路上，也始终有做自己的自由。','Happy birthday. May the year ahead bring people you love, work you enjoy, and plenty of room to be yourself.'),
];
export function validBirthday(value) {
 if(typeof value!=='string'||!/^\d{2}-\d{2}$/.test(value))return false;
 const [m,d]=value.split('-').map(Number),date=new Date(2000,m-1,d);return date.getMonth()===m-1&&date.getDate()===d;
}
export function birthdayMention(text,date=new Date()) {
 let s=String(text).trim();if(s.length>240||/我(?:朋友|妈妈|爸爸|同事|女儿|儿子)|(?:friend|mother|father|son|daughter)'s birthday/i.test(s))return null;
 const number=value=>{const digits='零一二三四五六七八九';if(value==='两')return 2;if(value.includes('十')){const [a,b]=value.split('十');return (a?digits.indexOf(a):1)*10+(b?digits.indexOf(b):0);}return digits.indexOf(value);};
 s=s.replace(/([零一二三四五六七八九十两]{1,3})月([零一二三四五六七八九十两]{1,3})[日号]/g,(_,m,d)=>number(m)+'月'+number(d)+'日');
 if(/(?:不要|别|不必|不用|无需).{0,5}(?:记|保存)|(?:do not|don't|never).{0,12}(?:remember|save)/i.test(s))return null;
 const prefix='(?:(?:请|帮我|麻烦)?记住[：,:\\s]*)?';
 let m=new RegExp('^'+prefix+'我的生日(?:是|在)\\s*(\\d{1,2})\\s*月\\s*(\\d{1,2})\\s*[日号]?').exec(s);
 if(!m)m=/^(?:please\s+)?(?:remember(?: that)?\s+)?my birthday (?:is|falls on)\s+(\d{1,2})[\/-](\d{1,2})\b/i.exec(s);
 if(!m){const english=/^(?:please\s+)?(?:remember(?: that)?\s+)?my birthday (?:is|falls on)\s+([a-z]+)\s+(\d{1,2})\b/i.exec(s);if(english){const names=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'],month=names.indexOf(english[1].slice(0,3).toLowerCase())+1;if(month)m=[english[0],String(month),english[2]];}}
 if(!m&&/^(?:(?:请|帮我)?记住[：,:\s]*)?(今天|明天)(?:是)?我的生日[。！!\s]*$|^(?:remember\s+)?(?:today|tomorrow) is my birthday[.!\s]*$/i.test(s)){const d=new Date(date);if(/明天|tomorrow/i.test(s))d.setDate(d.getDate()+1);return {date:localDate(d).slice(5),explicit:/记住|remember/i.test(s)};}
 if(!m)return null;const monthDay=m.slice(1).map(v=>v.padStart(2,'0')).join('-');return validBirthday(monthDay)?{date:monthDay,explicit:/记住|remember/i.test(s)}:null;
}
export function localDate(date=new Date()) {return [date.getFullYear(),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-');}
export function occasionsOn(date=new Date(),{birthday,country='CN',custom=[]}={}) {
 const key=localDate(date).slice(5),ids=[];
 const fixed={'01-01':'new-year','05-01':'labour-day','10-31':'halloween','12-25':'christmas','12-31':'new-year-eve'};
 if(fixed[key])ids.push(fixed[key]);if(country==='CN'&&key==='10-01')ids.push('national-day');
 if(country==='US'&&date.getMonth()===10&&date.getDay()===4&&date.getDate()>=22&&date.getDate()<=28)ids.push('thanksgiving');
 try{const parts=new Intl.DateTimeFormat('en-u-ca-chinese',{month:'numeric',day:'numeric'}).formatToParts(date),month=parts.find(p=>p.type==='month')?.value,day=parts.find(p=>p.type==='day')?.value;
  const lunar={'1-1':'spring-festival','1-15':'lantern','5-5':'dragon-boat','8-15':'mid-autumn'};if(country==='CN'&&lunar[month+'-'+day])ids.push(lunar[month+'-'+day]);
 }catch{}
 // February 29 birthdays are celebrated on February 28 in non-leap years.
 if(birthday===key||(birthday==='02-29'&&key==='02-28'&&new Date(date.getFullYear(),1,29).getMonth()!==1))ids.push('birthday');
 const built=ids.map(id=>OCCASIONS.find(o=>o.id===id));
 return [...built,...custom.filter(o=>o&&validBirthday(o.date)&&o.date===key&&typeof o.name==='string').slice(0,8).map(o=>occasion('custom-'+o.date,o.name.slice(0,60),o.name.slice(0,60),'confetti','节日快乐！愿今天有值得记住的小美好。','Wishing you a lovely celebration and a day worth remembering.'))];
}
export function preferredLanguage({language,counts={},ui='zh',country}={}) {
 if(['zh','en'].includes(language))return language;
 if(Math.max(counts.zh||0,counts.en||0)>=3)return (counts.en||0)>(counts.zh||0)?'en':'zh';
 if(['zh','en'].includes(ui))return ui;
 return ['CN','TW','HK','MO'].includes(country)?'zh':'en';
}
