import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {cliHome} from './config.mjs';

const modes=['auto','ask','full','deny'];
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const host=()=>hash([process.platform,os.hostname(),os.userInfo().uid]);
const fail=code=>{throw Object.assign(new Error(code),{code});};
const keyFor=root=>hash(process.platform==='win32'?root.toLowerCase():root);
const canonical=root=>fs.realpathSync(path.resolve(root));
const inside=(root,target)=>{const r=path.relative(root,target);return !r||r!=='..'&&!r.startsWith('..'+path.sep)&&!path.isAbsolute(r);};
const fileFor=env=>path.join(cliHome(env),'execution-permissions.json');
const blank=()=>({version:1,host:host(),profile:{mode:'auto'},workspaces:{},rules:[]});
function directory(env,create=false){const dir=cliHome(env);if(create)fs.mkdirSync(dir,{recursive:true,mode:0o700});const s=fs.lstatSync(dir,{throwIfNoEntry:false});if(s&&(!s.isDirectory()||s.isSymbolicLink()))fail('EXECUTION_PERMISSIONS_UNSAFE');return dir;}
export function readExecutionPermissions(env=process.env){
 directory(env);let fd;
 try{
  const leaf=fs.lstatSync(fileFor(env));if(!leaf.isFile()||leaf.isSymbolicLink())fail('EXECUTION_PERMISSIONS_INVALID');
  fd=fs.openSync(fileFor(env),fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0)|(fs.constants.O_NONBLOCK||0));const s=fs.fstatSync(fd);if(!s.isFile()||s.size>262144)fail('EXECUTION_PERMISSIONS_INVALID');
  if(s.dev!==leaf.dev||s.ino!==leaf.ino)fail('EXECUTION_PERMISSIONS_INVALID');
  const d=JSON.parse(fs.readFileSync(fd,'utf8'));
  if(d.version!==1||typeof d.host!=='string'||!modes.includes(d.profile?.mode)||!d.workspaces||Array.isArray(d.workspaces)||typeof d.workspaces!=='object'||Object.keys(d.workspaces).length>512||!Array.isArray(d.rules)||d.rules.length>256)fail('EXECUTION_PERMISSIONS_INVALID');
  for(const [key,value] of Object.entries(d.workspaces))if(!/^[a-f0-9]{64}$/.test(key)||!modes.includes(value?.mode)||typeof value.path!=='string')fail('EXECUTION_PERMISSIONS_INVALID');
  for(const r of d.rules)if(!r||!/^[a-f0-9]{64}$/.test(r.id)||!/^[a-f0-9]{64}$/.test(r.signature)||!(r.workspace==='*'||/^[a-f0-9]{64}$/.test(r.workspace))||typeof r.label!=='string'||r.label.length>160||!Number.isFinite(r.createdAt))fail('EXECUTION_PERMISSIONS_INVALID');
  return d.host===host()?d:blank();
 }catch(e){if(e.code==='ENOENT')return blank();fail('EXECUTION_PERMISSIONS_INVALID');}finally{if(fd!==undefined)fs.closeSync(fd);}
}
function update(env,change,{reset=false}={}){
 const dir=directory(env,true),lock=path.join(dir,'.execution-permissions.lock');let fd;
 try{fd=fs.openSync(lock,'wx',0o600);}catch(e){if(e.code==='EEXIST')fail('EXECUTION_PERMISSIONS_BUSY');throw e;}
 const temp=path.join(dir,'.execution-permissions.'+crypto.randomUUID());
 try{
  const d=reset?blank():readExecutionPermissions(env),next=change(d)||d,s=fs.lstatSync(fileFor(env),{throwIfNoEntry:false});if(s&&(!s.isFile()||s.isSymbolicLink()))fail('EXECUTION_PERMISSIONS_UNSAFE');
  if(next.rules.length>256||Object.keys(next.workspaces).length>512)fail('EXECUTION_PERMISSIONS_LIMIT');
  fs.writeFileSync(temp,JSON.stringify(next,null,2)+'\n',{flag:'wx',mode:0o600});fs.renameSync(temp,fileFor(env));fs.chmodSync(fileFor(env),0o600);return next;
 }finally{try{fs.unlinkSync(temp);}catch{}fs.closeSync(fd);fs.unlinkSync(lock);}
}
export function setExecutionMode(mode,{env=process.env,workspace,scope='workspace'}={}){
 if(!modes.includes(mode)||!['workspace','profile'].includes(scope))fail('EXECUTION_POLICY_INVALID');const root=canonical(workspace);
 return update(env,d=>{if(scope==='profile'){d.profile.mode=mode;d.workspaces={};}else d.workspaces[keyFor(root)]={path:root,mode};});
}
export function resetExecutionPermissions(env=process.env){return update(env,()=>blank(),{reset:true});}
export function executionStatus({env=process.env,workspace}={}){
 const d=readExecutionPermissions(env),root=canonical(workspace),key=keyFor(root);return {mode:d.workspaces[key]?.mode||d.profile.mode,scope:d.workspaces[key]?'workspace':'profile',workspace:root,profileMode:d.profile.mode,rules:d.rules.filter(r=>r.workspace==='*'||r.workspace===key).map(({id,label,createdAt,workspace})=>({id,label,createdAt,scope:workspace==='*'?'profile':'workspace'}))};
}
export function revokeExecutionRule(id,{env=process.env,workspace}={}){
 const key=keyFor(canonical(workspace));return update(env,d=>{if(id==='all'){d.rules=d.rules.filter(r=>r.workspace!==key&&r.workspace!=='*');d.workspaces[key]={path:canonical(workspace),mode:'auto'};}else d.rules=d.rules.filter(r=>r.id!==id);});
}

function tokenize(command){
 const words=[];let text='',quote=null,started=false;
 for(const c of command){if(quote){if(c===quote)quote=null;else text+=c;started=true;}else if(c==='"'||c==="'"){quote=c;started=true;}else if(/\s/.test(c)){if(started){words.push(text);text='';started=false;}}else{text+=c;started=true;}}
 if(quote)return null;if(started)words.push(text);return words;
}
const sensitivePath=text=>/(?:^|[\/\\\s"'])\.env(?:[.\/\\\s"']|$)|(?:^|[\/\\])(?:\.ssh|\.aws|\.gnupg|\.git|credentials?|secrets?|passwords?|execution-permissions\.json)(?:[.\/\\\s]|$)|(?:^|[\/\\])(?:etc|System32|Windows|Library)(?:[\/\\]|$)/i.test(text);
function programShadowed(program,root,env){
 const name=path.basename(program).toLowerCase(),windows=process.platform==='win32';
 if(windows&&['.exe','.cmd','.bat','.com',''].some(ext=>fs.existsSync(path.join(root,name+ext))))return true;
 let explicit=null;
 if(program.includes('/')||program.includes('\\')){try{explicit=fs.realpathSync(path.resolve(root,program));if(inside(root,explicit))return true;if(explicit===fs.realpathSync(process.execPath))return false;}catch{return true;}}
 for(const dir of String(env.PATH||'').split(path.delimiter)){
  if(!dir)return true;
  for(const ext of windows?['.exe','.com','.cmd','.bat','']:['']){const p=path.resolve(root,dir,(explicit?path.basename(program):program)+ext);if(fs.existsSync(p)){try{const resolved=fs.realpathSync(p);return inside(root,resolved)||Boolean(explicit&&explicit!==resolved);}catch{return true;}}}
 }
 return Boolean(explicit);
}
function commandRisk(command,root,env){
 if(typeof command!=='string'||!command.trim()||command.length>32768)return 'unknown';
 if(/[;&<>`\r\n$%!{}]/.test(command))return 'shell-effects';
 if(sensitivePath(command))return 'sensitive-files';
 const stages=command.split('|');
 for(const stage of stages){
  const words=tokenize(stage);if(!words?.length)return 'unknown';const [program,...args]=words,name=path.basename(program.replace(/\\/g,'/')).replace(/\.(?:exe|cmd|bat|com)$/i,'').toLowerCase();
  if(programShadowed(program,root,env))return 'project-executable';
  if(args.some(a=>/^(?:--(?:pre|exec|eval|output|upload|delete|ext-diff|textconv|paginate)|-(?:i|o)|\/c)(?:=|$)/i.test(a)))return 'command-effects';
  if(args.some(a=>['--follow','--dereference','-L','-R'].includes(a)))return 'indirect-files';
  for(const a of args){
   if(a.startsWith('-')||name==='dir'&&/^\/[a-z](?::[a-z]+)?$/i.test(a))continue;
   if(/[?*\[\]]/.test(a))return 'indirect-files';if(a.startsWith('~'))return 'outside-files';
   const target=path.resolve(root,a);if(!inside(root,target))return 'outside-files';
   try{const real=fs.realpathSync(target);if(!inside(root,real))return 'outside-files';if(sensitivePath(real))return 'sensitive-files';}catch(e){if(e.code!=='ENOENT')return 'indirect-files';}
  }
  if(['pwd','whoami','hostname'].includes(name)&&!args.length)continue;
  if(['node','python','python3','npm','pnpm','yarn','ruby','java'].includes(name)&&args.length===1&&['--version','-v','-V'].includes(args[0]))continue;
  if(['ls','dir','cat','type','head','tail','wc','rg','grep'].includes(name))continue;
  if(name==='git'&&['status','diff','log','show','ls-files','rev-parse'].includes(args[0])){
   // Git can launch configured helpers even for status/diff. Unknown global,
   // ancestor-repository and submodule settings therefore need an owner choice.
   if(Object.keys(env).some(k=>k.startsWith('GIT_'))||fs.existsSync(path.join(os.homedir(),'.gitconfig'))||fs.existsSync(path.join(env.XDG_CONFIG_HOME||path.join(os.homedir(),'.config'),'git/config'))||fs.existsSync(path.join(root,'.gitmodules'))||!fs.existsSync(path.join(root,'.git')))return 'project-hooks';
   if(args[0]!=='status'&&fs.existsSync(path.join(root,'.gitattributes')))return 'project-hooks';
   const config=path.join(root,'.git','config');try{if(!fs.lstatSync(path.join(root,'.git')).isDirectory()||!inside(root,fs.realpathSync(config))||fs.statSync(config).size>65536||/\[include|fsmonitor|textconv|(?:external|command)\s*=/i.test(fs.readFileSync(config,'utf8')))return 'project-hooks';}catch(e){if(e.code!=='ENOENT')return 'project-hooks';}
   if(args.some(a=>/^--(?:output|ext-diff|textconv|paginate|exec-path|config-env)(?:=|$)/.test(a)))return 'command-effects';continue;
  }
  return 'code-or-external-effect';
 }
 return 'read-only';
}
export function classifyExecution(pause,{workspace,env=process.env}={}){
 const root=canonical(workspace);
 if(pause?.kind==='choice'||pause?.kind==='secret')return {sensitive:true,risk:'human-input'};
 if(pause?.kind==='change'){
  const p=path.resolve(root,String(pause.path||''));let risk=!inside(root,p)?'outside-files':sensitivePath(p)?'sensitive-files':pause.after===''&&pause.before?'deletion':'workspace-edit';
  let ancestor=p;while(!fs.existsSync(ancestor)&&path.dirname(ancestor)!==ancestor)ancestor=path.dirname(ancestor);
  try{if(!inside(root,fs.realpathSync(ancestor)))risk='outside-files';}catch{risk='indirect-files';}
  if(/(?:^|[\/\\])(?:package\.json|Makefile|Dockerfile|\.npmrc|\.yarnrc|\.gitconfig|[^\/\\]*\.(?:sh|ps1|cmd|bat))$/i.test(p))risk='execution-config';
  return {sensitive:risk!=='workspace-edit',risk};
 }
 const risk=pause?.toolName==='shell'?commandRisk(pause.command,root,env):'external-action';return {sensitive:risk!=='read-only',risk};
}
function signature(pause,risk){return hash(pause.kind==='change'?{kind:'change',path:pause.path,risk}:{kind:pause.kind,tool:pause.toolName||'unknown',command:pause.command,action:pause.action||null,risk});}
export function rememberExecution(pause,{env=process.env,workspace,scope='workspace',risk}={}){
 const root=canonical(workspace),key=scope==='profile'?'*':keyFor(root),sig=signature(pause,risk),id=hash([key,sig]);
 update(env,d=>{if(!d.rules.some(r=>r.id===id))d.rules.push({id,signature:sig,workspace:key,label:(pause.kind==='change'?'file edit':pause.toolName||'action')+' · '+risk,createdAt:Date.now()});});return id;
}
export function executionDecider(ctx,prompt,{workspace}={}){
 const root=canonical(workspace||ctx.workspace());
 return async(pause,thread)=>{
  if(pause.kind==='choice'||pause.kind==='secret')return prompt(pause,thread);
  const d=readExecutionPermissions(ctx.env),key=keyFor(root),mode=ctx.opts.approval||d.workspaces[key]?.mode||d.profile.mode;
  if(!modes.includes(mode))fail('EXECUTION_POLICY_INVALID');
  const assessment=classifyExecution(pause,{workspace:root});
  if(mode==='deny')return {accept:false,authorization:'deny',risk:assessment.risk};
  if(mode==='full')return {accept:true,authorization:'full',risk:assessment.risk};
  const sig=signature(pause,assessment.risk),rule=d.rules.find(r=>(r.workspace==='*'||r.workspace===key)&&r.signature===sig);
  if(rule)return {accept:true,authorization:'always',risk:assessment.risk,ruleId:rule.id};
  if(mode==='auto'&&!assessment.sensitive)return {accept:true,authorization:'smart',risk:assessment.risk};
  const decision=await prompt({...pause,risk:assessment.risk,permissionChoices:true},thread);
  if(!decision?.accept)return decision;
  if(decision.full){setExecutionMode('full',{env:ctx.env,workspace:root});return {...decision,authorization:'full',risk:assessment.risk};}
  if(decision.remember){const ruleId=rememberExecution(pause,{env:ctx.env,workspace:root,risk:assessment.risk});return {...decision,authorization:'always',risk:assessment.risk,ruleId};}
  return {...decision,authorization:'one-time',risk:assessment.risk};
 };
}
