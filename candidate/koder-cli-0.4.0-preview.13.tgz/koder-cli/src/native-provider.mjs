export const KIMI_CODE_PRESET={id:'kimi-code',name:'Kimi Code · 会员编程套餐',vendor:'Moonshot AI',region:'cn',model:'k3-256k',models:['k3-256k','k3','kimi-for-coding','kimi-for-coding-highspeed'],baseUrl:'https://api.kimi.com/coding/v1',protocol:'responses',auth:'bearer',contextWindow:262144,maxOutput:32768,checkedAt:'2026-10-20',verification:'Native protocol fixtures; membership and account access require verification',source:'https://www.kimi.com/code/docs/en/',detail:'Kimi Code 会员编程接口；使用套餐控制台密钥，不与 Moonshot 按量 API 混用。保持真实 KoderCLI 身份，不冒充其他客户端。',key:{url:'https://www.kimi.com/code/',steps:['打开 Kimi Code 控制台，创建会员编程 API Key','选择会员具备权限的 k3-256k、k3 或 kimi-for-coding 型号','国内使用 api.kimi.com，海外使用 api.kimi.ai；仅用于套餐允许的编程任务']}};
// Native controls are bound to official service hosts and documented routes.
// Proxy endpoints retain their own protocol and user-specified limits.
export function normalizeNativeProvider(record,raw={}) {
 const url=new URL(record.baseUrl),clean=url.pathname.replace(/\/(?:chat\/completions|responses|messages)\/?$/,'').replace(/\/+$/,'');
 const kimi=['api.moonshot.cn','api.moonshot.ai'].includes(url.hostname)&&['','/v1','/anthropic','/anthropic/v1'].includes(clean);
 const deepseek=url.hostname==='api.deepseek.com'&&['','/v1','/anthropic','/anthropic/v1'].includes(clean);
 const coding=['api.kimi.com','api.kimi.ai'].includes(url.hostname)&&['/coding','/coding/v1'].includes(clean);
 if(!kimi&&!deepseek&&!coding)return record;
 if(record.presetId==='kimi-code'&&kimi||record.presetId==='kimi'&&coding)throw new Error('KIMI_ENDPOINT_MISMATCH: Kimi Code membership and Moonshot API are separate products. Use the matching preset and key.');
 if(kimi&&record.protocol==='responses')throw new Error('NATIVE_PROTOCOL_MISMATCH: this Kimi API route requires Chat Completions or Anthropic Messages. Kimi Code has its own Responses route.');
 if(record.protocol==='anthropic'){
  if(coding){record.baseUrl=url.origin+'/coding';record.chatPath='/v1/messages';}
  else {if(!clean.startsWith('/anthropic'))throw new Error('NATIVE_PROTOCOL_MISMATCH: select the official /anthropic endpoint for Messages.');record.baseUrl=url.origin+'/anthropic';record.chatPath='/v1/messages';}
 }else if(clean.includes('/anthropic'))throw new Error('NATIVE_PROTOCOL_MISMATCH: use Anthropic Messages for this endpoint.');
 else if(coding)record.baseUrl=url.origin+'/coding/v1';
 const codeModels=KIMI_CODE_PRESET.models;
 if(coding&&!codeModels.includes(record.model))throw new Error('KIMI_CODE_MODEL_UNKNOWN: use k3, k3-256k, kimi-for-coding or kimi-for-coding-highspeed from the current membership console; no silent fallback was attempted.');
 if(coding&&/^kimi-k/.test(record.model)||kimi&&codeModels.includes(record.model))throw new Error('KIMI_MODEL_MISMATCH: Kimi Code uses k3/k3-256k/kimi-for-coding; Moonshot API uses its kimi-k model IDs.');
 if(deepseek&&['deepseek-chat','deepseek-reasoner'].includes(record.model))throw new Error('DEEPSEEK_MODEL_LEGACY: the current official API lists deepseek-flash and deepseek-v4-pro. Select a model your account supports; no model or billing route was switched automatically.');
 const k3=kimi&&record.model==='kimi-k3'||coding&&['k3','k3-256k'].includes(record.model),k2=kimi&&/^kimi-k2\.(?:5|6|7-code(?:-highspeed)?)$/.test(record.model),ds=deepseek&&['deepseek-flash','deepseek-v4-pro'].includes(record.model),code=coding&&codeModels.includes(record.model);
 if(!k3&&!k2&&!ds&&!code)return record;
 if(kimi&&!clean)record.baseUrl=url.origin+'/v1';
 if(raw.contextWindow==null)record.contextWindow=code?262144:k3?1048576:k2?262144:1000000;
 if(raw.maxOutput==null)record.maxOutput=32768;
 const levels=k3||code&&record.model!=='kimi-for-coding-highspeed'?['low','high','max']:ds?['off','low','high','max']:record.model==='kimi-k2.7-code'||record.model==='kimi-k2.7-code-highspeed'||record.model==='kimi-for-coding-highspeed'?[]:['off','low'];
 const effort=levels.includes(raw.reasoningEffort)?raw.reasoningEffort:levels.includes('low')?'low':undefined;
 record.spec={...record.spec,reasoning:true,levels,efforts:Object.fromEntries(levels.filter(x=>x!=='off').map(x=>[x,x])),compat:{...record.spec?.compat,requiresReasoning:true,maxTokensField:k3?'max_completion_tokens':'max_tokens',thinkingFormat:k3||code?'openai':'deepseek',supportsReasoningEffort:k3||ds||code,responsesReasoning:deepseek||coding,nativeAnthropicThinking:ds?'toggle':'effort-only',...(coding?{clientIdentity:'KoderCLI'}:{})}};
 if(effort!==undefined)record.reasoningEffort=effort;
 return record;
}
