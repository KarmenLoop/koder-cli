import readline from 'node:readline/promises';
import fs from 'node:fs';
import path from 'node:path';
import {readPrivate,writePrivate,claimPrivate} from './private-state.mjs';
import {privateDirectory} from './private-state.mjs';
import {EFFECTS,playCelebration} from './celebration-animation.mjs';
import {OCCASIONS,occasionsOn,preferredLanguage,validBirthday,birthdayMention,localDate} from './occasions.mjs';
import {birthdayMusic} from './birthday-music.mjs';

export function celebrationPreferences(env) {
 const raw=readPrivate('preferences.json',env,{}),p=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
 return {auto:['off','notice','on'].includes(p.auto)?p.auto:'notice',birthday:validBirthday(p.birthday)?p.birthday:null,
  musicEnabled:p.musicEnabled===true,musicService:['local','qq','youtube'].includes(p.musicService)?p.musicService:'local',
  language:['zh','en','auto'].includes(p.language)?p.language:'auto',learnLanguage:p.learnLanguage===true,
  counts:{zh:Number.isSafeInteger(p.counts?.zh)?Math.max(0,Math.min(1000,p.counts.zh)):0,en:Number.isSafeInteger(p.counts?.en)?Math.max(0,Math.min(1000,p.counts.en)):0},
  country:/^[A-Z]{2}$/.test(p.country||'')?p.country:null,custom:Array.isArray(p.custom)?p.custom.filter(o=>validBirthday(o?.date)&&typeof o?.name==='string').slice(0,32):[]};
}
function save(ctx,patch) {const next={...celebrationPreferences(ctx.env),...patch};writePrivate('preferences.json',next,ctx.env);return next;}
export async function askOptional(ctx,prompt) {
 if(ctx.io.prompter)return ctx.io.prompter.ask(prompt,{fresh:true});
 if(!ctx.stdin.isTTY||!ctx.stdout.isTTY)return null;
 const rl=readline.createInterface({input:ctx.stdin,output:ctx.stdout,terminal:true,historySize:0});
 try{return await rl.question(prompt);}finally{rl.close();}
}
async function confirm(ctx,token,text) {
 ctx.stdout.write(text+'\n');if(ctx.opts.confirm===token)return true;
 return await askOptional(ctx,ctx.lang==='en'?`Type ${token} to enable, or Enter to skip: `:`输入 ${token} 开启，直接回车跳过：`)===token;
}
export async function lookupCountry(ctx) {
 const response=await (ctx.io.countryFetch||globalThis.fetch)('https://ipapi.co/country/',{redirect:'error',signal:AbortSignal.timeout(3000),credentials:'omit',headers:{Accept:'text/plain'}});
 if(!response.ok)throw new Error('REGION_LOOKUP_UNAVAILABLE');
 const reader=response.body.getReader();let bytes=0,value='';
 try{for(;;){const r=await reader.read();if(r.done)break;bytes+=r.value.length;if(bytes>16)throw new Error('REGION_LOOKUP_INVALID');value+=new TextDecoder().decode(r.value);}}finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
 const country=value.trim().toUpperCase();if(!/^[A-Z]{2}$/.test(country))throw new Error('REGION_LOOKUP_INVALID');return country;
}
const team=lang=>lang==='en'?'A little celebration from the KARMEN LOOP team.':'来自 KARMEN LOOP 团队的一点小小仪式感。';
export async function showOccasion(ctx,occasion,preferences=celebrationPreferences(ctx.env)) {
 const language=preferredLanguage({...preferences,ui:ctx.lang});
 const wish=occasion.blessing[language];
 await playCelebration({...ctx,lang:language},occasion.effect,{blessing:wish});
 return {id:occasion.id,effect:occasion.effect,blessing:wish};
}
export async function offerOccasions(ctx) {
 if(ctx.opts.json||!ctx.stdin.isTTY||!ctx.stdout.isTTY||ctx.env.CI||ctx.io.resume)return;
 try {
  const p=celebrationPreferences(ctx.env);if(p.auto==='off'&&!p.musicEnabled)return;
  const date=ctx.io.now?.()||new Date(),language=preferredLanguage({...p,ui:ctx.lang}),today=occasionsOn(date,{...p,country:p.country||(language==='zh'?'CN':'US')});
  for(const o of today) {
   if(p.auto!=='off'&&claimPrivate('notice-'+o.id+'-'+localDate(date),ctx.env)){
    if(p.auto==='on')await showOccasion(ctx,o,p);
    else ctx.stdout.write(o.blessing[language]+'\n'+(language==='en'?`Optional six-second celebration: /celebrate ${o.effect}; /celebrate auto off hides these notices.\n`:`六秒小彩蛋：/celebrate ${o.effect}；/celebrate auto off 可关闭节日提示。\n`));
   }
   if(o.id==='birthday'&&p.musicEnabled){const result=await birthdayMusic(ctx,{date,preferences:{...p,resolvedLanguage:language}});if(result.state==='browser-unavailable')ctx.stdout.write(language==='en'?'Birthday music is available from /celebrate music play.\n':'生日音乐可用 /celebrate music play 再试。\n');}
  }
 }catch{ /* Optional decoration never prevents a normal chat from starting. */ }
}
export function noticeBirthday(ctx,text) {
 if(ctx.opts.memory===false)return false;
 try {
  const mention=birthdayMention(text,ctx.io.now?.()||new Date());if(!mention)return false;
  if(mention.explicit){save(ctx,{birthday:mention.date});ctx.stdout.write(ctx.lang==='en'?`Saved only the month and day (${mention.date}) on this device. Music is controlled separately. /celebrate birthday forget removes it.\n`:`只在本机记住月日 ${mention.date}。音乐由独立设置控制；/celebrate birthday forget 可删除。\n`);return true;}
  if(celebrationPreferences(ctx.env).birthday!==mention.date)ctx.stdout.write(ctx.lang==='en'?`Want a birthday greeting? /celebrate birthday --date ${mention.date} lets you confirm it locally. You can ignore this.\n`:`想收到生日祝福的话，可用 /celebrate birthday --date ${mention.date} 在本机确认；也可以忽略。\n`);
 }catch{}
 return false;
}
export function observeLanguage(ctx,text) {
 if(ctx.opts.memory===false)return;
 try{const p=celebrationPreferences(ctx.env);if(!p.learnLanguage)return;const zh=(text.match(/[\u3400-\u9fff]/g)||[]).length,en=(text.match(/[a-z]/gi)||[]).length;if(zh+en<8)return;const key=zh*2>=en?'zh':'en';if(Math.max(p.counts.zh,p.counts.en)>=999){p.counts.zh=Math.floor(p.counts.zh/2);p.counts.en=Math.floor(p.counts.en/2);}p.counts[key]++;save(ctx,{counts:p.counts});}catch{}
}
export async function runCelebration(ctx) {
 const aliases={'代码雨':'code','礼花':'confetti','烟花':'fireworks','圣诞节':'christmas','万圣节':'halloween','国庆节':'national','跨年':'new-year','生日':'birthday'};
 const [raw='menu',value]=ctx.positionals,action=aliases[raw]||raw,en=ctx.lang==='en';let p=celebrationPreferences(ctx.env);
 const out=value=>ctx.stdout.write(ctx.opts.json?JSON.stringify(typeof value==='string'?{message:value}:value)+'\n':typeof value==='string'?value+'\n':JSON.stringify(value,null,2)+'\n');
 if(action==='status'){out(p);return 0;}
 if(action==='auto'){if(!['off','notice','on'].includes(value)){out('koder celebrate auto off|notice|on');return 0;}save(ctx,{auto:value});out(en?'Celebration preference saved.':'已保存彩蛋偏好。');return 0;}
 if(action==='birthday'&&(value||ctx.opts.date)) {
  if(value==='forget'){save(ctx,{birthday:null,musicEnabled:false});const dir=privateDirectory(ctx.env);for(const name of fs.readdirSync(dir))if(name==='birthday.html'||/^(?:notice-birthday-|music-birthday-)\d{4}-\d{2}-\d{2}$/.test(name))fs.unlinkSync(path.join(dir,name));out(en?'Birthday removed; automatic birthday music is off.':'已删除生日，并关闭生日音乐。');return 0;}
  if(!validBirthday(ctx.opts.date)){out(en?'Use --date MM-DD. No year or name is needed. Enter or q skips.':'使用 --date MM-DD，无需出生年份或姓名；回车或 q 可跳过。');return 0;}
  if(await confirm(ctx,'BIRTHDAY',en?'Save this birthday month/day locally for annual greetings? It is not sent to a model or synced. Music is a separate choice.':'把这个生日月日保存在本机，用于每年祝福？不会发给模型或同步；音乐需要另行开启。')){save(ctx,{birthday:ctx.opts.date});out(en?'Birthday saved locally.':'生日已保存在本机。');}return 0;
 }
 if(action==='music') {
  if(value==='off'){save(ctx,{musicEnabled:false});out(en?'Automatic birthday music is off.':'已关闭自动生日音乐。');return 0;}
  if(value==='on') {
   const service=ctx.opts.service||'local';if(!['local','qq','youtube'].includes(service))throw new Error('MUSIC_SERVICE_INVALID');
   if(await confirm(ctx,'MUSIC',en?'On your birthday, Koder may open one browser tab for music while you use chat. Local music stays on this computer. A selected external service receives your IP address; playback may need a click. You can turn this off at any time.':'生日使用对话时，允许 Koder 打开一个音乐浏览器页？本地旋律不联网；所选外部音乐平台会收到 IP 地址，自动播放可能需要点击。随时可以关闭。')){save(ctx,{musicEnabled:true,musicService:service});out(en?'Birthday music enabled.':'已开启生日音乐。');}return 0;
  }
  if(value==='play'){if(!p.musicEnabled){out(en?'Choose /celebrate music on first; Enter skips consent.':'先用 /celebrate music on 选择是否开启；回车可跳过。');return 0;}out(await birthdayMusic(ctx,{manual:true,preferences:{...p,resolvedLanguage:preferredLanguage({...p,ui:ctx.lang})}}));return 0;}
  out('koder celebrate music on|off|play [--service local|qq|youtube]');return 0;
 }
 if(action==='locale') {
  const patch={};if(ctx.opts.country){if(!/^[A-Z]{2}$/.test(ctx.opts.country))throw new Error('COUNTRY_CODE_INVALID');patch.country=ctx.opts.country;}
  if(ctx.opts.language){if(!['zh','en','auto'].includes(ctx.opts.language))throw new Error('CELEBRATION_LANGUAGE_INVALID');patch.language=ctx.opts.language;patch.learnLanguage=ctx.opts.language==='auto';if(!patch.learnLanguage)patch.counts={zh:0,en:0};}
  if(ctx.opts.ip&&await confirm(ctx,'IP',en?'Look up only your country through ipapi.co? That service receives your public IP address. This is a one-time lookup; no exact location or IP is saved. Country is a hint, never proof of language.':'通过 ipapi.co 查询一次国家/地区？对方会收到公网 IP；本机只保存国家代码，不保存 IP 或精确位置。国家仅作辅助，不能确定常用语言。')) {
   try{patch.country=await lookupCountry(ctx);}catch{out(en?'Country lookup unavailable; your existing language and region still apply.':'地区查询暂不可用，继续使用已有语言和地区设置。');}
  }
  if(Object.keys(patch).length)p=save(ctx,patch);out({...p,resolvedLanguage:preferredLanguage({...p,ui:ctx.lang})});return 0;
 }
 if(action==='custom') {
  const name=String(ctx.opts.name||'').replace(/[\x00-\x1f\x7f-\x9f]/g,'').trim().slice(0,60);if(!name||!validBirthday(ctx.opts.date)){out('koder celebrate custom --date MM-DD --name "Your holiday"');return 0;}
  save(ctx,{custom:[...p.custom.filter(o=>o.date!==ctx.opts.date),{date:ctx.opts.date,name}].slice(-32)});out(en?'Annual local celebration added.':'已加入每年自动识别的本地节日。');return 0;
 }
 let effect=action;
 if(action==='menu') {
  if(ctx.opts.json){out({effects:EFFECTS,durationMs:6000,optional:true,skip:['Enter','q','Esc']});return 0;}
  out(en?'A six-second detour. Nothing gets installed, changed, or sent.':'绕路六秒钟，正事不会跑掉。不会安装、改文件或发消息。');
  EFFECTS.forEach((id,i)=>out(`${i+1}. ${en?id:Object.keys(aliases).find(key=>aliases[key]===id)+' · '+id}`));out(en?'Enter / q / Esc: skip. Birthday, music, locale, and automatic notices are separate settings.':'回车 / q / Esc：跳过。生日、音乐、语言地区和自动提示可分别设置。');
  const answer=await askOptional(ctx,en?'Choose an effect, or Enter to skip: ':'选一个彩蛋，回车跳过：');effect=EFFECTS[Number(answer)-1]||answer;if(!EFFECTS.includes(effect))return 0;
 }
 if(!EFFECTS.includes(effect)){out(en?'Use koder celebrate for the optional menu.':'使用 koder celebrate 查看可跳过的菜单。');return 0;}
 const occasion=OCCASIONS.find(o=>o.id===effect||effect==='national'&&o.id==='national-day');
 const result=await playCelebration(ctx,effect,{blessing:occasion?.blessing[preferredLanguage({...p,ui:ctx.lang})]||team(ctx.lang)});
 if(ctx.opts.json)out(result);return 0;
}
