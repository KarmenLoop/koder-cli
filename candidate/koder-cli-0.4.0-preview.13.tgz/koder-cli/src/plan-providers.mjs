// Subscription endpoints stay separate from metered APIs. No fallback changes
// a host, credential class, or billing route on the user's behalf.
export const PLAN_PRESETS = [
 {id:'aliyun-token-plan',name:'阿里云 · Token Plan（个人 / 团队）',baseUrl:'https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1',protocol:'openai',
  models:['qwen3.8-max','qwen3.8-flash','qwen3.7-plus','deepseek-v4-pro','glm-5.2'],
  detail:'Token Plan 专属 sk-sp- 密钥。个人版与团队版的数据条款不同，请先查看所订套餐声明；不能混用 Coding Plan 或按量付费地址。',
  source:'https://help.aliyun.com/zh/model-studio/token-plan-personal-overview',
  key:{url:'https://bailian.console.aliyun.com/',steps:['切换到华北2（北京），打开 Token Plan 的我的订阅','复制当前个人版或团队席位的 sk-sp- 套餐密钥','保持 Token Plan 专用地址；可用型号以当前套餐控制台为准']}},
 {id:'aliyun-coding-plan',name:'阿里云 · Coding Plan',baseUrl:'https://coding.dashscope.aliyuncs.com/v1',protocol:'openai',
  models:['qwen3.7-plus','qwen3.6-plus','kimi-k2.5','glm-5','MiniMax-M2.5','qwen3-coder-next','qwen3-coder-plus'],
  detail:'Coding Plan 存量套餐的专属 sk-sp- 密钥。此入口不支持 Responses；不要填写 Token Plan 或按量付费密钥。',
  source:'https://help.aliyun.com/zh/model-studio/coding-plan',
  key:{url:'https://bailian.console.aliyun.com/',steps:['打开 Coding Plan 套餐页面','复制 Coding Plan 专属 sk-sp- 密钥','使用套餐明确支持的型号；此套餐与 Token Plan 独立']}},
 {id:'volcano-coding-plan',name:'火山引擎 · Coding Plan',baseUrl:'https://ark.cn-beijing.volces.com/api/coding/v3',protocol:'openai',
  models:['ark-code-latest','doubao-seed-2.1-pro','doubao-seed-2.1-lite','doubao-seed-evolving','minimax-m3','glm-5.3','glm-5.3-flash','deepseek-v4.1-flash','deepseek-v4-pro','kimi-k3','kimi-k2.8-preview'],
  detail:'火山方舟 Coding Plan 的专用 /api/coding/v3 地址。ark-code-latest 跟随控制台选择；/api/v3 是按量付费通道。',
  source:'https://ark.volcengine.com/region:cn-beijing/docs/coding-plan-personal-get-started',
  key:{url:'https://console.volcengine.com/ark/region:cn-beijing/coding-plan',steps:['打开方舟 Coding Plan 开通管理','从当前套餐页面取得 API Key','选 ark-code-latest 跟随控制台，或选择套餐明确支持的模型']}},
].map(p=>({...p,region:'cn',vendor:p.id.startsWith('volcano')?'Volcano Engine':'Alibaba Cloud',model:p.models[0],auth:'bearer',contextWindow:65536,maxOutput:8192,checkedAt:'2026-10-20',verification:'Native protocol fixture; subscription, account and quota require verification'}));

export function normalizePlanProvider(record) {
 const u=new URL(record.baseUrl),host=u.hostname,path=u.pathname.replace(/\/+$/,'');
 const aliToken=host==='token-plan.cn-beijing.maas.aliyuncs.com';
 const aliCoding=['coding.dashscope.aliyuncs.com','coding-intl.dashscope.aliyuncs.com'].includes(host);
 const aliMetered=['dashscope.aliyuncs.com','dashscope-intl.aliyuncs.com','dashscope-us.aliyuncs.com'].includes(host)||(/\.maas\.aliyuncs\.com$/.test(host)&&!aliToken);
 if(record.presetId==='volcano-coding-plan'&&host==='ark.cn-beijing.volces.com'&&!/^\/api\/coding(?:\/|$)/.test(path))throw new Error('PLAN_ENDPOINT_MISMATCH: this preset requires the Coding Plan path; no metered fallback was attempted.');
 if(record.presetId==='aliyun-token-plan'&&(aliCoding||aliMetered)||record.presetId==='aliyun-coding-plan'&&(aliToken||aliMetered))throw new Error('PLAN_ENDPOINT_MISMATCH: select the preset and credentials for this exact Alibaba subscription.');
 if((aliToken||aliCoding)&&record.apiKey&&/^sk-(?!sp-)/.test(record.apiKey))throw new Error('PLAN_KEY_MISMATCH: use the sk-sp- key issued for this exact subscription; no billing route was changed.');
 if(aliMetered&&/^sk-sp-/.test(record.apiKey))throw new Error('PLAN_ENDPOINT_MISMATCH: a subscription key needs its own Token Plan or Coding Plan endpoint; no metered fallback was attempted.');
 const volcano=host==='ark.cn-beijing.volces.com'&&/^\/api\/coding(?:\/|$)/.test(path);
 if(!aliToken&&!aliCoding&&!volcano)return record;
 const anthropic=record.protocol==='anthropic';
 const expected=volcano?(anthropic?'/api/coding':'/api/coding/v3'):aliToken?(anthropic?'/apps/anthropic':'/compatible-mode/v1'):(anthropic?'/apps/anthropic':'/v1');
 const suffix=anthropic?'/v1/messages':record.protocol==='responses'?'/responses':'/chat/completions';
 if(path!==expected&&path!==expected+suffix)throw new Error('PLAN_PROTOCOL_MISMATCH: select the matching OpenAI or Anthropic subscription endpoint.');
 if(aliCoding&&record.protocol==='responses')throw new Error('PLAN_PROTOCOL_MISMATCH: Alibaba Coding Plan requires Chat Completions or Anthropic Messages. Token Plan is a separate product.');
 if(volcano&&/^ep-/.test(record.model))throw new Error('PLAN_MODEL_MISMATCH: Coding Plan uses a supported model name or ark-code-latest, not a metered endpoint ID.');
 if(anthropic)record.chatPath='/v1/messages';
 record.baseUrl=u.origin+expected;
 return record;
}
