import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {cliHome} from './config.mjs';

const fail=()=>{throw new Error('PRIVATE_STATE_UNAVAILABLE');};
export function privateDirectory(env=process.env) {
 const root=cliHome(env),dir=path.join(root,'delight');
 for(const folder of [root,dir]) {
  fs.mkdirSync(folder,{recursive:true,mode:0o700});
  const s=fs.lstatSync(folder);if(!s.isDirectory()||s.isSymbolicLink())fail();
 }
 return dir;
}
export function readPrivate(name,env=process.env,fallback={}) {
 if(!/^[a-z0-9.-]+$/.test(name))fail();
 for(const folder of [cliHome(env),path.join(cliHome(env),'delight')]){const s=fs.lstatSync(folder,{throwIfNoEntry:false});if(s&&(!s.isDirectory()||s.isSymbolicLink()))fail();}
 const file=path.join(cliHome(env),'delight',name);let fd;
 try{fd=fs.openSync(file,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0)|(fs.constants.O_NONBLOCK||0));const s=fs.fstatSync(fd);if(!s.isFile()||s.size>131072)fail();return JSON.parse(fs.readFileSync(fd,'utf8'));}
 catch(e){if(e.code==='ENOENT')return structuredClone(fallback);fail();}
 finally{if(fd!==undefined)fs.closeSync(fd);}
}
export function writePrivate(name,value,env=process.env) {
 if(!/^[a-z0-9.-]+$/.test(name))fail();
 const dir=privateDirectory(env),file=path.join(dir,name),s=fs.lstatSync(file,{throwIfNoEntry:false});if(s&&(!s.isFile()||s.isSymbolicLink()))fail();
 const bytes=typeof value==='string'?value:JSON.stringify(value,null,2)+'\n';if(Buffer.byteLength(bytes)>131072)fail();
 const tmp=path.join(dir,'.'+name+'.'+crypto.randomUUID());
 try{fs.writeFileSync(tmp,bytes,{flag:'wx',mode:0o600});fs.renameSync(tmp,file);}finally{try{fs.unlinkSync(tmp);}catch{}}
 return file;
}
export function claimPrivate(name,env=process.env) {
 if(!/^[a-z0-9.-]+$/.test(name))fail();
 try{fs.writeFileSync(path.join(privateDirectory(env),name),'shown\n',{flag:'wx',mode:0o600});return true;}catch(e){if(e.code==='EEXIST')return false;throw e;}
}
