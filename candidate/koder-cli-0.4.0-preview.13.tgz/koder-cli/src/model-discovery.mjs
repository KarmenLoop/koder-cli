import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {cliHome} from './config.mjs';
import {loadModel} from './models.mjs';
export function cacheFile(record,env){return path.join(cliHome(env),'model-catalog',crypto.createHash('sha256').update(record.baseUrl.replace(/\/$/,'')+'|'+record.protocol).digest('hex')+'.json');}
export function cachedModels(record,env){try{const value=JSON.parse(fs.readFileSync(cacheFile(record,env),'utf8'));if(value.baseUrl!==record.baseUrl||value.protocol!==record.protocol)return [];return value.models.filter(m=>m.tools===true).map(m=>m.id);}catch{return [];}}
export async function discoverModels(record,{fetchImpl=globalThis.fetch}={}){
 const base=new URL(record.baseUrl);base.pathname=base.pathname.replace(/\/(?:chat\/completions|responses|messages)\/?$/,'').replace(/\/$/,'')+'/models';base.search='';
 const headers={accept:'application/json'};
 if(record.auth!=='none')headers[record.protocol==='anthropic'?'x-api-key':record.auth==='api-key'?'api-key':'authorization']=record.protocol==='anthropic'||record.auth==='api-key'?record.apiKey:'Bearer '+record.apiKey;
 if(record.protocol==='anthropic')headers['anthropic-version']='2023-06-01';
 if(record.sendApiKeyHeader)headers['api-key']=record.apiKey;
 const models=[];
 for(let page=0;page<20;page++){
  const response=await fetchImpl(base.href,{headers,redirect:'error',signal:AbortSignal.timeout(30000)});
  if(!response.ok){await response.body?.cancel();throw new Error('Model listing failed (HTTP '+response.status+'); current configuration was kept.');}
  const reader=response.body?.getReader(),chunks=[];let size=0;
  try{for(;;){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>8000000)throw new Error('Model listing is too large');chunks.push(Buffer.from(value));}}finally{await reader?.cancel().catch(()=>{});}
  const data=JSON.parse(Buffer.concat(chunks).toString());if(!Array.isArray(data.data))throw new Error('This endpoint does not expose a compatible model list.');
  for(const value of data.data){if(typeof value.id!=='string'||!value.id||value.id.length>240)continue;if(/:batch$|safeguard|(?:^|[-/])(?:tts|embed|embedding|whisper|transcribe|moderation|reward)(?:[-/]|$)/i.test(value.id))continue;const tools=value.supported_parameters?value.supported_parameters.includes('tools'):value.capabilities?.function_calling?.supported??value.capabilities?.tools?.supported??null;models.push({id:value.id,tools});}
  if(!data.has_more)return [...new Map(models.map(m=>[m.id,m])).values()];
  if(typeof data.last_id!=='string')throw new Error('Incomplete model pagination');base.searchParams.set('after_id',data.last_id);
 }
 throw new Error('Model listing pagination exceeded its limit; cache was not replaced.');
}
export async function modelCatalogCommand(ctx,action,target){
 if(action==='models'){
  const {presets}=await import('./commands/model.mjs');
  const list=await presets(ctx),selected=target?list.filter(p=>p.id===target):list;
  if(!selected.length)throw new Error('Unknown provider preset: '+target);
  if(ctx.opts.json)ctx.stdout.write(JSON.stringify(selected.map(p=>({id:p.id,models:p.models,source:p.source,checkedAt:p.checkedAt,verification:p.verification})))+'\n');
  else for(const p of selected)ctx.stdout.write(p.id+': '+(p.models?.join(', ')||'Enter your loaded model ID')+'\n'+(p.source||'')+'\n'+(p.verification||'Account unverified')+'\n');
  return 0;
 }
 const found=target?loadModel(target,ctx.env):ctx.requireProvider(),models=await discoverModels(found.record,{fetchImpl:ctx.io.fetchImpl||globalThis.fetch});
 const file=cacheFile(found.record,ctx.env);fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});
 fs.writeFileSync(file,JSON.stringify({baseUrl:found.record.baseUrl,protocol:found.record.protocol,checkedAt:new Date().toISOString(),models},null,2)+'\n',{mode:0o600});
 ctx.stdout.write(JSON.stringify({models,notice:'Model listing only. No model was selected and no inference or tool capability was verified.'})+'\n');return 0;
}
