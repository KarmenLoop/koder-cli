import {fg,RESET} from './color.mjs';
export const EFFECTS=['code','confetti','fireworks','christmas','halloween','national','new-year','birthday'];
const colors=['#76efb1','#7ca6ff','#fb83c1','#ffd479','#af98ff','#7ce5e8'];
const wave=(n)=>Math.sin(n*12.9898)*43758.5453%1;
export function renderCelebration(effect,progress,{columns=80,rows=18,depth='none',year=new Date().getFullYear()+1}={}) {
 const w=Math.max(24,Math.min(100,Math.floor(columns)-2)),h=Math.max(8,Math.min(22,Math.floor(rows)-5));
 const grid=Array.from({length:h},()=>Array.from({length:w},()=>({c:' ',color:colors[0]}))),t=Math.max(0,Math.min(1,progress));
 const put=(x,y,c,color)=>{x=Math.round(x);y=Math.round(y);if(x>=0&&x<w&&y>=0&&y<h)grid[y][x]={c,color};};
 const art=(lines,x=(w-Math.max(...lines.map(l=>l.length)))/2,y=3,color=colors[3])=>lines.forEach((line,r)=>[...line].forEach((c,k)=>put(x+k,y+r,c,color)));
 const snow=()=>{for(let i=0;i<22;i++)put((i*19+t*7)%w,(i*7+t*12)%h,'.','#b5d9ff');};
 if(effect==='code') {
  for(let x=1;x<w;x+=3){const head=(t*26+x*1.31)%(h+8);for(let r=0;r<9;r++)put(x,head-r,'01KARMEN<>[]{}+*'[Math.abs(Math.floor(wave(x*7+r+t*4)*15))%15],r===0?'#e7fff2':r<4?'#76efb1':'#32836b');}
 }else if(['fireworks','confetti'].includes(effect)) {
  for(let b=0;b<4;b++){const phase=(t*2.8+b*.27)%1,cx=w*(.18+b*.21),cy=h*(.3+(b%2)*.22);
   for(let p=0;p<28;p++){const a=p*Math.PI*2/28,r=phase*(effect==='confetti'?10:14),x=cx+Math.cos(a)*r*1.7,y=cy+Math.sin(a)*r*.55+phase*phase*7;
    if(phase<.86)put(x,y,phase<.18?'*':p%3===0?'+':'.',colors[(p+b)%colors.length]);}
  }
 }else if(effect==='christmas') {
  snow();put(w/2,1,'*','#ffd479');for(let y=2;y<Math.min(h-3,13);y++)for(let x=-y;x<=y;x++)put(w/2+x,y,Math.abs(x)===y?'/':(x+y)%4===0?'o':'^',(x+y)%4===0?colors[(y+x+24)%6]:'#76efb1');art(['|||'],w/2-1,Math.min(h-3,13),'#ba9368');
 }else if(effect==='halloween') {
  snow();art(['       _._       ','    .-\'   `-.    ','   /  /\\ /\\  \\   ','  |    /\\    |  ','  |  \\____/  |  ','   \\________/   '],undefined,Math.max(1,(h-6)/2),'#ffae68');
  art(['^o^'],(t*35)%Math.max(1,w-4),1,'#af98ff');
 }else if(effect==='national') {
  for(let i=0;i<3;i++){const x=w*(.2+i*.3),y=2+Math.sin(t*6+i)*.7;art(['  |  ',' /-\\ ','| * |',' \\-/ ','  |  '],x-2,y,i%2?'#ffd479':'#ff8a8a');}snow();
 }else if(effect==='birthday') {
  snow();art(['   i  i  i   ','   |  |  |   ',' .-----------.',' | *  *  *  |',' |~~~~~~~~~~|',' |  KARMEN  |',' ============'],undefined,Math.max(1,(h-7)/2),'#ffd479');
  for(let i=0;i<5;i++){const x=3+i*(w-6)/4,y=(h+3-(t*12+i*3)%(h+4));put(x,y,'o',colors[i]);put(x,y+1,'|',colors[i]);}
 }else {
  snow();const digits={0:[' ### ','#   #','#   #','#   #',' ### '],1:['  #  ',' ##  ','  #  ','  #  ',' ### '],2:[' ### ','    #',' ### ','#    ','#####'],3:['#### ','    #',' ### ','    #','#### '],4:['#  # ','#  # ','#####','   # ','   # '],5:['#####','#    ','#### ','    #','#### '],6:[' ### ','#    ','#### ','#   #',' ### '],7:['#####','    #','   # ','  #  ',' #   '],8:[' ### ','#   #',' ### ','#   #',' ### '],9:[' ### ','#   #',' ####','    #',' ### ']};
  art(Array.from({length:5},(_,r)=>String(year).split('').map(d=>digits[d][r]).join(' ')),undefined,Math.max(1,(h-5)/2),colors[Math.floor(t*4)%6]);
 }
 return grid.map(row=>row.map(p=>p.c===' '||depth==='none'?p.c:fg(p.color,depth)+p.c+RESET).join('')).join('\n');
}
export async function playCelebration(ctx,effect,{blessing='',signal=ctx.io.stopSignal}={}) {
 if(!EFFECTS.includes(effect))throw new Error('CELEBRATION_UNKNOWN');
 const reduced=ctx.env.KODER_REDUCED_MOTION==='1'||ctx.env.REDUCED_MOTION==='1';
 if(ctx.opts.json||!ctx.stdin.isTTY||!ctx.stdout.isTTY||ctx.env.CI||ctx.env.TERM==='dumb'||ctx.opts.animation===false||reduced){
  if(!ctx.opts.json&&blessing)ctx.stdout.write(blessing+'\n');return {effect,durationMs:0,skipped:true,reason:reduced?'reduced-motion':'static'};
 }
 const date=ctx.io.now?.()||new Date(),year=date.getMonth()===0?date.getFullYear():date.getFullYear()+1;
 const input=ctx.stdin,out=ctx.stdout,raw=input.isRaw,wasFlowing=input.readableFlowing===true,start=performance.now(),duration=6000;
 let timer,stop,replay='',settled=false;const keyListeners=input.listeners('keypress');
 // The existing line editor owns ordinary input. Borrow it only while this
 // optional screen is visible, then restore it and replay real typed text.
 input.removeAllListeners('keypress');
 const finish=()=>{if(!settled){settled=true;stop?.();}};
 const onData=bytes=>{const s=bytes.toString();if(!/^[\x03\x1b\r\n q]+$/.test(s))replay+=s;finish();};
 const frame=()=>{const elapsed=performance.now()-start;out.write('\x1b[H'+renderCelebration(effect,elapsed/duration,{columns:out.columns,rows:out.rows,depth:ctx.depth,year})+'\x1b[J\n\n'+blessing+'\n'+(ctx.lang==='en'?'Any key skips · 6 seconds · your work is waiting safely':'任意键跳过 · 6 秒 · 正常任务随时继续'));if(elapsed>=duration)finish();};
 try {
  out.write('\x1b[?1049h\x1b[?25l');input.setRawMode?.(true);input.resume();input.on('data',onData);signal?.addEventListener('abort',finish,{once:true});
  await new Promise(resolve=>{stop=resolve;if(signal?.aborted)return finish();frame();timer=setInterval(()=>{try{frame();}catch{finish();}},70);});
 }finally {
  clearInterval(timer);input.off('data',onData);signal?.removeEventListener('abort',finish);input.setRawMode?.(Boolean(raw));
  for(const listener of keyListeners)input.on('keypress',listener);if(!wasFlowing)input.pause();
  out.write('\x1b[0m\x1b[?25h\x1b[?1049l');if(replay)ctx.io.prompter?.rl?.write(replay);
 }
 return {effect,durationMs:Math.round(performance.now()-start),skipped:performance.now()-start<duration};
}
