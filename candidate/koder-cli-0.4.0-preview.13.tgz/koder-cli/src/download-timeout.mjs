export const DOWNLOAD_TIMEOUT_SECONDS=100000000;
export function downloadTimeout(env=process.env){
 const value=env.KODER_DOWNLOAD_TIMEOUT_SECONDS;
 if(value==null||value==='')return DOWNLOAD_TIMEOUT_SECONDS;
 if(!/^\d+$/.test(value)||Number(value)<1||Number(value)>DOWNLOAD_TIMEOUT_SECONDS)throw new Error('KODER_DOWNLOAD_TIMEOUT_SECONDS: expected 1..100000000');
 return Number(value);
}
// Node timers accept at most 2^31-1 ms. Longer waits must be rearmed against
// elapsed monotonic time; handing 100000000000 to setTimeout expires in 1 ms.
export function downloadDeadline(seconds,{now=()=>performance.now(),schedule=setTimeout,cancel=clearTimeout}={}){
 const controller=new AbortController(),end=now()+seconds*1000;let timer,disposed=false;
 function arm(){if(disposed)return;const left=end-now();if(left<=0){controller.abort(Object.assign(new Error('Download timed out'),{code:'DOWNLOAD_TIMEOUT'}));return;}timer=schedule(arm,Math.min(left,2147483647));timer?.unref?.();}
 arm();return {signal:controller.signal,dispose(){disposed=true;cancel(timer);}};
}
