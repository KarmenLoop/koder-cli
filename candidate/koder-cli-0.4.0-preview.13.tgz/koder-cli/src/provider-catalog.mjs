import fs from 'node:fs';
import {KoderError} from './errors.mjs';
let checkedCatalog;
export function readProviderCatalog(){return checkedCatalog??=JSON.parse(fs.readFileSync(new URL('./provider-catalog.json',import.meta.url),'utf8'));}
const ROOTS={'hunyuan-tokenhub':'https://tokenhub-intl.tencentcloudmaas.com/v1',zhipu:'https://open.bigmodel.cn/api/paas/v4',qwen:'https://dashscope.aliyuncs.com/compatible-mode/v1',kimi:'https://api.moonshot.cn/v1',doubao:'https://ark.cn-beijing.volces.com/api/v3',hunyuan:'https://api.hunyuan.cloud.tencent.com/v1',stepfun:'https://api.stepfun.com/v1',baichuan:'https://api.baichuan-ai.com/v1',spark:'https://spark-api-open.xf-yun.com/v1',qianfan:'https://qianfan.baidubce.com/v2',minimax:'https://api.minimax.io/v1','minimax-cn':'https://api.minimaxi.com/v1',deepseek:'https://api.deepseek.com/v1',chatgpt:'https://api.openai.com/v1',claude:'https://api.anthropic.com/v1',gemini:'https://generativelanguage.googleapis.com/v1beta/openai',grok:'https://api.x.ai/v1',mistral:'https://api.mistral.ai/v1',groq:'https://api.groq.com/openai/v1',cerebras:'https://api.cerebras.ai/v1',nvidia:'https://integrate.api.nvidia.com/v1',huggingface:'https://router.huggingface.co/v1',siliconflow:'https://api.siliconflow.cn/v1',openrouter:'https://openrouter.ai/api/v1',together:'https://api.together.xyz/v1',fireworks:'https://api.fireworks.ai/inference/v1',perplexity:'https://api.perplexity.ai/v1'};
export function limitsForPreset(preset,model){
 const providerCatalog=readProviderCatalog();
 const checked=providerCatalog.providers[preset.id];
 if(checked?.limits?.[model])return checked.limits[model];
 if(preset.models?.includes(model))return {contextWindow:checked?.contextWindow||preset.contextWindow,maxOutput:checked?.maxOutput||preset.maxOutput};
 return {contextWindow:8192,maxOutput:4096};
}
export function withProviderPresets(list){
 const providerCatalog=readProviderCatalog();
 const hy=list.find(p=>p.id==='hunyuan');
 if(hy)list=[...list,{...hy,id:'hunyuan-tokenhub',name:'Tencent HY4 · TokenHub',baseUrl:'https://tokenhub-intl.tencentcloudmaas.com/v1',key:{url:'https://console.cloud.tencent.com/tokenhub',steps:['Create a TokenHub API key; legacy Hunyuan credentials are not interchangeable.']}}];
 return list.filter(p=>!p.stopped&&!providerCatalog.removed[p.id]).map(p=>{
  const checked=providerCatalog.providers[p.id];if(!checked)return {...p,verification:'Endpoint and loaded model require local verification'};
  const spec=checked.limits?.[checked.models[0]]||checked;
  return {...p,model:checked.models[0],models:[...checked.models],protocol:checked.protocol||p.protocol,baseUrl:checked.baseUrl||p.baseUrl,contextWindow:spec.contextWindow,maxOutput:spec.maxOutput,checkedAt:providerCatalog.checkedAt,verification:checked.verification,source:checked.source};
 });
}
// Match both host and service path. A custom proxy never inherits controls or
// credentials from a similarly named model or a stale presetId.
export function normalizeProvider(record,raw={}){
 const providerCatalog=readProviderCatalog();
 const url=new URL(record.baseUrl),clean=url.pathname.replace(/\/(?:chat\/completions|responses|messages)\/?$/,'').replace(/\/$/,'');
 if(url.hostname==='api.lingyiwanwu.com')throw new Error('Yi API service is no longer available. Select a different provider; no fallback was attempted.');
 const entry=Object.entries(ROOTS).find(([,root])=>{const base=new URL(root);return url.origin===base.origin&&clean===base.pathname;});
 if(!entry)return record;
 const [id]=entry,checked=providerCatalog.providers[id];
 const known=checked.models.includes(record.model),limits=checked.limits?.[record.model]||checked;
 if(known){if(raw.contextWindow==null)record.contextWindow=limits.contextWindow;if(raw.maxOutput==null)record.maxOutput=limits.maxOutput;}
 const compat={};
 // Several OpenAI-compatible servers reject OpenAI-specific stream_options.
 if(['spark','baichuan','hunyuan','qianfan','stepfun'].includes(id))compat.streamOptions=false;
 if(id==='spark')compat.toolCallsSwitch=true;
 if(id==='chatgpt'&&/^(?:gpt-[5-9]|o[134])/.test(record.model)){
  record.protocol='responses';record.baseUrl=url.origin+clean;
  record.reasoningEffort=/^gpt-6(?:\.1)?-(?:astra|sol)/.test(record.model)?'low':undefined;
 }
 if(id==='perplexity')record.protocol='responses';
 if(id==='zhipu'&&/^glm-5\.3/.test(record.model))Object.assign(compat,{thinkingFormat:'zai',supportsReasoningEffort:true});
 if(id==='kimi'&&/^kimi-k3/.test(record.model))Object.assign(compat,{thinkingFormat:'openai',supportsReasoningEffort:true});
 const level=id==='zhipu'&&/^glm-5\.3/.test(record.model)?'low':id==='kimi'&&/^kimi-k3/.test(record.model)?'low':id==='claude'&&/^claude-(?:opus-5-5|sonnet-5-5|fable-)/.test(record.model)?'high':null;
 record.spec={compat,...(level?{reasoning:true,levels:[level],efforts:{[level]:level}}:{})};
 if(level)record.reasoningEffort=level;
 if(raw.reasoningEffort&&record.spec.levels?.includes(raw.reasoningEffort))record.reasoningEffort=raw.reasoningEffort;
 return record;
}
