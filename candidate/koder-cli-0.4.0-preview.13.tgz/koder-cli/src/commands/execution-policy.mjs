import {executionStatus,setExecutionMode,rememberExecution,classifyExecution,revokeExecutionRule,resetExecutionPermissions} from '../execution-permissions.mjs';

export async function runExecutionPolicy(ctx){
 const action=ctx.positionals[1]||'status',workspace=ctx.workspace(),options={env:ctx.env,workspace,scope:ctx.opts.scope||'workspace'};
 if(!['workspace','profile'].includes(options.scope))throw new Error('EXECUTION_SCOPE_INVALID: workspace | profile');
 const en=ctx.lang==='en';
 const confirm=async token=>{
  if(ctx.opts.confirm===token)return;
  const text=en?`This saves execution permission for ${options.scope==='profile'?'every workspace in this profile':workspace}. Full access can run code, modify/delete files and operate already authorized applications without per-action prompts. OS permissions and interactive secrets remain separate. Type ${token} to save; Enter cancels: `:`这会保存${options.scope==='profile'?'此配置下全部工作区':workspace}的执行许可。全面开放可运行代码、改删文件和操作已授权应用，不再逐项确认；系统权限和密码输入仍独立。输入 ${token} 保存，回车取消：`;
  if(!ctx.io.prompter||await ctx.io.prompter.ask(text,{fresh:true})!==token)throw new Error('EXECUTION_OWNER_CONFIRMATION_REQUIRED: '+token);
 };
 if(['auto','ask','full','deny'].includes(action)){
  if(action==='full')await confirm('FULL');setExecutionMode(action,options);
 }else if(action==='allow'){
  if(!ctx.opts.command)throw new Error('EXECUTION_COMMAND_REQUIRED');await confirm('ALLOW');const pause={kind:'approval',toolName:'shell',command:ctx.opts.command};rememberExecution(pause,{...options,risk:classifyExecution(pause,{workspace}).risk});
 }else if(action==='revoke'){
  const id=ctx.positionals[2];if(id!=='all'&&!/^[a-f0-9]{64}$/.test(id||''))throw new Error('EXECUTION_RULE_ID_REQUIRED: rule ID | all');revokeExecutionRule(id,options);
 }else if(action==='reset')resetExecutionPermissions(ctx.env);
 else if(action!=='status')throw new Error('koder permissions execution status|auto|ask|full|deny|allow|revoke|reset');
 const status=executionStatus(options);
 if(ctx.opts.json)ctx.stdout.write(JSON.stringify(status)+'\n');
 else{
  const names=en?{auto:'Smart: low-risk commands and ordinary workspace edits run automatically',ask:'Ask: confirm actions without a saved permission',full:'Full access: skip action prompts within existing scopes',deny:'Deny: reject changes and command actions'}:{auto:'智能判断：低风险命令与普通项目文件修改自动运行',ask:'逐项确认：已保存许可的操作除外',full:'全面开放：在既有授权范围内不再逐项询问',deny:'拒绝：不运行命令或文件修改'};
  ctx.stdout.write(`${names[status.mode]}\n${en?'Workspace':'工作区'}: ${status.workspace}\n${en?'Saved permissions':'已保存许可'}: ${status.rules.length}\n`);
  for(const rule of status.rules)ctx.stdout.write(`${rule.id}  ${rule.scope}  ${rule.label}\n`);
  ctx.stdout.write('koder permissions execution auto | ask | full --confirm FULL | deny\n');
  ctx.stdout.write(en?'Use --scope profile for all workspaces. revoke <id|all> removes saved rules; reset clears all execution settings. These choices never supply passwords, accept software terms, grant OS access or enable privacy features.\n':'--scope profile 可设置全部工作区；revoke <id|all> 撤销许可；reset 清空全部执行设置。不会代填密码、接受软件条款、授予系统权限或开启隐私功能。\n');
 }
 return 0;
}
