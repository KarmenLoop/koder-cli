import {feedbackText} from '../feedback.mjs';
export const flags={};
export async function run(ctx){ctx.stdout.write(ctx.opts.json?JSON.stringify({email:'info@karmenloop.com',automaticSending:false,template:feedbackText(ctx)})+'\n':feedbackText(ctx)+'\n');return 0;}
