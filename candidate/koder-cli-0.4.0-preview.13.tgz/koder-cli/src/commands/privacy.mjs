import fs from 'node:fs';
export const flags={};
export async function run(ctx){
 const action=ctx.positionals[0]||'consumer',lang=ctx.lang==='en'?'en':'zh';
 const files={consumer:`consumer-privacy.${lang}.md`,statement:`privacy-statement.${lang}.md`,sources:'SOURCES.json',desktop:`official-consumer-privacy.${lang}.md`,agreement:`official-consumer-agreement.${lang}.md`};
 if(!files[action]){ctx.stdout.write('koder privacy consumer|statement|sources|desktop|agreement\n');return 0;}
 const text=fs.readFileSync(new URL('../../docs/privacy/'+files[action],import.meta.url),'utf8');
 ctx.stdout.write(ctx.opts.json?JSON.stringify({document:action,language:lang,text})+'\n':text+'\n');return 0;
}
