import os from 'node:os';
import fs from 'node:fs';
import readline from 'node:readline';
import {createPrompter} from '../prompter.mjs';
import {openComputerCapabilities} from '../computer.mjs';
import {loadGateway,gatewayBindingId} from '../gateway/store.mjs';
import {platformId} from '../gateway/registry.mjs';
import {runExecutionPolicy} from './execution-policy.mjs';
import {executionStatus} from '../execution-permissions.mjs';
export const flags={mode:{type:'string'},root:{type:'string',multiple:true},capability:{type:'string',multiple:true},home:{type:'bool'},channel:{type:'string'},chat:{type:'string'},actor:{type:'string'},scope:{type:'string'},confirm:{type:'string'},command:{type:'string'}};
export async function run(ctx){
 const action=ctx.positionals[0]||'status';if(!['status','request','repair','revoke','execution'].includes(action))throw new Error('koder permissions status|request|repair|revoke|execution');
 let ownedPrompter;
 if(['request','execution'].includes(action)&&!ctx.io.prompter&&ctx.stdin.isTTY&&ctx.stdout.isTTY){ownedPrompter=createPrompter(readline.createInterface({input:ctx.stdin,output:ctx.stdout,terminal:true,historySize:0}),ctx.stdout);ctx.io={...ctx.io,prompter:ownedPrompter};}
 try{
  if(action==='execution')return await runExecutionPolicy(ctx);
  const runtime=await openComputerCapabilities(ctx);let capabilities;
  if(action==='request'){
   const full=ctx.opts.mode==='full';if(ctx.opts.mode&&!['full','custom'].includes(ctx.opts.mode))throw new Error('COMPUTER_MODE_INVALID');
   const selected=ctx.opts.capability||(full?['files.read','files.write','files.search','network','browser','desktop','channel.files','skills.update']:['files.read','files.write','files.search','network']),remoteActors=[],destinations=[];
   const fullRoots=full?(process.platform==='win32'?Array.from({length:26},(_,i)=>String.fromCharCode(65+i)+':\\').filter(root=>fs.existsSync(root)):['/']):[];
   if(ctx.opts.channel||ctx.opts.chat||ctx.opts.actor){const platform=platformId(ctx.opts.channel),configured=loadGateway(ctx.env).platforms[platform];if(!platform||!configured||!ctx.opts.chat||!ctx.opts.actor)throw new Error('COMPUTER_CHANNEL_SCOPE_REQUIRED');const destination={platform,bindingId:gatewayBindingId(configured),chatId:ctx.opts.chat};destinations.push(destination);remoteActors.push({...destination,actorId:ctx.opts.actor,capabilities:selected});}
   capabilities=await runtime.capabilities.request({capabilities:selected,roots:[...fullRoots,...(ctx.opts.root||[]),...(ctx.opts.home?[os.homedir()]:[])],destinations,remoteActors});
  }
  else if(action==='repair'){const repaired=await runtime.capabilities.repair({capability:ctx.opts.capability?.[0]||ctx.positionals[1]});ctx.stdout.write(JSON.stringify(repaired,null,ctx.opts.json?0:2)+'\n');return 0;}
  else capabilities=action==='revoke'?await runtime.capabilities.revoke():await runtime.capabilities.status();
  ctx.stdout.write(JSON.stringify({...runtime.metadata(),capabilities,execution:executionStatus({env:ctx.env,workspace:ctx.workspace()})},null,ctx.opts.json?0:2)+'\n');return 0;
 }finally{ownedPrompter?.close();}
}
