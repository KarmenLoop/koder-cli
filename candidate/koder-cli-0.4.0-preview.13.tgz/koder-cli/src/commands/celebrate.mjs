import {runCelebration} from '../celebrations.mjs';
export const flags={date:{type:'string'},confirm:{type:'string'},service:{type:'string'},country:{type:'string'},language:{type:'string'},ip:{type:'bool'},name:{type:'string'},animation:{type:'bool'}};
export const run=runCelebration;
