import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {cliHome} from './config.mjs';
import {KoderError} from './errors.mjs';

const HOSTS = new Set(['api.xiaomimimo.com', 'token-plan-cn.xiaomimimo.com', 'token-plan-sgp.xiaomimimo.com', 'token-plan-ams.xiaomimimo.com']);
export const MIMO_MODELS = ['mimo-v2.6-pro', 'mimo-v2.6-flash'];

export function isOfficialMiMo(record) {
  return HOSTS.has(new URL(record.baseUrl).hostname) && /^mimo-/i.test(record.model);
}

export function withMiMoPresets(presets) {
  return presets.flatMap(preset => {
    if (preset.id !== 'mimo') return [preset];
    const paid = {...preset, name:'小米 MiMo · 按量付费', contextWindow:1048576, models:[...MIMO_MODELS],
      detail:'按量付费 API，使用 sk- 密钥。Token Plan 套餐请选择另一项，不能混用密钥。'};
    return [paid, {...paid, id:'mimo-token-plan', name:'小米 MiMo · Token Plan 套餐',
      baseUrl:'https://token-plan-cn.xiaomimimo.com/v1',
      detail:'Token Plan 套餐，使用 tp- 或 ttp- 密钥；默认中国集群，可按控制台修改接入地址。',
      key:{url:'https://platform.xiaomimimo.com/#/token-plan', steps:['登录小米 MiMo 开放平台，打开 Token Plan 页面','复制套餐专属的 tp- 或 ttp- 密钥；按量付费密钥不能用于套餐接口','如控制台显示其他集群地址，在接口地址中填写该地址']}}];
  });
}

export function normalizeMiMo(record) {
  if (!isOfficialMiMo(record)) return record;
  const url = new URL(record.baseUrl), plan = url.hostname.startsWith('token-plan-');
  if ((!plan && /^(?:tp|ttp)-/.test(record.apiKey)) || (plan && /^sk-/.test(record.apiKey))) {
    throw new KoderError('model.mimoKeyMismatch', {plan:plan?'Token Plan':'pay-as-you-go'});
  }
  record.sendApiKeyHeader = true;
  if (record.protocol === 'anthropic') {
    if (!/\/anthropic(?:\/v1)?(?:\/messages)?\/?$/.test(url.pathname)) throw new KoderError('model.mimoProtocol');
    record.chatPath = /\/anthropic\/?$/.test(url.pathname) ? '/v1/messages' : '/messages';
  } else {
    if (/\/anthropic(?:\/|$)/.test(url.pathname)) throw new KoderError('model.mimoProtocol');
    record.spec = {compat:{maxTokensField:'max_completion_tokens'}};
  }
  return record;
}

// A Koder-managed profile keeps Hermes' unrelated model credentials and settings
// untouched. JSON is valid YAML. The secret exists only in the child environment.
export function hermesMiMoConfig(ctx, record) {
  if (!record || !isOfficialMiMo(record)) return null;
  if (!record.apiKey) throw new KoderError('model.badField',{field:'apiKey / keyEnv'});
  const base = new URL(record.baseUrl);
  base.pathname = '/v1'; base.search = ''; base.hash = '';
  const model = {provider:'custom', default:record.model, base_url:base.href.replace(/\/$/,''),
    key_env:'KODER_HERMES_MODEL_KEY', api_mode:'chat_completions', context_length:record.contextWindow};
  const hash = crypto.createHash('sha256').update(JSON.stringify(model)).digest('hex').slice(0,24);
  const home = path.join(cliHome(ctx.env), 'engines', 'hermes', 'mimo-'+hash);
  fs.mkdirSync(home, {recursive:true, mode:0o700});
  const file = path.join(home,'config.yaml');
  try { fs.writeFileSync(file,JSON.stringify({_config_version:12,model},null,2)+'\n',{mode:0o600,flag:'wx'}); }
  catch(error) { if(error.code!=='EEXIST')throw error; }
  let saved;
  try {
    if(!fs.lstatSync(file).isFile() || fs.lstatSync(file).isSymbolicLink())throw new Error();
    saved=JSON.parse(fs.readFileSync(file,'utf8')).model;
  }catch{throw new KoderError('model.hermesProfileChanged',{file});}
  if(!saved || saved.api_key || Object.entries(model).some(([key,value])=>saved[key]!==value))throw new KoderError('model.hermesProfileChanged',{file});
  return {modelId:'custom:'+record.model, env:{...ctx.env,HERMES_HOME:home,KODER_HERMES_MODEL_KEY:record.apiKey},
    redact:value=>String(value).split(record.apiKey).join('<REDACTED>')};
}
