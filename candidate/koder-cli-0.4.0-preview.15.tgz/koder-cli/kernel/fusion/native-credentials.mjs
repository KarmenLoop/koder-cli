import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';

const failed=code=>Object.assign(new Error(code),{code});
const MAX=262144;
const instances=new Map();
export function openMemoryCredentials({platform=process.platform,spawnImpl=spawn,dir,namespace='memory'}={}) {
 if(typeof dir!=='string')throw failed('MEMORY_CREDENTIALS_INVALID');
 if(!/^[a-z0-9-]{1,32}$/.test(namespace))throw failed('MEMORY_CREDENTIALS_INVALID');
 const key=platform+'\0'+namespace+'\0'+path.resolve(dir);if(instances.has(key))return instances.get(key);
 const service='com.koder.cli.'+namespace+'.'+crypto.createHash('sha256').update(path.resolve(dir)).digest('hex').slice(0,24);
 const file=path.join(dir,namespace+'-credentials.dpapi');
 let volatile=null,processOnly=!['darwin','win32','linux'].includes(platform),verified=false;
 const env=Object.fromEntries(['PATH','HOME','USERPROFILE','SystemRoot','SYSTEMROOT','WINDIR','ProgramFiles','PROGRAMFILES','DBUS_SESSION_BUS_ADDRESS','XDG_RUNTIME_DIR'].filter(k=>typeof process.env[k]==='string').map(k=>[k,process.env[k]]));
 if(platform==='win32'){
  const system=env.SystemRoot||env.SYSTEMROOT||'C:\\Windows',programFiles=env.ProgramFiles||env.PROGRAMFILES;
  env.PSModulePath=[path.win32.join(system,'System32/WindowsPowerShell/v1.0/Modules'),programFiles&&path.win32.join(programFiles,'WindowsPowerShell/Modules')].filter(Boolean).join(';');
 }
 const run=(cmd,args,input='')=>new Promise((resolve,reject)=>{
  let child,output='',done=false,timer;
  const finish=(e,result)=>{if(done)return;done=true;clearTimeout(timer);e?reject(failed('MEMORY_CREDENTIALS_UNAVAILABLE')):resolve(result);};
  try{child=spawnImpl(cmd,args,{stdio:['pipe','pipe','pipe'],env,windowsHide:true});}catch{return finish(true);}
  timer=setTimeout(()=>{child.kill();finish(true);},10000);
  child.on('error',()=>finish(true));child.stdin.on('error',()=>finish(true));child.stderr.on('data',()=>{});
  child.stdout.on('data',b=>{output+=b;if(Buffer.byteLength(output)>MAX){child.kill();finish(true);}});
  child.on('close',code=>finish(null,{code,output}));child.stdin.end(input);
 });
 const ps=script=>['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from("$ErrorActionPreference='Stop'; [Console]::InputEncoding=[Text.UTF8Encoding]::new($false); [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); Add-Type -AssemblyName System.Security; $s=[Console]::In.ReadLine(); if($null -eq $s){throw 'missing protected input'}; "+script,'utf16le').toString('base64')];
 const powershell=path.win32.join(env.SystemRoot||env.SYSTEMROOT||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const protect="[Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($s),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))";
 const unprotect="[Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($s.Trim()),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))";
 async function native(action,value) {
  let result;
  if(platform==='darwin') {
   const args=action==='write'?['-i']:action==='read'?['find-generic-password','-a','koder-cli','-s',service,'-w']:['delete-generic-password','-a','koder-cli','-s',service];
   const input=action==='write'?`add-generic-password -U -a koder-cli -s ${service} -w ${Buffer.from(value).toString('base64')}\n`:'';
   result=await run('/usr/bin/security',args,input);
   if(result.code===44&&action!=='write')return null;
   if(result.code!==0)throw failed('MEMORY_CREDENTIALS_UNAVAILABLE');
   return action==='read'?(result.output.trim()?Buffer.from(result.output.trim(),'base64').toString('utf8'):null):null;
  }
  if(platform==='win32') {
   if(action==='clear'){fs.rmSync(file,{force:true});return null;}
   if(action==='read') {
    if(!fs.existsSync(file))return null;
    const fd=fs.openSync(file,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));let encrypted;
    try{const stat=fs.fstatSync(fd);if(!stat.isFile()||stat.size>MAX)throw failed('MEMORY_CREDENTIALS_INVALID');encrypted=fs.readFileSync(fd,'utf8');}finally{fs.closeSync(fd);}
    result=await run(powershell,ps(unprotect),encrypted.trim()+'\n');
   } else {
    result=await run(powershell,ps(protect),value+'\n');
    if(result.code!==0||!result.output.trim())throw failed('MEMORY_CREDENTIALS_UNAVAILABLE');
    fs.mkdirSync(dir,{recursive:true,mode:0o700});if(fs.lstatSync(dir).isSymbolicLink())throw failed('MEMORY_CREDENTIALS_INVALID');
    const temp=file+'.'+crypto.randomUUID();try{fs.writeFileSync(temp,result.output.trim(),{flag:'wx',mode:0o600});fs.renameSync(temp,file);}finally{fs.rmSync(temp,{force:true});}
   }
   if(result.code!==0)throw failed('MEMORY_CREDENTIALS_UNAVAILABLE');return action==='read'?result.output.trim():null;
  }
  if(platform==='linux') {
   const args=action==='write'?['store','--label=KODER shared memory','service',service]:[action==='read'?'lookup':'clear','service',service];
   result=await run('secret-tool',args,action==='write'?value:'');
   if(action==='read'&&result.code===1&&!result.output)return null;
   if(result.code!==0)throw failed('MEMORY_CREDENTIALS_UNAVAILABLE');return action==='read'?result.output.trim():null;
  }
  return null;
 }
 const vault={
  async read(){if(processOnly)return volatile&&structuredClone(volatile);try{const raw=await native('read');if(!raw)return null;if(Buffer.byteLength(raw)>MAX)throw failed('MEMORY_CREDENTIALS_INVALID');const value=JSON.parse(raw);if(!value||typeof value!=='object'||Array.isArray(value))throw failed('MEMORY_CREDENTIALS_INVALID');verified=true;return value;}catch{throw failed('MEMORY_CREDENTIALS_UNAVAILABLE');}},
  async write(value){const raw=JSON.stringify(value);if(Buffer.byteLength(raw)>MAX)throw failed('MEMORY_CREDENTIALS_INVALID');if(!processOnly){try{await native('write',raw);verified=true;volatile=null;return;}catch{processOnly=true;}}volatile=JSON.parse(raw);},
  async clear(){volatile=null;if(!processOnly){try{await native('clear');}catch{throw failed('MEMORY_CREDENTIALS_CLEAR_FAILED');}}},
  availability(){return {mode:processOnly?'process-only':'protected',kind:processOnly?'process':platform==='darwin'?'keychain':platform==='win32'?'dpapi-current-user':'secret-service',nativeVerified:verified};},
 };
 instances.set(key,vault);return vault;
}
