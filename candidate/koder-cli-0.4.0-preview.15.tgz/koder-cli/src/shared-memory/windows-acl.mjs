import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
// Inspect native ACLs. Existing nonempty directories are never taken over.
const SCRIPT="\n$ErrorActionPreference='Stop'\n$root=$env:KODER_MEMORY_ACL_ROOT\n$item=Get-Item -LiteralPath $root -Force\nif (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'reparse root' }\n$me=[Security.Principal.WindowsIdentity]::GetCurrent().User\n$allowed=@($me.Value,'S-1-5-18','S-1-5-32-544')\nfunction IsPrivate($acl) {\n if ($allowed -notcontains $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value) { return $false }\n if (-not $acl.AreAccessRulesProtected) { return $false }\n $rules=$acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])\n foreach ($rule in $rules) {\n  if ($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and $allowed -notcontains $rule.IdentityReference.Value) { return $false }\n }\n return $true\n}\n$acl=Get-Acl -LiteralPath $root\nif ($allowed -notcontains $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value) { throw 'owner mismatch' }\nif (-not (IsPrivate $acl)) {\n if (@(Get-ChildItem -LiteralPath $root -Force).Count -ne 0) { throw 'existing directory is not private' }\n $next=[Security.AccessControl.DirectorySecurity]::new()\n $next.SetOwner($me)\n $next.SetAccessRuleProtection($true,$false)\n foreach ($sid in $allowed) {\n  $identity=[Security.Principal.SecurityIdentifier]::new($sid)\n  $rule=[Security.AccessControl.FileSystemAccessRule]::new($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')\n  $next.AddAccessRule($rule)\n }\n Set-Acl -LiteralPath $root -AclObject $next\n}\n$checked=Get-Acl -LiteralPath $root\nif (-not (IsPrivate $checked)) { throw 'ACL readback failed' }\n[Console]::Out.Write('{\"private\":true}')\n";

export function verifyWindowsMemoryAcl(root,{run=spawnSync,env=process.env}={}){
 if(process.platform!=='win32')return false;
 const before=fs.lstatSync(root);
 if(!before.isDirectory()||before.isSymbolicLink())return false;
 const system=env.SystemRoot||env.SYSTEMROOT;
 if(!system||!path.win32.isAbsolute(system))return false;
 const executable=path.join(system,'System32/WindowsPowerShell/v1.0/powershell.exe');
 const childEnv={...env,KODER_MEMORY_ACL_ROOT:root},modulePath=Object.keys(env).find(k=>k.toLowerCase()==='psmodulepath');
 for(const key of Object.keys(childEnv))if(key.toLowerCase()==='psmodulepath')delete childEnv[key];
 childEnv.PSModulePath=[path.join(system,'System32/WindowsPowerShell/v1.0/Modules'),env.ProgramFiles&&path.join(env.ProgramFiles,'WindowsPowerShell/Modules'),modulePath&&env[modulePath]].filter(Boolean).join(path.delimiter);
 const result=run(executable,['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand',Buffer.from(SCRIPT,'utf16le').toString('base64')],{env:childEnv,encoding:'utf8',windowsHide:true,timeout:10000,maxBuffer:8192});
 if(result.status!==0||result.error)return false;
 const after=fs.lstatSync(root);
 if(after.isSymbolicLink()||!after.isDirectory()||after.dev!==before.dev||after.ino!==before.ino)return false;
 try{return JSON.parse(result.stdout).private===true;}catch{return false;}
}

