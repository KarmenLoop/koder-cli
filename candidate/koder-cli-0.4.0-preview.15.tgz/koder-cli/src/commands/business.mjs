import {businessText,starText} from '../business.mjs';
export async function run(ctx){ctx.stdout.write((ctx.command==='star'?starText(ctx.lang):businessText(ctx.lang))+'\n');return 0;}
