// Official references are fetched lazily. No catalog, key or bulk cache is
// installed locally. Private collection queries never fall back to this port.
const ENDPOINT='https://karmenloop.com/api/koder-resources';
export function createRemoteResourcePort({fetchImpl=fetch}={}){
 async function request(action,args={},context={}){
  context.signal?.throwIfAborted();
  const limit=args.limit??(action==='search'?8:8000),offset=args.offset??0;
  if(action==='search'&&(typeof args.query!=='string'||!args.query.trim()||args.query.length>500))throw Error('RESOURCE_QUERY');
  if(action==='read'&&!/^[a-f0-9]{64}$/.test(args.id||''))throw Error('RESOURCE_ID');
  if(!Number.isSafeInteger(offset)||offset<0||offset>8000000||!Number.isSafeInteger(limit)||limit<1||limit>(action==='search'?20:12000))throw Error('RESOURCE_REQUEST');
  const payload=action==='status'?{action}:{action,...(action==='search'?{query:args.query}:{id:args.id}),offset,limit};
  try{
   const signal=context.signal?AbortSignal.any([context.signal,AbortSignal.timeout(20000)]):AbortSignal.timeout(20000);
   const response=await fetchImpl(ENDPOINT,{method:'POST',redirect:'error',signal,headers:{'content-type':'application/json','accept':'application/json'},body:JSON.stringify(payload)});
   if(!response.ok||!response.headers.get('content-type')?.includes('application/json'))throw Error('RESOURCE_UNAVAILABLE');
   const reader=response.body.getReader(),chunks=[];let size=0;
   try{for(;;){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>256*1024)throw Error('RESOURCE_LIMIT');chunks.push(r.value);}}finally{await reader.cancel().catch(()=>{});}
   const bytes=new Uint8Array(size);let at=0;for(const b of chunks){bytes.set(b,at);at+=b.length;}const result=JSON.parse(new TextDecoder().decode(bytes));
   if(!result||result.available!==true||action==='search'&&(!Array.isArray(result.items)||result.items.length>limit)||action==='read'&&(result.id!==args.id||typeof result.content!=='string'||result.content.length>limit))throw Error('RESOURCE_PROTOCOL');
   return result;
  }catch(error){context.signal?.throwIfAborted();return {available:false,error:'RESOURCE_UNAVAILABLE',notice:'The official reference service is unavailable. Continue the task with other available tools; do not claim a reference was read.'};}
 }
 return {search:(args,ctx)=>request('search',args,ctx),read:(args,ctx)=>request('read',args,ctx),status:ctx=>request('status',{},ctx)};
}
