import {OFFICIAL} from './official.mjs';
export const REPOSITORY='https://github.com/KarmenLoop/koder-cli';
export function starText(lang='zh'){return lang==='en'?`Find Koder useful? A GitHub star helps others discover it: ${REPOSITORY}\nStars are optional. Skip this freely; every licensed feature works without one.`:`如果 Koder 帮到了你，欢迎在 GitHub 点一颗 Star：${REPOSITORY}\n点星完全自愿，直接跳过即可，不影响任何已获许可的功能。`;}
export function businessText(lang='zh'){
 return lang==='en'?[
  'KARMEN LOOP · Commercial licensing and private delivery',
  'Personal, noncommercial use of the new proprietary build is free. Commercial use and organizational deployment require separate written authorization. The personal license does not permit secondary development or changes to proprietary implementation code.',
  'Company licensing and a dedicated private repository are available by inquiry. Agree on authorized users, deployment scope, repository contents, access, updates, support and any development rights in a written agreement before delivery. A private repository does not itself grant source or modification rights.',
  `Contact: ${OFFICIAL.email}`,
  'Subject: Koder commercial licensing / dedicated private repository',
  'Include your organization, intended use, approximate user count, deployment needs and whether you need a private repository. Do not include keys or confidential documents.',
  'This command does not send email, open a browser, create a repository, place an order or grant a commercial license. Third-party components and earlier versions retain their own licenses.',
 ].join('\n'):[
  'KARMEN LOOP · 商业授权与私有交付',
  '新专有发行版可免费用于个人非商业用途。商用与组织内部部署须另获书面授权；个人许可不包含二次开发或修改自有实现代码。',
  '公司授权服务＋专用私有仓库可通过邮件洽询。交付前书面约定人数、部署范围、仓库内容、访问人员、更新维护、支持及是否另授开发权。拥有私有仓库本身不代表获得源码或修改权。',
  `联系邮箱：${OFFICIAL.email}`,
  '邮件主题：Koder 商业授权／专用私有仓库',
  '可填写公司名称、使用场景、预计人数、部署方式及私有仓库需求；不要发送密钥或保密文件。',
  '此命令不发送邮件、打开浏览器、创建仓库、下单或自动授予商用许可。第三方组件和旧版本仍按各自许可证使用。',
 ].join('\n');
}
